﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Words.NET.WordsLicense
// Assembly: Xceed.Words.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: E7E4AD43-EEB5-447C-A4A6-061F1929B7FE
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Words.NETStandard.dll

using System;
using Xceed.Utils.Exceptions;
using Xceed.Utils.Licensing;

namespace Xceed.Words.NET
{
  internal class WordsLicense : XceedLicense
  {
    public static XceedLicense CreateLicense(string licenseKey, Type licenserType)
    {
      XceedLicense xceedLicense = (XceedLicense) new WordsLicense();
      xceedLicense.Initialize(licenseKey, licenserType);
      return xceedLicense.LicenseKey == null || xceedLicense.LicenseKey.Length == 0 ? (XceedLicense) null : xceedLicense;
    }

    private WordsLicense()
    {
    }

    protected override void ThrowNoKeyInCodeAndRegistry() => ThrowException.ThrowLicenseException(this.LicenseeType, (object) null, this.LicenseeType.FullName + ".LicenseKey property must be set to a valid license key in the code of your application before using this product. Please refer to the Licensing topic in the documentation for more information on this exception.");

    protected override void ThrowKeyInvalid() => ThrowException.ThrowLicenseException(this.LicenseeType, (object) null, "The license key used to license this Xceed product is invalid. " + this.LicenseeType.FullName + ".LicenseKey must be set to a valid license key before using this product. Please refer to the Licensing topic in the documentation for specific instructions on how to avoid this exception.");

    protected override void ThrowKeyInvalidProductVersion() => ThrowException.ThrowLicenseException(this.LicenseeType, (object) null, "License key version too old, it does not qualify to unlock this version of Xceed Words for .NET. Please upgrade your license to benefit from the latest bug fixes and/or features.");

    protected override void ThrowTrialKeyExpired() => ThrowException.ThrowLicenseException(this.LicenseeType, (object) null, "You did not unlock this control with a license key, therefore you have been using Xceed Words for .NET in trial mode which has expired. You must now set the " + this.LicenseeType.FullName + ".LicenseKey property with a valid license key. Please refer to the Licensing topic in the documentation for more information on this exception.");

    protected override XceedLicense.ProductVersion[] AllowedVersions
    {
      get
      {
        XceedLicense.VersionNumber versionNumber = new XceedLicense.VersionNumber("1.7");
        return new XceedLicense.ProductVersion[1]
        {
          new XceedLicense.ProductVersion(LicenseProduct.XceedWordsNET, versionNumber, versionNumber)
        };
      }
    }

    protected override Type LicenseeType => typeof (Licenser);
  }
}
