﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Xceed Words for .NET")]
[assembly: AssemblyDescription("This assembly implements the classes for Xceed Words for .NET.")]
[assembly: AssemblyCompany("Xceed Software Inc.")]
[assembly: AssemblyProduct("Xceed Words for .NET")]
[assembly: AssemblyCopyright("Copyright (C) Xceed Software Inc. 2009-2020")]
[assembly: AssemblyConfiguration("Retail")]
[assembly: ComVisible(false)]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("..\\SolutionItems\\Xceed.snk")]
[assembly: AssemblyKeyName("")]
[assembly: AssemblyVersion("1.7.20371.21580")]
