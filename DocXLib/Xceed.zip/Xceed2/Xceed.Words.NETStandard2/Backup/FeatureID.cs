﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Words.NET.FeatureID
// Assembly: Xceed.Words.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: E7E4AD43-EEB5-447C-A4A6-061F1929B7FE
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Words.NETStandard.dll

namespace Xceed.Words.NET
{
  internal enum FeatureID
  {
    NoFeatureSpecified,
  }
}
