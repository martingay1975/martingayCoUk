﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Words.NET.DocX
// Assembly: Xceed.Words.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: E7E4AD43-EEB5-447C-A4A6-061F1929B7FE
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Words.NETStandard.dll

using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Packaging;
using System.Xml.Linq;
using Xceed.Document.NET;

namespace Xceed.Words.NET
{
  /// <summary>Represents a DocX document.</summary>
  public class DocX : Xceed.Document.NET.Document
  {
    internal DocX(Xceed.Document.NET.Document document, XElement xml)
      : base(document, xml)
    {
    }

    /// <summary>Creates a DocX Document using a Stream.</summary>
    /// <returns>A DocX object which represents the document.</returns>
    /// <param name="stream">The Stream to create the document from.</param>
    public static DocX Create(Stream stream, DocumentTypes documentType = DocumentTypes.Document)
    {
      Xceed.Document.NET.Document document = (Xceed.Document.NET.Document) new DocX((Xceed.Document.NET.Document) null, (XElement) null);
      Xceed.Document.NET.Document.PrepareDocument(ref document, documentType);
      document._stream = stream;
      return document as DocX;
    }

    /// <summary>Creates a DocX Document using a fully qualified or relative filename.</summary>
    /// <returns>A <strong>DocX</strong> object which represents the document.</returns>
    /// <param name="filename">The fully qualified or relative filename.</param>
    public static DocX Create(string filename, DocumentTypes documentType = DocumentTypes.Document)
    {
      Xceed.Document.NET.Document document = (Xceed.Document.NET.Document) new DocX((Xceed.Document.NET.Document) null, (XElement) null);
      Xceed.Document.NET.Document.PrepareDocument(ref document, documentType);
      document._filename = filename;
      return document as DocX;
    }

    /// <summary>Loads a document into a DocX object using a Stream.</summary>
    /// <returns>A DocX object which represents the document.</returns>
    /// <param name="stream">The Stream to load the document from.</param>
    public static DocX Load(Stream stream)
    {
      Xceed.Document.NET.Document document = (Xceed.Document.NET.Document) new DocX((Xceed.Document.NET.Document) null, (XElement) null);
      return Xceed.Document.NET.Document.Load(stream, document, DocumentTypes.Document) as DocX;
    }

    /// <summary>Loads a document into a DocX object using a fully qualified or relative filename.</summary>
    /// <returns>A DocX object which represents the document.</returns>
    /// <param name="filename">The fully qualified or relative filename.</param>
    public static DocX Load(string filename)
    {
      Xceed.Document.NET.Document document = (Xceed.Document.NET.Document) new DocX((Xceed.Document.NET.Document) null, (XElement) null);
      return Xceed.Document.NET.Document.Load(filename, document, DocumentTypes.Document) as DocX;
    }

    public static void ConvertToPdf(
      Xceed.Document.NET.Document fileToConvert,
      string outputFileName,
      List<PdfExternalFont> externalFonts = null)
    {
      Xceed.Document.NET.Document.ConvertToPdfInternal(fileToConvert, outputFileName, externalFonts);
    }

    public static void ConvertToPdf(
      Xceed.Document.NET.Document fileToConvert,
      Stream outputStream,
      List<PdfExternalFont> externalFonts = null)
    {
      Xceed.Document.NET.Document.ConvertToPdfInternal(fileToConvert, outputStream, externalFonts);
    }

    public override void SaveAs(Stream stream)
    {
      if (this.IsPackageClosed(this._package))
        (this._stream.Length > 0L ? (Xceed.Document.NET.Document) DocX.Load(this._stream) : (Xceed.Document.NET.Document) DocX.Load(this._filename)).SaveAs(stream);
      else
        base.SaveAs(stream);
    }

    public override void SaveAs(string filename)
    {
      if (this.IsPackageClosed(this._package))
        (!string.IsNullOrEmpty(this._filename) ? (Xceed.Document.NET.Document) DocX.Load(this._filename) : (Xceed.Document.NET.Document) DocX.Load(this._stream)).SaveAs(filename);
      else
        base.SaveAs(filename);
    }

    /// <summary>Saves this document.</summary>
    public override void Save()
    {
      if (this.IsPackageClosed(this._package))
      {
        (!string.IsNullOrEmpty(this._filename) ? (Xceed.Document.NET.Document) DocX.Load(this._filename) : (Xceed.Document.NET.Document) DocX.Load(this._stream)).Save();
      }
      else
      {
        using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(this.PackagePart.GetStream(FileMode.Create, FileAccess.Write))))
          this._mainDoc.Save(textWriter, SaveOptions.None);
        if (this._settings == null || !this.isProtected)
        {
          using (TextReader textReader = (TextReader) new StreamReader(this._settingsPart.GetStream()))
            this._settings = XDocument.Load(textReader);
        }
        this.SaveHeadersFooters();
        using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(this._settingsPart.GetStream(FileMode.Create, FileAccess.Write))))
          this._settings.Save(textWriter, SaveOptions.None);
        if (this._endnotesPart != null)
        {
          using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(this._endnotesPart.GetStream(FileMode.Create, FileAccess.Write))))
            this._endnotes.Save(textWriter, SaveOptions.None);
        }
        if (this._footnotesPart != null)
        {
          using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(this._footnotesPart.GetStream(FileMode.Create, FileAccess.Write))))
            this._footnotes.Save(textWriter, SaveOptions.None);
        }
        if (this._stylesPart != null)
        {
          using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(this._stylesPart.GetStream(FileMode.Create, FileAccess.Write))))
            this._styles.Save(textWriter, SaveOptions.None);
        }
        if (this._stylesWithEffectsPart != null)
        {
          using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(this._stylesWithEffectsPart.GetStream(FileMode.Create, FileAccess.Write))))
            this._stylesWithEffects.Save(textWriter, SaveOptions.None);
        }
        if (this._numberingPart != null)
        {
          using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(this._numberingPart.GetStream(FileMode.Create, FileAccess.Write))))
            this._numbering.Save(textWriter, SaveOptions.None);
        }
        if (this._fontTablePart != null)
        {
          using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(this._fontTablePart.GetStream(FileMode.Create, FileAccess.Write))))
            this._fontTable.Save(textWriter, SaveOptions.None);
        }
        this._package.Close();
        if (this._filename != null)
        {
          using (FileStream fileStream = new FileStream(this._filename.EndsWith(".docx") || this._filename.EndsWith(".doc") ? this._filename : this._filename + ".docx", FileMode.Create))
          {
            if (this._memoryStream.CanSeek)
            {
              this._memoryStream.Position = 0L;
              HelperFunctions.CopyStream((Stream) this._memoryStream, (Stream) fileStream);
            }
            else
              fileStream.Write(this._memoryStream.ToArray(), 0, (int) this._memoryStream.Length);
          }
        }
        else
        {
          if (!this._stream.CanSeek)
            return;
          this._stream.SetLength(0L);
          this._stream.Position = 0L;
          this._memoryStream.WriteTo(this._stream);
          this._memoryStream.Flush();
        }
      }
    }

    /// <summary>Copies the document into a new Document.</summary>
    /// <returns>A copy of the Document.</returns>
    public override Xceed.Document.NET.Document Copy()
    {
      try
      {
        DocX docX = this;
        if (this.IsPackageClosed(this._package))
          docX = !string.IsNullOrEmpty(this._filename) ? DocX.Load(this._filename) : DocX.Load(this._stream);
        MemoryStream memoryStream = new MemoryStream();
        docX.SaveAs((Stream) memoryStream);
        memoryStream.Seek(0L, SeekOrigin.Begin);
        return (Xceed.Document.NET.Document) DocX.Load((Stream) memoryStream);
      }
      catch (Exception ex)
      {
        return (Xceed.Document.NET.Document) this;
      }
    }

    protected internal override void SaveHeadersFooters()
    {
      foreach (Section section in (IEnumerable<Section>) this.Sections)
      {
        Headers headers = section.Headers;
        Footers footers = section.Footers;
        if (headers.Even != null)
        {
          using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(this._package.GetPart(PackUriHelper.ResolvePartUri(this.PackagePart.Uri, this.PackagePart.GetRelationship(headers.Even.Id).TargetUri)).GetStream(FileMode.Create, FileAccess.Write))))
            new XDocument(new XDeclaration("1.0", "UTF-8", "yes"), new object[1]
            {
              (object) headers.Even.Xml
            }).Save(textWriter, SaveOptions.None);
        }
        if (headers.Odd != null)
        {
          using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(this._package.GetPart(PackUriHelper.ResolvePartUri(this.PackagePart.Uri, this.PackagePart.GetRelationship(headers.Odd.Id).TargetUri)).GetStream(FileMode.Create, FileAccess.Write))))
            new XDocument(new XDeclaration("1.0", "UTF-8", "yes"), new object[1]
            {
              (object) headers.Odd.Xml
            }).Save(textWriter, SaveOptions.None);
        }
        if (headers.First != null)
        {
          using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(this._package.GetPart(PackUriHelper.ResolvePartUri(this.PackagePart.Uri, this.PackagePart.GetRelationship(headers.First.Id).TargetUri)).GetStream(FileMode.Create, FileAccess.Write))))
            new XDocument(new XDeclaration("1.0", "UTF-8", "yes"), new object[1]
            {
              (object) headers.First.Xml
            }).Save(textWriter, SaveOptions.None);
        }
        if (footers.Odd != null)
        {
          using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(this._package.GetPart(PackUriHelper.ResolvePartUri(this.PackagePart.Uri, this.PackagePart.GetRelationship(footers.Odd.Id).TargetUri)).GetStream(FileMode.Create, FileAccess.Write))))
            new XDocument(new XDeclaration("1.0", "UTF-8", "yes"), new object[1]
            {
              (object) footers.Odd.Xml
            }).Save(textWriter, SaveOptions.None);
        }
        if (footers.Even != null)
        {
          using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(this._package.GetPart(PackUriHelper.ResolvePartUri(this.PackagePart.Uri, this.PackagePart.GetRelationship(footers.Even.Id).TargetUri)).GetStream(FileMode.Create, FileAccess.Write))))
            new XDocument(new XDeclaration("1.0", "UTF-8", "yes"), new object[1]
            {
              (object) footers.Even.Xml
            }).Save(textWriter, SaveOptions.None);
        }
        if (footers.First != null)
        {
          using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(this._package.GetPart(PackUriHelper.ResolvePartUri(this.PackagePart.Uri, this.PackagePart.GetRelationship(footers.First.Id).TargetUri)).GetStream(FileMode.Create, FileAccess.Write))))
            new XDocument(new XDeclaration("1.0", "UTF-8", "yes"), new object[1]
            {
              (object) footers.First.Xml
            }).Save(textWriter, SaveOptions.None);
        }
      }
    }

    private bool IsPackageClosed(Package package)
    {
      if (package == null)
        return true;
      try
      {
        int fileOpenAccess = (int) package.FileOpenAccess;
      }
      catch (Exception ex)
      {
        return true;
      }
      return false;
    }
  }
}
