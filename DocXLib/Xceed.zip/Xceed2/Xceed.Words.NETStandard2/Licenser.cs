﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Words.NET.Licenser
// Assembly: Xceed.Words.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: E7E4AD43-EEB5-447C-A4A6-061F1929B7FE
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Words.NETStandard.dll

using System;
using Xceed.Utils.Exceptions;
using Xceed.Utils.Licensing;

namespace Xceed.Words.NET
{
//  /// <summary>Represents the class that registers the classes defined in the Xceed.Words.NET assembly.</summary>
//  public static class Licenser
//  {
//    //private static XceedLicense _license;
//    private static bool m_fullyUnlock;
//    private static string _licenseKey = string.Empty;

//    /// <summary>Gets or sets the license key used to license this product.</summary>
//    public static string LicenseKey
//    {
//      get => Licenser._licenseKey;
//      set
//      {
//        if (value == null)
//          throw new ArgumentNullException(nameof (LicenseKey));
//        if (Licenser._license != null && Licenser._license.IsFromRegistry)
//          ThrowException.ThrowLicenseException((Type) null, (object) null, typeof (Licenser).FullName + ".LicenseKey must be set to a valid license key in your code before the product is used.  Please refer to the Licensing topic in the documentation for specific instructions on how to avoid this exception.");
//        Licenser._license = WordsLicense.CreateLicense(value, typeof (Licenser));
//        Licenser._licenseKey = value;
//        Xceed.Document.NET.Licenser.LicenseKey = value;
//      }
//    }

//    internal static void Unlock()
//    {
//      Licenser.m_fullyUnlock = true;
//      Xceed.Document.NET.Licenser.Unlock();
//    }

//    internal static void VerifyLicense()
//    {
//      if (Licenser.m_fullyUnlock || Licenser._license != null)
//        return;
//      Licenser._license = WordsLicense.CreateLicense(string.Empty, typeof (Licenser));
//    }

//    internal static void VerifyLicense(FeatureID featureId)
//    {
//      if (Licenser.m_fullyUnlock)
//        return;
//      Licenser.VerifyLicense();
//    }

//    internal static void VerifyLicenseDesignMode()
//    {
//      if (Licenser._license != null)
//        return;
//      try
//      {
//        Licenser.VerifyLicense();
//      }
//      catch
//      {
//      }
//    }

//    internal static void VerifyLicenseDesignMode(FeatureID featureID)
//    {
//      try
//      {
//        Licenser.VerifyLicense(featureID);
//      }
//      catch
//      {
//      }
//    }

//    internal static XceedLicense License => Licenser._license;
//  }
}
