﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

//[assembly: Extension]
[assembly: AssemblyTitle("Xceed Document for .NET")]
[assembly: AssemblyDescription("This assembly implements the classes for Xceed Document for .NET Standard.")]
[assembly: AssemblyCompany("Xceed Software Inc.")]
[assembly: AssemblyProduct("Xceed Document for .NET Standard")]
[assembly: AssemblyCopyright("Copyright (C) Xceed Software Inc. 2009-2020")]
[assembly: AssemblyConfiguration("Retail")]
[assembly: ComVisible(false)]
[assembly: InternalsVisibleTo("Xceed.Words.NET")]
[assembly: InternalsVisibleTo("Xceed.Words.NETStandard")]
[assembly: InternalsVisibleTo("Xceed.PdfCreator.NET")]
[assembly: InternalsVisibleTo("Xceed.PdfCreator.NETStandard")]
[assembly: AssemblyKeyName("")]
[assembly: AssemblyVersion("1.7.20371.21580")]
