﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Border
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System.Drawing;

namespace Xceed.Document.NET
{
  /// <summary>Represents a Border of a Table or <see cref="Xceed.Document.NET~Xceed.Document.NET.Cell.html">Cell</see>.</summary>
  public class Border
  {
    /// <summary>Gets or sets the Style of this Border.</summary>
    public BorderStyle Tcbs { get; set; }

    /// <summary>Gets or sets the Size of this Border.</summary>
    public BorderSize Size { get; set; }

    /// <summary>Gets or sets the Space of this Border (in points).</summary>
    public float Space { get; set; }

    /// <summary>Gets or sets the Color of this Border.</summary>
    public Color Color { get; set; }

    /// <summary>Initializes a new instance of the <strong>Border</strong> class.</summary>
    public Border()
    {
      //Licenser.VerifyLicense();
      this.Tcbs = BorderStyle.Tcbs_single;
      this.Size = BorderSize.one;
      this.Space = 0.0f;
      this.Color = Color.Black;
    }

    public Border(BorderStyle tcbs, BorderSize size, float space, Color color)
    {
      Licenser.VerifyLicense();
      this.Tcbs = tcbs;
      this.Size = size;
      this.Space = space;
      this.Color = color;
    }

    internal static string GetNumericSize(BorderSize borderSize)
    {
      string str;
      switch (borderSize)
      {
        case BorderSize.two:
          str = "4";
          break;
        case BorderSize.three:
          str = "6";
          break;
        case BorderSize.four:
          str = "8";
          break;
        case BorderSize.five:
          str = "12";
          break;
        case BorderSize.six:
          str = "18";
          break;
        case BorderSize.seven:
          str = "24";
          break;
        case BorderSize.eight:
          str = "36";
          break;
        case BorderSize.nine:
          str = "48";
          break;
        default:
          str = "2";
          break;
      }
      return str;
    }
  }
}
