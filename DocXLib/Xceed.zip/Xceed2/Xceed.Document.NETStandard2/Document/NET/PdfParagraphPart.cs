﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfParagraphPart
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace Xceed.Document.NET
{
    internal class PdfParagraphPart
    {
        internal PdfParagraph _pdfParagraph;

        internal PdfParagraphPart(PdfParagraph p) => this._pdfParagraph = p != null ? p : throw new ArgumentNullException(nameof(p));

        internal virtual void UpdateText(Xceed.Pdf.Layout.Text.Text text, bool isMeasuring = false)
        {
        }

        internal static string ConvertIntToRoman(int number, bool isCapital)
        {
            if (number < 0 || number > 399)
                throw new ArgumentOutOfRangeException("Value must be between 1 and 399");
            if (number < 1)
                return string.Empty;
            if (number >= 100)
                return (isCapital ? "C" : "c") + PdfParagraphPart.ConvertIntToRoman(number - 100, isCapital);
            if (number >= 90)
                return (isCapital ? "XC" : "xc") + PdfParagraphPart.ConvertIntToRoman(number - 90, isCapital);
            if (number >= 50)
                return (isCapital ? "L" : "l") + PdfParagraphPart.ConvertIntToRoman(number - 50, isCapital);
            if (number >= 40)
                return (isCapital ? "XL" : "xl") + PdfParagraphPart.ConvertIntToRoman(number - 40, isCapital);
            if (number >= 10)
                return (isCapital ? "X" : "x") + PdfParagraphPart.ConvertIntToRoman(number - 10, isCapital);
            if (number >= 9)
                return (isCapital ? "IX" : "ix") + PdfParagraphPart.ConvertIntToRoman(number - 9, isCapital);
            if (number >= 5)
                return (isCapital ? "V" : "v") + PdfParagraphPart.ConvertIntToRoman(number - 5, isCapital);
            if (number >= 4)
                return (isCapital ? "IV" : "iv") + PdfParagraphPart.ConvertIntToRoman(number - 4, isCapital);
            if (number >= 1)
                return (isCapital ? "I" : "i") + PdfParagraphPart.ConvertIntToRoman(number - 1, isCapital);
            throw new ArgumentOutOfRangeException("Value must be between 1 and 399");
        }

        internal string ConvertTextDigitToRoman(string text, bool isCapital)
        {
            string str = new string(text.Where<char>((Func<char, bool>)(c => char.IsDigit(c))).ToArray<char>());
            string roman = PdfParagraphPart.ConvertIntToRoman(int.Parse(str), isCapital);
            return text.Replace(str, roman);
        }

        internal string ConvertTextDigitToLetter(string text, bool isCapital)
        {
            string str = new string(text.Where<char>((Func<char, bool>)(c => char.IsDigit(c))).ToArray<char>());
            char ch = (char)((int.Parse(str) - 1) % 26 + (isCapital ? 65 : 97));
            return text.Replace(str, ch.ToString());
        }

        internal static RectangleF GetPdfParagraphPartDimensions(
          Section currentSection,
          PdfPageInfo currentPdfPageInfo,
          DocumentElement element,
          float paragraphHeight = 0.0f)
        {
            if (currentSection == null)
                throw new ArgumentNullException(nameof(currentSection));
            if (currentPdfPageInfo == null)
                throw new ArgumentNullException(nameof(currentPdfPageInfo));
            switch (element)
            {
                case null:
                    throw new ArgumentNullException(nameof(element));
                case Picture _:
                    return PdfPicture.GetDimensions(currentSection, currentPdfPageInfo, element as Picture);
                case Shape _:
                    return PdfShape.GetDimensions(currentSection, currentPdfPageInfo, element as Shape);
                case Table _:
                    return PdfTable.GetTableDimensions(currentSection, currentPdfPageInfo, element as Table, paragraphHeight);
                default:
                    return RectangleF.Empty;
            }
        }

        internal static bool IsWrappedObjectRelativeFromPageInY(DocumentElement element)
        {
            switch (element)
            {
                case null:
                    throw new ArgumentNullException(nameof(element));
                case Picture _:
                case Shape _:
                    return PdfUtils.IsRelativeFromPageInY(element);
                case Table _:
                    return PdfTable.IsTableRelativeFromPageInY(element as Table);
                default:
                    return false;
            }
        }

        internal static PointF GetHorizontalMargins(DocumentElement element)
        {
            switch (element)
            {
                case null:
                    throw new ArgumentNullException(nameof(element));
                case Picture _:
                case Shape _:
                    return PdfUtils.GetHorizontalMargins(element);
                case Table _:
                    return PdfTable.GetHorizontalMargins(element as Table);
                default:
                    return new PointF();
            }
        }

        internal static PointF GetVerticalMargins(DocumentElement element)
        {
            switch (element)
            {
                case null:
                    throw new ArgumentNullException(nameof(element));
                case Picture _:
                case Shape _:
                    return PdfUtils.GetVerticalMargins(element);
                case Table _:
                    return PdfTable.GetVerticalMargins(element as Table);
                default:
                    return new PointF();
            }
        }

        internal static List<Tuple<bool, RectangleF>> CreateBlockedRegions(
          Section currentSection,
          IList wrappedObjectInfoList)
        {
            throw new NullReferenceException(nameof(currentSection));
            //  if (currentSection == null)
            //    throw new NullReferenceException(nameof (currentSection));
            //  List<PdfWrappedObjectInfo> wrappedObjectInfoList1 = wrappedObjectInfoList != null ? wrappedObjectInfoList as List<PdfWrappedObjectInfo> : throw new NullReferenceException(nameof (wrappedObjectInfoList));
            //  List<Tuple<bool, RectangleF>> tupleList = new List<Tuple<bool, RectangleF>>();
            //  foreach (PdfWrappedObjectInfo wrappedObjectInfo in wrappedObjectInfoList1)
            //  {
            //    if (wrappedObjectInfo.WrappingType != WrappingType.WrapBehindText && wrappedObjectInfo.WrappingType != WrappingType.WrapInFrontOfText)
            //    {
            //      RectangleF dimension;
            //      PointF pointF;
            //      Tuple<bool, RectangleF> tuple;
            //      if (wrappedObjectInfo.WrappingType == WrappingType.WrapTopAndBottom)
            //      {
            //        RectangleF rectangleF1;
            //        ref RectangleF local1 = ref rectangleF1;
            //        double num1 = (double) currentSection.MarginLeft - 1.0;
            //        dimension = wrappedObjectInfo.Dimension;
            //        double y1 = (double) dimension.Y;
            //        double num2 = (double) currentSection.PageWidth - (double) currentSection.MarginRight - (double) currentSection.MarginLeft + 2.0;
            //        dimension = wrappedObjectInfo.Dimension;
            //        double height1 = (double) dimension.Height;
            //        local1 = new RectangleF((float) num1, (float) y1, (float) num2, (float) height1);
            //        if (rectangleF1.IntersectsWith(wrappedObjectInfo.Dimension))
            //        {
            //          RectangleF rectangleF2;
            //          ref RectangleF local2 = ref rectangleF2;
            //          double marginLeft = (double) currentSection.MarginLeft;
            //          dimension = wrappedObjectInfo.Dimension;
            //          double y2 = (double) dimension.Y;
            //          pointF = wrappedObjectInfo.MarginV;
            //          double x1 = (double) pointF.X;
            //          double num3 = y2 - x1;
            //          double num4 = (double) currentSection.PageWidth - (double) currentSection.MarginLeft - (double) currentSection.MarginRight;
            //          dimension = wrappedObjectInfo.Dimension;
            //          double height2 = (double) dimension.Height;
            //          pointF = wrappedObjectInfo.MarginV;
            //          double x2 = (double) pointF.X;
            //          double num5 = height2 + x2;
            //          pointF = wrappedObjectInfo.MarginV;
            //          double y3 = (double) pointF.Y;
            //          double num6 = num5 + y3;
            //          local2 = new RectangleF((float) marginLeft, (float) num3, (float) num4, (float) num6);
            //          tuple = new Tuple<bool, RectangleF>(true, rectangleF2);
            //        }
            //        else
            //          continue;
            //      }
            //      else
            //      {
            //        RectangleF rectangleF;
            //        ref RectangleF local = ref rectangleF;
            //        dimension = wrappedObjectInfo.Dimension;
            //        double x1 = (double) dimension.X;
            //        pointF = wrappedObjectInfo.MarginH;
            //        double x2 = (double) pointF.X;
            //        double num1 = x1 - x2;
            //        dimension = wrappedObjectInfo.Dimension;
            //        double y1 = (double) dimension.Y;
            //        pointF = wrappedObjectInfo.MarginV;
            //        double x3 = (double) pointF.X;
            //        double num2 = y1 - x3;
            //        dimension = wrappedObjectInfo.Dimension;
            //        double width = (double) dimension.Width;
            //        pointF = wrappedObjectInfo.MarginH;
            //        double x4 = (double) pointF.X;
            //        double num3 = width + x4;
            //        pointF = wrappedObjectInfo.MarginH;
            //        double y2 = (double) pointF.Y;
            //        double num4 = num3 + y2;
            //        dimension = wrappedObjectInfo.Dimension;
            //        double height = (double) dimension.Height;
            //        pointF = wrappedObjectInfo.MarginV;
            //        double x5 = (double) pointF.X;
            //        double num5 = height + x5;
            //        pointF = wrappedObjectInfo.MarginV;
            //        double y3 = (double) pointF.Y;
            //        double num6 = num5 + y3;
            //        local = new RectangleF((float) num1, (float) num2, (float) num4, (float) num6);
            //        tuple = new Tuple<bool, RectangleF>(false, rectangleF);
            //      }
            //      tupleList.Add(tuple);
            //    }
            //  }
            //  return tupleList;
            //}
        }
    }
}
