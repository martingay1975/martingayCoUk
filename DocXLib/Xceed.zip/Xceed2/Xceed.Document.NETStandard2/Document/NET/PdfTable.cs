﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfTable
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO.Packaging;
using System.Linq;
using System.Xml.Linq;
using Xceed.Pdf;
using Xceed.Pdf.Layout.Table;
using Xceed.Pdf.Layout.Text.Atoms;
using Xceed.Pdf.Layout.Text.Blocks;

namespace Xceed.Document.NET
{
  internal class PdfTable : PdfParagraphPart
  {
    private Xceed.Pdf.Graphics _graphics;
    private Xceed.Pdf.Layout.Border _insideHPdfBorder;
    private Xceed.Pdf.Layout.Border _insideVPdfBorder;
    private Xceed.Document.NET.Document _fileToConvert;
    private Xceed.Document.NET.Table _table;
    private int _pageNumber;

    internal PdfTable(PdfParagraph p, Xceed.Document.NET.Table table, Xceed.Pdf.Graphics graphics, int pageNumber)
      : base(p)
    {
      if (table == null)
        throw new ArgumentNullException(nameof (table));
      if (graphics == null)
        throw new ArgumentNullException(nameof (graphics));
      this._table = table;
      this._graphics = graphics;
      this._fileToConvert = this._pdfParagraph.GetFileToConvert();
      this._pageNumber = pageNumber;
    }

    internal Xceed.Pdf.Layout.Table.Table Table { get; private set; }

    internal override void UpdateText(Xceed.Pdf.Layout.Text.Text text, bool isMeasuring = false)
    {
      this.Table = new Xceed.Pdf.Layout.Table.Table();
      Section currentSection = this._pdfParagraph.GetCurrentSection();
      this.UpdateTextCore(this.Table, currentSection.MarginLeft, currentSection.MarginRight, currentSection.PageWidth, isMeasuring);
    }

    internal static bool IsTableWrappingAround(Xceed.Document.NET.Table table)
    {
      if (table == null)
        throw new ArgumentNullException(nameof (table));
      return PdfTable.GetTablePositionningElement(table) != null;
    }

    internal static RectangleF GetTableDimensions(
      Section currentSection,
      PdfPageInfo currentPdfPageInfo,
      Xceed.Document.NET.Table table,
      float paragraphHeight = 0.0f)
    {
      if (currentSection == null)
        throw new ArgumentNullException(nameof (currentSection));
      if (currentPdfPageInfo == null)
        throw new ArgumentNullException(nameof (currentPdfPageInfo));
      double num1 = table != null ? (double) PdfTable.GetTablePositionX(currentSection, table) : throw new ArgumentNullException(nameof (table));
      float tablePositionY = PdfTable.GetTablePositionY(currentSection, currentPdfPageInfo, table, paragraphHeight);
      float single = Convert.ToSingle(table.ColumnWidths.Sum());
      float tableHeight = PdfTable.GetTableHeight(currentSection, currentPdfPageInfo, table);
      double num2 = (double) tablePositionY;
      double num3 = (double) single;
      double num4 = (double) tableHeight;
      return new RectangleF((float) num1, (float) num2, (float) num3, (float) num4);
    }

    internal static float GetTablePositionX(Section currentSection, Xceed.Document.NET.Table table)
    {
      if (currentSection == null)
        throw new ArgumentNullException(nameof (currentSection));
      XElement el = table != null ? PdfTable.GetTablePositionningElement(table) : throw new ArgumentNullException(nameof (table));
      if (el == null)
        return 0.0f;
      string attribute1 = el.GetAttribute(XName.Get("horzAnchor", Xceed.Document.NET.Document.w.NamespaceName));
      string str = el.GetAttribute(XName.Get("tblpXSpec", Xceed.Document.NET.Document.w.NamespaceName));
      string attribute2 = el.GetAttribute(XName.Get("tblpX", Xceed.Document.NET.Document.w.NamespaceName));
      float single = Convert.ToSingle(table.ColumnWidths.Sum());
      if (string.IsNullOrEmpty(str) && string.IsNullOrEmpty(attribute2))
        str = "left";
      if (str != null)
      {
        if (!(str == "left"))
        {
          if (!(str == "center"))
          {
            if (!(str == "right"))
            {
              if (!(str == "inside"))
              {
                if (str == "outside")
                {
                  if (attribute1 != null)
                  {
                    if (attribute1 == "page")
                      return currentSection.PageWidth - single;
                    if (attribute1 == "margin" || attribute1 == "text")
                      ;
                  }
                  return currentSection.PageWidth - currentSection.MarginRight - single;
                }
              }
              else
              {
                if (attribute1 != null)
                {
                  if (attribute1 == "page")
                    return 0.0f;
                  if (attribute1 == "margin" || attribute1 == "text")
                    ;
                }
                return currentSection.MarginLeft;
              }
            }
            else
            {
              if (attribute1 != null)
              {
                if (attribute1 == "page")
                  return currentSection.PageWidth - single;
                if (attribute1 == "margin" || attribute1 == "text")
                  ;
              }
              return currentSection.PageWidth - currentSection.MarginRight - single;
            }
          }
          else
          {
            if (attribute1 != null)
            {
              if (attribute1 == "page")
                return (float) ((double) currentSection.PageWidth / 2.0 - (double) single / 2.0);
              if (attribute1 == "margin" || attribute1 == "text")
                ;
            }
            return (float) ((double) currentSection.MarginLeft + ((double) currentSection.PageWidth - (double) currentSection.MarginLeft - (double) currentSection.MarginRight) / 2.0 - (double) single / 2.0);
          }
        }
        else
        {
          if (attribute1 != null)
          {
            if (attribute1 == "page")
              return 0.0f;
            if (attribute1 == "margin" || attribute1 == "text")
              ;
          }
          return currentSection.MarginLeft;
        }
      }
      float val2 = Convert.ToSingle(attribute2) / 20f;
      if (attribute1 != null)
      {
        if (attribute1 == "page")
          return Math.Max(0.0f, val2);
        if (attribute1 == "margin" || attribute1 == "text")
          ;
      }
      return Math.Max(0.0f, currentSection.MarginLeft + val2);
    }

    internal static float GetTablePositionY(
      Section currentSection,
      PdfPageInfo currentPdfPageInfo,
      Xceed.Document.NET.Table table,
      float paragraphHeight)
    {
      if (currentSection == null)
        throw new ArgumentNullException(nameof (currentSection));
      if (currentPdfPageInfo == null)
        throw new ArgumentNullException(nameof (currentPdfPageInfo));
      XElement el = table != null ? PdfTable.GetTablePositionningElement(table) : throw new ArgumentNullException(nameof (table));
      if (el == null)
        return 0.0f;
      string attribute1 = el.GetAttribute(XName.Get("vertAnchor", Xceed.Document.NET.Document.w.NamespaceName));
      string str = el.GetAttribute(XName.Get("tblpYSpec", Xceed.Document.NET.Document.w.NamespaceName));
      string attribute2 = el.GetAttribute(XName.Get("tblpY", Xceed.Document.NET.Document.w.NamespaceName));
      float tableHeight = PdfTable.GetTableHeight(currentSection, currentPdfPageInfo, table);
      if (string.IsNullOrEmpty(str) && string.IsNullOrEmpty(attribute2))
        str = "top";
      if (str != null)
      {
        if (!(str == "top"))
        {
          if (!(str == "center"))
          {
            if (!(str == "bottom"))
            {
              if (!(str == "inside"))
              {
                if (str == "outside")
                {
                  if (attribute1 != null)
                  {
                    if (attribute1 == "page")
                      return currentSection.PageHeight - tableHeight;
                    if (attribute1 == "paragraph" || attribute1 == "margin")
                      ;
                  }
                  return currentSection.PageHeight - currentSection.MarginBottom - tableHeight;
                }
              }
              else
              {
                if (attribute1 != null)
                {
                  if (attribute1 == "page")
                    return 0.0f;
                  if (attribute1 == "paragraph" || attribute1 == "margin")
                    ;
                }
                return currentSection.MarginTop;
              }
            }
            else
            {
              if (attribute1 != null)
              {
                if (attribute1 == "page")
                  return currentSection.PageHeight - tableHeight;
                if (attribute1 == "paragraph" || attribute1 == "margin")
                  ;
              }
              return currentSection.PageHeight - currentSection.MarginBottom - tableHeight;
            }
          }
          else
          {
            if (attribute1 != null)
            {
              if (attribute1 == "page")
                return (float) ((double) currentSection.PageHeight / 2.0 - (double) tableHeight / 2.0);
              if (attribute1 == "paragraph" || attribute1 == "margin")
                ;
            }
            return (float) ((double) currentSection.MarginTop + ((double) currentSection.PageHeight - (double) currentSection.MarginBottom - (double) currentSection.MarginTop) / 2.0 - (double) tableHeight / 2.0);
          }
        }
        else
        {
          if (attribute1 != null)
          {
            if (attribute1 == "page")
              return 0.0f;
            if (attribute1 == "paragraph" || attribute1 == "margin")
              ;
          }
          return currentSection.MarginTop;
        }
      }
      float val1 = Convert.ToSingle(attribute2) / 20f;
      if (attribute1 != null)
      {
        if (attribute1 == "page")
          return Math.Max(0.0f, Math.Min(val1, currentSection.PageHeight - tableHeight));
        if (attribute1 == "margin")
          return Math.Max(0.0f, Math.Min(currentSection.MarginTop + val1, currentSection.PageHeight - tableHeight));
        if (attribute1 == "paragraph")
          ;
      }
      return Math.Max(0.0f, Math.Min(currentPdfPageInfo.PositionY + paragraphHeight + val1, currentSection.PageHeight - tableHeight));
    }

    internal static bool IsTableRelativeFromPageInY(Xceed.Document.NET.Table table)
    {
      XElement el = table != null ? PdfTable.GetTablePositionningElement(table) : throw new ArgumentNullException(nameof (table));
      return el != null && el.GetAttribute(XName.Get("vertAnchor", Xceed.Document.NET.Document.w.NamespaceName)) == "page";
    }

    internal static PointF GetHorizontalMargins(Xceed.Document.NET.Table table)
    {
      if (table == null)
        throw new ArgumentNullException(nameof (table));
      PointF pointF = new PointF();
      XElement positionningElement = PdfTable.GetTablePositionningElement(table);
      if (positionningElement != null)
      {
        string attribute1 = positionningElement.GetAttribute(XName.Get("leftFromText", Xceed.Document.NET.Document.w.NamespaceName));
        if (!string.IsNullOrEmpty(attribute1))
          pointF.X = Convert.ToSingle(attribute1) / 20f;
        string attribute2 = positionningElement.GetAttribute(XName.Get("rightFromText", Xceed.Document.NET.Document.w.NamespaceName));
        if (!string.IsNullOrEmpty(attribute2))
          pointF.Y = Convert.ToSingle(attribute2) / 20f;
      }
      return pointF;
    }

    internal static PointF GetVerticalMargins(Xceed.Document.NET.Table table)
    {
      if (table == null)
        throw new ArgumentNullException(nameof (table));
      PointF pointF = new PointF();
      XElement positionningElement = PdfTable.GetTablePositionningElement(table);
      if (positionningElement != null)
      {
        string attribute1 = positionningElement.GetAttribute(XName.Get("topFromText", Xceed.Document.NET.Document.w.NamespaceName));
        if (!string.IsNullOrEmpty(attribute1))
          pointF.X = Convert.ToSingle(attribute1) / 20f;
        string attribute2 = positionningElement.GetAttribute(XName.Get("bottomFromText", Xceed.Document.NET.Document.w.NamespaceName));
        if (!string.IsNullOrEmpty(attribute2))
          pointF.Y = Convert.ToSingle(attribute2) / 20f;
      }
      return pointF;
    }

    internal static PdfParagraph CreateTablePdfParagraph(
      Xceed.Document.NET.Document fileToConvert,
      PackagePart packagePart,
      Section currentSection,
      PdfPageInfo currentPdfPageInfo,
      Xceed.Document.NET.Table table,
      XElement tableElement = null)
    {
      if (fileToConvert == null)
        throw new ArgumentNullException(nameof (fileToConvert));
      if (currentSection == null)
        throw new ArgumentNullException(nameof (currentSection));
      if (currentPdfPageInfo == null)
        throw new ArgumentNullException(nameof (currentPdfPageInfo));
      return new PdfParagraph(new Paragraph(fileToConvert, new XElement(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName)), 0)
      {
        FollowingTables = new List<Xceed.Document.NET.Table>()
        {
          table != null ? table : new Xceed.Document.NET.Table(fileToConvert, tableElement, packagePart)
        }
      }, (Paragraph) null, (Paragraph) null, 0, currentPdfPageInfo.PageNumber, currentPdfPageInfo.Page.Graphics, fileToConvert, currentSection);
    }

    internal void RemoveFirstRowExcedingText(float textHeightToRemove)
    {
      if ((double) textHeightToRemove <= 0.0)
        return;
      Xceed.Pdf.Layout.Table.Row row = ((IEnumerable<Xceed.Pdf.Layout.Table.Row>) this.Table.Rows.Buffer).FirstOrDefault<Xceed.Pdf.Layout.Table.Row>((Func<Xceed.Pdf.Layout.Table.Row, bool>) (r => !r.IsTableHeader));
      if (row == null && this.Table.Rows.Size > 1)
        row = this.Table.Rows[1];
      for (int index1 = 0; index1 < row.Cells.Size; ++index1)
      {
        Xceed.Pdf.Layout.Table.Cell cell = row.Cells[index1];
        if (cell.Content != null && cell.Content.Buffer != null)
        {
          cell.Height -= textHeightToRemove;
          int count = 0;
          float num = 0.0f;
          foreach (Xceed.Pdf.Layout.Block block in ((IEnumerable<Xceed.Pdf.Layout.Block>) cell.Content.Buffer).Where<Xceed.Pdf.Layout.Block>((Func<Xceed.Pdf.Layout.Block, bool>) (b => b != null)))
          {
            if (block is Xceed.Pdf.Layout.Text.Text text)
            {
              if ((double) num + (double) text.Height - (double) text.Paddings.Top > (double) textHeightToRemove)
              {
                bool flag = false;
                float top = text.Paddings.Top;
                for (int index2 = 0; index2 < text.Lines.Size; ++index2)
                {
                  Line line = text.Lines[index2];
                  float heightWithInterval = text.GetLineHeightWithInterval(index2);
                  top += heightWithInterval;
                  if ((double) num + (double) top > (double) textHeightToRemove)
                  {
                    num += top - heightWithInterval;
                    text.Lines.Remove(0, index2);
                    flag = true;
                    break;
                  }
                }
                if (flag)
                  break;
              }
              else
              {
                text.Lines.Remove(0, text.Lines.Size);
                ++count;
              }
              num += text.Height;
            }
          }
          if (count > 0)
          {
            cell.Content.Remove(0, count);
            for (int index2 = 0; index2 < cell.Content.Size; ++index2)
              cell.Content.Buffer[index2].Top = Math.Max(cell.Content.Buffer[index2].Top - num, 0.0f);
          }
        }
      }
      float height = row.Height;
      row.Height = ((IEnumerable<Xceed.Pdf.Layout.Table.Cell>) row.Cells.Buffer).Where<Xceed.Pdf.Layout.Table.Cell>((Func<Xceed.Pdf.Layout.Table.Cell, bool>) (c => c != null)).Max<Xceed.Pdf.Layout.Table.Cell>((Func<Xceed.Pdf.Layout.Table.Cell, float>) (c => c.Height));
      bool flag1 = false;
      for (int index1 = 0; index1 < this.Table.Rows.Size; ++index1)
      {
        if (flag1)
        {
          for (int index2 = 0; index2 < this.Table.Rows[index1].Cells.Size; ++index2)
            this.Table.Rows[index1].Cells[index2].Top -= height - row.Height;
        }
        else if (this.Table.Rows[index1].Equals((object) row))
          flag1 = true;
      }
    }

    internal RowCollection RemovePrecedingExcedingRows(int drawnRows)
    {
      RowCollection rowCollection = new RowCollection();
      if (drawnRows <= 0)
        return rowCollection;
      int num = this.Table.Rows[0].IsTableHeader ? 1 : 0;
      rowCollection.Add(this.Table.Rows.Buffer, num, drawnRows - num);
      this.Table.Rows.Remove(num, drawnRows - num);
      return rowCollection;
    }

    internal RowCollection RemoveExcedingRows(
      float remainingHeight,
      ref int fullyDrawnRowsCount)
    {
      fullyDrawnRowsCount = 0;
      RowCollection rowCollection = new RowCollection();
      float num1 = 0.0f;
      for (int index1 = 0; index1 < this.Table.Rows.Size; ++index1)
      {
        Xceed.Pdf.Layout.Table.Row row = this.Table.Rows[index1];
        num1 += row.Height;
        if ((double) num1 > (double) remainingHeight)
        {
          int num2;
          int num3;
          if (!row.CantSplit)
          {
            float remainingRowHeight = remainingHeight - (num1 - row.Height);
            if (this.CanDisplaySplitRowContent(row, remainingRowHeight))
            {
              for (int index2 = 0; index2 < row.Cells.Size; ++index2)
              {
                Xceed.Pdf.Layout.Table.Cell cell = row.Cells[index2];
                if (cell.Content != null && cell.Content.Buffer != null && ((IEnumerable<Xceed.Pdf.Layout.Block>) cell.Content.Buffer).Count<Xceed.Pdf.Layout.Block>() > 0 && (double) ((IEnumerable<Xceed.Pdf.Layout.Block>) cell.Content.Buffer).Where<Xceed.Pdf.Layout.Block>((Func<Xceed.Pdf.Layout.Block, bool>) (b => b != null)).Select<Xceed.Pdf.Layout.Block, float>((Func<Xceed.Pdf.Layout.Block, float>) (b => b.Height)).Sum() >= (double) remainingRowHeight)
                {
                  float num4 = 0.0f;
                  foreach (Xceed.Pdf.Layout.Block block in ((IEnumerable<Xceed.Pdf.Layout.Block>) cell.Content.Buffer).Where<Xceed.Pdf.Layout.Block>((Func<Xceed.Pdf.Layout.Block, bool>) (b => b != null)))
                  {
                    if (block is Xceed.Pdf.Layout.Text.Text text)
                    {
                      float top = text.Paddings.Top;
                      for (int index3 = 0; index3 < text.Lines.Size; ++index3)
                      {
                        Line line = text.Lines[index3];
                        top += text.GetLineHeightWithInterval(index3);
                        if ((double) num4 + (double) top > (double) remainingRowHeight)
                        {
                          top -= text.GetLineHeightWithInterval(index3);
                          text.Lines.Remove(index3, text.Lines.Size - index3);
                        }
                      }
                      text.Height = top;
                      num4 += top;
                    }
                  }
                }
              }
              num2 = index1 + 1;
              num3 = this.Table.Rows.Size - index1 - 1;
              row.Height = ((IEnumerable<Xceed.Pdf.Layout.Table.Cell>) row.Cells.Buffer).Where<Xceed.Pdf.Layout.Table.Cell>((Func<Xceed.Pdf.Layout.Table.Cell, bool>) (c => c != null)).Max<Xceed.Pdf.Layout.Table.Cell>((Func<Xceed.Pdf.Layout.Table.Cell, float>) (c => ((IEnumerable<Xceed.Pdf.Layout.Block>) c.Content.Buffer).Where<Xceed.Pdf.Layout.Block>((Func<Xceed.Pdf.Layout.Block, bool>) (b => b != null)).Select<Xceed.Pdf.Layout.Block, float>((Func<Xceed.Pdf.Layout.Block, float>) (b => b.Height)).Sum()));
              ((IEnumerable<Xceed.Pdf.Layout.Table.Cell>) row.Cells.Buffer).Where<Xceed.Pdf.Layout.Table.Cell>((Func<Xceed.Pdf.Layout.Table.Cell, bool>) (c => c != null)).ToList<Xceed.Pdf.Layout.Table.Cell>().ForEach((System.Action<Xceed.Pdf.Layout.Table.Cell>) (c =>
              {
                c.VerticalAlignment = Xceed.Pdf.Layout.VerticalAlignment.Top;
                c.Measure(this._graphics);
                c.Height = row.Height;
              }));
            }
            else
            {
              num2 = index1;
              num3 = this.Table.Rows.Size - index1;
            }
          }
          else
          {
            num2 = index1;
            num3 = this.Table.Rows.Size - index1;
          }
          rowCollection.Add(this.Table.Rows.Buffer, num2, num3);
          this.Table.Rows.Remove(num2, num3);
          break;
        }
        ++fullyDrawnRowsCount;
      }
      this.Table.Height = this.GetTotalRowsHeight();
      return rowCollection;
    }

    internal float AdjustTablePosition(PdfPageInfo currentPdfPageInfo)
    {
      float y1 = currentPdfPageInfo.PositionY;
      List<Tuple<bool, RectangleF>> blockedRegions = PdfParagraphPart.CreateBlockedRegions(this._pdfParagraph.GetCurrentSection(), (IList) currentPdfPageInfo.WrappedObjects);
      if (blockedRegions.Count > 0)
      {
        bool flag1 = true;
        while (flag1)
        {
          RectangleF rectangleF1 = new RectangleF(this.Table.Left, y1, this.Table.Width, this.Table.Height);
          bool flag2 = false;
          foreach (Tuple<bool, RectangleF> tuple in blockedRegions)
          {
            if (rectangleF1.IntersectsWith(tuple.Item2))
            {
              RectangleF rectangleF2 = tuple.Item2;
              double y2 = (double) rectangleF2.Y;
              rectangleF2 = tuple.Item2;
              double height = (double) rectangleF2.Height;
              y1 = (float) (y2 + height + 1.0);
              flag2 = true;
              break;
            }
          }
          if (!flag2)
            flag1 = false;
        }
      }
      return y1;
    }

    private static XElement GetTablePositionningElement(Xceed.Document.NET.Table table) => table?.Xml.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("tblpPr", Xceed.Document.NET.Document.w.NamespaceName));

    internal static float GetTableHeight(
      Section currentSection,
      PdfPageInfo currentPdfPageInfo,
      Xceed.Document.NET.Table table)
    {
      if (currentSection == null)
        throw new ArgumentNullException(nameof (currentSection));
      if (currentPdfPageInfo == null)
        throw new ArgumentNullException(nameof (currentPdfPageInfo));
      if (table == null)
        throw new ArgumentNullException(nameof (table));
      PdfTable pdfTable = PdfTable.CreateTablePdfParagraph(table.Document, table.PackagePart, currentSection, currentPdfPageInfo, table).CreatePdfTable(table, currentPdfPageInfo, true) as PdfTable;
      currentPdfPageInfo.Page.Graphics.MeasureBlock(0.0f, 0.0f, pdfTable.Table.Width, 0.0f, (Xceed.Pdf.Layout.Block) pdfTable.Table);
      return Convert.ToSingle(((IEnumerable<Xceed.Pdf.Layout.Table.Row>) pdfTable.Table.Rows.Buffer).Where<Xceed.Pdf.Layout.Table.Row>((Func<Xceed.Pdf.Layout.Table.Row, bool>) (x => x != null)).Select<Xceed.Pdf.Layout.Table.Row, float>((Func<Xceed.Pdf.Layout.Table.Row, float>) (x => x.Height)).Sum());
    }

    private void UpdateTextCore(
      Xceed.Pdf.Layout.Table.Table pdfTable,
      float marginLeft,
      float marginRight,
      float availableWidth,
      bool isMeasuring = false)
    {
      XElement styleFromStyleId = this.GetWantedStyleFromStyleId(this._table.Xml, this.GetTableStyle());
      this.SetTablePropertiesFromStyle(pdfTable, styleFromStyleId);
      for (int index1 = 0; index1 < this._table.Rows.Count; ++index1)
      {
        Xceed.Pdf.Layout.Table.Row row = pdfTable.AddRow();
        this.SetRowPropertiesFromStyle(row, styleFromStyleId.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName)));
        this.SetRowPropertiesFromStyle(row, this._table.Rows[index1].Xml.Element(XName.Get("trPr", Xceed.Document.NET.Document.w.NamespaceName)));
        for (int index2 = 0; index2 < this._table.Rows[index1].Cells.Count; ++index2)
        {
          Cell cell1 = this._table.Rows[index1].Cells[index2];
          Xceed.Pdf.Layout.Table.Cell cell2 = row.AddCell();
          this.SetCellSpacing(cell2, index1 == 0, index1 == this._table.Rows.Count - 1, index2 == 0, index2 == this._table.Rows[index1].Cells.Count - 1);
          cell2.Width = Convert.ToSingle(cell1.Width - (double) cell2.Spacings.Left - (double) cell2.Spacings.Right);
          cell2.WidthIsFixed = true;
          this.SetCellInsideBordersFromTableStyle(cell2, index1 == 0, index1 == this._table.Rows.Count - 1, index2 == 0, index2 == this._table.Rows[index1].Cells.Count - 1);
          this.SetCellPropertiesFromStyle(cell2, styleFromStyleId.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName)), pdfTable, new bool?());
          List<Paragraph> list = cell1.Paragraphs.Where<Paragraph>((Func<Paragraph, bool>) (p => this.IsParagraphInCurrentTable(p) && p.ParentContainer != ContainerType.Shape)).ToList<Paragraph>();
          bool flag = false;
          for (int index3 = 0; index3 < list.Count; ++index3)
          {
            if (index3 == 0)
            {
              List<XElement> cellInitialTables = this.GetCellInitialTables(cell1);
              if (cellInitialTables != null)
              {
                Paragraph current = new Paragraph(this._fileToConvert, new XElement(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName)), 0);
                current.FollowingTables = new List<Xceed.Document.NET.Table>();
                foreach (XElement xml in cellInitialTables)
                  current.FollowingTables.Add(new Xceed.Document.NET.Table(this._fileToConvert, xml, this._fileToConvert.PackagePart));
                PdfParagraph tablePdfParagraph = new PdfParagraph(current, (Paragraph) null, (Paragraph) null, 0, this._pageNumber, this._graphics, this._fileToConvert, this._pdfParagraph.GetCurrentSection());
                this.AddTablesInCell(current.FollowingTables, cell2, tablePdfParagraph, Convert.ToSingle(cell1.Width));
                flag = true;
              }
            }
            Xceed.Pdf.Layout.Text.Text text = cell2.AddText();
            PdfParagraph pdfParagraph = new PdfParagraph(list[index3], index3 == 0 ? (Paragraph) null : list[index3 - 1], index3 == list.Count - 1 ? (Paragraph) null : list[index3 + 1], index3, this._pageNumber, this._graphics, this._fileToConvert, this._pdfParagraph.GetCurrentSection());
            this.SetParagraphProperties(pdfParagraph, styleFromStyleId);
            this.SetParagraphProperties(pdfParagraph, list[index3].Xml);
            this.SetTableLookFromTableStyle(pdfTable, cell2, pdfParagraph, styleFromStyleId, this._table.TableLook, index1 == 0, index1 == this._table.Rows.Count - 1, index2 == 0, index2 == this._table.Rows[index1].Cells.Count - 1, index1 % 2 == 1, index2 % 2 == 1);
            if (!flag || flag && list[index3].MagicText.Count > 0)
            {
              pdfParagraph.UpdateParagraphPageNumber();
              pdfParagraph.FillContent(text, isMeasuring);
              if (pdfParagraph.ContainsTotalPageNumber() && !PdfConverter.IsTotalPageNumberCalculated())
                this._pdfParagraph.SetContainsTotalPageNumber(true);
            }
            this.SetCellPropertiesFromStyle(cell2, cell1.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName)), pdfTable, new bool?());
            if ((double) pdfTable.CellPaddings.Top == 0.0 && (!flag || flag && list[index3].MagicText.Count > 0))
              text.Paddings.Top = pdfParagraph.GetLineSpacingBefore(text);
            if ((double) pdfTable.CellPaddings.Bottom == 0.0 && (!flag || flag && list[index3].MagicText.Count > 0))
              text.Paddings.Bottom = pdfParagraph.GetLineSpacingAfter(text);
            flag = false;
            if (pdfParagraph.ContainsUnwrappedTables())
            {
              this.AddTablesInCell(pdfParagraph.GetUnwrappedTables(), cell2, pdfParagraph, Convert.ToSingle(cell1.Width));
              flag = true;
            }
          }
          if ((double) row.Height != 0.0 && row.HeightIsFixed)
            this.ClipCellContentHeight(cell2, row.Height);
        }
      }
      this.SetTableWidth(pdfTable, styleFromStyleId, marginLeft, marginRight, availableWidth);
      this.SetTableAlignment(pdfTable, styleFromStyleId, marginLeft, marginRight, availableWidth);
    }

    private void ClipCellContentHeight(Xceed.Pdf.Layout.Table.Cell newCell, float fixedRowHeight)
    {
      if (newCell == null)
        return;
      fixedRowHeight -= newCell.Paddings.Top;
      newCell.Measure(this._graphics);
      if ((double) newCell.Height <= (double) fixedRowHeight || newCell.Content == null || newCell.Content.Buffer == null)
        return;
      IEnumerable<Xceed.Pdf.Layout.Block> blocks = ((IEnumerable<Xceed.Pdf.Layout.Block>) newCell.Content.Buffer).Where<Xceed.Pdf.Layout.Block>((Func<Xceed.Pdf.Layout.Block, bool>) (x => x != null));
      if (blocks == null)
        return;
      float num = 0.0f;
      foreach (Xceed.Pdf.Layout.Block block in blocks)
      {
        if ((double) num + (double) block.Height > (double) fixedRowHeight)
        {
          block.Height = fixedRowHeight - num;
          block.HeightIsFixed = true;
        }
        num += block.Height;
      }
    }

    private void AddTablesInCell(
      List<Xceed.Document.NET.Table> tables,
      Xceed.Pdf.Layout.Table.Cell newCell,
      PdfParagraph tablePdfParagraph,
      float cellWidth)
    {
      if (tables == null)
        return;
      foreach (Xceed.Document.NET.Table table in tables)
      {
        PdfTable pdfTable = new PdfTable(tablePdfParagraph, table, this._graphics, this._pageNumber);
        pdfTable.Table = newCell.AddTable();
        pdfTable.UpdateTextCore(pdfTable.Table, 0.0f, 0.0f, cellWidth);
      }
    }

    private string GetTableStyle()
    {
      string str = "";
      if (this._table == null)
        return str;
      XElement xelement = this._table.Xml.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("tblStyle", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement != null)
      {
        XAttribute xattribute = xelement.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null)
          str = xattribute.Value;
      }
      return str;
    }

    private float GetTablePreferredWidth(
      XElement xml,
      float marginLeft,
      float marginRight,
      float availableWidth)
    {
      if (xml != null)
      {
        XElement xelement1 = xml.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 != null)
        {
          XElement xelement2 = xelement1.Element(XName.Get("tblW", Xceed.Document.NET.Document.w.NamespaceName));
          if (xelement2 != null)
          {
            string attribute = xelement2.GetAttribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName));
            if (!string.IsNullOrEmpty(attribute))
            {
              if (attribute.Equals("auto"))
                return 0.0f;
              if (attribute.Equals("pct"))
              {
                XAttribute xattribute = xelement2.Attribute(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName));
                float result;
                if (xattribute != null && HelperFunctions.TryParseFloat(xattribute.Value, out result))
                {
                  float num = availableWidth - marginLeft - marginRight;
                  return result / 5000f * num;
                }
              }
            }
          }
          return this.GetWidthValue(xelement2, 0.0f);
        }
      }
      return 0.0f;
    }

    private void SetParagraphProperties(PdfParagraph p, XElement xml)
    {
      if (p == null || xml == null)
        return;
      XElement xelement = xml.Element(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement != null)
      {
        Paragraph styledParagraph = new Paragraph((Xceed.Document.NET.Document) null, new XElement((XName) "tableParagraph"), 0);
        XElement pPr = styledParagraph.GetOrCreate_pPr();
        foreach (XElement element in xelement.Elements())
          pPr.Add((object) element);
        HelperFunctions.UpdateParagraphFromStyledParagraph(p.GetOriginalParagraph(), styledParagraph);
      }
      XElement rPr = xml.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (rPr == null)
        return;
      Formatting newFormatting = Formatting.Parse(rPr);
      foreach (FormattedText formattedText in p.GetOriginalParagraph().MagicText)
      {
        Formatting formatting = formattedText.formatting;
        p.UpdateFormattingFromFormatting(ref formatting, newFormatting, formattedText.InitialFormatting);
        formattedText.InternalModifyFormatting(formatting);
      }
    }

    private void SetTableWidth(
      Xceed.Pdf.Layout.Table.Table pdfTable,
      XElement design,
      float marginLeft,
      float marginRight,
      float availableWidth)
    {
      if (design == null)
        return;
      this.UpdateCellsWidth(pdfTable, design, marginLeft, marginRight, availableWidth);
      if (pdfTable.Rows.Size == 0)
        return;
      float val1_1 = 0.0f;
      float val1_2 = 0.0f;
      for (int index1 = 0; index1 < pdfTable.Rows.Size; ++index1)
      {
        float val2_1 = 0.0f;
        float val2_2 = 0.0f;
        if (pdfTable.Rows[index1].Cells != null)
        {
          for (int index2 = 0; index2 < pdfTable.Rows[index1].Cells.Size; ++index2)
          {
            Xceed.Pdf.Layout.Table.Cell cell = pdfTable.Rows[index1].Cells[index2];
            val2_1 += cell.Width;
            val2_2 += cell.Spacings.Left + cell.Spacings.Right;
          }
          val1_1 = Math.Max(val1_1, val2_1);
          val1_2 = Math.Max(val1_2, val2_2);
        }
      }
      float num = val1_1 + val1_2;
      pdfTable.Width = num;
    }

    private bool IsTableWidthFixed(XElement tbl)
    {
      if (tbl == null)
        return false;
      XElement xelement1 = tbl.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 != null)
      {
        XElement xelement2 = xelement1.Element(XName.Get("tblLayout", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 != null)
        {
          XAttribute xattribute = xelement2.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName));
          if (xattribute != null)
            return xattribute.Value.Equals("fixed");
        }
      }
      return false;
    }

    private void SetCellInsideBordersFromTableStyle(
      Xceed.Pdf.Layout.Table.Cell cell,
      bool isFirstRow,
      bool isLastRow,
      bool isFirstColumn,
      bool isLastColumn)
    {
      if (cell == null)
        return;
      if ((!isFirstColumn || (double) cell.Spacings.Left > 0.0) && this._insideVPdfBorder != null)
        cell.Borders.Left = this._insideVPdfBorder.Clone();
      if ((!isLastColumn || (double) cell.Spacings.Right > 0.0) && this._insideVPdfBorder != null)
        cell.Borders.Right = this._insideVPdfBorder.Clone();
      if ((!isFirstRow || (double) cell.Spacings.Top > 0.0) && this._insideHPdfBorder != null)
        cell.Borders.Top = this._insideHPdfBorder.Clone();
      if (isLastRow && (double) cell.Spacings.Bottom <= 0.0 || this._insideHPdfBorder == null)
        return;
      cell.Borders.Bottom = this._insideHPdfBorder.Clone();
    }

    private void SetCellSpacing(
      Xceed.Pdf.Layout.Table.Cell cell,
      bool isFirstRow,
      bool isLastRow,
      bool isFirstColumn,
      bool isLastColumn)
    {
      if (cell == null)
        return;
      if (!isFirstRow)
        cell.Spacings.Top /= 2f;
      if (!isLastRow)
        cell.Spacings.Bottom /= 2f;
      if (!isFirstColumn)
        cell.Spacings.Left /= 2f;
      if (isLastColumn)
        return;
      cell.Spacings.Right /= 2f;
    }

    private void SetTableLookFromTableStyle(
      Xceed.Pdf.Layout.Table.Table table,
      Xceed.Pdf.Layout.Table.Cell cell,
      PdfParagraph p,
      XElement design,
      TableLook tableLook,
      bool isFirstRow,
      bool isLastRow,
      bool isFirstColumn,
      bool isLastColumn,
      bool isOddRow,
      bool isOddColumn)
    {
      if (table == null || cell == null || (p == null || design == null) || tableLook == null)
        return;
      if (isOddColumn && !(tableLook.FirstColumn & isFirstColumn) && (!(tableLook.LastColumn & isLastColumn) && !tableLook.NoVerticalBanding))
        this.SetTableLookFromTableStyleCore(table, cell, p, design, "band1Vert", new bool?(false), isFirstRow, isLastRow, isFirstColumn, isLastColumn);
      if (!isOddColumn && !(tableLook.FirstColumn & isFirstColumn) && (!(tableLook.LastColumn & isLastColumn) && !tableLook.NoVerticalBanding))
        this.SetTableLookFromTableStyleCore(table, cell, p, design, "band2Vert", new bool?(false), isFirstRow, isLastRow, isFirstColumn, isLastColumn);
      if (isOddRow && !(tableLook.FirstRow & isFirstRow) && (!(tableLook.LastRow & isLastRow) && !tableLook.NoHorizontalBanding))
        this.SetTableLookFromTableStyleCore(table, cell, p, design, "band1Horz", new bool?(true), isFirstRow, isLastRow, isFirstColumn, isLastColumn);
      if (!isOddRow && !(tableLook.FirstRow & isFirstRow) && (!(tableLook.LastRow & isLastRow) && !tableLook.NoHorizontalBanding))
        this.SetTableLookFromTableStyleCore(table, cell, p, design, "band2Horz", new bool?(true), isFirstRow, isLastRow, isFirstColumn, isLastColumn);
      if (isFirstColumn && tableLook.FirstColumn)
        this.SetTableLookFromTableStyleCore(table, cell, p, design, "firstCol", new bool?(false), isFirstRow, isLastRow, isFirstColumn, isLastColumn);
      if (isLastColumn && tableLook.LastColumn)
        this.SetTableLookFromTableStyleCore(table, cell, p, design, "lastCol", new bool?(false), isFirstRow, isLastRow, isFirstColumn, isLastColumn);
      if (isFirstRow && tableLook.FirstRow)
        this.SetTableLookFromTableStyleCore(table, cell, p, design, "firstRow", new bool?(true), isFirstRow, isLastRow, isFirstColumn, isLastColumn);
      if (isLastRow && tableLook.LastRow)
        this.SetTableLookFromTableStyleCore(table, cell, p, design, "lastRow", new bool?(true), isFirstRow, isLastRow, isFirstColumn, isLastColumn);
      if (isFirstRow & isFirstColumn)
        this.SetTableLookFromTableStyleCore(table, cell, p, design, "nwCell", new bool?(), isFirstRow, isLastRow, isFirstColumn, isLastColumn);
      if (isFirstRow & isLastColumn)
        this.SetTableLookFromTableStyleCore(table, cell, p, design, "neCell", new bool?(), isFirstRow, isLastRow, isFirstColumn, isLastColumn);
      if (isLastRow & isFirstColumn)
        this.SetTableLookFromTableStyleCore(table, cell, p, design, "swCell", new bool?(), isFirstRow, isLastRow, isFirstColumn, isLastColumn);
      if (!(isLastRow & isLastColumn))
        return;
      this.SetTableLookFromTableStyleCore(table, cell, p, design, "seCell", new bool?(), isFirstRow, isLastRow, isFirstColumn, isLastColumn);
    }

    private void SetTableLookFromTableStyleCore(
      Xceed.Pdf.Layout.Table.Table table,
      Xceed.Pdf.Layout.Table.Cell cell,
      PdfParagraph p,
      XElement design,
      string type,
      bool? isRow,
      bool isFirstRow,
      bool isLastRow,
      bool isFirstColumn,
      bool isLastColumn)
    {
      if (table == null || cell == null || (p == null || design == null) || string.IsNullOrEmpty(type))
        return;
      IEnumerable<XElement> source = design.Elements(XName.Get("tblStylePr", Xceed.Document.NET.Document.w.NamespaceName));
      if (source == null || source.Count<XElement>() <= 0)
        return;
      XElement xml1 = source.Where<XElement>((Func<XElement, bool>) (x => x.Attribute(XName.Get(nameof (type), Xceed.Document.NET.Document.w.NamespaceName)) != null && x.Attribute(XName.Get(nameof (type), Xceed.Document.NET.Document.w.NamespaceName)).Value.Equals(type))).FirstOrDefault<XElement>();
      if (xml1 == null)
        return;
      XElement design1 = xml1.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (design1 != null)
        this.SetTablePropertiesFromStyle(table, design1);
      XElement xml2 = xml1.Element(XName.Get("trPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xml2 != null)
        this.SetRowPropertiesFromStyle(this.GetParentRow(cell), xml2);
      XElement xml3 = xml1.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xml3 != null)
        this.SetCellPropertiesFromStyle(cell, xml3, table, isRow);
      this.SetParagraphProperties(p, xml1);
    }

    private void UpdateCellsWidth(
      Xceed.Pdf.Layout.Table.Table pdfTable,
      XElement xml,
      float marginLeft,
      float marginRight,
      float availableWidth)
    {
      if (xml == null || pdfTable == null)
        return;
      float val2 = this.GetTablePreferredWidth(xml, marginLeft, marginRight, availableWidth);
      bool flag1 = !this.IsTableWidthFixed(xml);
      bool flag2 = false;
      IEnumerable<Xceed.Pdf.Layout.Table.Row> rows = ((IEnumerable<Xceed.Pdf.Layout.Table.Row>) pdfTable.Rows.Buffer).Where<Xceed.Pdf.Layout.Table.Row>((Func<Xceed.Pdf.Layout.Table.Row, bool>) (x => x != null));
      List<float> floatList = new List<float>();
      IEnumerable<XElement> xelements = xml.Element(XName.Get("tblGrid", Xceed.Document.NET.Document.w.NamespaceName))?.Elements(XName.Get("gridCol", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelements != null)
      {
        foreach (XElement el in xelements)
        {
          string attribute = el.GetAttribute(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName));
          floatList.Add(Convert.ToSingle(attribute, (IFormatProvider) new CultureInfo("en-US")) / 20f);
        }
      }
      if (((floatList.Count <= 0 ? 0 : ((double) floatList.Sum() > (double) availableWidth - (double) marginLeft - (double) marginRight ? 1 : 0)) & (flag1 ? 1 : 0)) != 0 && (double) val2 == 0.0)
      {
        flag2 = true;
        val2 = availableWidth - marginLeft - marginRight;
      }
      if (flag1 && !flag2)
      {
        if (rows.Count<Xceed.Pdf.Layout.Table.Row>() <= 0)
          return;
        bool isAutoFitContents = Xceed.Document.NET.Table.GetAutoFitFromXml(xml) == AutoFit.Contents;
        float[] cellsContentWidths = this.GetMaxColumnCellsContentWidths(rows, pdfTable, isAutoFitContents);
        if ((double) val2 != 0.0)
        {
          List<float> source = floatList.Count > 0 ? floatList : ((IEnumerable<float>) cellsContentWidths).ToList<float>();
          if ((double) val2 <= (double) source.Sum())
          {
            foreach (Xceed.Pdf.Layout.Table.Row row in rows)
            {
              int num = 0;
              for (int index = 0; index < row.Cells.Size; ++index)
              {
                Xceed.Pdf.Layout.Table.Cell cell = row.Cells[index];
                if (cell.GridSpan > 1)
                {
                  cell.Width = source.Skip<float>(num).Take<float>(cell.GridSpan).Sum();
                  num += cell.GridSpan;
                }
                else
                {
                  cell.Width = Math.Min(source[num], val2);
                  ++num;
                }
              }
            }
          }
          else
          {
            float num1 = val2 - source.Sum();
            foreach (Xceed.Pdf.Layout.Table.Row row in rows)
            {
              float num2 = ((IEnumerable<Xceed.Pdf.Layout.Table.Cell>) row.Cells.Buffer).Where<Xceed.Pdf.Layout.Table.Cell>((Func<Xceed.Pdf.Layout.Table.Cell, bool>) (x => x != null)).Sum<Xceed.Pdf.Layout.Table.Cell>((Func<Xceed.Pdf.Layout.Table.Cell, float>) (x => x.Width));
              int num3 = 0;
              for (int index = 0; index < row.Cells.Size; ++index)
              {
                Xceed.Pdf.Layout.Table.Cell cell = row.Cells[index];
                if (cell.GridSpan > 1)
                {
                  cell.Width = source.Skip<float>(num3).Take<float>(cell.GridSpan).Sum() + cell.Width / num2 * num1;
                  num3 += cell.GridSpan;
                }
                else
                {
                  cell.Width = source[num3] + cell.Width / num2 * num1;
                  ++num3;
                }
              }
            }
          }
        }
        else
          this.SetCellWidthsBasedOnColumnsWidths(rows, floatList, cellsContentWidths);
      }
      else if ((double) val2 != 0.0)
      {
        if (floatList.Count > 0 && !flag2)
        {
          this.SetCellWidthsBasedOnColumnsWidths(rows, floatList);
        }
        else
        {
          foreach (Xceed.Pdf.Layout.Table.Row row in rows)
          {
            float num = ((IEnumerable<Xceed.Pdf.Layout.Table.Cell>) row.Cells.Buffer).Where<Xceed.Pdf.Layout.Table.Cell>((Func<Xceed.Pdf.Layout.Table.Cell, bool>) (x => x != null)).Sum<Xceed.Pdf.Layout.Table.Cell>((Func<Xceed.Pdf.Layout.Table.Cell, float>) (x => x.Width));
            for (int index = 0; index < row.Cells.Size; ++index)
            {
              Xceed.Pdf.Layout.Table.Cell cell = row.Cells[index];
              cell.Width = Math.Max(cell.Width / num * val2, 15f);
            }
          }
        }
      }
      else
        this.SetCellWidthsBasedOnColumnsWidths(rows, floatList);
    }

    private float[] GetMaxColumnCellsContentWidths(
      IEnumerable<Xceed.Pdf.Layout.Table.Row> rows,
      Xceed.Pdf.Layout.Table.Table pdfTable,
      bool isAutoFitContents)
    {
      int val1 = 0;
      foreach (Xceed.Pdf.Layout.Table.Row row in rows)
      {
        IEnumerable<int> source = ((IEnumerable<Xceed.Pdf.Layout.Table.Cell>) row.Cells.Buffer).Where<Xceed.Pdf.Layout.Table.Cell>((Func<Xceed.Pdf.Layout.Table.Cell, bool>) (c => c != null)).Select<Xceed.Pdf.Layout.Table.Cell, int>((Func<Xceed.Pdf.Layout.Table.Cell, int>) (c => c.GridSpan));
        int val2 = source.Where<int>((Func<int, bool>) (s => s <= 1)).Count<int>() + source.Where<int>((Func<int, bool>) (s => s > 1)).Sum();
        val1 = Math.Max(val1, val2);
      }
      float[] numArray = new float[val1];
      foreach (Xceed.Pdf.Layout.Table.Row row in rows)
      {
        int index1 = 0;
        for (int index2 = 0; index2 < row.Cells.Size; ++index2)
        {
          Xceed.Pdf.Layout.Table.Cell cell = row.Cells[index2];
          if (cell.GridSpan > 1)
          {
            index1 += cell.GridSpan;
          }
          else
          {
            numArray[index1] = Math.Max(this.MeasureCellContentWidth(pdfTable, isAutoFitContents, cell), numArray[index1]);
            ++index1;
          }
        }
      }
      return numArray;
    }

    private void SetCellWidthsBasedOnColumnsWidths(
      IEnumerable<Xceed.Pdf.Layout.Table.Row> rows,
      List<float> columnWidths,
      float[] maxColumnCellsContentWidths = null)
    {
      if (rows == null || columnWidths == null)
        return;
      foreach (Xceed.Pdf.Layout.Table.Row row in rows)
      {
        int index1 = 0;
        for (int index2 = 0; index2 < row.Cells.Size; ++index2)
        {
          Xceed.Pdf.Layout.Table.Cell cell = row.Cells[index2];
          if (cell.GridSpan > 1)
          {
            if (columnWidths.Count > 0)
              cell.Width = columnWidths.Skip<float>(index1).Take<float>(cell.GridSpan).Sum();
            else if (maxColumnCellsContentWidths != null)
              this.SetAutomaticResizeCellWidth(cell, ((IEnumerable<float>) maxColumnCellsContentWidths).Skip<float>(index1).Take<float>(cell.GridSpan).Sum());
            index1 += cell.GridSpan;
          }
          else
          {
            if (columnWidths.Count > 0)
              cell.Width = columnWidths[index1];
            else if (maxColumnCellsContentWidths != null)
              this.SetAutomaticResizeCellWidth(cell, maxColumnCellsContentWidths[index1]);
            ++index1;
          }
        }
      }
    }

    private float MeasureCellContentWidth(Xceed.Pdf.Layout.Table.Table pdfTable, bool isAutoFitContents, Xceed.Pdf.Layout.Table.Cell cell)
    {
      if (pdfTable == null || cell == null)
        return 0.0f;
      if (cell.WidthIsFixed && !isAutoFitContents)
        return cell.Width;
      float val1 = 0.0f;
      if (((IEnumerable<Xceed.Pdf.Layout.Block>) cell.Content.Buffer).FirstOrDefault<Xceed.Pdf.Layout.Block>() is Xceed.Pdf.Layout.Text.Text text)
      {
        this._graphics.MeasureBlock(0.0f, 0.0f, 0.0f, 0.0f, (Xceed.Pdf.Layout.Block) text);
        for (int index = 0; index < text.Lines.Size; ++index)
          val1 = Math.Max(val1, text.Lines[index].Width);
        val1 += pdfTable.CellPaddings.Left + pdfTable.CellPaddings.Right;
      }
      return val1;
    }

    private void SetAutomaticResizeCellWidth(Xceed.Pdf.Layout.Table.Cell cell, float maxColumnCellsContentWidth)
    {
      if (cell == null || (double) cell.Width >= (double) maxColumnCellsContentWidth)
        return;
      cell.Width = maxColumnCellsContentWidth;
    }

    private void SetTableAlignment(
      Xceed.Pdf.Layout.Table.Table pdfTable,
      XElement design,
      float marginLeft,
      float marginRight,
      float availableWidth)
    {
      if (pdfTable == null)
        return;
      pdfTable.Left += marginLeft;
      if (design == null)
        return;
      XElement xelement1 = design.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 == null)
        return;
      XElement xelement2 = xelement1.Element(XName.Get("jc", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 == null)
        return;
      XAttribute xattribute = xelement2.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute == null)
        return;
      switch (xattribute.Value)
      {
        case "right":
          pdfTable.Left = availableWidth - marginRight - pdfTable.Width;
          break;
        case "center":
          pdfTable.Left = (float) ((double) availableWidth / 2.0 - (double) pdfTable.Width / 2.0);
          break;
      }
    }

    private XElement GetWantedStyleFromStyleId(XElement design, string styleId)
    {
      if (string.IsNullOrEmpty(styleId))
        return design;
      XElement style = HelperFunctions.GetStyle(this._fileToConvert, styleId);
      if (style != null)
      {
        XElement xelement1 = style.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 != null)
        {
          XElement xelement2 = design.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
          if (xelement2 == null)
          {
            design.Add((object) new XElement(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName)));
            xelement2 = design.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
          }
          foreach (XElement element in xelement1.Elements())
          {
            XElement xelement3 = xelement2.Element(element.Name);
            if (xelement3 != null)
            {
              if (xelement3.Name.LocalName == "tblBorders" || xelement3.Name.LocalName == "tblCellMar")
              {
                foreach (XElement xelement4 in element.Descendants().ToList<XElement>())
                {
                  if (xelement3.Descendants(xelement4.Name).FirstOrDefault<XElement>() == null)
                    xelement3.Add((object) xelement4);
                }
              }
              else
              {
                foreach (XAttribute attribute in element.Attributes())
                {
                  if (xelement3.Attribute(attribute.Name) == null)
                    xelement3.Add((object) attribute);
                }
              }
            }
            else
              xelement2.Add((object) element);
          }
        }
        XElement xelement5 = style.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement5 != null)
        {
          XElement xelement2 = design.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
          if (xelement2 == null)
          {
            design.Add((object) new XElement(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName)));
            xelement2 = design.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
          }
          foreach (XElement element in xelement5.Elements())
          {
            XElement xelement3 = xelement2.Element(element.Name);
            if (xelement3 != null)
            {
              foreach (XAttribute attribute in element.Attributes())
              {
                if (xelement3.Attribute(attribute.Name) == null)
                  xelement3.Add((object) attribute);
              }
            }
            else
              xelement2.Add((object) element);
          }
        }
        XElement xelement6 = style.Element(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement6 != null)
        {
          XElement xelement2 = design.Element(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName));
          if (xelement2 == null)
          {
            design.Add((object) new XElement(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName)));
            xelement2 = design.Element(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName));
          }
          foreach (XElement element in xelement6.Elements())
          {
            XElement xelement3 = xelement2.Element(element.Name);
            if (xelement3 != null)
            {
              if (xelement3.Name.LocalName == "pBdr" || xelement3.Name.LocalName == "numPr")
              {
                foreach (XElement xelement4 in element.Descendants().ToList<XElement>())
                {
                  if (xelement3.Descendants(xelement4.Name).FirstOrDefault<XElement>() == null)
                    xelement3.Add((object) xelement4);
                }
              }
              else
              {
                foreach (XAttribute attribute in element.Attributes())
                {
                  if (xelement3.Attribute(attribute.Name) == null)
                    xelement3.Add((object) attribute);
                }
              }
            }
            else
              xelement2.Add((object) element);
          }
        }
        XElement xelement7 = style.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement7 != null)
        {
          XElement xelement2 = design.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
          if (xelement2 == null)
          {
            design.Add((object) new XElement(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)));
            xelement2 = design.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
          }
          foreach (XElement element in xelement7.Elements())
          {
            XElement xelement3 = xelement2.Element(element.Name);
            if (xelement3 != null)
            {
              foreach (XAttribute attribute in element.Attributes())
              {
                if (xelement3.Attribute(attribute.Name) == null)
                  xelement3.Add((object) attribute);
              }
            }
            else
              xelement2.Add((object) element);
          }
        }
        IEnumerable<XElement> source = style.Elements(XName.Get("tblStylePr", Xceed.Document.NET.Document.w.NamespaceName));
        if (source != null && source.Count<XElement>() > 0 && design.Element(XName.Get("tblStylePr", Xceed.Document.NET.Document.w.NamespaceName)) == null)
        {
          foreach (XElement xelement2 in source)
            design.Add((object) xelement2);
        }
        XElement el = style.Element(XName.Get("basedOn", Xceed.Document.NET.Document.w.NamespaceName));
        if (el != null)
          design = this.GetWantedStyleFromStyleId(design, el.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)));
      }
      return design;
    }

    private void SetTablePropertiesFromStyle(Xceed.Pdf.Layout.Table.Table pdfTable, XElement design)
    {
      if (pdfTable == null || design == null)
        return;
      XElement xelement1 = design.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 == null)
        return;
      XElement shd = xelement1.Element(XName.Get("shd", Xceed.Document.NET.Document.w.NamespaceName));
      if (shd != null)
        pdfTable.BackColor = this.GetBackgroundColor(shd);
      XElement xelement2 = xelement1.Element(XName.Get("tblBorders", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 != null)
      {
        Xceed.Pdf.Layout.Border pdfBorder1 = PdfConverter.WordsBorderToPdfBorder(HelperFunctions.GetBorderFromXml(xelement2.Element(XName.Get("top", Xceed.Document.NET.Document.w.NamespaceName))));
        Xceed.Pdf.Layout.Border pdfBorder2 = PdfConverter.WordsBorderToPdfBorder(HelperFunctions.GetBorderFromXml(xelement2.Element(XName.Get("left", Xceed.Document.NET.Document.w.NamespaceName))));
        Xceed.Pdf.Layout.Border pdfBorder3 = PdfConverter.WordsBorderToPdfBorder(HelperFunctions.GetBorderFromXml(xelement2.Element(XName.Get("right", Xceed.Document.NET.Document.w.NamespaceName))));
        Xceed.Pdf.Layout.Border pdfBorder4 = PdfConverter.WordsBorderToPdfBorder(HelperFunctions.GetBorderFromXml(xelement2.Element(XName.Get("bottom", Xceed.Document.NET.Document.w.NamespaceName))));
        this._insideHPdfBorder = PdfConverter.WordsBorderToPdfBorder(HelperFunctions.GetBorderFromXml(xelement2.Element(XName.Get("insideH", Xceed.Document.NET.Document.w.NamespaceName))));
        this._insideVPdfBorder = PdfConverter.WordsBorderToPdfBorder(HelperFunctions.GetBorderFromXml(xelement2.Element(XName.Get("insideV", Xceed.Document.NET.Document.w.NamespaceName))));
        pdfTable.Borders.SetBorders(pdfBorder2, pdfBorder1, pdfBorder3, pdfBorder4);
      }
      pdfTable.CellPaddings.Left = 5.75f;
      pdfTable.CellPaddings.Right = 5.75f;
      XElement xelement3 = xelement1.Element(XName.Get("tblCellMar", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement3 != null)
      {
        XElement node1 = xelement3.Element(XName.Get("left", Xceed.Document.NET.Document.w.NamespaceName));
        pdfTable.CellPaddings.Left = this.GetWidthValue(node1, pdfTable.CellPaddings.Left);
        XElement node2 = xelement3.Element(XName.Get("top", Xceed.Document.NET.Document.w.NamespaceName));
        pdfTable.CellPaddings.Top = this.GetWidthValue(node2, pdfTable.CellPaddings.Top);
        XElement node3 = xelement3.Element(XName.Get("right", Xceed.Document.NET.Document.w.NamespaceName));
        pdfTable.CellPaddings.Right = this.GetWidthValue(node3, pdfTable.CellPaddings.Right);
        XElement node4 = xelement3.Element(XName.Get("bottom", Xceed.Document.NET.Document.w.NamespaceName));
        pdfTable.CellPaddings.Bottom = this.GetWidthValue(node4, pdfTable.CellPaddings.Bottom);
      }
      XElement node5 = xelement1.Element(XName.Get("tblCellSpacing", Xceed.Document.NET.Document.w.NamespaceName));
      pdfTable.CellSpacings.SetSpacings(this.GetWidthValue(node5, 0.0f) * 2f);
      XElement node6 = xelement1.Element(XName.Get("tblInd", Xceed.Document.NET.Document.w.NamespaceName));
      pdfTable.Left += this.GetWidthValue(node6, 0.0f);
    }

    private Color GetBackgroundColor(XElement shd)
    {
      Color color = Color.White;
      XAttribute xattribute1 = shd.Attribute(XName.Get("fill", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute1 != null)
        color = HelperFunctions.GetColorFromHtml(xattribute1.Value);
      XAttribute xattribute2 = shd.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute2 != null)
      {
        XAttribute xattribute3 = shd.Attribute(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute3 != null && !string.IsNullOrEmpty(xattribute3.Value))
        {
          Color colorFromHtml = HelperFunctions.GetColorFromHtml(xattribute3.Value, "000000");
          switch (xattribute2.Value)
          {
            case "solid":
              color = colorFromHtml;
              break;
            case "clear":
              break;
            default:
              if (xattribute2.Value.Contains("pct"))
              {
                color = Color.FromArgb(int.Parse(xattribute2.Value.Substring(3, xattribute2.Value.Length - 3)) * (int) byte.MaxValue / 100, colorFromHtml);
                break;
              }
              break;
          }
        }
      }
      return color;
    }

    private float GetWidthValue(XElement node, float defaultValue)
    {
      if (node != null)
      {
        XAttribute xattribute = node.Attribute(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName));
        float result;
        if (xattribute != null && HelperFunctions.TryParseFloat(xattribute.Value, out result))
          return result / 20f;
      }
      return defaultValue;
    }

    private void SetCellPropertiesFromStyle(Xceed.Pdf.Layout.Table.Cell cell, XElement xml, Xceed.Pdf.Layout.Table.Table pdfTable, bool? isRow)
    {
      if (cell == null || xml == null || pdfTable == null)
        return;
      XElement shd = xml.Element(XName.Get("shd", Xceed.Document.NET.Document.w.NamespaceName));
      if (shd != null)
      {
        cell.BackColor = this.GetBackgroundColor(shd);
        this.UpdateCellContentColor(cell);
      }
      XElement xelement1 = xml.Element(XName.Get("tcBorders", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 != null)
      {
        int argb = Color.White.ToArgb();
        Border borderFromXml1 = HelperFunctions.GetBorderFromXml(!isRow.HasValue || isRow.Value ? xelement1.Element(XName.Get("top", Xceed.Document.NET.Document.w.NamespaceName)) : (XElement) null);
        Color color;
        Xceed.Pdf.Layout.Border border1;
        if ((double) cell.Spacings.Top > 0.0 && borderFromXml1 != null)
        {
          color = borderFromXml1.Color;
          if (color.ToArgb() == argb)
          {
            border1 = (Xceed.Pdf.Layout.Border) null;
            goto label_9;
          }
        }
        border1 = PdfConverter.WordsBorderToPdfBorder(borderFromXml1);
label_9:
        Xceed.Pdf.Layout.Border topBorder = border1;
        Border borderFromXml2 = HelperFunctions.GetBorderFromXml(!isRow.HasValue || !isRow.Value ? xelement1.Element(XName.Get("left", Xceed.Document.NET.Document.w.NamespaceName)) : (XElement) null);
        Xceed.Pdf.Layout.Border border2;
        if ((double) cell.Spacings.Left > 0.0 && borderFromXml2 != null)
        {
          color = borderFromXml2.Color;
          if (color.ToArgb() == argb)
          {
            border2 = (Xceed.Pdf.Layout.Border) null;
            goto label_13;
          }
        }
        border2 = PdfConverter.WordsBorderToPdfBorder(borderFromXml2);
label_13:
        Xceed.Pdf.Layout.Border leftBorder = border2;
        Border borderFromXml3 = HelperFunctions.GetBorderFromXml(!isRow.HasValue || !isRow.Value ? xelement1.Element(XName.Get("right", Xceed.Document.NET.Document.w.NamespaceName)) : (XElement) null);
        Xceed.Pdf.Layout.Border border3;
        if ((double) cell.Spacings.Right > 0.0 && borderFromXml3 != null)
        {
          color = borderFromXml3.Color;
          if (color.ToArgb() == argb)
          {
            border3 = (Xceed.Pdf.Layout.Border) null;
            goto label_17;
          }
        }
        border3 = PdfConverter.WordsBorderToPdfBorder(borderFromXml3);
label_17:
        Xceed.Pdf.Layout.Border rightBorder = border3;
        Border borderFromXml4 = HelperFunctions.GetBorderFromXml(!isRow.HasValue || isRow.Value ? xelement1.Element(XName.Get("bottom", Xceed.Document.NET.Document.w.NamespaceName)) : (XElement) null);
        Xceed.Pdf.Layout.Border border4;
        if ((double) cell.Spacings.Bottom > 0.0 && borderFromXml4 != null)
        {
          color = borderFromXml4.Color;
          if (color.ToArgb() == argb)
          {
            border4 = (Xceed.Pdf.Layout.Border) null;
            goto label_21;
          }
        }
        border4 = PdfConverter.WordsBorderToPdfBorder(borderFromXml4);
label_21:
        Xceed.Pdf.Layout.Border bottomBorder = border4;
        cell.Borders.SetBorders(leftBorder, topBorder, rightBorder, bottomBorder);
      }
      XElement node1 = xml.Element(XName.Get("tcW", Xceed.Document.NET.Document.w.NamespaceName));
      if (node1 != null)
      {
        XAttribute xattribute = node1.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null && xattribute.Value != "auto")
          cell.Width = this.GetWidthValue(node1, 0.0f);
      }
      XElement xelement2 = xml.Element(XName.Get("vAlign", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 != null)
      {
        XAttribute xattribute = xelement2.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null)
        {
          switch (xattribute.Value)
          {
            case "bottom":
              cell.VerticalAlignment = Xceed.Pdf.Layout.VerticalAlignment.Bottom;
              break;
            case "center":
              cell.VerticalAlignment = Xceed.Pdf.Layout.VerticalAlignment.Middle;
              break;
            case "top":
              cell.VerticalAlignment = Xceed.Pdf.Layout.VerticalAlignment.Top;
              break;
          }
        }
      }
      XElement xelement3 = xml.Element(XName.Get("tcMar", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement3 != null)
      {
        this.GetParentRow(cell);
        XElement node2 = xelement3.Element(XName.Get("left", Xceed.Document.NET.Document.w.NamespaceName));
        cell.Paddings.Left = this.GetWidthValue(node2, pdfTable.CellPaddings.Left);
        XElement node3 = xelement3.Element(XName.Get("top", Xceed.Document.NET.Document.w.NamespaceName));
        cell.Paddings.Top = this.GetWidthValue(node3, pdfTable.CellPaddings.Top);
        XElement node4 = xelement3.Element(XName.Get("right", Xceed.Document.NET.Document.w.NamespaceName));
        cell.Paddings.Right = this.GetWidthValue(node4, pdfTable.CellPaddings.Right);
        XElement node5 = xelement3.Element(XName.Get("bottom", Xceed.Document.NET.Document.w.NamespaceName));
        cell.Paddings.Bottom = this.GetWidthValue(node5, pdfTable.CellPaddings.Bottom);
      }
      XElement xelement4 = xml.Element(XName.Get("gridSpan", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement4 != null)
      {
        XAttribute xattribute = xelement4.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null)
          cell.GridSpan = int.Parse(xattribute.Value);
      }
      XElement xelement5 = xml.Element(XName.Get("vMerge", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement5 == null)
        return;
      XAttribute xattribute1 = xelement5.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
      cell.VMerge = xattribute1 != null ? xattribute1.Value : "continue";
    }

    private void SetRowPropertiesFromStyle(Xceed.Pdf.Layout.Table.Row row, XElement xml)
    {
      if (row == null | xml == null)
        return;
      XElement xelement1 = xml.Element(XName.Get("trHeight", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 != null)
      {
        XAttribute xattribute1 = xelement1.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        float result;
        if (xattribute1 != null && HelperFunctions.TryParseFloat(xattribute1.Value, out result))
        {
          row.Height = result / 20f;
          XAttribute xattribute2 = xelement1.Attribute(XName.Get("hRule", Xceed.Document.NET.Document.w.NamespaceName));
          row.HeightIsFixed = xattribute2 != null && xattribute2.Value == "exact";
        }
      }
      XElement xelement2 = xml.Element(XName.Get("cantSplit", Xceed.Document.NET.Document.w.NamespaceName));
      row.CantSplit = xelement2 != null;
      XElement xelement3 = xml.Element(XName.Get("tblHeader", Xceed.Document.NET.Document.w.NamespaceName));
      row.IsTableHeader = xelement3 != null;
    }

    private void UpdateCellContentColor(Xceed.Pdf.Layout.Table.Cell cell)
    {
      //if (cell == null || cell.Content == null || cell.Content.Buffer == null)
      //  return;
      //Color backColor = cell.BackColor;
      //if (cell.BackColor.A < (byte) 204 || cell.BackColor.R != (byte) 0 || (cell.BackColor.G != (byte) 0 || cell.BackColor.B != (byte) 0))
      //  return;
      //foreach (Xceed.Pdf.Layout.Block block in cell.Content.Buffer)
      //{
      //  if (block is Xceed.Pdf.Layout.Text.Text text && text.Atoms != null && text.Atoms.Buffer != null)
      //  {
      //    foreach (Atom atom in text.Atoms.Buffer)
      //    {
      //      if (atom is CharAtom charAtom && charAtom.Style != null && (charAtom.Style.Brush != null && charAtom.Style.Brush is SolidBrush brush))
      //      {
      //        brush.Color();
      //        if (brush.Color().R == (byte) 0 && brush.Color().G == (byte) 0 && brush.Color().B == (byte) 0)
      //          charAtom.Style.Brush = (Brush) new SolidBrush(Color.White);
      //      }
      //    }
      //  }
      //}
    }

    private Xceed.Pdf.Layout.Table.Row GetParentRow(Xceed.Pdf.Layout.Table.Cell cell)
    {
      for (int index1 = 0; index1 < cell.Table.Rows.Size; ++index1)
      {
        for (int index2 = 0; index2 < cell.Table.Rows[index1].Cells.Size; ++index2)
        {
          if (cell.Table.Rows[index1].Cells[index2].Equals((object) cell))
            return cell.Table.Rows[index1];
        }
      }
      return (Xceed.Pdf.Layout.Table.Row) null;
    }

    private bool CanDisplaySplitRowContent(Xceed.Pdf.Layout.Table.Row row, float remainingRowHeight)
    {
      if (row == null)
        return false;
      for (int index = 0; index < row.Cells.Size; ++index)
      {
        Xceed.Pdf.Layout.Table.Cell cell = row.Cells[index];
        if (cell.Content != null && cell.Content.Buffer != null && ((IEnumerable<Xceed.Pdf.Layout.Block>) cell.Content.Buffer).Count<Xceed.Pdf.Layout.Block>() > 0 && ((double) ((IEnumerable<Xceed.Pdf.Layout.Block>) cell.Content.Buffer).Where<Xceed.Pdf.Layout.Block>((Func<Xceed.Pdf.Layout.Block, bool>) (b => b != null)).Select<Xceed.Pdf.Layout.Block, float>((Func<Xceed.Pdf.Layout.Block, float>) (b => b.Height)).Sum() >= (double) remainingRowHeight && cell.Content.Buffer[0] is Xceed.Pdf.Layout.Text.Text text && (text.Lines.Size > 0 && (double) text.Lines[0].Height <= (double) remainingRowHeight)))
          return true;
      }
      return false;
    }

    private float GetTotalRowsHeight()
    {
      float num = 0.0f;
      for (int index = 0; index < this.Table.Rows.Size; ++index)
        num += Xceed.Pdf.Layout.Table.Table.GetRowHeight(this.Table.Rows[index]);
      return num;
    }

    private bool IsParagraphInCurrentTable(Paragraph p) => object.Equals((object) p.Xml.Ancestors(XName.Get("tbl", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>(), (object) this._table.Xml);

    private List<XElement> GetCellInitialTables(Cell cell)
    {
      if (cell == null)
        return (List<XElement>) null;
      List<XElement> xelementList = (List<XElement>) null;
      IEnumerator<XElement> enumerator = cell.Xml.Elements().GetEnumerator();
      enumerator.MoveNext();
      XElement current;
      for (current = enumerator.Current; current != null && current.Name.LocalName.Contains("Pr"); current = enumerator.Current)
        enumerator.MoveNext();
      for (; current != null && current.Name.LocalName == "tbl"; current = enumerator.Current)
      {
        if (xelementList == null)
          xelementList = new List<XElement>();
        xelementList.Add(current);
        enumerator.MoveNext();
      }
      return xelementList;
    }
  }
}
