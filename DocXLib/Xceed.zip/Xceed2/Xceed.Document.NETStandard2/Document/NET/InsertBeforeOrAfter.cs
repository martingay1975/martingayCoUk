﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.InsertBeforeOrAfter
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO.Packaging;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents the base class for DocumentElements that support the ablity to insert new
  /// DocumentElements before or after the current DocumentElement.</summary>
  public abstract class InsertBeforeOrAfter : DocumentElement
  {
    public InsertBeforeOrAfter(Xceed.Document.NET.Document document, XElement xml)
      : base(document, xml)
    {
    }

    /// <summary>Inserts a page break before the current object.</summary>
    public virtual void InsertPageBreakBeforeSelf() => this.Xml.AddBeforeSelf((object) new XElement(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("br", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName), (object) "page")))));

    /// <summary>Inserts a page break after the current object.</summary>
    public virtual void InsertPageBreakAfterSelf() => this.Xml.AddAfterSelf((object) new XElement(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("br", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName), (object) "page")))));

    /// <summary>Inserts an incremental caption text under the current picture, table or paragraph.</summary>
    /// <returns>The new paragraph with the inserted text.</returns>
    /// <param name="captionText">The caption text to insert.</param>
    public virtual Paragraph InsertCaptionAfterSelf(string captionText)
    {
      Paragraph paragraph = this.InsertParagraphAfterSelf(captionText + " ");
      paragraph.StyleId = "Caption";
      XElement xelement1 = new XElement(XName.Get("fldSimple", Xceed.Document.NET.Document.w.NamespaceName));
      xelement1.Add((object) new XAttribute(XName.Get("instr", Xceed.Document.NET.Document.w.NamespaceName), (object) (" SEQ " + captionText + " \\* ARABIC ")));
      XElement xelement2 = XElement.Parse(string.Format("<w:r xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">\r\n           <w:rPr>\r\n              <w:noProof /> \r\n           </w:rPr>\r\n           <w:t>{0}</w:t> \r\n         </w:r>", (object) (this.Document.Xml.Descendants(XName.Get("fldSimple", Xceed.Document.NET.Document.w.NamespaceName)).Where<XElement>((Func<XElement, bool>) (field => field != null && field.GetAttribute(XName.Get("instr", Xceed.Document.NET.Document.w.NamespaceName)) != null && field.GetAttribute(XName.Get("instr", Xceed.Document.NET.Document.w.NamespaceName)).StartsWith(" SEQ " + captionText))).Count<XElement>() + 1)));
      xelement1.Add((object) xelement2);
      paragraph.Xml.Add((object) xelement1);
      return paragraph;
    }

    /// <summary>Inserts the provided Paragraph before the current
    /// object.</summary>
    /// <returns>The new Paragraph that was inserted.</returns>
    /// <param name="p">The Paragraph to insert.</param>
    public virtual Paragraph InsertParagraphBeforeSelf(Paragraph p)
    {
      this.Xml.AddBeforeSelf((object) p.Xml);
      XElement xelement = this.Xml.ElementsBeforeSelf().First<XElement>();
      p.Xml = xelement;
      return p;
    }

    /// <summary>Inserts the provided Paragraph after the current object.</summary>
    /// <returns>The new Paragraph that was inserted.</returns>
    /// <param name="p">The Paragraph to insert.</param>
    public virtual Paragraph InsertParagraphAfterSelf(Paragraph p)
    {
      this.Xml.AddAfterSelf((object) p.Xml);
      XElement xml = this.Xml.ElementsAfterSelf().First<XElement>();
      if (this is Paragraph)
        return new Paragraph(this.Document, xml, (this as Paragraph)._endIndex);
      p.Xml = xml;
      return p;
    }

    /// <summary>Inserts a Paragraph before the current object, using the
    /// provided text.</summary>
    /// <returns>The new Paragraph that was inserted.</returns>
    /// <param name="text">The text for the new Paragraph.</param>
    public virtual Paragraph InsertParagraphBeforeSelf(string text) => this.InsertParagraphBeforeSelf(text, false, new Formatting());

    /// <summary>Inserts a Paragraph after the current object, using the
    /// provided text.</summary>
    /// <returns>The new Paragraph that was inserted.</returns>
    /// <param name="text">The text for the new Paragraph.</param>
    public virtual Paragraph InsertParagraphAfterSelf(string text) => this.InsertParagraphAfterSelf(text, false, new Formatting());

    /// <summary>Inserts a Paragraph before the current object, using the
    /// provided text, and optionally track this change.</summary>
    /// <returns>The new Paragraph that was inserted.</returns>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public virtual Paragraph InsertParagraphBeforeSelf(string text, bool trackChanges) => this.InsertParagraphBeforeSelf(text, trackChanges, new Formatting());

    /// <summary>Inserts a Paragraph after the current object, using the
    /// provided text, and optionally track this change.</summary>
    /// <returns>The new Paragraph that was inserted.</returns>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public virtual Paragraph InsertParagraphAfterSelf(string text, bool trackChanges) => this.InsertParagraphAfterSelf(text, trackChanges, new Formatting());

    /// <summary>Inserts a Paragraph before the current object, using the
    /// provided text and formatting, and optionally track this change.</summary>
    /// <returns>The new Paragraph that was inserted.</returns>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="formatting">The format to apply to the new Paragraph.</param>
    public virtual Paragraph InsertParagraphBeforeSelf(
      string text,
      bool trackChanges,
      Formatting formatting)
    {
      XElement xelement = new XElement(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
      {
        (object) new XElement(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName)),
        (object) HelperFunctions.FormatInput(text, formatting.Xml)
      });
      if (trackChanges)
        xelement = Paragraph.CreateEdit(EditType.ins, DateTime.Now, (object) xelement);
      this.Xml.AddBeforeSelf((object) xelement);
      return new Paragraph(this.Document, this.Xml.ElementsBeforeSelf().Last<XElement>(), -1);
    }

    /// <summary>Inserts a Paragraph after the current object, using the
    /// provided text and formatting, and optionally track this change.</summary>
    /// <returns>The new Paragraph that was inserted.</returns>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="formatting">The format to apply to the new Paragraph.</param>
    public virtual Paragraph InsertParagraphAfterSelf(
      string text,
      bool trackChanges,
      Formatting formatting)
    {
      XElement xelement = new XElement(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
      {
        (object) new XElement(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName)),
        (object) HelperFunctions.FormatInput(text, formatting.Xml)
      });
      if (trackChanges)
        xelement = Paragraph.CreateEdit(EditType.ins, DateTime.Now, (object) xelement);
      this.Xml.AddAfterSelf((object) xelement);
      return new Paragraph(this.Document, this.Xml.ElementsAfterSelf().First<XElement>(), -1);
    }

    /// <summary>Inserts a Table of a specific size after the current object.</summary>
    /// <returns>The new Table that was inserted.</returns>
    /// <param name="rowCount">The row count for the new Table.</param>
    /// <param name="columnCount">The column count for the new Table.</param>
    public virtual Table InsertTableAfterSelf(int rowCount, int columnCount)
    {
      this.Xml.AddAfterSelf((object) HelperFunctions.CreateTable(rowCount, columnCount));
      Table table = new Table(this.Document, this.Xml.ElementsAfterSelf().First<XElement>(), this.Document.PackagePart);
      table.PackagePart = this.PackagePart;
      return table;
    }

    /// <summary>Inserts the provided Table after the current object.</summary>
    /// <returns>The new Table that was inserted.</returns>
    /// <param name="t">The Table to insert.</param>
    public virtual Table InsertTableAfterSelf(Table t)
    {
      this.AddMissingPicturesInDocument(t);
      this.Xml.AddAfterSelf((object) t.Xml);
      Table table = new Table(this.Document, this.Xml.ElementsAfterSelf().First<XElement>(), this.Document.PackagePart);
      table.PackagePart = this.PackagePart;
      return table;
    }

    /// <summary>Inserts a Table of a specific size before the current
    /// object.</summary>
    /// <returns>The new Table that was inserted.</returns>
    /// <param name="rowCount">The row count for the new Table.</param>
    /// <param name="columnCount">The column count for the new Table.</param>
    public virtual Table InsertTableBeforeSelf(int rowCount, int columnCount)
    {
      this.Xml.AddBeforeSelf((object) HelperFunctions.CreateTable(rowCount, columnCount));
      Table table = new Table(this.Document, this.Xml.ElementsBeforeSelf().Last<XElement>(), this.Document.PackagePart);
      table.PackagePart = this.PackagePart;
      return table;
    }

    /// <summary>Inserts the provided Table before the current object.</summary>
    /// <returns>The new Table that was inserted.</returns>
    /// <param name="t">The Table to insert.</param>
    public virtual Table InsertTableBeforeSelf(Table t)
    {
      this.AddMissingPicturesInDocument(t);
      this.Xml.AddBeforeSelf((object) t.Xml);
      Table table = new Table(this.Document, this.Xml.ElementsBeforeSelf().Last<XElement>(), this.Document.PackagePart);
      table.PackagePart = this.PackagePart;
      return table;
    }

    /// <summary>Inserts a defined List after the current object.</summary>
    /// <returns>The new List that was inserted.</returns>
    /// <param name="list">The List to insert.</param>
    public virtual List InsertListAfterSelf(List list)
    {
      for (int index = list.Items.Count - 1; index >= 0; --index)
        this.Xml.AddAfterSelf((object) list.Items[index].Xml);
      return list;
    }

    /// <summary>Inserts a defined List before the current object.</summary>
    /// <returns>The new List that was inserted.</returns>
    /// <param name="list">The List to insert.</param>
    public virtual List InsertListBeforeSelf(List list)
    {
      foreach (DocumentElement documentElement in list.Items)
        this.Xml.AddBeforeSelf((object) documentElement.Xml);
      return list;
    }

    private void AddMissingPicturesInDocument(Table t)
    {
      if (t == null)
        return;
      foreach (Paragraph paragraph in t.Paragraphs)
      {
        if (paragraph.Pictures.Count > 0)
        {
          foreach (Picture picture1 in paragraph.Pictures)
          {
            bool flag = false;
            using (IEnumerator<PackageRelationship> enumerator = this.Document.PackagePart.GetRelationshipsByType("http://schemas.openxmlformats.org/officeDocument/2006/relationships/image").GetEnumerator())
            {
              while (((IEnumerator) enumerator).MoveNext())
              {
                if (enumerator.Current.TargetUri.ToString().Contains(picture1.FileName))
                {
                  flag = true;
                  break;
                }
              }
            }
            if (!flag)
            {
              Picture picture2 = this.Document.AddImage(picture1.Stream, "image/jpeg").CreatePicture(picture1.Height, picture1.Width);
              paragraph.PackagePart = this.Document.PackagePart;
              paragraph.ReplacePicture(picture1, picture2);
            }
          }
        }
      }
    }
  }
}
