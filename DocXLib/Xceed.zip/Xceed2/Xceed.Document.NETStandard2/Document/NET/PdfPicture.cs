﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfPicture
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Xml.Linq;
using Xceed.Pdf.Utils;

namespace Xceed.Document.NET
{
  internal class PdfPicture : PdfParagraphPart
  {
    private static Dictionary<Picture, Image> _pdfDrawnPicturesDictionary;
    private Picture _picture;

    internal PdfPicture(PdfParagraph p, Picture picture)
      : base(p)
      => this._picture = picture != null ? picture : throw new ArgumentNullException(nameof (picture));

    internal override void UpdateText(Xceed.Pdf.Layout.Text.Text text, bool isMeasuring = false)
    {
      //switch (PdfUtils.GetWrapping((DocumentElement) this._picture))
      //{
      //  case WrappingType.WrapInLineWithText:
      //    Image image = PdfPicture.GetImage(this._pdfParagraph.GetCurrentSection(), this._picture);
      //    if (this._picture.IsJpegImage())
      //    {
      //      text.AddContent(image, this._picture.Width, this._picture.Height, (ImageCompressor) new JPEGImageCompressor());
      //      break;
      //    }
      //    text.AddContent(image, this._picture.Width, this._picture.Height);
      //    break;
      //}
    }

    internal static Image GetImage(Section currentSection, Picture picture)
    {
            return (Image)null;
      //try
      //{
      //  if (PdfPicture._pdfDrawnPicturesDictionary == null)
      //    PdfPicture._pdfDrawnPicturesDictionary = new Dictionary<Picture, Image>();
      //  Picture key = ((IEnumerable<Picture>) PdfPicture._pdfDrawnPicturesDictionary.Keys).FirstOrDefault<Picture>((Func<Picture, bool>) (x => x.Id == picture.Id && x.FileName == picture.FileName));
      //  if (key != null)
      //    return PdfPicture._pdfDrawnPicturesDictionary[key];
      //  PackageRelationship imageRelationship = PdfPicture.GetImageRelationship(currentSection, picture.Id, picture.FileName);
      //  if (imageRelationship == null)
      //    return (Image) null;
      //  Uri targetUri = imageRelationship.TargetUri;
      //  Uri uri = PackUriHelper.ResolvePartUri(imageRelationship.SourceUri(), targetUri);
      //  Image image = Image.FromStream((Stream) new PackagePartStream(imageRelationship.Package().GetPart(uri).GetStream()));
      //  Bitmap bitmap = new Bitmap(image.Width(), image.Height());
      //  using (Graphics graphics = Graphics.FromImage((Image) bitmap))
      //  {
      //    graphics.Clear(Color.White);
      //    graphics.TranslateTransform((float) (image.Width() / 2), (float) (image.Height() / 2));
      //    graphics.RotateTransform((float) picture.Rotation);
      //    graphics.TranslateTransform((float) (-image.Width() / 2), (float) (-image.Height() / 2));
      //    graphics.set_InterpolationMode((InterpolationMode) 2);
      //    graphics.set_SmoothingMode((SmoothingMode) 2);
      //    graphics.set_PixelOffsetMode((PixelOffsetMode) 2);
      //    if (picture.Cropping != null)
      //    {
      //      int int32_1 = Convert.ToInt32(picture.Cropping.Left / 100f * (float) image.Width());
      //      int int32_2 = Convert.ToInt32(picture.Cropping.Top / 100f * (float) image.Height());
      //      int int32_3 = Convert.ToInt32((float) image.Width() - picture.Cropping.Right / 100f * (float) image.Width() - (float) int32_1);
      //      int int32_4 = Convert.ToInt32((float) image.Height() - picture.Cropping.Bottom / 100f * (float) image.Height() - (float) int32_2);
      //      graphics.DrawImage(image, new Rectangle(0, 0, image.Width(), image.Height()), new Rectangle(int32_1, int32_2, int32_3, int32_4), (GraphicsUnit) 2);
      //    }
      //    else
      //      graphics.DrawImage(image, 0.0f, 0.0f, (float) image.Width(), (float) image.Height());
      //  }
      //  PdfPicture._pdfDrawnPicturesDictionary.Add(picture, (Image) bitmap);
      //  return (Image) bitmap;
      //}
      //catch (Exception ex)
      //{
      //  return (Image) null;
      //}
        }

    internal static RectangleF GetDimensions(
      Section currentSection,
      PdfPageInfo currentPdfPageInfo,
      Picture picture)
    {
      if (currentSection == null)
        throw new ArgumentNullException(nameof (currentSection));
      if (currentPdfPageInfo == null)
        throw new ArgumentNullException(nameof (currentPdfPageInfo));
      if (picture == null)
        throw new ArgumentNullException(nameof (picture));
      double positionX = (double) PdfUtils.GetPositionX(currentSection, currentPdfPageInfo, (DocumentElement) picture);
      float positionY = PdfUtils.GetPositionY(currentSection, currentPdfPageInfo, (DocumentElement) picture);
      float width = picture.Width;
      float height = picture.Height;
      double num1 = (double) positionY;
      double num2 = (double) width;
      double num3 = (double) height;
      return new RectangleF((float) positionX, (float) num1, (float) num2, (float) num3);
    }

    internal static string GetPictureIdFromXElement(XElement xElement)
    {
      if (xElement == null)
        throw new NullReferenceException(nameof (xElement));
      XElement xelement1 = xElement.Element(XName.Get("drawing", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 != null)
      {
        XElement el = xelement1.Descendants(XName.Get("blip", Xceed.Document.NET.Document.a.NamespaceName)).FirstOrDefault<XElement>();
        if (el != null)
          return el.GetAttribute(XName.Get("embed", Xceed.Document.NET.Document.r.NamespaceName));
      }
      XElement xelement2 = xElement.Element(XName.Get("pict", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 != null)
      {
        XElement el = xelement2.Descendants(XName.Get("imagedata", Xceed.Document.NET.Document.v.NamespaceName)).FirstOrDefault<XElement>();
        if (el != null)
          return el.GetAttribute(XName.Get("id", Xceed.Document.NET.Document.r.NamespaceName));
      }
      return (string) null;
    }

    internal static void CleanPictures() => PdfPicture._pdfDrawnPicturesDictionary = (Dictionary<Picture, Image>) null;

    private static PackageRelationship GetImageRelationship(
      Section currentSection,
      string pictureId,
      string pictureFileName)
    {
      if (currentSection == null || pictureFileName == null)
        return (PackageRelationship) null;
      PackageRelationship relationshipCore1 = PdfPicture.GetImageRelationshipCore(currentSection.Document.PackagePart, pictureId);
      if (relationshipCore1 != null && relationshipCore1.TargetUri != (Uri) null && (relationshipCore1.TargetUri.OriginalString != null && relationshipCore1.TargetUri.OriginalString.Contains(pictureFileName)))
        return relationshipCore1;
      if (currentSection.Headers.First != null)
      {
        PackageRelationship relationshipCore2 = PdfPicture.GetImageRelationshipCore(currentSection.Headers.First.PackagePart, pictureId);
        if (relationshipCore2 != null && relationshipCore2.TargetUri != (Uri) null && (relationshipCore2.TargetUri.OriginalString != null && relationshipCore2.TargetUri.OriginalString.Contains(pictureFileName)))
          return relationshipCore2;
      }
      if (currentSection.Headers.Odd != null)
      {
        PackageRelationship relationshipCore2 = PdfPicture.GetImageRelationshipCore(currentSection.Headers.Odd.PackagePart, pictureId);
        if (relationshipCore2 != null && relationshipCore2.TargetUri != (Uri) null && (relationshipCore2.TargetUri.OriginalString != null && relationshipCore2.TargetUri.OriginalString.Contains(pictureFileName)))
          return relationshipCore2;
      }
      if (currentSection.Headers.Even != null)
      {
        PackageRelationship relationshipCore2 = PdfPicture.GetImageRelationshipCore(currentSection.Headers.Even.PackagePart, pictureId);
        if (relationshipCore2 != null && relationshipCore2.TargetUri != (Uri) null && (relationshipCore2.TargetUri.OriginalString != null && relationshipCore2.TargetUri.OriginalString.Contains(pictureFileName)))
          return relationshipCore2;
      }
      if (currentSection.Footers.First != null)
      {
        PackageRelationship relationshipCore2 = PdfPicture.GetImageRelationshipCore(currentSection.Footers.First.PackagePart, pictureId);
        if (relationshipCore2 != null && relationshipCore2.TargetUri != (Uri) null && (relationshipCore2.TargetUri.OriginalString != null && relationshipCore2.TargetUri.OriginalString.Contains(pictureFileName)))
          return relationshipCore2;
      }
      if (currentSection.Footers.Odd != null)
      {
        PackageRelationship relationshipCore2 = PdfPicture.GetImageRelationshipCore(currentSection.Footers.Odd.PackagePart, pictureId);
        if (relationshipCore2 != null && relationshipCore2.TargetUri != (Uri) null && (relationshipCore2.TargetUri.OriginalString != null && relationshipCore2.TargetUri.OriginalString.Contains(pictureFileName)))
          return relationshipCore2;
      }
      if (currentSection.Footers.Even != null)
      {
        PackageRelationship relationshipCore2 = PdfPicture.GetImageRelationshipCore(currentSection.Footers.Even.PackagePart, pictureId);
        if (relationshipCore2 != null && relationshipCore2.TargetUri != (Uri) null && (relationshipCore2.TargetUri.OriginalString != null && relationshipCore2.TargetUri.OriginalString.Contains(pictureFileName)))
          return relationshipCore2;
      }
      return (PackageRelationship) null;
    }

    private static PackageRelationship GetImageRelationshipCore(
      PackagePart packagePart,
      string pictureId)
    {
      if (packagePart == null)
        return (PackageRelationship) null;
      if (((IEnumerable<PackageRelationship>) packagePart.GetRelationshipsByType("http://schemas.openxmlformats.org/officeDocument/2006/relationships/image")).Count<PackageRelationship>() > 0 && packagePart.RelationshipExists(pictureId))
      {
        PackageRelationship relationship = packagePart.GetRelationship(pictureId);
        if (relationship.RelationshipType == "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image")
          return relationship;
      }
      return (PackageRelationship) null;
    }
  }
}
