﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfConverter
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Xml.Linq;
using Xceed.Pdf;
using Xceed.Pdf.Atoms;
using Xceed.Pdf.Layout;
using Xceed.Pdf.Layout.Table;
using Xceed.Pdf.Layout.Text.Atoms;
using Xceed.Pdf.Utils;

namespace Xceed.Document.NET
{
  internal class PdfConverter : PdfIDrawContent, PdfIConverter
  {
    internal static Dictionary<string, XYZDestination> _hyperlinkAnchorsDictionary = new Dictionary<string, XYZDestination>();
    internal static List<PdfPageNumberParagraphInfo> _pageNumberParagraphs = new List<PdfPageNumberParagraphInfo>();
    private static int _calculatedTotalPageNumber = -1;
    private static List<PdfExternalFont> _externalFonts = new List<PdfExternalFont>();
    private Xceed.Document.NET.Document _fileToConvert;
    private PdfPageInfo _currentPdfPageInfo;
    private Xceed.Pdf.Document _outputPdfDocument;
    private string _outputFilName;
    private System.IO.Stream _outputPdfStream;
    private List<PdfParagraph> _waitingToBeDrawnPdfParagraphList;
    private string _fileToConvertBackground;
    private int _currentSection;
    private const float ListItemIndentCoefficient = 360f;

    internal PdfConverter(
      Xceed.Document.NET.Document fileToConvert,
      string outputFileName,
      List<PdfExternalFont> externalFonts)
      : this(fileToConvert, externalFonts)
    {
      if (string.IsNullOrEmpty(outputFileName))
        throw new ArgumentNullException(nameof (outputFileName));
      this._outputFilName = outputFileName.EndsWith(".pdf") ? outputFileName : outputFileName + ".pdf";
    }

    internal PdfConverter(
      Xceed.Document.NET.Document fileToConvert,
      System.IO.Stream outputStream,
      List<PdfExternalFont> externalFonts)
      : this(fileToConvert, externalFonts)
    {
      this._outputPdfStream = outputStream != null ? outputStream : throw new ArgumentNullException(nameof (outputStream));
    }

    private PdfConverter(Xceed.Document.NET.Document fileToConvert, List<PdfExternalFont> externalFonts)
    {
      Licenser.VerifyLicense();
      this._fileToConvert = fileToConvert != null ? fileToConvert.Copy() : throw new ArgumentNullException(nameof (fileToConvert));
      this._outputPdfDocument = new Xceed.Pdf.Document();
      this._outputPdfDocument.Options = DocumentOption.SubsetFonts | DocumentOption.Compress;
      if (externalFonts != null)
        PdfConverter._externalFonts = externalFonts;
      this.SetDocumentProperties(this._outputPdfDocument);
      this.ResetPdfData();
    }

    internal static Xceed.Pdf.Layout.Border WordsBorderToPdfBorder(Border wordsBorder)
    {
            return (Xceed.Pdf.Layout.Border)null;
      //      if (wordsBorder == null)
      //  return (Xceed.Pdf.Layout.Border) null;
      //float single = System.Convert.ToSingle(Border.GetNumericSize(wordsBorder.Size));
      //DashStyle dashStyle = (DashStyle) 0;
      //float[] dashPattern = (float[]) null;
      //bool isDouble = false;
      //switch (wordsBorder.Tcbs)
      //{
      //  case BorderStyle.Tcbs_single:
      //    dashStyle = (DashStyle) 0;
      //    break;
      //  case BorderStyle.Tcbs_double:
      //    dashStyle = (DashStyle) 0;
      //    isDouble = true;
      //    break;
      //  case BorderStyle.Tcbs_dotted:
      //    dashStyle = (DashStyle) 2;
      //    break;
      //  case BorderStyle.Tcbs_dashed:
      //    dashStyle = (DashStyle) 5;
      //    dashPattern = new float[2]{ 4f, 4f };
      //    break;
      //  case BorderStyle.Tcbs_dotDash:
      //    dashStyle = (DashStyle) 3;
      //    break;
      //  case BorderStyle.Tcbs_dotDotDash:
      //    dashStyle = (DashStyle) 4;
      //    break;
      //  case BorderStyle.Tcbs_dashSmallGap:
      //    dashStyle = (DashStyle) 5;
      //    dashPattern = new float[2]{ 3f, 2f };
      //    break;
      //  case BorderStyle.Tcbs_nil:
      //    wordsBorder.Color = Color.Transparent;
      //    break;
      //}
      //return wordsBorder.Tcbs != BorderStyle.Tcbs_none ? new Xceed.Pdf.Layout.Border(single / 8f, wordsBorder.Color, wordsBorder.Space, dashStyle, dashPattern, isDouble) : (Xceed.Pdf.Layout.Border) null;
    }

    internal static bool IsTotalPageNumberCalculated() => PdfConverter._calculatedTotalPageNumber != -1;

    internal static int GetTotalPageNumberCalculated() => PdfConverter._calculatedTotalPageNumber;

    internal static List<PdfExternalFont> GetExternalFonts() => PdfConverter._externalFonts;

    internal Xceed.Pdf.Document Convert()
    {
      this.ValidateConversion();
      this._waitingToBeDrawnPdfParagraphList = new List<PdfParagraph>();
      this.UpdateParagraphsFromStyles();
      this.UpdateTOC();
      this._fileToConvertBackground = this.GetFileToConvertBackground();
      this.AddPage();
      this.CreatePdfParagraphs((IEnumerable<Paragraph>) this._fileToConvert.Paragraphs.Where<Paragraph>((Func<Paragraph, bool>) (x => x.ParentContainer != ContainerType.Cell && x.ParentContainer != ContainerType.Shape)).ToList<Paragraph>());
      this.DrawInFrontOfTextWrappedObjects();
      this.DrawEndnotes(this._currentPdfPageInfo.FooterHeight);
      this.DrawFootnotes(this._currentPdfPageInfo.FooterHeight);
      PdfConverter._calculatedTotalPageNumber = this._currentPdfPageInfo.PageNumber;
      this.DrawPageNumberParagraphs();
      this._currentPdfPageInfo.Page.Graphics.Flush();
      if (this._outputFilName != null)
        this._outputPdfDocument.Generate(this._outputFilName);
      else if (this._outputPdfStream != null && this._outputPdfStream.CanSeek)
      {
        this._outputPdfStream.SetLength(0L);
        this._outputPdfStream.Position = 0L;
        this._outputPdfDocument.Generate(this._outputPdfStream);
      }
      return this._outputPdfDocument;
    }

    private void SetDocumentProperties(Xceed.Pdf.Document document)
    {
      if (document == null)
        return;
      string key1 = this._fileToConvert.CoreProperties.Keys.FirstOrDefault<string>((Func<string, bool>) (k => k.Contains("title")));
      if (key1 != null)
        this._outputPdfDocument.Info.Title = this._fileToConvert.CoreProperties[key1];
      string key2 = this._fileToConvert.CoreProperties.Keys.FirstOrDefault<string>((Func<string, bool>) (k => k.Contains("subject")));
      if (key2 != null)
        this._outputPdfDocument.Info.Subject = this._fileToConvert.CoreProperties[key2];
      string key3 = this._fileToConvert.CoreProperties.Keys.FirstOrDefault<string>((Func<string, bool>) (k => k.Contains("creator")));
      if (key3 != null)
        this._outputPdfDocument.Info.Author = this._fileToConvert.CoreProperties[key3];
      string key4 = this._fileToConvert.CoreProperties.Keys.FirstOrDefault<string>((Func<string, bool>) (k => k.Contains("keywords")));
      if (key4 != null)
        this._outputPdfDocument.Info.Keywords = this._fileToConvert.CoreProperties[key4];
      string key5 = this._fileToConvert.CoreProperties.Keys.FirstOrDefault<string>((Func<string, bool>) (k => k.Contains("created")));
      if (key5 != null)
        this._outputPdfDocument.Info.Created = System.Convert.ToDateTime(this._fileToConvert.CoreProperties[key5]);
      string key6 = this._fileToConvert.CoreProperties.Keys.FirstOrDefault<string>((Func<string, bool>) (k => k.Contains("modified")));
      if (key6 != null)
        this._outputPdfDocument.Info.Modified = System.Convert.ToDateTime(this._fileToConvert.CoreProperties[key6]);
      foreach (KeyValuePair<string, CustomProperty> customProperty in this._fileToConvert.CustomProperties)
        this._outputPdfDocument.Info.AddProperty(customProperty.Key, customProperty.Value.Value.ToString());
    }

    private void ResetPdfData()
    {
      PdfListItem.CleanListsInfo();
      PdfFootnote.CleanFootnotes();
      PdfEndnote.CleanEndnotes();
      PdfPicture.CleanPictures();
      PdfConverter._hyperlinkAnchorsDictionary.Clear();
      PdfConverter._pageNumberParagraphs.Clear();
      PdfConverter._calculatedTotalPageNumber = -1;
    }

    private void ValidateConversion()
    {
    }

    private bool IsSectionStartingWithTable()
    {
      XElement fromCurrentSection = this.GetFirstElementFromCurrentSection();
      return fromCurrentSection != null && fromCurrentSection.Name.LocalName == "tbl";
    }

    private XElement GetFirstElementFromCurrentSection()
    {
      if (this._currentSection > 0)
      {
        List<XElement> list = this._fileToConvert._mainDoc.Root.Element(XName.Get("body", Xceed.Document.NET.Document.w.NamespaceName)).Descendants(XName.Get("sectPr", Xceed.Document.NET.Document.w.NamespaceName)).ToList<XElement>();
        if (list != null && this._currentSection < list.Count<XElement>())
        {
          XElement parent = list[this._currentSection - 1].Parent.Parent;
          if (parent != null)
            return parent.ElementsAfterSelf().FirstOrDefault<XElement>();
        }
      }
      return this._fileToConvert._mainDoc.Root.Element(XName.Get("body", Xceed.Document.NET.Document.w.NamespaceName)).Elements().First<XElement>();
    }

    private bool IsEndOfLine(Xceed.Pdf.Layout.Text.Text text) => text != null && text.Atoms != null && (text.Atoms.Buffer != null && text.Atoms.Size == 1) && text.Atoms[0] is CharAtom atom && atom.Char == '\r';

    private bool IsParagraphFittingOnPage(
      float currentPosY,
      float paragraphHeight,
      float marginBottom)
    {
      float num = 0.0f;
      Xceed.Pdf.Layout.Text.Text footnotesContent = PdfFootnote.GetFootnotesContent();
      if (footnotesContent != null)
      {
        if ((double) footnotesContent.Height == 0.0)
          this.MeasureText(footnotesContent);
        num = footnotesContent.Height;
      }
      return (double) currentPosY + (double) paragraphHeight <= (double) this.GetCurrentSection().PageHeight - (double) marginBottom - (double) num;
    }

    private void AddPage(
      int firstParagraphId = 0,
      int paragraphDrawnLinesCount = 0,
      int tableDrawnRowsCount = 0,
      float tableLastSplitRowHeight = 0.0f)
    {
      if (this._currentPdfPageInfo != null)
      {
        this.DrawInFrontOfTextWrappedObjects();
        this.DrawFootnotes(this._currentPdfPageInfo.FooterHeight);
        this._currentPdfPageInfo.Clear();
        this._currentPdfPageInfo.Page.Graphics.Flush();
      }
      PdfFootnote.CleanFootnotes();
      Section currentSection = this.GetCurrentSection();
      this._currentPdfPageInfo = new PdfPageInfo()
      {
        Page = this._outputPdfDocument.Pages.AddPage(currentSection.PageWidth, currentSection.PageHeight),
        PageId = this._currentPdfPageInfo != null ? ++this._currentPdfPageInfo.PageId : 1,
        PageNumber = this._currentPdfPageInfo != null ? ++this._currentPdfPageInfo.PageNumber : this.GetInitialPageNumber(),
        PositionY = currentSection.MarginTop,
        HeaderHeight = currentSection.MarginTop,
        FooterHeight = currentSection.MarginBottom,
        FirstParagraphId = firstParagraphId,
        FirstParagraphDrawnLinesCount = paragraphDrawnLinesCount,
        FirstParagraphDrawnRowsCount = tableDrawnRowsCount,
        FirstParagraphLastSplitRowHeight = tableLastSplitRowHeight,
        FirstSectionId = this._currentSection,
        InitialListItemsDictionary = PdfListItem.GetListsInfo() != null ? PdfListItem.GetListsInfo().CloneListNumberDictionary() : (IDictionary) new Dictionary<int, Dictionary<int, string>>()
      };
      this.SetBackground();
      this.AddHeaderFooter();
    }

    private Section GetCurrentSection() => this._fileToConvert.Sections[this._currentSection];

    private int GetInitialPageNumber()
    {
      Section currentSection = this.GetCurrentSection();
      if (currentSection != null)
      {
        XElement el = currentSection.Xml.Element(XName.Get("pgNumType", Xceed.Document.NET.Document.w.NamespaceName));
        if (el != null)
        {
          string attribute = el.GetAttribute(XName.Get("start", Xceed.Document.NET.Document.w.NamespaceName));
          if (!string.IsNullOrEmpty(attribute))
            return int.Parse(attribute);
        }
      }
      return 1;
    }

    private void AddHeaderFooter(HeaderFooterType headerFooterType = HeaderFooterType.None)
    {
      float positionY = this._currentPdfPageInfo.PositionY;
      if (headerFooterType != HeaderFooterType.Footer)
        new PdfHeader((PdfIConverter) this).Draw();
      float num = Math.Max(positionY, this._currentPdfPageInfo.HeaderHeight);
      if (headerFooterType != HeaderFooterType.Header)
        new PdfFooter((PdfIConverter) this).Draw();
      this._currentPdfPageInfo.PositionY = num;
    }

    private void CreatePdfParagraphs(IEnumerable<Paragraph> paragraphs)
    {
      List<Paragraph> paragraphList = paragraphs != null ? paragraphs.ToList<Paragraph>() : throw new ArgumentNullException(nameof (paragraphs));
      if (paragraphList.Count == 0 && this.IsSectionStartingWithTable())
        ((PdfIConverter) this).DrawInitialTables((Container) this._fileToConvert, (PdfIDrawContent) this, this._currentPdfPageInfo.HeaderHeight, this._currentPdfPageInfo.FooterHeight);
      bool flag = true;
      for (int index = 0; index < paragraphList.Count; ++index)
      {
        if (flag && this.IsSectionStartingWithTable())
          ((PdfIConverter) this).DrawInitialTables((Container) this._fileToConvert, (PdfIDrawContent) this, this._currentPdfPageInfo.HeaderHeight, this._currentPdfPageInfo.FooterHeight);
        Paragraph paragraph = paragraphList[index];
        PdfParagraph pdfParagraph = new PdfParagraph(paragraph, index == 0 ? (Paragraph) null : paragraphList[index - 1], index == paragraphList.Count - 1 ? (Paragraph) null : paragraphList[index + 1], index, this._currentPdfPageInfo.PageNumber, this._currentPdfPageInfo.Page.Graphics, this._fileToConvert, this.GetCurrentSection(), index == this._currentPdfPageInfo.FirstParagraphId);
        DocumentElement objectFromParagraph = ((PdfIConverter) this).GetUndrawnWrappedObjectFromParagraph(paragraph);
        if (objectFromParagraph != null)
        {
          if (this._waitingToBeDrawnPdfParagraphList.Count > 0)
            this.DrawWaitingToBeDrawnPdfParagraphs();
          this._currentPdfPageInfo.PositionY += pdfParagraph.GetLineSpacingBefore();
          if (objectFromParagraph is Xceed.Document.NET.Table)
            ((PdfIConverter) this).DrawPdfParagraph(pdfParagraph, (PdfIDrawContent) this, this._currentPdfPageInfo.HeaderHeight, this._currentPdfPageInfo.FooterHeight);
          float paragraphHeight = this.MeasurePdfParagraphs((IEnumerable<PdfParagraph>) new List<PdfParagraph>()
          {
            pdfParagraph
          });
          RectangleF paragraphPartDimensions = PdfParagraphPart.GetPdfParagraphPartDimensions(this.GetCurrentSection(), this._currentPdfPageInfo, objectFromParagraph, paragraphHeight);
          if (this.IsParagraphFittingOnPage(this._currentPdfPageInfo.PositionY, paragraphHeight, this._currentPdfPageInfo.FooterHeight) && (PdfParagraphPart.IsWrappedObjectRelativeFromPageInY(objectFromParagraph) || this.IsParagraphFittingOnPage(paragraphPartDimensions.Y, paragraphPartDimensions.Height, 0.0f)))
          {
            ((PdfIConverter) this).UdpatePdfPageForWrappedObject(objectFromParagraph, pdfParagraph);
            this._currentSection = this._currentPdfPageInfo.FirstSectionId;
            this._currentPdfPageInfo.PositionY = this._currentPdfPageInfo.HeaderHeight;
          }
          else
          {
            List<PdfWrappedObjectInfo> wrappedObjectInfoList = new List<PdfWrappedObjectInfo>((IEnumerable<PdfWrappedObjectInfo>) this._currentPdfPageInfo.WrappedObjects);
            this.AddPage(pdfParagraph.GetParagraphId());
            this._currentPdfPageInfo.DoneWrappedObjects.AddRange((IEnumerable<PdfWrappedObjectInfo>) wrappedObjectInfoList);
            ((PdfIConverter) this).UdpatePdfPageForWrappedObject(objectFromParagraph, pdfParagraph);
          }
          index = this._currentPdfPageInfo.FirstParagraphId - 1;
        }
        else if (pdfParagraph.IsParagraphContainingPageBreak() && (pdfParagraph.IsParagraphContainingPageBreakBefore() && (double) this._currentPdfPageInfo.PositionY > (double) this._currentPdfPageInfo.HeaderHeight || !pdfParagraph.IsParagraphContainingPageBreakBefore() && (double) this._currentPdfPageInfo.PositionY >= (double) this._currentPdfPageInfo.HeaderHeight) && this.ManageParagraphWithPageBreak(pdfParagraph))
        {
          if (pdfParagraph.IsParagraphContainingSectionBreak())
            flag = true;
        }
        else if (pdfParagraph.IsParagraphKeepWithNextParagraph())
        {
          this._waitingToBeDrawnPdfParagraphList.Add(pdfParagraph);
        }
        else
        {
          if (this._waitingToBeDrawnPdfParagraphList.Count > 0)
            this.DrawWaitingToBeDrawnPdfParagraphs(pdfParagraph);
          else
            ((PdfIConverter) this).DrawPdfParagraph(pdfParagraph, (PdfIDrawContent) this, this._currentPdfPageInfo.HeaderHeight, this._currentPdfPageInfo.FooterHeight);
          flag = false;
        }
      }
      this.DrawWaitingToBeDrawnPdfParagraphs();
    }

    private void ResetPdfPage()
    {
      this._outputPdfDocument.Pages.Content.Remove(this._outputPdfDocument.Pages.Content.Size - 1);
      this._currentPdfPageInfo.Page = this._outputPdfDocument.Pages.AddPage(this.GetCurrentSection().PageWidth, this.GetCurrentSection().PageHeight);
      PdfListItem.GetListsInfo()?.SetListNumberDictionary(this._currentPdfPageInfo.InitialListItemsDictionary);
    }

    private void DrawWrappedObject(
      DocumentElement wrappedObject,
      RectangleF wrappedObjectDimensions,
      bool drawAllWrappingObjectTypes = false)
    {
      //switch (wrappedObject)
      //{
      //  case Picture _:
      //    if (!(!PdfUtils.IsWrappingInFrontOfText(wrappedObject) | drawAllWrappingObjectTypes))
      //      break;
      //    Picture picture = wrappedObject as Picture;
      //    System.Drawing.Image image = PdfPicture.GetImage(this.GetCurrentSection(), picture);
      //    if (picture.IsJpegImage())
      //    {
      //      this._currentPdfPageInfo.Page.Graphics.DrawImage(image, (ImageCompressor) new JPEGImageCompressor(), wrappedObjectDimensions.X, wrappedObjectDimensions.Y, wrappedObjectDimensions.Width, wrappedObjectDimensions.Height);
      //      break;
      //    }
      //    this._currentPdfPageInfo.Page.Graphics.DrawImage(image, wrappedObjectDimensions.X, wrappedObjectDimensions.Y, wrappedObjectDimensions.Width, wrappedObjectDimensions.Height);
      //    break;
      //  case Shape _:
      //    if (!(!PdfUtils.IsWrappingInFrontOfText(wrappedObject) | drawAllWrappingObjectTypes))
      //      break;
      //    Shape shape = wrappedObject as Shape;
      //    PdfShape pdfShape = PdfShape.CreateShapePdfParagraph(this._fileToConvert, this.GetCurrentSection(), this._currentPdfPageInfo, shape).CreatePdfShape(shape, this._currentPdfPageInfo) as PdfShape;
      //    this._currentPdfPageInfo.Page.Graphics.DrawShape(wrappedObjectDimensions.X, wrappedObjectDimensions.Y, wrappedObjectDimensions.Width, wrappedObjectDimensions.Height, pdfShape.Shape);
      //    break;
      //  case Xceed.Document.NET.Table _:
      //    PdfPageInfo pdfPageInfo = this._currentPdfPageInfo.Clone();
      //    Xceed.Document.NET.Table table = wrappedObject as Xceed.Document.NET.Table;
      //    PdfParagraph tablePdfParagraph = PdfTable.CreateTablePdfParagraph(this._fileToConvert, table.PackagePart, this.GetCurrentSection(), this._currentPdfPageInfo, table);
      //    PdfTable pdfTable = tablePdfParagraph.CreatePdfTable(table, this._currentPdfPageInfo) as PdfTable;
      //    if (tablePdfParagraph.ContainsTotalPageNumber())
      //    {
      //      if (!PdfConverter.IsTotalPageNumberCalculated())
      //      {
      //        PdfConverter._pageNumberParagraphs.Add(new PdfPageNumberParagraphInfo(pdfPageInfo, tablePdfParagraph));
      //        break;
      //      }
      //      this._currentPdfPageInfo.Page.Graphics.DrawTable(wrappedObjectDimensions.X, wrappedObjectDimensions.Y, wrappedObjectDimensions.Width, pdfTable.Table);
      //      break;
      //    }
      //    this._currentPdfPageInfo.Page.Graphics.DrawTable(wrappedObjectDimensions.X, wrappedObjectDimensions.Y, wrappedObjectDimensions.Width, pdfTable.Table);
      //    break;
      //}
    }

    private void DrawWrappedObjects(
      IEnumerable<PdfWrappedObjectInfo> wrappedObjectInfos,
      bool drawAllWrappingObjectTypes = false)
    {
      if (wrappedObjectInfos == null)
        return;
      foreach (PdfWrappedObjectInfo wrappedObjectInfo in wrappedObjectInfos)
        this.DrawWrappedObject(this.GetWrappedObjectFromContainers(wrappedObjectInfo.Id, wrappedObjectInfo.HeaderFooterType), new RectangleF(wrappedObjectInfo.Dimension.X, wrappedObjectInfo.Dimension.Y, wrappedObjectInfo.Dimension.Width, wrappedObjectInfo.Dimension.Height), drawAllWrappingObjectTypes);
    }

    private DocumentElement GetWrappedObjectFromContainers(
      string id,
      HeaderFooterType headerFooterType)
    {
      DocumentElement documentElement = (DocumentElement) null;
      Section currentSection = this.GetCurrentSection();
      switch (headerFooterType)
      {
        case HeaderFooterType.None:
          documentElement = this.GetWrappedObjectFromContainer(id, (Container) this._fileToConvert);
          break;
        case HeaderFooterType.Header:
          documentElement = (this.GetWrappedObjectFromContainer(id, (Container) currentSection.Headers.Odd) ?? this.GetWrappedObjectFromContainer(id, (Container) currentSection.Headers.Even)) ?? this.GetWrappedObjectFromContainer(id, (Container) currentSection.Headers.First);
          break;
        case HeaderFooterType.Footer:
          documentElement = (this.GetWrappedObjectFromContainer(id, (Container) currentSection.Footers.Odd) ?? this.GetWrappedObjectFromContainer(id, (Container) currentSection.Footers.Even)) ?? this.GetWrappedObjectFromContainer(id, (Container) currentSection.Footers.First);
          break;
      }
      return documentElement;
    }

    private DocumentElement GetWrappedObjectFromContainer(
      string id,
      Container container)
    {
      return container == null ? (DocumentElement) null : ((DocumentElement) container.Pictures.FirstOrDefault<Picture>((Func<Picture, bool>) (x => x.Id == id)) ?? (DocumentElement) container.Shapes.FirstOrDefault<Shape>((Func<Shape, bool>) (x => x.Id.Equals(id)))) ?? (DocumentElement) container.Tables.FirstOrDefault<Xceed.Document.NET.Table>((Func<Xceed.Document.NET.Table, bool>) (x => x.Index.ToString() == id));
    }

    private void DrawFootnotes(float marginBottom)
    {
      Xceed.Pdf.Layout.Text.Text footnotesContent = PdfFootnote.GetFootnotesContent();
      if (footnotesContent == null)
        return;
      this._currentPdfPageInfo.PositionY = this.GetCurrentSection().PageHeight - marginBottom - PdfFootnote.GetFootnotesContentHeight();
      ((PdfIConverter) this).DrawTextWithPosition(footnotesContent);
    }

    private void DrawEndnotes(float marginBottom)
    {
      Xceed.Pdf.Layout.Text.Text endnotesContent = PdfEndnote.GetEndnotesContent();
      if (endnotesContent == null)
        return;
      this.MeasureText(endnotesContent);
      this._currentPdfPageInfo.PositionY = this.GetCurrentSection().PageHeight - marginBottom - PdfFootnote.GetFootnotesContentHeight() - endnotesContent.Height;
      ((PdfIConverter) this).DrawTextWithPosition(endnotesContent);
    }

    private void DrawPageNumberParagraphs()
    {
      foreach (PdfPageNumberParagraphInfo pageNumberParagraph in PdfConverter._pageNumberParagraphs)
      {
        this._currentPdfPageInfo = pageNumberParagraph.PdfPageInfo;
        if (pageNumberParagraph.PdfParagraph.ContainsWrappedTables())
        {
          List<Xceed.Document.NET.Table> wrappedTables = pageNumberParagraph.PdfParagraph.GetWrappedTables();
          if (wrappedTables != null)
          {
            foreach (Xceed.Document.NET.Table table in wrappedTables)
            {
              Xceed.Document.NET.Table wrappedTable = table;
              PdfWrappedObjectInfo wrappedObjectInfo = this._currentPdfPageInfo.WrappedObjects.FirstOrDefault<PdfWrappedObjectInfo>((Func<PdfWrappedObjectInfo, bool>) (x => x.Type == WrappedObjectType.Table && x.Id == wrappedTable.Index.ToString()));
              if (wrappedObjectInfo != null)
                this.DrawWrappedObject((DocumentElement) wrappedTable, wrappedObjectInfo.Dimension);
            }
          }
        }
        else
        {
          PdfIDrawContent drawContentInterface = pageNumberParagraph.PdfParagraph.IsInTOC() ? (PdfIDrawContent) this : (PdfIDrawContent) new PdfFooter((PdfIConverter) this);
          ((PdfIConverter) this).DrawPdfParagraph(pageNumberParagraph.PdfParagraph, drawContentInterface, this._currentPdfPageInfo.HeaderHeight, this._currentPdfPageInfo.FooterHeight);
        }
      }
    }

    private void DrawInFrontOfTextWrappedObjects() => this.DrawWrappedObjects(this._currentPdfPageInfo.WrappedObjects.Where<PdfWrappedObjectInfo>((Func<PdfWrappedObjectInfo, bool>) (x => (x.Type == WrappedObjectType.Picture || x.Type == WrappedObjectType.Shape) && x.WrappingType != WrappingType.WrapBehindText)), true);

    private void DrawWaitingToBeDrawnPdfParagraphs(PdfParagraph currentParagraph = null)
    {
      if (currentParagraph != null)
        this._waitingToBeDrawnPdfParagraphList.Add(currentParagraph);
      if (this._waitingToBeDrawnPdfParagraphList.Count <= 0)
        return;
      if (!this.IsParagraphFittingOnPage(this._currentPdfPageInfo.PositionY, this.MeasurePdfParagraphs((IEnumerable<PdfParagraph>) this._waitingToBeDrawnPdfParagraphList, isMeasuringUnwrappedTables: false), this._currentPdfPageInfo.FooterHeight))
        this.AddPage(this._waitingToBeDrawnPdfParagraphList.First<PdfParagraph>().GetParagraphId());
      for (int index = 0; index < this._waitingToBeDrawnPdfParagraphList.Count; ++index)
        ((PdfIConverter) this).DrawPdfParagraph(this._waitingToBeDrawnPdfParagraphList[index], (PdfIDrawContent) this, this._currentPdfPageInfo.HeaderHeight, this._currentPdfPageInfo.FooterHeight);
      this._waitingToBeDrawnPdfParagraphList.Clear();
    }

    private bool ManageParagraphWithPageBreak(PdfParagraph pdfParagraph)
    {
      if (pdfParagraph.IsParagraphContainingPageBreakBefore())
      {
        this.DrawWaitingToBeDrawnPdfParagraphs();
        this.AddPage(pdfParagraph.GetParagraphId());
        pdfParagraph.SetIsFirstParagraphOnPage(true);
        return false;
      }
      if (pdfParagraph.IsParagraphContainingSectionBreak())
      {
        this.DrawWaitingToBeDrawnPdfParagraphs();
        ((PdfIConverter) this).DrawPdfParagraph(pdfParagraph, (PdfIDrawContent) this, this._currentPdfPageInfo.HeaderHeight, this._currentPdfPageInfo.FooterHeight);
        this.ChangeSection();
        if (this.GetCurrentSection().SectionBreakType != SectionBreakType.continuous)
          this.AddPage(pdfParagraph.GetParagraphId() + 1);
        return true;
      }
      if (!pdfParagraph.IsParagraphContainingPageBreakInMiddle() || (double) this._currentPdfPageInfo.PositionY <= (double) this._currentPdfPageInfo.HeaderHeight && (this._waitingToBeDrawnPdfParagraphList.Count <= 0 || (double) this._currentPdfPageInfo.PositionY < (double) this._currentPdfPageInfo.HeaderHeight))
        return false;
      Paragraph originalParagraph = pdfParagraph.GetOriginalParagraph();
      XElement xml = originalParagraph.Xml;
      int pageBreakRunId = pdfParagraph.GetPageBreakRunId();
      IEnumerable<XElement> source1 = xml.Elements(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName));
      List<XElement> list = source1.ToList<XElement>();
      bool flag = source1.Count<XElement>() != pageBreakRunId + 1;
      source1.Skip<XElement>(pageBreakRunId + 1).Remove<XElement>();
      this.DrawWaitingToBeDrawnPdfParagraphs();
      if (source1.Count<XElement>() > 0 && originalParagraph.MagicText.Count > 0)
        ((PdfIConverter) this).DrawPdfParagraph(pdfParagraph, (PdfIDrawContent) this, this._currentPdfPageInfo.HeaderHeight, this._currentPdfPageInfo.FooterHeight);
      this.AddPage(flag ? pdfParagraph.GetParagraphId() : pdfParagraph.GetParagraphId() + 1);
      if (flag)
      {
        pdfParagraph.SetIsFirstParagraphOnPage(true);
        if (pageBreakRunId != -1 && pdfParagraph.GetOriginalParagraph().IsListItem && source1.Count<XElement>() > 0 && source1.Any<XElement>((Func<XElement, bool>) (r => r.Elements(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName)).Count<XElement>() > 0)))
        {
          pdfParagraph.GetOriginalParagraph().IsListItemBacker = new bool?(false);
          float indentationBefore = pdfParagraph.GetOriginalParagraph().IndentationBefore;
          pdfParagraph.GetOriginalParagraph().IndentationHanging = 0.0f;
          pdfParagraph.GetOriginalParagraph().IndentationBefore = indentationBefore;
        }
      }
      source1.Remove<XElement>();
      xml.Add((object) list);
      originalParagraph.ClearMagicTextCache();
      IEnumerable<XElement> source2 = xml.Elements(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName));
      source2.Take<XElement>(pageBreakRunId + 1).Remove<XElement>();
      if (source2.Count<XElement>() > 0 || pdfParagraph.ContainsUnwrappedTables())
        ((PdfIConverter) this).DrawPdfParagraph(pdfParagraph, (PdfIDrawContent) this, this._currentPdfPageInfo.HeaderHeight, this._currentPdfPageInfo.FooterHeight);
      source2.Remove<XElement>();
      xml.Add((object) list);
      originalParagraph.ClearMagicTextCache();
      return true;
    }

    private void ChangeSection()
    {
      ++this._currentSection;
      this._currentPdfPageInfo.PageId = 0;
      int pageNumberStart = this.GetCurrentSection().PageNumberStart;
      if (pageNumberStart < 0)
        return;
      this._currentPdfPageInfo.PageNumber = pageNumberStart - 1;
    }

    private void DrawTextDirectly(Xceed.Pdf.Layout.Text.Text text)
    {
      if (text == null)
        return;
      text.Draw(this._currentPdfPageInfo.Page.Graphics);
      float num = 0.0f;
      for (int lineId = 0; lineId < text.Lines.Size; ++lineId)
        num += text.GetLineHeightWithInterval(lineId);
      this._currentPdfPageInfo.PositionY += num;
    }

    private void DrawTableDirectly(Xceed.Pdf.Layout.Table.Table table)
    {
      if (table == null)
        return;
      table.Draw(this._currentPdfPageInfo.Page.Graphics);
      float num = 0.0f;
      for (int index = 0; index < table.Rows.Size; ++index)
        num += table.Rows[index].Height;
      this._currentPdfPageInfo.PositionY += num;
    }

    private void SplitTable(
      PdfTable pdfTable,
      PdfParagraph paragraph,
      float marginTop,
      float marginBottom,
      int drawnRows,
      float drawnSplitRowHeight,
      int paragraphDrawnLines)
    {
      this._currentPdfPageInfo.Page.Graphics.MeasureBlock(pdfTable.Table.Left, this._currentPdfPageInfo.PositionY, pdfTable.Table.Width, 0.0f, (Block) pdfTable.Table);
      if (pdfTable.Table.Rows.Size <= 0)
        return;
      RowCollection rowCollection1 = (RowCollection) null;
      if (drawnRows > 0)
      {
        rowCollection1 = pdfTable.RemovePrecedingExcedingRows(drawnRows);
        this._currentPdfPageInfo.Page.Graphics.MeasureBlock(pdfTable.Table.Left, this._currentPdfPageInfo.PositionY, pdfTable.Table.Width, 0.0f, (Block) pdfTable.Table);
      }
      if ((double) drawnSplitRowHeight > 0.0)
        pdfTable.RemoveFirstRowExcedingText(drawnSplitRowHeight);
      float remainingHeight = this.GetCurrentSection().PageHeight - marginBottom - this._currentPdfPageInfo.PositionY - PdfFootnote.GetFootnotesContentHeight();
      int fullyDrawnRowsCount = 0;
      RowCollection rowCollection2 = pdfTable.RemoveExcedingRows(remainingHeight, ref fullyDrawnRowsCount);
      if ((double) pdfTable.Table.Height > 0.0)
        this.DrawTableDirectly(pdfTable.Table);
      if (rowCollection2.Size == 0 && fullyDrawnRowsCount == pdfTable.Table.Rows.Size)
      {
        this._currentPdfPageInfo.FirstParagraphDrawnRowsCount = 0;
      }
      else
      {
        drawnSplitRowHeight = fullyDrawnRowsCount == pdfTable.Table.Rows.Size ? 0.0f : pdfTable.Table.Rows.Buffer[pdfTable.Table.Rows.Size - 1].Height;
        int num = rowCollection1 == null ? fullyDrawnRowsCount : rowCollection1.Size + fullyDrawnRowsCount;
        this.AddPage(paragraph != null ? paragraph.GetParagraphId() : 0, paragraphDrawnLines, num, drawnSplitRowHeight);
        if (rowCollection1 != null)
          pdfTable.Table.Rows.Insert(rowCollection1.Buffer, rowCollection1.Size, pdfTable.Table.Rows[0].IsTableHeader ? 1 : 0);
        pdfTable.Table.Rows.Add(rowCollection2.Buffer, rowCollection2.Size);
        this.SplitTable(pdfTable, paragraph, marginTop, marginBottom, num, drawnSplitRowHeight, paragraphDrawnLines);
      }
    }

    private float MeasurePdfParagraphs(
      IEnumerable<PdfParagraph> paragraphs,
      bool addLastParagraphSpacing = false,
      bool isMeasuringUnwrappedTables = true)
    {
      if (paragraphs == null)
        throw new ArgumentNullException(nameof (paragraphs));
      float num1 = 0.0f;
      List<PdfParagraph> list = paragraphs.ToList<PdfParagraph>();
      for (int index = 0; index < list.Count; ++index)
      {
        PdfParagraph pdfParagraph = list[index];
        Xceed.Pdf.Layout.Text.Text pdfText = pdfParagraph.CreatePdfText((IList) this._currentPdfPageInfo.WrappedObjects, true);
        this.MeasureText(pdfText);
        float num2 = num1 + pdfParagraph.GetLineSpacingBefore(pdfText);
        num1 = addLastParagraphSpacing || index != list.Count - 1 || pdfText.Lines.Size <= 0 ? num2 + pdfText.Height + pdfParagraph.GetLineSpacingAfter(pdfText) : num2 + pdfText.Lines[0].Height;
        if (isMeasuringUnwrappedTables && pdfParagraph.ContainsUnwrappedTables())
        {
          foreach (Xceed.Document.NET.Table table in pdfParagraph.GetTables())
            num1 += PdfTable.GetTableHeight(this.GetCurrentSection(), this._currentPdfPageInfo, table);
        }
      }
      return num1;
    }

    private void MeasureText(Xceed.Pdf.Layout.Text.Text text)
    {
      Section currentSection = this.GetCurrentSection();
      this._currentPdfPageInfo.Page.Graphics.MeasureBlock(currentSection.MarginLeft, this._currentPdfPageInfo.PositionY, currentSection.PageWidth - currentSection.MarginLeft - currentSection.MarginRight, 0.0f, (Block) text);
    }

    private void UpdateParagraphFromStyle(Paragraph p, string styleId)
    {
      if (p == null || string.IsNullOrEmpty(styleId))
        return;
      Paragraph styledParagraph = this.CreateStyledParagraph((Paragraph) null, styleId, p.IsListItem);
      HelperFunctions.UpdateParagraphFromStyledParagraph(p, styledParagraph);
    }

    private Paragraph CreateStyledParagraph(Paragraph p, string styleId, bool isListItem)
    {
      if (p == null)
        p = new Paragraph(this._fileToConvert, new XElement((XName) "styleParagraph"), 0);
      XElement style = HelperFunctions.GetStyle(this._fileToConvert, styleId);
      if (style != null)
      {
        XElement el = style.Element(XName.Get("basedOn", Xceed.Document.NET.Document.w.NamespaceName));
        if (el != null)
          p = this.CreateStyledParagraph(p, el.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)), isListItem);
        XElement xelement1 = style.Element(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 != null)
        {
          XElement pPr = p.GetOrCreate_pPr();
          foreach (XElement element in xelement1.Elements())
          {
            if (!isListItem || !(element.Name.LocalName == "ind"))
            {
              XElement xelement2 = pPr.Element(element.Name);
              if (xelement2 != null)
              {
                if (xelement2.Name.LocalName == "pBdr" || xelement2.Name.LocalName == "numPr")
                {
                  foreach (XElement xelement3 in element.Descendants().ToList<XElement>())
                  {
                    XElement xelement4 = xelement2.Descendants(xelement3.Name).FirstOrDefault<XElement>();
                    if (xelement4 != null)
                      xelement4.ReplaceWith((object) xelement3);
                    else
                      xelement2.Add((object) xelement3);
                  }
                }
                else
                {
                  foreach (XAttribute attribute in element.Attributes())
                  {
                    if (xelement2.Attribute(attribute.Name) == null)
                      xelement2.Add((object) attribute);
                    else
                      xelement2.SetAttributeValue(XName.Get(attribute.Name.LocalName, Xceed.Document.NET.Document.w.NamespaceName), (object) attribute.Value);
                  }
                }
              }
              else
                pPr.Add((object) element);
            }
          }
        }
        XElement xelement5 = style.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement5 != null)
        {
          XElement rPr = p.GetOrCreate_rPr();
          foreach (XElement element in xelement5.Elements())
          {
            XElement xelement2 = rPr.Element(element.Name);
            if (xelement2 != null)
            {
              foreach (XAttribute attribute in element.Attributes())
              {
                if (xelement2.Attribute(attribute.Name) == null)
                  xelement2.Add((object) attribute);
                else
                  xelement2.SetAttributeValue(XName.Get(attribute.Name.LocalName, Xceed.Document.NET.Document.w.NamespaceName), (object) attribute.Value);
              }
            }
            else
              rPr.Add((object) element);
          }
        }
      }
      return p;
    }

    private void UpdateTOC()
    {
      if (!TableOfContents.IsDocumentContainingTableOfContentToUpdate(this._fileToConvert))
        return;
      IEnumerable<XElement> xelements = TableOfContents.UpdateTOCParagraphs(this._fileToConvert);
      if (xelements == null)
        return;
      foreach (XElement xml in xelements)
      {
        Paragraph p = new Paragraph(this._fileToConvert, xml, 0);
        this.UpdateParagraphFromStyle(p, p.StyleId);
      }
    }

    private void UpdateParagraphsFromStyles()
    {
      foreach (Paragraph paragraph in this._fileToConvert.Paragraphs)
        this.UpdateParagraphFromStyle(paragraph, paragraph.StyleId);
      foreach (Section section in (IEnumerable<Section>) this._fileToConvert.Sections)
      {
        if (section.Headers.First != null)
        {
          foreach (Paragraph paragraph in section.Headers.First.Paragraphs)
            this.UpdateParagraphFromStyle(paragraph, paragraph.StyleId);
        }
        if (section.Headers.Odd != null)
        {
          foreach (Paragraph paragraph in section.Headers.Odd.Paragraphs)
            this.UpdateParagraphFromStyle(paragraph, paragraph.StyleId);
        }
        if (section.Headers.Even != null)
        {
          foreach (Paragraph paragraph in section.Headers.Even.Paragraphs)
            this.UpdateParagraphFromStyle(paragraph, paragraph.StyleId);
        }
        if (section.Footers.First != null)
        {
          foreach (Paragraph paragraph in section.Footers.First.Paragraphs)
            this.UpdateParagraphFromStyle(paragraph, paragraph.StyleId);
        }
        if (section.Footers.Odd != null)
        {
          foreach (Paragraph paragraph in section.Footers.Odd.Paragraphs)
            this.UpdateParagraphFromStyle(paragraph, paragraph.StyleId);
        }
        if (section.Footers.Even != null)
        {
          foreach (Paragraph paragraph in section.Footers.Even.Paragraphs)
            this.UpdateParagraphFromStyle(paragraph, paragraph.StyleId);
        }
      }
    }

    private void UpdatePdfParagraphHyperlinkReference(PdfParagraph p)
    {
      foreach (string key in PdfConverter._hyperlinkAnchorsDictionary.Keys)
      {
        if (p.ValidateBookmark(key))
        {
          PdfConverter._hyperlinkAnchorsDictionary[key].Page = this._currentPdfPageInfo.Page;
          PdfConverter._hyperlinkAnchorsDictionary[key].Top = this._currentPdfPageInfo.Page.Height - this._currentPdfPageInfo.PositionY;
        }
      }
    }

    private void UpdatePdfPageNumberReference(PdfParagraph p)
    {
      foreach (PdfPageNumberParagraphInfo pageNumberParagraph in PdfConverter._pageNumberParagraphs)
      {
        if (p.ValidateBookmark(pageNumberParagraph.PageRefId))
        {
          pageNumberParagraph.PageRefNumber = this._currentPdfPageInfo.PageNumber;
          break;
        }
      }
    }

    private string GetFileToConvertBackground()
    {
      XElement el = this._fileToConvert._mainDoc.Root.Element(XName.Get("background", Xceed.Document.NET.Document.w.NamespaceName));
      return el != null ? el.GetAttribute(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName)) : (string) null;
    }

    private void SetBackground()
    {
      //Section currentSection = this.GetCurrentSection();
      //if (!string.IsNullOrEmpty(this._fileToConvertBackground))
      //{
      //  this._currentPdfPageInfo.Page.Graphics.Brush = (Brush) new SolidBrush(HelperFunctions.GetColorFromHtml(this._fileToConvertBackground));
      //  this._currentPdfPageInfo.Page.Graphics.FillRectangle(0.0f, 0.0f, currentSection.PageWidth, currentSection.PageHeight);
      //}
      //Borders pageBorders = currentSection.PageBorders;
      //if (pageBorders == null)
      //  return;
      //Xceed.Pdf.Layout.Borders borders = new Xceed.Pdf.Layout.Borders();
      //float left = 0.0f;
      //float top = 0.0f;
      //float num1 = 0.0f;
      //float num2 = 0.0f;
      //if (pageBorders.Left != null)
      //{
      //  left = pageBorders.Left.Space;
      //  borders.Left = PdfConverter.WordsBorderToPdfBorder(pageBorders.Left);
      //}
      //if (pageBorders.Top != null)
      //{
      //  top = pageBorders.Top.Space;
      //  borders.Top = PdfConverter.WordsBorderToPdfBorder(pageBorders.Top);
      //}
      //if (pageBorders.Right != null)
      //{
      //  num1 = pageBorders.Right.Space;
      //  borders.Right = PdfConverter.WordsBorderToPdfBorder(pageBorders.Right);
      //}
      //if (pageBorders.Bottom != null)
      //{
      //  num2 = pageBorders.Bottom.Space;
      //  borders.Bottom = PdfConverter.WordsBorderToPdfBorder(pageBorders.Bottom);
      //}
      //Block.DrawBorders(this._currentPdfPageInfo.Page.Graphics, left, top, currentSection.PageWidth - left - num1, currentSection.PageHeight - top - num2, borders);
    }

    void PdfIDrawContent.DrawText(
      Xceed.Pdf.Layout.Text.Text text,
      PdfParagraph paragraph,
      float marginBottom,
      bool isParagraphKeepingLinesTogether)
    {
      this.MeasureText(text);
      if (paragraph.GetParagraphId() == this._currentPdfPageInfo.FirstParagraphId && text.Lines != null && this._currentPdfPageInfo.FirstParagraphDrawnLinesCount > 0)
      {
        text.Lines.Remove(0, this._currentPdfPageInfo.FirstParagraphDrawnLinesCount);
        this.DrawTextDirectly(text);
      }
      else if (!this.IsEndOfLine(text) && (double) text.Height > 0.0 && !this.IsParagraphFittingOnPage(this._currentPdfPageInfo.PositionY, text.Height, marginBottom))
      {
        float num1 = 0.0f;
        int count = 0;
        if (!isParagraphKeepingLinesTogether)
        {
          float num2 = this.GetCurrentSection().PageHeight - marginBottom - this._currentPdfPageInfo.PositionY - PdfFootnote.GetFootnotesContentHeight();
          for (int index = 0; index < text.Lines.Size; ++index)
          {
            num1 += text.GetLineHeightWithInterval(index);
            if ((double) num1 >= (double) num2)
            {
              count = text.Lines.Size - index;
              text.Lines.Remove(index, count);
              break;
            }
          }
          this.DrawTextDirectly(text);
        }
        this.AddPage(paragraph.GetParagraphId(), text.Lines.Size);
        text.ClearBlockedRegions();
        this.MeasureText(text);
        if (!isParagraphKeepingLinesTogether)
          text.Lines.Remove(0, Math.Max(0, text.Lines.Size - count));
        this.DrawTextDirectly(text);
      }
      else
        ((PdfIConverter) this).DrawTextWithPosition(text);
      this.UpdatePdfPageNumberReference(paragraph);
    }

    void PdfIDrawContent.DrawPdfTable(
      Xceed.Document.NET.Table table,
      PdfParagraph paragraph,
      float marginTop,
      float marginBottom,
      int paragraphDrawnLines,
      PdfPageInfo initialCurrentPdfPageInfo)
    {
      PdfTable pdfTable = paragraph.CreatePdfTable(table, this._currentPdfPageInfo) as PdfTable;
      if (paragraph.GetParagraphId() == this._currentPdfPageInfo.FirstParagraphId && this._currentPdfPageInfo.FirstParagraphDrawnRowsCount > 0)
      {
        this.SplitTable(pdfTable, paragraph, marginTop, marginBottom, this._currentPdfPageInfo.FirstParagraphDrawnRowsCount, this._currentPdfPageInfo.FirstParagraphLastSplitRowHeight, paragraphDrawnLines);
      }
      else
      {
        this._currentPdfPageInfo.Page.Graphics.MeasureBlock(pdfTable.Table.Left, this._currentPdfPageInfo.PositionY, pdfTable.Table.Width, 0.0f, (Block) pdfTable.Table);
        this._currentPdfPageInfo.PositionY = pdfTable.AdjustTablePosition(this._currentPdfPageInfo);
        if (!this.IsParagraphFittingOnPage(this._currentPdfPageInfo.PositionY, pdfTable.Table.Height, marginBottom))
          this.SplitTable(pdfTable, paragraph, marginTop, marginBottom, 0, 0.0f, paragraphDrawnLines);
        else if (paragraph.ContainsTotalPageNumber())
        {
          if (!PdfConverter.IsTotalPageNumberCalculated())
          {
            if (!this._currentPdfPageInfo.IsTemporaryPage)
              PdfConverter._pageNumberParagraphs.Add(new PdfPageNumberParagraphInfo(initialCurrentPdfPageInfo, paragraph));
            this._currentPdfPageInfo.PositionY += pdfTable.Table.Height;
          }
          else
          {
            this._currentPdfPageInfo.Page.Graphics.DrawTable(pdfTable.Table.Left, this._currentPdfPageInfo.PositionY, pdfTable.Table.Width, pdfTable.Table);
            this._currentPdfPageInfo.PositionY += pdfTable.Table.Height;
          }
        }
        else
        {
          this._currentPdfPageInfo.Page.Graphics.DrawTable(pdfTable.Table.Left, this._currentPdfPageInfo.PositionY, pdfTable.Table.Width, pdfTable.Table);
          this._currentPdfPageInfo.PositionY += pdfTable.Table.Height;
        }
      }
    }

    PdfPageInfo PdfIConverter.GetCurrentPdfPageInfo() => this._currentPdfPageInfo;

    Section PdfIConverter.GetCurrentSection() => this.GetCurrentSection();

    Xceed.Document.NET.Document PdfIConverter.GetFileToConvert() => this._fileToConvert;

    Xceed.Pdf.Document PdfIConverter.GetOutputPdfDocument() => this._outputPdfDocument;

    void PdfIConverter.SetCurrentPdfPageInfo(PdfPageInfo pdfPageInfo) => this._currentPdfPageInfo = pdfPageInfo.Clone();

    void PdfIConverter.DrawInitialTables(
      Container container,
      PdfIDrawContent drawContentInterface,
      float marginTop,
      float marginBottom)
    {
      if (container == null)
        return;
      PdfPageInfo initialCurrentPdfPageInfo = this._currentPdfPageInfo.Clone();
      bool flag = container is Xceed.Document.NET.Document;
      for (XElement tableElement = flag ? this.GetFirstElementFromCurrentSection() : container.Xml.Elements().First<XElement>(); tableElement != null && tableElement.Name.LocalName != "p"; tableElement = tableElement.ElementsAfterSelf().Count<XElement>() > 0 ? tableElement.ElementsAfterSelf().First<XElement>() : (XElement) null)
      {
        if (tableElement.Name.LocalName == "tbl")
        {
          PdfParagraph tablePdfParagraph = PdfTable.CreateTablePdfParagraph(this._fileToConvert, container.PackagePart, this.GetCurrentSection(), this._currentPdfPageInfo, (Xceed.Document.NET.Table) null, tableElement);
          List<Xceed.Document.NET.Table> tables = tablePdfParagraph.GetTables();
          if (tables != null)
          {
            foreach (Xceed.Document.NET.Table table in tables)
            {
              if (PdfTable.IsTableWrappingAround(table))
              {
                HeaderFooterType headerFooterType = flag ? HeaderFooterType.None : (container is Header ? HeaderFooterType.Header : HeaderFooterType.Footer);
                ((PdfIConverter) this).UdpatePdfPageForWrappedObject((DocumentElement) table, (PdfParagraph) null, false, headerFooterType);
              }
              else
                drawContentInterface.DrawPdfTable(table, tablePdfParagraph, marginTop, marginBottom, 0, initialCurrentPdfPageInfo);
            }
          }
        }
      }
    }

    void PdfIConverter.DrawPdfParagraph(
      PdfParagraph paragraph,
      PdfIDrawContent drawContentInterface,
      float marginTop,
      float marginBottom)
    {
      PdfPageInfo pdfPageInfo = this._currentPdfPageInfo.Clone();
      Xceed.Pdf.Layout.Text.Text pdfText = paragraph.CreatePdfText((IList) this._currentPdfPageInfo.WrappedObjects);
      this.UpdatePdfParagraphHyperlinkReference(paragraph);
      bool isParagraphKeepingLinesTogether = paragraph.IsParagraphKeepingLinesTogether();
      this._currentPdfPageInfo.PositionY += paragraph.GetLineSpacingBefore(pdfText);
      if (paragraph.ContainsTotalPageNumber() || paragraph.IsInTOC() && paragraph.IsLastTextPageNumber())
      {
        if (!PdfConverter.IsTotalPageNumberCalculated())
        {
          PdfConverter._pageNumberParagraphs.Add(new PdfPageNumberParagraphInfo(pdfPageInfo, paragraph));
          this.MeasureText(pdfText);
          this._currentPdfPageInfo.PositionY += pdfText.Height;
        }
        else
          drawContentInterface.DrawText(pdfText, paragraph, marginBottom, isParagraphKeepingLinesTogether);
      }
      else
        drawContentInterface.DrawText(pdfText, paragraph, marginBottom, isParagraphKeepingLinesTogether);
      this._currentPdfPageInfo.PositionY += paragraph.GetLineSpacingAfter(pdfText);
      if (!paragraph.ContainsUnwrappedTables())
        return;
      if (pdfText.Lines.Size == 0)
        this._currentPdfPageInfo.PositionY -= paragraph.GetLineSpacingAfter(pdfText);
      foreach (Xceed.Document.NET.Table table in paragraph.GetTables())
        drawContentInterface.DrawPdfTable(table, paragraph, marginTop, marginBottom, pdfText.Lines.Size, pdfPageInfo);
    }

    DocumentElement PdfIConverter.GetUndrawnWrappedObjectFromParagraph(
      Paragraph p,
      HeaderFooterType headerFooterType)
    {
      if (p == null)
        return (DocumentElement) null;
      Picture picture = p.Pictures.FirstOrDefault<Picture>((Func<Picture, bool>) (x => PdfUtils.IsWrappingAround((DocumentElement) x) && this._currentPdfPageInfo.WrappedObjects.FirstOrDefault<PdfWrappedObjectInfo>((Func<PdfWrappedObjectInfo, bool>) (info => info.Id == x.Id && info.HeaderFooterType == headerFooterType)) == null && this._currentPdfPageInfo.DoneWrappedObjects.FirstOrDefault<PdfWrappedObjectInfo>((Func<PdfWrappedObjectInfo, bool>) (info => info.Id == x.Id && info.HeaderFooterType == headerFooterType)) == null));
      if (picture != null)
        return (DocumentElement) picture;
      Shape shape = p.Shapes.FirstOrDefault<Shape>((Func<Shape, bool>) (x => PdfUtils.IsWrappingAround((DocumentElement) x) && this._currentPdfPageInfo.WrappedObjects.FirstOrDefault<PdfWrappedObjectInfo>((Func<PdfWrappedObjectInfo, bool>) (info => info.Id.Equals(x.Id) && info.HeaderFooterType == headerFooterType)) == null && this._currentPdfPageInfo.DoneWrappedObjects.FirstOrDefault<PdfWrappedObjectInfo>((Func<PdfWrappedObjectInfo, bool>) (info => info.Id == x.Id && info.HeaderFooterType == headerFooterType)) == null));
      if (shape != null)
        return (DocumentElement) shape;
      if (p.FollowingTables != null)
      {
        foreach (Xceed.Document.NET.Table followingTable in p.FollowingTables)
        {
          Xceed.Document.NET.Table table = followingTable;
          if (PdfTable.IsTableWrappingAround(table) && this._currentPdfPageInfo.WrappedObjects.FirstOrDefault<PdfWrappedObjectInfo>((Func<PdfWrappedObjectInfo, bool>) (info => info.Id == table.Index.ToString())) == null && this._currentPdfPageInfo.DoneWrappedObjects.FirstOrDefault<PdfWrappedObjectInfo>((Func<PdfWrappedObjectInfo, bool>) (info => info.Id == table.Index.ToString())) == null)
            return (DocumentElement) table;
        }
      }
      return (DocumentElement) null;
    }

    void PdfIConverter.UdpatePdfPageForWrappedObject(
      DocumentElement wrappedObject,
      PdfParagraph pdfParagraph,
      bool resetPdfPage,
      HeaderFooterType headerFooterType)
    {
      bool flag = false;
      string id1;
      switch (wrappedObject)
      {
        case Picture _:
          id1 = ((Picture) wrappedObject).Id;
          break;
        case Shape _:
          id1 = ((Shape) wrappedObject).Id;
          break;
        default:
          id1 = ((Xceed.Document.NET.Table) wrappedObject).Index.ToString();
          break;
      }
      string wrappedObjectId = id1;
      if (this._currentPdfPageInfo.WrappedObjects.FirstOrDefault<PdfWrappedObjectInfo>((Func<PdfWrappedObjectInfo, bool>) (x => x.Id == wrappedObjectId && x.HeaderFooterType == headerFooterType)) == null)
      {
        double num1;
        if (pdfParagraph == null)
          num1 = 0.0;
        else
          num1 = (double) this.MeasurePdfParagraphs((IEnumerable<PdfParagraph>) new List<PdfParagraph>()
          {
            pdfParagraph
          }, true);
        float paragraphHeight = (float) num1;
        int num2;
        switch (wrappedObject)
        {
          case Picture _:
            num2 = 0;
            break;
          case Shape _:
            num2 = 1;
            break;
          default:
            num2 = 2;
            break;
        }
        string id2 = wrappedObjectId;
        int num3 = (int) headerFooterType;
        RectangleF paragraphPartDimensions = PdfParagraphPart.GetPdfParagraphPartDimensions(this.GetCurrentSection(), this._currentPdfPageInfo, wrappedObject, paragraphHeight);
        PointF horizontalMargins = PdfParagraphPart.GetHorizontalMargins(wrappedObject);
        PointF verticalMargins = PdfParagraphPart.GetVerticalMargins(wrappedObject);
        int num4;
        switch (wrappedObject)
        {
          case Picture _:
          case Shape _:
            num4 = (int) PdfUtils.GetWrapping(wrappedObject);
            break;
          default:
            num4 = 7;
            break;
        }
        int zorder = PdfUtils.GetZOrder(wrappedObject);
        PdfWrappedObjectInfo wrappedObjectInfo = new PdfWrappedObjectInfo((WrappedObjectType) num2, id2, (HeaderFooterType) num3, paragraphPartDimensions, horizontalMargins, verticalMargins, (WrappingType) num4, zorder);
        int index = this._currentPdfPageInfo.WrappedObjects.FindIndex((Predicate<PdfWrappedObjectInfo>) (w => w.ZOrder > wrappedObjectInfo.ZOrder));
        this._currentPdfPageInfo.WrappedObjects.Insert(index >= 0 ? index : this._currentPdfPageInfo.WrappedObjects.Count, wrappedObjectInfo);
        flag = true;
      }
      if (resetPdfPage)
      {
        this.ResetPdfPage();
        this.SetBackground();
        this.DrawWrappedObjects(this._currentPdfPageInfo.WrappedObjects.Where<PdfWrappedObjectInfo>((Func<PdfWrappedObjectInfo, bool>) (x => (x.Type == WrappedObjectType.Picture || x.Type == WrappedObjectType.Shape) && x.WrappingType != WrappingType.WrapInFrontOfText || x.Type == WrappedObjectType.Table)));
        switch (headerFooterType)
        {
          case HeaderFooterType.Header:
            break;
          case HeaderFooterType.Footer:
            this.AddHeaderFooter(HeaderFooterType.Header);
            break;
          default:
            this.AddHeaderFooter();
            break;
        }
      }
      else
      {
        if (!flag)
          return;
        if (this._currentPdfPageInfo.WrappedObjects.FindIndex((Predicate<PdfWrappedObjectInfo>) (x => x.Id == wrappedObjectId && x.HeaderFooterType == headerFooterType)) == this._currentPdfPageInfo.WrappedObjects.Count - 1)
          this.DrawWrappedObject(wrappedObject, this._currentPdfPageInfo.WrappedObjects.Last<PdfWrappedObjectInfo>().Dimension);
        else
          this.DrawWrappedObjects(this._currentPdfPageInfo.WrappedObjects.Where<PdfWrappedObjectInfo>((Func<PdfWrappedObjectInfo, bool>) (x => (x.Type == WrappedObjectType.Picture || x.Type == WrappedObjectType.Shape) && x.WrappingType != WrappingType.WrapInFrontOfText || x.Type == WrappedObjectType.Table)));
      }
    }

    void PdfIConverter.DrawTextWithPosition(Xceed.Pdf.Layout.Text.Text text)
    {
      Section currentSection = this.GetCurrentSection();
      this._currentPdfPageInfo.Page.Graphics.DrawText(currentSection.MarginLeft, this._currentPdfPageInfo.PositionY, currentSection.PageWidth - currentSection.MarginLeft - currentSection.MarginRight, text);
      this._currentPdfPageInfo.PositionY += text.Height;
    }
  }
}
