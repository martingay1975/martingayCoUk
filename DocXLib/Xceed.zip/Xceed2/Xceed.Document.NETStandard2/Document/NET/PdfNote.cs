﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfNote
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using Xceed.Pdf.Layout;

namespace Xceed.Document.NET
{
  internal abstract class PdfNote : PdfParagraphPart
  {
    private XElement _runContainingNote;

    internal PdfNote(PdfParagraph p, XElement run)
      : base(p)
      => this._runContainingNote = run;

    internal abstract string GetReferenceNoteType();

    internal abstract string GetNoteType();

    internal abstract string GetNotePropertiesType();

    internal abstract string GetDefaultNumberedText(string id);

    internal abstract XDocument GetNoteFile();

    internal abstract Xceed.Pdf.Layout.Text.Text GetNotesContent();

    internal abstract void CreateNotesContent();

    internal override void UpdateText(Xceed.Pdf.Layout.Text.Text text, bool isMeasuring = false)
    {
      //XElement el = this._runContainingNote.Descendants(XName.Get(this.GetReferenceNoteType(), Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
      //if (el == null)
      //  return;
      //string id = el.GetAttribute(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName));
      //if (string.IsNullOrEmpty(id))
      //  return;
      //Style noteNumberStyle = this.GetNoteNumberStyle(this._runContainingNote);
      //string numberedText = this.GetNumberedText(id);
      //text.AddContent(numberedText, noteNumberStyle);
      //XDocument noteFile = this.GetNoteFile();
      //if (noteFile == null)
      //  return;
      //XElement endNote = noteFile.Root.Elements(XName.Get(this.GetNoteType(), Xceed.Document.NET.Document.w.NamespaceName)).Where<XElement>((Func<XElement, bool>) (e => e.GetAttribute(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName)).Equals(id))).FirstOrDefault<XElement>();
      //if (endNote == null)
      //  return;
      //if (this.GetNotesContent() == null)
      //{
      //  this.CreateNotesContent();
      //  this.GetNotesContent().AddContent("        _________________________________");
      //}
      //this.GetNotesContent().AddContent("\n", noteNumberStyle);
      //Style noteContentStyle = this.GetNoteContentStyle(endNote);
      //Style style = (Style) null;
      //if (noteNumberStyle != null)
      //{
      //  style = noteNumberStyle.Clone();
      //  style.Font = noteContentStyle.Font;
      //}
      //this.GetNotesContent().AddContent(numberedText, style);
      //this.GetNotesContent().AddContent(" " + endNote.Value, noteContentStyle);
    }

    private Style GetNoteNumberStyle(XElement run) => this.GetNoteStyle(run, "rStyle");

    private Style GetNoteContentStyle(XElement endNote) => this.GetNoteStyle(endNote, "pStyle");

    private Style GetNoteStyle(XElement run, string styleType)
    {
      XElement el = run.Descendants(XName.Get(styleType, Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
      if (el != null)
      {
        string attribute = el.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        if (!string.IsNullOrEmpty(attribute))
          return this._pdfParagraph.GetLayoutStyle(attribute);
      }
      return (Style) null;
    }

    private string GetNumberedText(string id)
    {
      IEnumerable<XElement> source = this._pdfParagraph.GetFileToConvert()._settings.Descendants(XName.Get(this.GetNotePropertiesType(), Xceed.Document.NET.Document.w.NamespaceName));
      if (source != null)
      {
        XElement xelement = source.FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Element(XName.Get("numFmt", Xceed.Document.NET.Document.w.NamespaceName)) != null));
        if (xelement != null)
        {
          switch (xelement.Value)
          {
            case "decimal":
              return id;
            case "lowerLetter":
              return this.ConvertTextDigitToLetter(id, false);
            case "upperLetter":
              return this.ConvertTextDigitToLetter(id, true);
            case "lowerRoman":
              return this.ConvertTextDigitToRoman(id, false);
            case "upperRoman":
              return this.ConvertTextDigitToRoman(id, true);
            default:
              return this.GetDefaultNumberedText(id);
          }
        }
      }
      return this.GetDefaultNumberedText(id);
    }
  }
}
