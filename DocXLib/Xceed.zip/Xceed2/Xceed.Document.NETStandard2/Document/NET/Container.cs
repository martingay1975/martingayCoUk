﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Container
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents the base class for a Container.</summary>
  public abstract class Container : DocumentElement
  {
    /// <summary>Gets the collection of Paragraphs in this Container.</summary>
    public virtual ReadOnlyCollection<Paragraph> Paragraphs
    {
      get
      {
        List<Paragraph> paragraphs = this.GetParagraphs();
        this.InitParagraphs(paragraphs);
        return paragraphs.AsReadOnly();
      }
    }

    public virtual ReadOnlyCollection<Paragraph> ParagraphsDeepSearch => this.Paragraphs;

    /// <summary>Gets the collection of Sections after reading the xml of this Container.</summary>
    public virtual IList<Section> Sections => this.GetSections();

    /// <summary>Gets the collection of Tables in this Container.</summary>
    public virtual List<Table> Tables => this.Xml.Descendants(Xceed.Document.NET.Document.w + "tbl").Select<XElement, Table>((Func<XElement, Table>) (t => new Table(this.Document, t, this.PackagePart))).ToList<Table>();

    /// <summary>Gets the collection of Hyperlinks in this Container.</summary>
    public virtual List<Hyperlink> Hyperlinks
    {
      get
      {
        List<Hyperlink> hyperlinkList = new List<Hyperlink>();
        foreach (Paragraph paragraph in this.Paragraphs)
          hyperlinkList.AddRange((IEnumerable<Hyperlink>) paragraph.Hyperlinks);
        return hyperlinkList;
      }
    }

    /// <summary>Gets the collection of Pictures in this Container.</summary>
    public virtual List<Picture> Pictures
    {
      get
      {
        List<Picture> pictureList = new List<Picture>();
        foreach (Paragraph paragraph in this.Paragraphs)
          pictureList.AddRange((IEnumerable<Picture>) paragraph.Pictures);
        return pictureList;
      }
    }

    /// <summary>Gets the collection of Shapes in this Container.</summary>
    public virtual List<Shape> Shapes
    {
      get
      {
        List<Shape> shapeList = new List<Shape>();
        foreach (Paragraph paragraph in this.Paragraphs)
          shapeList.AddRange((IEnumerable<Shape>) paragraph.Shapes);
        return shapeList;
      }
    }

    /// <summary>Gets the collection of TextBoxes in this Container.</summary>
    public virtual List<Shape> TextBoxes
    {
      get
      {
        List<Shape> shapeList = new List<Shape>();
        foreach (Paragraph paragraph in this.Paragraphs)
          shapeList.AddRange((IEnumerable<Shape>) paragraph.TextBoxes);
        return shapeList;
      }
    }

    /// <summary>Gets the collection of Lists in this Container.</summary>
    public virtual List<List> Lists
    {
      get
      {
        List<List> listList = new List<List>();
        List list = new List(this.Document, this.Xml);
        foreach (Paragraph paragraph in this.Paragraphs)
        {
          if (paragraph.IsListItem)
          {
            if (list.CanAddListItem(paragraph))
            {
              list.AddItem(paragraph);
            }
            else
            {
              listList.Add(list);
              list = new List(this.Document, this.Xml);
              list.AddItem(paragraph);
            }
          }
        }
        listList.Add(list);
        return listList;
      }
    }

    /// <summary>Reads the xml of the Container to create a list of Sections.</summary>
    /// <returns>A collection of the Sections in the Container.</returns>
    public IList<Section> GetSections()
    {
      ReadOnlyCollection<Paragraph> paragraphs = this.Paragraphs;
      List<Section> source1 = new List<Section>();
      List<Paragraph> paragraphList = new List<Paragraph>();
      foreach (Paragraph paragraph in paragraphs)
      {
        XElement xml = paragraph.Xml.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (s => s.Name.LocalName == "sectPr"));
        if (xml != null)
        {
          paragraphList.Add(paragraph);
          source1.Add(new Section(this.Document, xml, source1.Count<Section>() > 0 ? source1.Select<Section, XElement>((Func<Section, XElement>) (s => s.Xml)) : (IEnumerable<XElement>) null)
          {
            SectionParagraphs = paragraphList
          });
          paragraphList = new List<Paragraph>();
        }
        else
          paragraphList.Add(paragraph);
      }
      XElement xelement = this.Xml.DescendantsAndSelf(XName.Get("body", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
      if (xelement != null)
      {
        IEnumerable<XElement> source2 = xelement.Elements(XName.Get("sectPr", Xceed.Document.NET.Document.w.NamespaceName));
        XElement xml = source2.LastOrDefault<XElement>();
        if (xml != null)
        {
          Section section = source1.Count > 0 ? new Section(this.Document, xml, source1.Select<Section, XElement>((Func<Section, XElement>) (s => s.Xml))) : new Section(this.Document, xml, source2.Count<XElement>() > 1 ? source2.Take<XElement>(source2.Count<XElement>() - 1) : (IEnumerable<XElement>) null);
          section.SectionParagraphs = paragraphList;
          source1.Add(section);
        }
      }
      return (IList<Section>) source1;
    }

    /// <summary>Sets the Direction of the content of this Container.</summary>
    /// <param name="direction">The Direction of the content.</param>
    public virtual void SetDirection(Direction direction)
    {
      foreach (Paragraph paragraph in this.Paragraphs)
        paragraph.Direction = direction;
    }

    /// <summary>Retrieves all the indexes in this Container where the provided search value is found.</summary>
    /// <returns>A list of indexes that match the search conditions.</returns>
    /// <param name="str">The value to search for.</param>
    public virtual List<int> FindAll(string str) => this.FindAll(str, RegexOptions.None);

    /// <summary>Retrieves all the indexes in this Container where the provided search value is found, using the provided RegexOptions.</summary>
    /// <returns>A list of indexes that match the search conditions.</returns>
    /// <param name="str">The value to search for.</param>
    /// <param name="options">A value representing the regular expression options to use.</param>
    public virtual List<int> FindAll(string str, RegexOptions options)
    {
      List<int> intList = new List<int>();
      foreach (Paragraph paragraph in this.Paragraphs)
      {
        List<int> all = paragraph.FindAll(str, options);
        for (int index = 0; index < all.Count<int>(); ++index)
          all[index] += paragraph._startIndex;
        intList.AddRange((IEnumerable<int>) all);
      }
      return intList;
    }

    /// <summary>Finds all unique instances of the provided Regex pattern.</summary>
    /// <returns>A list of all the unique string values that were found.</returns>
    /// <param name="pattern">The pattern to search for.</param>
    /// <param name="options">The regular expression options to use.</param>
    public virtual List<string> FindUniqueByPattern(string pattern, RegexOptions options)
    {
      List<string> stringList = new List<string>();
      foreach (Paragraph paragraph in this.Paragraphs)
      {
        List<string> allByPattern = paragraph.FindAllByPattern(pattern, options);
        stringList.AddRange((IEnumerable<string>) allByPattern);
      }
      Dictionary<string, int> dictionary = new Dictionary<string, int>();
      foreach (string key in stringList)
      {
        if (!dictionary.ContainsKey(key))
          dictionary.Add(key, 0);
      }
      return dictionary.Keys.ToList<string>();
    }

    /// <summary>Replaces all instances of a string with another string.</summary>
    /// <param name="searchValue">The value to be replaced.</param>
    /// <param name="newValue">The new value to replace with.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="options">The regular expression options to use.</param>
    /// <param name="newFormatting">The formatting to apply to the new text.</param>
    /// <param name="matchFormatting">The formatting that the text must match in order to be replaced.</param>
    /// <param name="fo">A MatchFormattingOptions value indicating
    /// how the formatting should be matched.</param>
    /// <param name="escapeRegEx">
    ///         <strong>true</strong> if if the searchValue needs to be escaped, otherwise <strong>false</strong>. If it represents a valid RegEx pattern, this should be
    /// false.</param>
    /// <param name="useRegExSubstitutions">
    ///         <strong>true</strong> if a RegEx-like replace should be performed (i.e. if the newValue contains RegEx substitutions), otherwise <strong>false</strong>. Does
    /// not perform named-group substitutions (only numbered groups).</param>
    /// <param name="removeEmptyParagraph">
    /// <strong>true</strong> if the paragraph should be removed if it's empty, otherwise <strong>false</strong>.</param>
    public virtual void ReplaceText(
      string searchValue,
      string newValue,
      bool trackChanges = false,
      RegexOptions options = RegexOptions.None,
      Formatting newFormatting = null,
      Formatting matchFormatting = null,
      MatchFormattingOptions fo = MatchFormattingOptions.SubsetMatch,
      bool escapeRegEx = true,
      bool useRegExSubstitutions = false,
      bool removeEmptyParagraph = true)
    {
      if (string.IsNullOrEmpty(searchValue))
        throw new ArgumentException("searchValue cannot be null or empty.", nameof (searchValue));
      if (newValue == null)
        throw new ArgumentException("newValue cannot be null.", nameof (newValue));
      foreach (Paragraph paragraph in this.Paragraphs)
        paragraph.ReplaceText(searchValue, newValue, trackChanges, options, newFormatting, matchFormatting, fo, escapeRegEx, useRegExSubstitutions, removeEmptyParagraph);
    }

    /// <summary>Replaces all instances of a string with another string, using the provided Func to match a regex search group value to its corresponding replacement string.</summary>
    /// <param name="searchValue">The value to be replaced.</param>
    /// <param name="regexMatchHandler">A Func that accepts the matching regex search group value and passes it to this to return the replacement string.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="options">The regular expression options to use.</param>
    /// <param name="newFormatting">The formatting to apply to the new text.</param>
    /// <param name="matchFormatting">The formatting that the text must match in order to be replaced.</param>
    /// <param name="fo">A MatchFormattingOptions value indicating
    /// how the formatting should be matched.</param>
    /// <param name="removeEmptyParagraph">
    /// <strong>true</strong> if the paragraph should be removed if it's empty, otherwise <strong>false</strong>.</param>
    public virtual void ReplaceText(
      string searchValue,
      Func<string, string> regexMatchHandler,
      bool trackChanges = false,
      RegexOptions options = RegexOptions.None,
      Formatting newFormatting = null,
      Formatting matchFormatting = null,
      MatchFormattingOptions fo = MatchFormattingOptions.SubsetMatch,
      bool removeEmptyParagraph = true)
    {
      if (string.IsNullOrEmpty(searchValue))
        throw new ArgumentException("searchValue cannot be null or empty.", nameof (searchValue));
      if (regexMatchHandler == null)
        throw new ArgumentException("regexMatchHandler cannot be null", nameof (regexMatchHandler));
      foreach (Paragraph paragraph in this.Paragraphs)
        paragraph.ReplaceText(searchValue, regexMatchHandler, trackChanges, options, newFormatting, matchFormatting, fo, removeEmptyParagraph);
    }

    /// <summary>Replaces all instances of a string with a DocumentElement.</summary>
    /// <param name="searchValue">The value to be replaced.</param>
    /// <param name="objectToAdd">A DocumentElement representing the object to add, it can be a Picture, a Hyperlink or
    /// a Table.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="options">The regular expression options to use.</param>
    /// <param name="matchFormatting">The formatting that the text must match in order to be replaced.</param>
    /// <param name="fo">A MatchFormattingOptions value indicating
    /// how the formatting should be matched.</param>
    /// <param name="escapeRegEx">
    ///         <strong>true</strong> if if the searchValue needs to be escaped, otherwise <strong>false</strong>. If it represents a valid RegEx pattern, this should be
    /// false.</param>
    /// <param name="removeEmptyParagraph">
    /// <strong>true</strong> if the paragraph should be removed if it's empty, otherwise <strong>false</strong>.</param>
    public virtual void ReplaceTextWithObject(
      string searchValue,
      DocumentElement objectToAdd,
      bool trackChanges = false,
      RegexOptions options = RegexOptions.None,
      Formatting matchFormatting = null,
      MatchFormattingOptions fo = MatchFormattingOptions.SubsetMatch,
      bool escapeRegEx = true,
      bool removeEmptyParagraph = true)
    {
      if (string.IsNullOrEmpty(searchValue))
        throw new ArgumentException("searchValue cannot be null or empty.", nameof (searchValue));
      if (objectToAdd == null)
        throw new ArgumentException("objectToAdd cannot be null.", nameof (objectToAdd));
      foreach (Paragraph paragraph in this.Paragraphs)
        paragraph.ReplaceTextWithObject(searchValue, objectToAdd, trackChanges, options, matchFormatting, fo, escapeRegEx, removeEmptyParagraph);
    }

    /// <summary>Inserts the provided text to this Container, at the provided bookmark position, using the specified formatting.</summary>
    /// <param name="toInsert">The text to insert.</param>
    /// <param name="bookmarkName">The name of the Bookmark where the text will be inserted.</param>
    /// <param name="formatting">The Formatting to apply to the inserted text.</param>
    public virtual void InsertAtBookmark(
      string toInsert,
      string bookmarkName,
      Formatting formatting = null)
    {
      if (string.IsNullOrWhiteSpace(bookmarkName))
        throw new ArgumentException("bookmark cannot be null or empty", nameof (bookmarkName));
      foreach (Paragraph paragraph in this.Paragraphs)
        paragraph.InsertAtBookmark(toInsert, bookmarkName, formatting);
    }

    /// <summary>Inserts a Paragraph at a specific location in this
    /// Container, using the provided text, and optionally track this change.</summary>
    /// <param name="index">The index of the Paragraph where the new Paragraph is to be inserted.</param>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public virtual Paragraph InsertParagraph(int index, string text, bool trackChanges) => this.InsertParagraph(index, text, trackChanges, (Formatting) null);

    /// <summary>Inserts a Paragraph in this Container.</summary>
    public virtual Paragraph InsertParagraph() => this.InsertParagraph(string.Empty, false);

    /// <summary>Inserts the provided Paragraph at a specific location in
    /// this Container.</summary>
    /// <param name="index">The index of the Paragraph where the new Paragraph is to be inserted.</param>
    /// <param name="p">The Paragraph to insert.</param>
    public virtual Paragraph InsertParagraph(int index, Paragraph p)
    {
      XElement xelement = new XElement(p.Xml);
      p.Xml = xelement;
      Paragraph effectedByInsert = HelperFunctions.GetFirstParagraphEffectedByInsert(this.Document, index);
      if (effectedByInsert == null)
      {
        this.AddElementInXml((object) p.Xml);
      }
      else
      {
        XElement[] xelementArray = HelperFunctions.SplitParagraph(effectedByInsert, index - effectedByInsert._startIndex);
        effectedByInsert.Xml.ReplaceWith((object) xelementArray[0], (object) xelement, (object) xelementArray[1]);
      }
      this.SetParentContainer(p);
      return p;
    }

    /// <summary>Inserts the provided Paragraph in this Container.</summary>
    /// <param name="p">The Paragraph to insert.</param>
    public virtual Paragraph InsertParagraph(Paragraph p)
    {
      if (p._styles.Count<XElement>() > 0)
      {
        Uri uri = new Uri("/word/styles.xml", UriKind.Relative);
        XDocument xdocument;
        if (!this.Document._package.PartExists(uri))
        {
          using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(this.Document._package.CreatePart(uri, "application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml", (CompressionOption) 1).GetStream())))
          {
            xdocument = new XDocument(new XDeclaration("1.0", "UTF-8", "yes"), new object[1]
            {
              (object) new XElement(XName.Get("styles", Xceed.Document.NET.Document.w.NamespaceName))
            });
            xdocument.Save(textWriter);
          }
        }
        PackagePart part = this.Document._package.GetPart(uri);
        using (TextReader textReader = (TextReader) new StreamReader(part.GetStream()))
        {
          xdocument = XDocument.Load(textReader);
          XElement xelement = xdocument.Element(XName.Get("styles", Xceed.Document.NET.Document.w.NamespaceName));
          IEnumerable<string> source = xelement.Descendants(XName.Get("style", Xceed.Document.NET.Document.w.NamespaceName)).Select(d => new
          {
            d = d,
            a = d.Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName))
          }).Where(_param1 => _param1.a != null).Select(_param1 => _param1.a.Value);
          foreach (XElement style in p._styles)
          {
            if (!source.Contains<string>(style.Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName)).Value))
              xelement.Add((object) style);
          }
        }
        using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(part.GetStream())))
          xdocument.Save(textWriter);
      }
      XElement xml = new XElement(p.Xml);
      this.AddElementInXml((object) xml);
      int num = 0;
      if (this.Document._paragraphLookup.Keys.Count<int>() > 0)
      {
        int key = this.Document._paragraphLookup.Last<KeyValuePair<int, Paragraph>>().Key;
        num = this.Document._paragraphLookup.Last<KeyValuePair<int, Paragraph>>().Value.Text.Length != 0 ? key + this.Document._paragraphLookup.Last<KeyValuePair<int, Paragraph>>().Value.Text.Length : key + 1;
      }
      Paragraph newParagraph = new Paragraph(this.Document, xml, num);
      this.Document._paragraphLookup.Add(num, newParagraph);
      this.SetParentContainer(newParagraph);
      return newParagraph;
    }

    /// <summary>Inserts a Paragraph at a specific location in this Container, using the provided text and
    /// formatting, and optionally track this change.</summary>
    /// <param name="index">The index of the Paragraph where the new Paragraph is to be inserted.</param>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="formatting">The format to apply to the new Paragraph.</param>
    public virtual Paragraph InsertParagraph(
      int index,
      string text,
      bool trackChanges,
      Formatting formatting)
    {
      Paragraph newParagraph = new Paragraph(this.Document, new XElement(Xceed.Document.NET.Document.w + "p"), index);
      newParagraph.InsertText(0, text, trackChanges, formatting);
      Paragraph effectedByInsert = HelperFunctions.GetFirstParagraphEffectedByInsert(this.Document, index);
      if (effectedByInsert != null)
      {
        int index1 = index - effectedByInsert._startIndex;
        if (index1 > 0)
        {
          XElement[] xelementArray = HelperFunctions.SplitParagraph(effectedByInsert, index1);
          effectedByInsert.Xml.ReplaceWith((object) xelementArray[0], (object) newParagraph.Xml, (object) xelementArray[1]);
        }
        else
          effectedByInsert.Xml.ReplaceWith((object) newParagraph.Xml, (object) effectedByInsert.Xml);
      }
      else
        this.AddElementInXml((object) newParagraph);
      this.SetParentContainer(newParagraph);
      return newParagraph;
    }

    /// <summary>Inserts a Paragraph in this Container, using the provided text.</summary>
    /// <param name="text">The text for the new Paragraph.</param>
    public virtual Paragraph InsertParagraph(string text) => this.InsertParagraph(text, false, new Formatting());

    /// <summary>Inserts a Paragraph in this Container, using the provided text, and optionally track this
    /// change.</summary>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public virtual Paragraph InsertParagraph(string text, bool trackChanges) => this.InsertParagraph(text, trackChanges, new Formatting());

    /// <summary>Inserts a Paragraph in this Container, using the provided text and formatting, and
    /// optionally track this change.</summary>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="formatting">The format to apply to the new Paragraph.</param>
    public virtual Paragraph InsertParagraph(
      string text,
      bool trackChanges,
      Formatting formatting)
    {
      XElement xml = new XElement(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
      {
        (object) new XElement(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName)),
        (object) HelperFunctions.FormatInput(text, formatting.Xml)
      });
      if (trackChanges)
        xml = HelperFunctions.CreateEdit(EditType.ins, DateTime.Now, (object) xml);
      this.AddElementInXml((object) xml);
      Paragraph newParagraph = new Paragraph(this.Document, xml, 0);
      switch (this)
      {
        case Cell cell:
          newParagraph.PackagePart = cell.PackagePart;
          break;
        case Xceed.Document.NET.Document _:
          newParagraph.PackagePart = this.Document.PackagePart;
          break;
        case Footer footer:
          newParagraph.PackagePart = footer.PackagePart;
          break;
        case Header header:
          newParagraph.PackagePart = header.PackagePart;
          break;
        default:
          newParagraph.PackagePart = this.Document.PackagePart;
          break;
      }
      this.SetParentContainer(newParagraph);
      return newParagraph;
    }

    /// <summary>Removes the Paragraph found at a specific location from
    /// this Container.</summary>
    /// <returns>
    /// <strong>true</strong> if the paragraph was removed successfully, otherwise <strong>false</strong>.</returns>
    /// <param name="index">The Index of the Paragraph to remove.</param>
    public bool RemoveParagraphAt(int index)
    {
      List<XElement> list = this.Xml.Descendants(Xceed.Document.NET.Document.w + "p").ToList<XElement>();
      if (index >= list.Count)
        return false;
      list[index].Remove();
      return true;
    }

    /// <summary>Removes a Paragraph from this Container.</summary>
    /// <returns>
    /// <strong>true</strong> if the paragraph was removed successfully, otherwise <strong>false</strong>.</returns>
    /// <param name="paragraph">The Paragraph to remove.</param>
    public bool RemoveParagraph(Paragraph paragraph)
    {
      int index = this.Xml.Descendants(Xceed.Document.NET.Document.w + "p").ToList<XElement>().IndexOf(paragraph.Xml);
      return index != -1 && this.RemoveParagraphAt(index);
    }

    /// <summary>Inserts an equation to this Container.</summary>
    /// <returns>The Paragraph with the new equation added.</returns>
    /// <param name="equation">The equation to insert.</param>
    /// <param name="align">The Alignment to apply.</param>
    public virtual Paragraph InsertEquation(string equation, Alignment align = Alignment.center)
    {
      Paragraph paragraph = this.InsertParagraph();
      paragraph.AppendEquation(equation, align);
      return paragraph;
    }

    /// <summary>Inserts a Bookmark to this Container.</summary>
    /// <returns>The Paragraph with the new bookmark added.</returns>
    /// <param name="bookmarkName">The name for the Bookmark to insert.</param>
    public virtual Paragraph InsertBookmark(string bookmarkName)
    {
      Paragraph paragraph = this.InsertParagraph();
      paragraph.AppendBookmark(bookmarkName);
      return paragraph;
    }

    /// <summary>Inserts a Table of a specific size in this Container.</summary>
    /// <returns>The new Table that was inserted.</returns>
    /// <param name="rowCount">The row count for the new Table.</param>
    /// <param name="columnCount">The column count for the new Table.</param>
    public virtual Table InsertTable(int rowCount, int columnCount)
    {
      XElement table1 = HelperFunctions.CreateTable(rowCount, columnCount);
      this.AddElementInXml((object) table1);
      Table table2 = new Table(this.Document, table1, this.PackagePart);
      table2.PackagePart = this.PackagePart;
      return table2;
    }

    /// <summary>Inserts a Table of a specific size and at a specific location, in this Container.</summary>
    /// <returns>The new Table that was inserted.</returns>
    /// <param name="index">The index of the Paragraph where the Table is to be inserted.</param>
    /// <param name="rowCount">The row count for the new Table.</param>
    /// <param name="columnCount">The column count for the new Table.</param>
    public virtual Table InsertTable(int index, int rowCount, int columnCount)
    {
      XElement table1 = HelperFunctions.CreateTable(rowCount, columnCount);
      Paragraph effectedByInsert = HelperFunctions.GetFirstParagraphEffectedByInsert(this.Document, index);
      if (effectedByInsert == null)
      {
        this.Xml.Elements().First<XElement>().AddFirst((object) table1);
      }
      else
      {
        XElement[] xelementArray = HelperFunctions.SplitParagraph(effectedByInsert, index - effectedByInsert._startIndex);
        effectedByInsert.Xml.ReplaceWith((object) xelementArray[0], (object) table1, (object) xelementArray[1]);
      }
      Table table2 = new Table(this.Document, table1, this.PackagePart);
      table2.PackagePart = this.PackagePart;
      return table2;
    }

    /// <summary>Inserts the provided Table in this Container.</summary>
    /// <returns>The new Table that was inserted.</returns>
    /// <param name="t">The Table to insert.</param>
    public virtual Table InsertTable(Table t)
    {
      XElement xml = new XElement(t.Xml);
      this.AddElementInXml((object) xml);
      Table table = new Table(this.Document, xml, this.PackagePart);
      table.Design = t.Design;
      table.PackagePart = this.PackagePart;
      return table;
    }

    /// <summary>Inserts the provided Table at a specific location in this Container.</summary>
    /// <returns>The new Table that was inserted.</returns>
    /// <param name="index">The index of the Paragraph where the Table is to be inserted.</param>
    /// <param name="t">The Table to insert.</param>
    public virtual Table InsertTable(int index, Table t)
    {
      Paragraph effectedByInsert = HelperFunctions.GetFirstParagraphEffectedByInsert(this.Document, index);
      XElement[] xelementArray = HelperFunctions.SplitParagraph(effectedByInsert, index - effectedByInsert._startIndex);
      XElement xml = new XElement(t.Xml);
      effectedByInsert.Xml.ReplaceWith((object) xelementArray[0], (object) xml, (object) xelementArray[1]);
      Table table = new Table(this.Document, xml, this.PackagePart);
      table.Design = t.Design;
      table.PackagePart = this.PackagePart;
      return table;
    }

    /// <summary>Inserts a Section to this Container.</summary>
    /// <returns>The section that was inserted.</returns>
    public virtual Section InsertSection() => this.InsertSection(false);

    /// <summary>Inserts a Section to this Container, and optionally track
    /// this change.</summary>
    /// <returns>The section that was inserted.</returns>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public virtual Section InsertSection(bool trackChanges) => (Section) null;

    /// <summary>Inserts a section page break to this Container, and optionally track this change.</summary>
    /// <returns>The section that was inserted.</returns>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public virtual Section InsertSectionPageBreak(bool trackChanges = false) => (Section) null;

    /// <summary>Inserts a List to this Container.</summary>
    /// <returns>The List that was inserted.</returns>
    /// <param name="list">The List to insert.</param>
    public virtual List InsertList(List list)
    {
      foreach (DocumentElement documentElement in list.Items)
        this.AddElementInXml((object) documentElement.Xml);
      return list;
    }

    /// <summary>Inserts a List to this Container, using the provided font
    /// size.</summary>
    /// <returns>The List that was inserted.</returns>
    /// <param name="list">The List to insert.</param>
    /// <param name="fontSize">The font size to apply to the list items.</param>
    public virtual List InsertList(List list, double fontSize)
    {
      foreach (Paragraph paragraph in list.Items)
      {
        paragraph.FontSize(fontSize);
        this.AddElementInXml((object) paragraph.Xml);
      }
      return list;
    }

    /// <summary>Inserts a List to this Container, using the provided font
    /// family and font size.</summary>
    /// <returns>The List that was inserted.</returns>
    /// <param name="list">The List to insert.</param>
    /// <param name="fontFamily">The font family to apply to the list items.</param>
    /// <param name="fontSize">The font size to apply to the list items.</param>
    public virtual List InsertList(List list, Font fontFamily, double fontSize)
    {
      foreach (Paragraph paragraph in list.Items)
      {
        paragraph.Font(fontFamily);
        paragraph.FontSize(fontSize);
        this.AddElementInXml((object) paragraph.Xml);
      }
      return list;
    }

    /// <summary>Inserts a List to this Container at a specific index
    /// position.</summary>
    /// <returns>The List that was inserted.</returns>
    /// <param name="index">The index position at which to insert the List.</param>
    /// <param name="list">The List to insert.</param>
    public virtual List InsertList(int index, List list)
    {
      Paragraph effectedByInsert = HelperFunctions.GetFirstParagraphEffectedByInsert(this.Document, index);
      XElement[] xelementArray = HelperFunctions.SplitParagraph(effectedByInsert, index - effectedByInsert._startIndex);
      List<XElement> xelementList = new List<XElement>()
      {
        xelementArray[0]
      };
      xelementList.AddRange(list.Items.Select<Paragraph, XElement>((Func<Paragraph, XElement>) (i => new XElement(i.Xml))));
      xelementList.Add(xelementArray[1]);
      effectedByInsert.Xml.ReplaceWith((object[]) xelementList.ToArray());
      return list;
    }

    /// <param name="bookmarkNames">The names of the bookmarks to validate.</param>
    public virtual string[] ValidateBookmarks(params string[] bookmarkNames)
    {
      List<string> stringList = new List<string>();
      foreach (string bookmarkName1 in bookmarkNames)
      {
        string bookmarkName = bookmarkName1;
        if (this.Paragraphs.Any<Paragraph>((Func<Paragraph, bool>) (p => p.ValidateBookmark(bookmarkName))))
          return new string[0];
        stringList.Add(bookmarkName);
      }
      return stringList.ToArray();
    }

    /// <summary>Removes all text occurences that match the provided format.</summary>
    /// <returns>The number of text occurences that were removed.</returns>
    /// <param name="formattingToMatch">The formatting that the text must match in order to be removed.</param>
    /// <param name="formattingOptions">A MatchFormattingOptions value indicating
    /// how the formatting should be matched.</param>
    public int RemoveTextInGivenFormat(
      Formatting formattingToMatch,
      MatchFormattingOptions formattingOptions = MatchFormattingOptions.SubsetMatch)
    {
      int num = 0;
      foreach (XElement element in this.Xml.Elements())
        num += this.RecursiveRemoveText(element, formattingToMatch, formattingOptions);
      return num;
    }

    protected internal virtual void AddElementInXml(object element) => this.Xml.Add(element);

    internal List<Paragraph> GetParagraphs()
    {
      int startIndex = 0;
      List<Paragraph> paragraphList = new List<Paragraph>();
      IEnumerable<XElement> xelements = this.Xml.Descendants(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelements != null)
      {
        foreach (XElement xelement in xelements)
        {
          if (xelement.Ancestors().FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Name.Equals((object) XName.Get("Fallback", Xceed.Document.NET.Document.mc.NamespaceName)))) == null)
          {
            Paragraph paragraph = new Paragraph(this.Document, xelement, startIndex);
            paragraph.PackagePart = this.PackagePart;
            paragraphList.Add(paragraph);
            startIndex += HelperFunctions.GetText(xelement).Length;
          }
        }
      }
      return paragraphList;
    }

    internal void GetParagraphsRecursive(
      XElement xml,
      ref int index,
      ref List<Paragraph> paragraphs,
      bool isDeepSearch = false)
    {
      bool flag = true;
      if (xml.Name.LocalName == "p")
      {
        paragraphs.Add(new Paragraph(this.Document, xml, index));
        index += HelperFunctions.GetText(xml).Length;
        if (!isDeepSearch)
          flag = false;
      }
      if (!flag || !xml.HasElements)
        return;
      foreach (XElement element in xml.Elements())
        this.GetParagraphsRecursive(element, ref index, ref paragraphs, isDeepSearch);
    }

    internal int RecursiveRemoveText(
      XElement element,
      Formatting formattingToMatch,
      MatchFormattingOptions formattingOptions)
    {
      int num = 0;
      foreach (XElement element1 in element.Elements())
      {
        if ("rPr".Equals(element1.Name.LocalName) && HelperFunctions.ContainsEveryChildOf(formattingToMatch.Xml, element1, formattingOptions))
        {
          element1.Parent.Remove();
          ++num;
        }
        num += this.RecursiveRemoveText(element1, formattingToMatch, formattingOptions);
      }
      return num;
    }

    private void GetListItemType(Paragraph p)
    {
      string listItemType = HelperFunctions.GetListItemType(p, this.Document);
      if (listItemType == null)
        return;
      p.ListItemType = this.GetListItemType(listItemType);
    }

    private ContainerType GetParentFromXmlName(string xmlName)
    {
      switch (xmlName)
      {
        case "body":
          return ContainerType.Body;
        case "ftr":
          return ContainerType.Footer;
        case "hdr":
          return ContainerType.Header;
        case "p":
          return ContainerType.Paragraph;
        case "sectPr":
          return ContainerType.Section;
        case "tbl":
          return ContainerType.Table;
        case "tc":
          return ContainerType.Cell;
        case "txbxContent":
          return ContainerType.Shape;
        default:
          return ContainerType.None;
      }
    }

    private void SetParentContainer(Paragraph newParagraph)
    {
      string name = this.GetType().Name;
      if (name == null)
        return;
      // ISSUE: reference to a compiler-generated method
      switch (PrivateImplementationDetails.ComputeStringHash(name))
      {
        case 290429312:
          if (!(name == "Header"))
            break;
          newParagraph.ParentContainer = ContainerType.Header;
          break;
        case 474734565:
          if (!(name == "TOC"))
            break;
          newParagraph.ParentContainer = ContainerType.TOC;
          break;
        case 763853676:
          if (!(name == "Section"))
            break;
          newParagraph.ParentContainer = ContainerType.Section;
          break;
        case 1116344469:
          if (!(name == "Body"))
            break;
          newParagraph.ParentContainer = ContainerType.Body;
          break;
        case 1385410265:
          if (!(name == "Paragraph"))
            break;
          newParagraph.ParentContainer = ContainerType.Paragraph;
          break;
        case 1465712594:
          if (!(name == "Footer"))
            break;
          newParagraph.ParentContainer = ContainerType.Footer;
          break;
        case 3607948159:
          if (!(name == "Table"))
            break;
          newParagraph.ParentContainer = ContainerType.Table;
          break;
        case 3909778389:
          if (!(name == "Cell"))
            break;
          newParagraph.ParentContainer = ContainerType.Cell;
          break;
      }
    }

    private ListItemType GetListItemType(string listItemType)
    {
      switch (listItemType)
      {
        case "bullet":
          return ListItemType.Bulleted;
        default:
          return ListItemType.Numbered;
      }
    }

    private void InitParagraphs(List<Paragraph> paragraphs)
    {
      if (this.Document.Sections == null || this.Document.Sections.Count == 0)
        return;
      foreach (Paragraph paragraph in paragraphs)
      {
        XElement xml = paragraph.Xml.ElementsAfterSelf().FirstOrDefault<XElement>();
        if (xml == null && paragraph.IsInSdt())
          xml = paragraph.GetParentSdt().ElementsAfterSelf().FirstOrDefault<XElement>();
        for (XElement xelement = paragraph.GetOrCreate_pPr().Element(XName.Get("sectPr", Xceed.Document.NET.Document.w.NamespaceName)); xml != null && xml.Name.Equals((object) (Xceed.Document.NET.Document.w + "tbl")) && xelement == null; xml = xml.ElementsAfterSelf().FirstOrDefault<XElement>())
        {
          if (paragraph.FollowingTables == null)
            paragraph.FollowingTables = new List<Table>();
          paragraph.FollowingTables.Add(new Table(this.Document, xml, this.PackagePart));
        }
        paragraph.ParentContainer = this.GetParentFromXmlName(paragraph.Xml.Ancestors().First<XElement>().Name.LocalName);
        if (paragraph.IsListItem)
          this.GetListItemType(paragraph);
      }
    }

    internal Container(Xceed.Document.NET.Document document, XElement xml)
      : base(document, xml)
    {
    }
  }
}
