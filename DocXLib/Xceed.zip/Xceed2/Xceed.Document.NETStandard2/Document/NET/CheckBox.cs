﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.CheckBox
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a CheckBox.</summary>
  public class CheckBox : DocumentElement
  {
    private bool isChecked;
    private double? size;

    /// <summary>
    ///   <span id="BugEvents">Gets or sets if this CheckBox is checked.</span>
    /// </summary>
    public bool IsChecked
    {
      get => this.isChecked;
      set
      {
        this.isChecked = value;
        XElement xelement1 = this.Xml.Element(XName.Get("sdtPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 == null)
        {
          this.Xml.Add((object) new XElement(XName.Get("sdtPr", Xceed.Document.NET.Document.w.NamespaceName)));
          xelement1 = this.Xml.Element(XName.Get("sdtPr", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement2 = xelement1.Element(XName.Get("checkbox", Xceed.Document.NET.Document.w14.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.Add((object) new XElement(XName.Get("checkbox", Xceed.Document.NET.Document.w.NamespaceName)));
          xelement2 = xelement1.Element(XName.Get("checkbox", Xceed.Document.NET.Document.w14.NamespaceName));
          xelement1.Add((object) new XElement(XName.Get("checkedState", Xceed.Document.NET.Document.w14.NamespaceName), new object[2]
          {
            (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w14.NamespaceName), (object) "2612"),
            (object) new XAttribute(XName.Get("font", Xceed.Document.NET.Document.w14.NamespaceName), (object) "MS Gothic")
          }));
          xelement1.Add((object) new XElement(XName.Get("uncheckedState", Xceed.Document.NET.Document.w14.NamespaceName), new object[2]
          {
            (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w14.NamespaceName), (object) "2610"),
            (object) new XAttribute(XName.Get("font", Xceed.Document.NET.Document.w14.NamespaceName), (object) "MS Gothic")
          }));
        }
        XElement xelement3 = xelement2.Element(XName.Get("checked", Xceed.Document.NET.Document.w14.NamespaceName));
        if (xelement3 == null)
        {
          xelement2.Add((object) new XElement(XName.Get("checked", Xceed.Document.NET.Document.w14.NamespaceName)));
          xelement3 = xelement2.Element(XName.Get("checked", Xceed.Document.NET.Document.w14.NamespaceName));
        }
        xelement3.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w14.NamespaceName), this.isChecked ? (object) "1" : (object) "0");
        this.Xml.Descendants(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName)).Remove<XElement>();
        XElement xelement4 = this.Xml.Element(XName.Get("sdtContent", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement4 == null)
        {
          this.Xml.Add((object) new XElement(XName.Get("sdtContent", Xceed.Document.NET.Document.w.NamespaceName)));
          xelement4 = this.Xml.Element(XName.Get("sdtContent", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement5 = xelement4.Descendants(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
        if (xelement5 == null)
          return;
        string str = (this.isChecked ? xelement2.Element(XName.Get("checkedState", Xceed.Document.NET.Document.w14.NamespaceName)) : xelement2.Element(XName.Get("uncheckedState", Xceed.Document.NET.Document.w14.NamespaceName))).Attribute(XName.Get("val", Xceed.Document.NET.Document.w14.NamespaceName)).Value;
        xelement5.Add((object) new XElement(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName), (object) Convert.ToChar(Convert.ToInt32(str, 16))));
      }
    }

    /// <summary>
    ///   <span id="BugEvents">Gets or set the size of this CheckBox.</span>
    /// </summary>
    public double? Size
    {
      get
      {
        double? size = this.size;
        double num = 2.0;
        return !size.HasValue ? new double?() : new double?(size.GetValueOrDefault() / num);
      }
      set
      {
        if (value.HasValue)
        {
          double num;
          if ((num = (double) ((int) value.Value * 2)) - num != 0.0)
            throw new ArgumentException(nameof (Size), "Value must be either a whole or half number, examples: 32, 32.5");
          this.size = value.Value > 0.0 && value.Value < 1639.0 ? new double?(value.Value * 2.0) : throw new ArgumentException(nameof (Size), "Value must be in the range 0 - 1638");
        }
        else
          this.size = new double?();
        XElement xelement1 = this.Xml.Element(XName.Get("sdtContent", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 == null)
        {
          this.Xml.Add((object) new XElement(XName.Get("sdtContent", Xceed.Document.NET.Document.w.NamespaceName)));
          xelement1 = this.Xml.Element(XName.Get("sdtContent", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement2 = xelement1.Element(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 == null)
          return;
        XElement xelement3 = xelement2.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement3 == null)
        {
          xelement2.Add((object) new XElement(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)));
          xelement3 = xelement2.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement4 = xelement3.Element(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement4 == null)
        {
          xelement3.Add((object) new XElement(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName)));
          xelement4 = xelement3.Element(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement5 = xelement3.Element(XName.Get("szCs", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement5 == null)
        {
          xelement3.Add((object) new XElement(XName.Get("szCs", Xceed.Document.NET.Document.w.NamespaceName)));
          xelement5 = xelement3.Element(XName.Get("szCs", Xceed.Document.NET.Document.w.NamespaceName));
        }
        if (!this.size.HasValue)
        {
          xelement4.Remove();
          xelement5.Remove();
        }
        else
        {
          xelement4.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) this.size);
          xelement5.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) this.size);
        }
      }
    }

    internal CheckBox(Xceed.Document.NET.Document document, XElement xml)
      : base(document, xml)
    {
      //Licenser.VerifyLicense();
      XAttribute xattribute1 = this.Xml.Descendants(XName.Get("checkbox", Xceed.Document.NET.Document.w14.NamespaceName)).FirstOrDefault<XElement>()?.Element(XName.Get("checked", Xceed.Document.NET.Document.w14.NamespaceName))?.Attribute(XName.Get("val", Xceed.Document.NET.Document.w14.NamespaceName));
      this.isChecked = xattribute1 != null && xattribute1.Value == "1";
      XAttribute xattribute2 = this.Xml.Element(XName.Get("sdtContent", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName))?.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
      this.size = xattribute2 != null ? new double?((double) Convert.ToInt32(xattribute2.Value)) : new double?();
    }

    /// <summary>Removes the CheckBox from the Paragraph and Document.</summary>
    public void Remove() => this.Xml.Remove();
  }
}
