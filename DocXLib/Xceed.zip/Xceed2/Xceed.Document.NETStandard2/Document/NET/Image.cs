﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Image
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.IO;
using System.IO.Packaging;

namespace Xceed.Document.NET
{
  /// <summary>Represents an Image.</summary>
  public class Image
  {
    private string _id;
    private Xceed.Document.NET.Document _document;
    internal PackageRelationship _pr;

    /// <summary>Gets the Id of this Image.</summary>
    public string Id => this._id;

    /// <summary>Gets the File Name of this Image.</summary>
    public string FileName => Path.GetFileName(this._pr.TargetUri.ToString());

    internal Image(Xceed.Document.NET.Document document, PackageRelationship pr)
    {
      //Licenser.VerifyLicense();
      this._document = document;
      this._pr = pr;
      this._id = pr.Id;
    }

    public Stream GetStream(FileMode mode, FileAccess access)
    {
      string originalString1 = this._pr.SourceUri.OriginalString;
      string str = originalString1.Remove(originalString1.LastIndexOf('/'));
      string originalString2 = this._pr.TargetUri.OriginalString;
      return (Stream) new PackagePartStream(this._document._package.GetPart(new Uri(originalString2.Contains(str) ? originalString2 : str + "/" + originalString2, UriKind.Relative)).GetStream(mode, access));
    }

    /// <summary>Adds an image to a Document, creates a custom view of that image (picture) and then inserts it into a Paragraph using Append().</summary>
    /// <returns>The newly created Picture.</returns>
    public Picture CreatePicture() => this.CreatePicture(-1f, -1f);

    public Picture CreatePicture(float height, float width) => Paragraph.CreatePicture(this._document, this._id, string.Empty, string.Empty, width, height);
  }
}
