﻿// Decompiled with JetBrains decompiler
// Type: _XceedVersionInfo
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

internal static class _XceedVersionInfo
{
  public const string BaseVersion = "1.7";
  public const string Version = "1.7.20371.21580";
  public const string PublicKeyToken = "ba83ff368b7563c6";
  public const string PublicKey = "002400000480000094000000060200000024000052534131000400000100010071E9D3E8FB4B521B04EA8F76D94C5FE657793FF51E88DD9DD1AD6D056525454770A74B63478A1B63ED2AD979E65BEE25DE44BA686242CE430F0C7DF1475C18BEB5467555F740961A969E5E411CA4567C73B471F32815041356C9A106309D46EF9F232CB4BB0B0746475B5DB8CE1D4FCF17D99A80A0F7205DFD03D43B109583C2";
}
