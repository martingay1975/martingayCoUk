﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.FormattedText
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;

namespace Xceed.Document.NET
{
  /// <summary>Represents a FormattedText.</summary>
  public class FormattedText : IComparable
  {
    public int index;
    public string text;
    private Formatting _formatting;
    private bool _setInitialFormatting = true;

    public Formatting formatting
    {
      get => this._formatting;
      set
      {
        this._formatting = value;
        if (!this._setInitialFormatting)
          return;
        this.InitialFormatting = value?.Clone();
      }
    }

    internal Formatting InitialFormatting { get; private set; }

    /// <summary>Initializes a new instance of the <strong>FormattedText</strong> class.</summary>
    public FormattedText() => Licenser.VerifyLicense();

    /// <summary>Compares this FormattedText to another object.</summary>
    /// <param name="obj">The object with which the FormattedText is compared to.</param>
    public int CompareTo(object obj)
    {
      FormattedText formattedText1 = (FormattedText) obj;
      FormattedText formattedText2 = this;
      return formattedText1.formatting == null || formattedText2.formatting == null ? -1 : formattedText2.formatting.CompareTo((object) formattedText1.formatting);
    }

    internal void InternalModifyFormatting(Formatting f)
    {
      this._setInitialFormatting = false;
      this.formatting = f;
      this._setInitialFormatting = true;
    }
  }
}
