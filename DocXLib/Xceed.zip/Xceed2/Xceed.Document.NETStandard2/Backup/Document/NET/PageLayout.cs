﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PageLayout
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a PageLayout.</summary>
  public class PageLayout : DocumentElement
  {
    internal PageLayout(Xceed.Document.NET.Document document, XElement xml)
      : base(document, xml)
    {
    }

    /// <summary>Gets or sets the Orientation of this PageLayout.</summary>
    public Orientation Orientation
    {
      get
      {
        XElement xelement = this.Xml.Element(XName.Get("pgSz", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement == null)
          return Orientation.Portrait;
        XAttribute xattribute = xelement.Attribute(XName.Get("orient", Xceed.Document.NET.Document.w.NamespaceName));
        return xattribute == null || !xattribute.Value.Equals("Landscape", StringComparison.CurrentCultureIgnoreCase) ? Orientation.Portrait : Orientation.Landscape;
      }
      set
      {
        if (this.Orientation == value)
          return;
        XElement xelement = this.Xml.Element(XName.Get("pgSz", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement == null)
        {
          this.Xml.SetElementValue(XName.Get("pgSz", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement = this.Xml.Element(XName.Get("pgSz", Xceed.Document.NET.Document.w.NamespaceName));
        }
        xelement.SetAttributeValue(XName.Get("orient", Xceed.Document.NET.Document.w.NamespaceName), (object) value.ToString().ToLower());
        if (value == Orientation.Landscape)
        {
          xelement.SetAttributeValue(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName), (object) "16838");
          xelement.SetAttributeValue(XName.Get("h", Xceed.Document.NET.Document.w.NamespaceName), (object) "11906");
        }
        else
        {
          if (value != Orientation.Portrait)
            return;
          xelement.SetAttributeValue(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName), (object) "11906");
          xelement.SetAttributeValue(XName.Get("h", Xceed.Document.NET.Document.w.NamespaceName), (object) "16838");
        }
      }
    }
  }
}
