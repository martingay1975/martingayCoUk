﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfHeaderFooterBase
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using Xceed.Pdf.Layout;

namespace Xceed.Document.NET
{
  internal abstract class PdfHeaderFooterBase : PdfIDrawContent
  {
    internal PdfIConverter _pdfConverterInterface;

    internal PdfHeaderFooterBase(PdfIConverter pdfConverterInterface) => this._pdfConverterInterface = pdfConverterInterface;

    internal abstract void CreatePdfParagraphs(Container container);

    internal abstract void Draw();

    internal void CreatePdfParagraphsCore(
      Container container,
      float marginTop,
      bool resetPdfPageForWrappedObject = true)
    {
      HeaderFooterType headerFooterType = container is Header ? HeaderFooterType.Header : HeaderFooterType.Footer;
      List<Paragraph> list = container.Paragraphs.Where<Paragraph>((Func<Paragraph, bool>) (x => x.ParentContainer != ContainerType.Cell && x.ParentContainer != ContainerType.Shape)).ToList<Paragraph>().ToList<Paragraph>();
      if (list.Count == 0 && this.IsStartingWithTable(container.Xml))
        this._pdfConverterInterface.DrawInitialTables(container, (PdfIDrawContent) this);
      for (int index = 0; index < list.Count; ++index)
      {
        if (index == 0 && this.IsStartingWithTable(container.Xml))
          this._pdfConverterInterface.DrawInitialTables(container, (PdfIDrawContent) this);
        Paragraph paragraph = list[index];
        PdfParagraph pdfParagraph = new PdfParagraph(paragraph, index == 0 ? (Paragraph) null : list[index - 1], index == list.Count - 1 ? (Paragraph) null : list[index + 1], index, this._pdfConverterInterface.GetCurrentPdfPageInfo().PageNumber, this._pdfConverterInterface.GetCurrentPdfPageInfo().Page.Graphics, this._pdfConverterInterface.GetFileToConvert(), this._pdfConverterInterface.GetCurrentSection());
        DocumentElement objectFromParagraph = this._pdfConverterInterface.GetUndrawnWrappedObjectFromParagraph(paragraph, headerFooterType);
        if (objectFromParagraph != null)
        {
          this._pdfConverterInterface.GetCurrentPdfPageInfo().PositionY += pdfParagraph.GetLineSpacingBefore();
          this._pdfConverterInterface.UdpatePdfPageForWrappedObject(objectFromParagraph, pdfParagraph, resetPdfPageForWrappedObject, headerFooterType);
          index = -1;
          this._pdfConverterInterface.GetCurrentPdfPageInfo().PositionY = marginTop;
        }
        else
          this._pdfConverterInterface.DrawPdfParagraph(pdfParagraph, (PdfIDrawContent) this, marginTop, 0.0f);
      }
    }

    private bool IsStartingWithTable(XElement xml)
    {
      XElement xelement = xml.Elements().First<XElement>();
      return xelement != null && xelement.Name.LocalName == "tbl";
    }

    void PdfIDrawContent.DrawText(
      Xceed.Pdf.Layout.Text.Text text,
      PdfParagraph paragraph,
      float marginBottom,
      bool isParagraphKeepingLinesTogether)
    {
      this._pdfConverterInterface.DrawTextWithPosition(text);
    }

    void PdfIDrawContent.DrawPdfTable(
      Table table,
      PdfParagraph paragraph,
      float marginTop,
      float marginBottom,
      int paragraphDrawnLines,
      PdfPageInfo initialCurrentPdfPageInfo)
    {
      PdfTable pdfTable = paragraph.CreatePdfTable(table, this._pdfConverterInterface.GetCurrentPdfPageInfo()) as PdfTable;
      this._pdfConverterInterface.GetCurrentPdfPageInfo().Page.Graphics.MeasureBlock(pdfTable.Table.Left, this._pdfConverterInterface.GetCurrentPdfPageInfo().PositionY, pdfTable.Table.Width, 0.0f, (Block) pdfTable.Table);
      this._pdfConverterInterface.GetCurrentPdfPageInfo().PositionY = pdfTable.AdjustTablePosition(this._pdfConverterInterface.GetCurrentPdfPageInfo());
      if (paragraph.ContainsTotalPageNumber())
      {
        if (!PdfConverter.IsTotalPageNumberCalculated())
        {
          if (!this._pdfConverterInterface.GetCurrentPdfPageInfo().IsTemporaryPage)
            PdfConverter._pageNumberParagraphs.Add(new PdfPageNumberParagraphInfo(initialCurrentPdfPageInfo, paragraph));
          this._pdfConverterInterface.GetCurrentPdfPageInfo().PositionY += pdfTable.Table.Height;
        }
        else
        {
          this._pdfConverterInterface.GetCurrentPdfPageInfo().Page.Graphics.DrawTable(pdfTable.Table.Left, this._pdfConverterInterface.GetCurrentPdfPageInfo().PositionY, pdfTable.Table.Width, pdfTable.Table);
          this._pdfConverterInterface.GetCurrentPdfPageInfo().PositionY += pdfTable.Table.Height;
        }
      }
      else
      {
        this._pdfConverterInterface.GetCurrentPdfPageInfo().Page.Graphics.DrawTable(pdfTable.Table.Left, this._pdfConverterInterface.GetCurrentPdfPageInfo().PositionY, pdfTable.Table.Width, pdfTable.Table);
        this._pdfConverterInterface.GetCurrentPdfPageInfo().PositionY += pdfTable.Table.Height;
      }
    }
  }
}
