﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Document
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a Document.</summary>
  public class Document : Container, IDisposable
  {
    internal static XNamespace w = (XNamespace) "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
    internal static XNamespace rel = (XNamespace) "http://schemas.openxmlformats.org/package/2006/relationships";
    internal static XNamespace r = (XNamespace) "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    internal static XNamespace m = (XNamespace) "http://schemas.openxmlformats.org/officeDocument/2006/math";
    internal static XNamespace customPropertiesSchema = (XNamespace) "http://schemas.openxmlformats.org/officeDocument/2006/custom-properties";
    internal static XNamespace customVTypesSchema = (XNamespace) "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes";
    internal static XNamespace wp = (XNamespace) "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing";
    internal static XNamespace a = (XNamespace) "http://schemas.openxmlformats.org/drawingml/2006/main";
    internal static XNamespace c = (XNamespace) "http://schemas.openxmlformats.org/drawingml/2006/chart";
    internal static XNamespace pic = (XNamespace) "http://schemas.openxmlformats.org/drawingml/2006/picture";
    internal static XNamespace n = (XNamespace) "http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering";
    internal static XNamespace v = (XNamespace) "urn:schemas-microsoft-com:vml";
    internal static XNamespace mc = (XNamespace) "http://schemas.openxmlformats.org/markup-compatibility/2006";
    internal static XNamespace wps = (XNamespace) "http://schemas.microsoft.com/office/word/2010/wordprocessingShape";
    internal static XNamespace w14 = (XNamespace) "http://schemas.microsoft.com/office/word/2010/wordml";
    private readonly object nextFreeDocPrIdLock = new object();
    private long? nextFreeDocPrId;
    private string _defaultParagraphStyleId;
    private IList<Section> _cachedSections;
    private static List<string> _imageContentTypes = new List<string>()
    {
      "image/jpeg",
      "image/jpg",
      "image/png",
      "image/bmp",
      "image/gif",
      "image/tiff",
      "image/icon",
      "image/pcx",
      "image/emf",
      "image/x-emf",
      "image/wmf"
    };
    internal const string RelationshipImage = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image";
    internal const string ContentTypeApplicationRelationShipXml = "application/vnd.openxmlformats-package.relationships+xml";
    internal PackagePart _settingsPart;
    internal PackagePart _endnotesPart;
    internal PackagePart _footnotesPart;
    internal PackagePart _stylesPart;
    internal PackagePart _stylesWithEffectsPart;
    internal PackagePart _numberingPart;
    internal PackagePart _fontTablePart;
    internal Package _package;
    internal XDocument _mainDoc;
    internal XDocument _settings;
    internal XDocument _endnotes;
    internal XDocument _footnotes;
    internal XDocument _styles;
    internal XDocument _stylesWithEffects;
    internal XDocument _numbering;
    internal XDocument _fontTable;
    internal Dictionary<int, Paragraph> _paragraphLookup = new Dictionary<int, Paragraph>();
    internal MemoryStream _memoryStream;
    internal string _filename;
    internal System.IO.Stream _stream;

    /// <summary>Gets the cached list of Sections from this Document.</summary>
    public override IList<Section> Sections => this._cachedSections;

    /// <summary>Gets or sets the top margin (in points) of the first Section in this Document.</summary>
    public float MarginTop
    {
      get
      {
        int count = this.Sections.Count;
        return this.Sections[0].MarginTop;
      }
      set
      {
        int count = this.Sections.Count;
        this.Sections[0].MarginTop = value;
      }
    }

    /// <summary>Gets or sets the bottom margin (in points) of the first Section in this Document.</summary>
    public float MarginBottom
    {
      get
      {
        int count = this.Sections.Count;
        return this.Sections[0].MarginBottom;
      }
      set
      {
        int count = this.Sections.Count;
        this.Sections[0].MarginBottom = value;
      }
    }

    /// <summary>Gets or sets the left margin (in points) of the first Section in this Document.</summary>
    public float MarginLeft
    {
      get
      {
        int count = this.Sections.Count;
        return this.Sections[0].MarginLeft;
      }
      set
      {
        int count = this.Sections.Count;
        this.Sections[0].MarginLeft = value;
      }
    }

    /// <summary>Gets or sets the right margin (in points) of the first Section in this Document.</summary>
    public float MarginRight
    {
      get
      {
        int count = this.Sections.Count;
        return this.Sections[0].MarginRight;
      }
      set
      {
        int count = this.Sections.Count;
        this.Sections[0].MarginRight = value;
      }
    }

    /// <summary>Gets or sets the header margin (in points) of the first Section in this Document.</summary>
    public float MarginHeader
    {
      get
      {
        int count = this.Sections.Count;
        return this.Sections[0].MarginHeader;
      }
      set
      {
        int count = this.Sections.Count;
        this.Sections[0].MarginHeader = value;
      }
    }

    /// <summary>Gets or sets the footer margin (in points) of the first Section in this Document.</summary>
    public float MarginFooter
    {
      get
      {
        int count = this.Sections.Count;
        return this.Sections[0].MarginFooter;
      }
      set
      {
        int count = this.Sections.Count;
        this.Sections[0].MarginFooter = value;
      }
    }

    /// <summary>Gets or sets if the mirror margins option is enabled for the first Section in this Document.</summary>
    public bool MirrorMargins
    {
      get
      {
        int count = this.Sections.Count;
        return this.Sections[0].MirrorMargins;
      }
      set
      {
        int count = this.Sections.Count;
        this.Sections[0].MirrorMargins = value;
      }
    }

    /// <summary>Gets or sets the page width (in points) of the first Section in this Document.</summary>
    public float PageWidth
    {
      get
      {
        int count = this.Sections.Count;
        return this.Sections[0].PageWidth;
      }
      set
      {
        int count = this.Sections.Count;
        this.Sections[0].PageWidth = value;
      }
    }

    /// <summary>Gets or sets the page height (in points) of the first Section in this Document.</summary>
    public float PageHeight
    {
      get
      {
        int count = this.Sections.Count;
        return this.Sections[0].PageHeight;
      }
      set
      {
        int count = this.Sections.Count;
        this.Sections[0].PageHeight = value;
      }
    }

    /// <summary>Gets or sets the background color to use for all the pages in the document.</summary>
    public Color PageBackground
    {
      get
      {
        XElement xelement = this._mainDoc.Root.Element(XName.Get("background", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement != null)
        {
          XAttribute xattribute = xelement.Attribute(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName));
          if (xattribute != null)
            return HelperFunctions.GetColorFromHtml(xattribute.Value);
        }
        return Color.White;
      }
      set
      {
        this._mainDoc.Root.Element(XName.Get("background", Xceed.Document.NET.Document.w.NamespaceName))?.Remove();
        XElement xelement = new XElement(XName.Get("background", Xceed.Document.NET.Document.w.NamespaceName));
        this._mainDoc.Root.AddFirst((object) xelement);
        xelement.SetAttributeValue(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName), (object) value.ToHex());
      }
    }

    /// <summary>Gets or sets the <strong>Borders</strong> to use for all the pages of the first Section in this Document.</summary>
    public Borders PageBorders
    {
      get
      {
        int count = this.Sections.Count;
        return this.Sections[0].PageBorders;
      }
      set
      {
        int count = this.Sections.Count;
        this.Sections[0].PageBorders = value;
      }
    }

    /// <summary>Gets if any editing restrictions are imposed on this Document.</summary>
    public bool isProtected => this._settings.Descendants(XName.Get("documentProtection", Xceed.Document.NET.Document.w.NamespaceName)).Count<XElement>() > 0;

    /// <summary>Gets the PageLayout of the first Section in this Document.</summary>
    public PageLayout PageLayout
    {
      get
      {
        int count = this.Sections.Count;
        return this.Sections[0].PageLayout;
      }
    }

    /// <summary>Gets the Headers of the first Section in this Document.</summary>
    public Headers Headers
    {
      get
      {
        int count = this.Sections.Count;
        return this.Sections[0].Headers;
      }
    }

    /// <summary>Gets the Footers of the first Section in this Document.</summary>
    public Footers Footers
    {
      get
      {
        int count = this.Sections.Count;
        return this.Sections[0].Footers;
      }
    }

    /// <summary>Gets or sets if the even and odd pages of the Document use different Headers and <see cref="Xceed.Document.NET~Xceed.Document.NET.Footer.html">Footers</see>.</summary>
    public bool DifferentOddAndEvenPages
    {
      get
      {
        XDocument xdocument;
        using (TextReader textReader = (TextReader) new StreamReader((System.IO.Stream) new PackagePartStream(this._settingsPart.GetStream())))
          xdocument = XDocument.Load(textReader);
        return xdocument.Root.Element(Xceed.Document.NET.Document.w + "evenAndOddHeaders") != null;
      }
      set
      {
        XDocument xdocument;
        using (TextReader textReader = (TextReader) new StreamReader(this._settingsPart.GetStream()))
          xdocument = XDocument.Load(textReader);
        XElement xelement = xdocument.Root.Element(Xceed.Document.NET.Document.w + "evenAndOddHeaders");
        if (xelement == null)
        {
          if (value)
            xdocument.Root.AddFirst((object) new XElement(Xceed.Document.NET.Document.w + "evenAndOddHeaders"));
        }
        else if (!value)
          xelement.Remove();
        using (TextWriter textWriter = (TextWriter) new StreamWriter((System.IO.Stream) new PackagePartStream(this._settingsPart.GetStream())))
          xdocument.Save(textWriter);
      }
    }

    /// <summary>Gets or sets if the first page of the first Section in this Document uses an independent Header
    /// and <see cref="Xceed.Document.NET~Xceed.Document.NET.Footer.html">Footer</see>.</summary>
    public bool DifferentFirstPage
    {
      get
      {
        int count = this.Sections.Count;
        return this.Sections[0].DifferentFirstPage;
      }
      set
      {
        int count = this.Sections.Count;
        this.Sections[0].DifferentFirstPage = value;
      }
    }

    /// <summary>Gets the collection of Images in this Document.</summary>
    public List<Image> Images
    {
      get
      {
        PackageRelationshipCollection relationshipsByType = this.PackagePart.GetRelationshipsByType("http://schemas.openxmlformats.org/officeDocument/2006/relationships/image");
        return ((IEnumerable<PackageRelationship>) relationshipsByType).Any<PackageRelationship>() ? ((IEnumerable<PackageRelationship>) relationshipsByType).Select<PackageRelationship, Image>((Func<PackageRelationship, Image>) (i => new Image(this, i))).ToList<Image>() : new List<Image>();
      }
    }

    /// <summary>Gets the dictionary for the CustomProperties in this Document.</summary>
    public Dictionary<string, CustomProperty> CustomProperties
    {
      get
      {
        if (!this._package.PartExists(new Uri("/docProps/custom.xml", UriKind.Relative)))
          return new Dictionary<string, CustomProperty>();
        XDocument xdocument;
        using (TextReader textReader = (TextReader) new StreamReader(this._package.GetPart(new Uri("/docProps/custom.xml", UriKind.Relative)).GetStream(FileMode.Open, FileAccess.Read)))
          xdocument = XDocument.Load(textReader, LoadOptions.PreserveWhitespace);
        return xdocument.Descendants(XName.Get("property", Xceed.Document.NET.Document.customPropertiesSchema.NamespaceName)).Select(p => new
        {
          p = p,
          Name = p.Attribute(XName.Get("name")).Value
        }).Select(_param1 => new
        {
          \u003C\u003Eh__TransparentIdentifier0 = _param1,
          Type = _param1.p.Descendants().Single<XElement>().Name.LocalName
        }).Select(_param1 => new
        {
          \u003C\u003Eh__TransparentIdentifier1 = _param1,
          Value = _param1.\u003C\u003Eh__TransparentIdentifier0.p.Descendants().Single<XElement>().Value
        }).Select(_param1 => new CustomProperty(_param1.\u003C\u003Eh__TransparentIdentifier1.\u003C\u003Eh__TransparentIdentifier0.Name, _param1.\u003C\u003Eh__TransparentIdentifier1.Type, _param1.Value)).ToDictionary<CustomProperty, string>((Func<CustomProperty, string>) (p => p.Name), (IEqualityComparer<string>) StringComparer.CurrentCultureIgnoreCase);
      }
    }

    /// <summary>Gets the dictionary for the core properties in this Document.</summary>
    public Dictionary<string, string> CoreProperties
    {
      get
      {
        if (!this._package.PartExists(new Uri("/docProps/core.xml", UriKind.Relative)))
          return new Dictionary<string, string>();
        XDocument corePropDoc;
        using (TextReader textReader = (TextReader) new StreamReader(this._package.GetPart(new Uri("/docProps/core.xml", UriKind.Relative)).GetStream(FileMode.Open, FileAccess.Read)))
          corePropDoc = XDocument.Load(textReader, LoadOptions.PreserveWhitespace);
        return corePropDoc.Root.Elements().Select<XElement, KeyValuePair<string, string>>((Func<XElement, KeyValuePair<string, string>>) (docProperty => new KeyValuePair<string, string>(string.Format("{0}:{1}", (object) corePropDoc.Root.GetPrefixOfNamespace(docProperty.Name.Namespace), (object) docProperty.Name.LocalName), docProperty.Value))).ToDictionary<KeyValuePair<string, string>, string, string>((Func<KeyValuePair<string, string>, string>) (p => p.Key), (Func<KeyValuePair<string, string>, string>) (v => v.Value));
      }
    }

    /// <summary>Gets the Text in this Document.</summary>
    public string Text => HelperFunctions.GetText(this.Xml);

    /// <summary>Gets the collection of Paragraphs in this Document.</summary>
    public override ReadOnlyCollection<Paragraph> Paragraphs
    {
      get
      {
        ReadOnlyCollection<Paragraph> paragraphs = base.Paragraphs;
        foreach (DocumentElement documentElement in paragraphs)
          documentElement.PackagePart = this.PackagePart;
        return paragraphs;
      }
    }

    /// <summary>Gets the collection of Lists in this Document.</summary>
    public override List<List> Lists
    {
      get
      {
        List<List> lists = base.Lists;
        lists.ForEach((System.Action<List>) (x => x.Items.ForEach((System.Action<Paragraph>) (i => i.PackagePart = this.PackagePart))));
        return lists;
      }
    }

    /// <summary>Gets the collection of Tables in this Document.</summary>
    public override List<Table> Tables
    {
      get
      {
        List<Table> tables = base.Tables;
        tables.ForEach((System.Action<Table>) (x => x.PackagePart = this.PackagePart));
        return tables;
      }
    }

    /// <summary>Gets the list of foot notes in this Document.</summary>
    public IEnumerable<string> FootnotesText
    {
      get
      {
        foreach (XElement element in this._footnotes.Root.Elements(Xceed.Document.NET.Document.w + "footnote"))
          yield return HelperFunctions.GetText(element);
      }
    }

    /// <summary>Gets the list of end notes in this Document.</summary>
    public IEnumerable<string> EndnotesText
    {
      get
      {
        foreach (XElement element in this._endnotes.Root.Elements(Xceed.Document.NET.Document.w + "endnote"))
          yield return HelperFunctions.GetText(element);
      }
    }

    /// <summary>Gets the collection of Bookmarks in this Document.</summary>
    public BookmarkCollection Bookmarks
    {
      get
      {
        BookmarkCollection bookmarkCollection1 = new BookmarkCollection();
        foreach (XElement descendant in this.Xml.Descendants(XName.Get("bookmarkStart", Xceed.Document.NET.Document.w.NamespaceName)))
        {
          XElement parent = descendant.Parent;
          while (parent.Name != XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName))
            parent = parent.Parent;
          BookmarkCollection bookmarkCollection2 = bookmarkCollection1;
          Bookmark bookmark = new Bookmark();
          bookmark.Name = descendant.Attribute(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName)).Value;
          Paragraph paragraph = new Paragraph(this, parent, -1);
          paragraph.PackagePart = this.PackagePart;
          bookmark.Paragraph = paragraph;
          bookmarkCollection2.Add(bookmark);
        }
        foreach (Section section in (IEnumerable<Section>) this.Sections)
        {
          Headers headers = section.Headers;
          if (headers != null)
          {
            if (headers.Odd != null)
            {
              foreach (Paragraph paragraph in headers.Odd.Paragraphs)
                bookmarkCollection1.AddRange(paragraph.GetBookmarks());
            }
            if (headers.Even != null)
            {
              foreach (Paragraph paragraph in headers.Even.Paragraphs)
                bookmarkCollection1.AddRange(paragraph.GetBookmarks());
            }
            if (headers.First != null)
            {
              foreach (Paragraph paragraph in headers.First.Paragraphs)
                bookmarkCollection1.AddRange(paragraph.GetBookmarks());
            }
          }
          Footers footers = section.Footers;
          if (footers != null)
          {
            if (footers.Odd != null)
            {
              foreach (Paragraph paragraph in footers.Odd.Paragraphs)
                bookmarkCollection1.AddRange(paragraph.GetBookmarks());
            }
            if (footers.Even != null)
            {
              foreach (Paragraph paragraph in footers.Even.Paragraphs)
                bookmarkCollection1.AddRange(paragraph.GetBookmarks());
            }
            if (footers.First != null)
            {
              foreach (Paragraph paragraph in footers.First.Paragraphs)
                bookmarkCollection1.AddRange(paragraph.GetBookmarks());
            }
          }
        }
        return bookmarkCollection1;
      }
    }

    /// <summary>Gets the collection of CheckBoxes in this Document.</summary>
    public List<CheckBox> CheckBoxes
    {
      get
      {
        List<CheckBox> checkBoxList = new List<CheckBox>();
        foreach (XObject descendant in this.Xml.Descendants(XName.Get("checkbox", Xceed.Document.NET.Document.w14.NamespaceName)))
        {
          XElement parent = descendant.Parent;
          while (parent.Name != XName.Get("sdt", Xceed.Document.NET.Document.w.NamespaceName))
            parent = parent.Parent;
          checkBoxList.Add(new CheckBox(this, parent));
        }
        return checkBoxList;
      }
    }

    /// <summary>Inserts a Section in the Document by making a copy of the previous Section, and optionally track this change.</summary>
    /// <returns>The section that was inserted.</returns>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public override Section InsertSection(bool trackChanges) => this.InsertSection(trackChanges, false);

    /// <summary>Inserts a Section page break to the Document by making a copy of the previous Section, and optionally track this change.</summary>
    /// <returns>The section that was inserted.</returns>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public override Section InsertSectionPageBreak(bool trackChanges = false) => this.InsertSection(trackChanges, true);

    public override void ReplaceText(
      string searchValue,
      string newValue,
      bool trackChanges = false,
      RegexOptions options = RegexOptions.None,
      Formatting newFormatting = null,
      Formatting matchFormatting = null,
      MatchFormattingOptions fo = MatchFormattingOptions.SubsetMatch,
      bool escapeRegEx = true,
      bool useRegExSubstitutions = false,
      bool removeEmptyParagraph = true)
    {
      base.ReplaceText(searchValue, newValue, trackChanges, options, newFormatting, matchFormatting, fo, escapeRegEx, useRegExSubstitutions, removeEmptyParagraph);
      foreach (Section section in (IEnumerable<Section>) this.Sections)
      {
        foreach (Header header in new List<Header>()
        {
          section.Headers.First,
          section.Headers.Even,
          section.Headers.Odd
        })
        {
          if (header != null)
          {
            foreach (Paragraph paragraph in header.Paragraphs)
              paragraph.ReplaceText(searchValue, newValue, trackChanges, options, newFormatting, matchFormatting, fo, escapeRegEx, useRegExSubstitutions, removeEmptyParagraph);
          }
        }
      }
      foreach (Section section in (IEnumerable<Section>) this.Sections)
      {
        foreach (Footer footer in new List<Footer>()
        {
          section.Footers.First,
          section.Footers.Even,
          section.Footers.Odd
        })
        {
          if (footer != null)
          {
            foreach (Paragraph paragraph in footer.Paragraphs)
              paragraph.ReplaceText(searchValue, newValue, trackChanges, options, newFormatting, matchFormatting, fo, escapeRegEx, useRegExSubstitutions, removeEmptyParagraph);
          }
        }
      }
    }

    public override void ReplaceText(
      string searchValue,
      Func<string, string> regexMatchHandler,
      bool trackChanges = false,
      RegexOptions options = RegexOptions.None,
      Formatting newFormatting = null,
      Formatting matchFormatting = null,
      MatchFormattingOptions fo = MatchFormattingOptions.SubsetMatch,
      bool removeEmptyParagraph = true)
    {
      base.ReplaceText(searchValue, regexMatchHandler, trackChanges, options, newFormatting, matchFormatting, fo, removeEmptyParagraph);
      foreach (Section section in (IEnumerable<Section>) this.Sections)
      {
        foreach (IParagraphContainer paragraphContainer in new List<IParagraphContainer>()
        {
          (IParagraphContainer) section.Headers.First,
          (IParagraphContainer) section.Headers.Even,
          (IParagraphContainer) section.Headers.Odd,
          (IParagraphContainer) section.Footers.First,
          (IParagraphContainer) section.Footers.Even,
          (IParagraphContainer) section.Footers.Odd
        })
        {
          if (paragraphContainer != null)
          {
            foreach (Paragraph paragraph in paragraphContainer.Paragraphs)
              paragraph.ReplaceText(searchValue, regexMatchHandler, trackChanges, options, newFormatting, matchFormatting, fo, removeEmptyParagraph);
          }
        }
      }
    }

    public override void ReplaceTextWithObject(
      string searchValue,
      DocumentElement objectToAdd,
      bool trackChanges = false,
      RegexOptions options = RegexOptions.None,
      Formatting matchFormatting = null,
      MatchFormattingOptions fo = MatchFormattingOptions.SubsetMatch,
      bool escapeRegEx = true,
      bool removeEmptyParagraph = true)
    {
      base.ReplaceTextWithObject(searchValue, objectToAdd, trackChanges, options, matchFormatting, fo, escapeRegEx, removeEmptyParagraph);
      foreach (Section section in (IEnumerable<Section>) this.Sections)
      {
        foreach (Header header in new List<Header>()
        {
          section.Headers.First,
          section.Headers.Even,
          section.Headers.Odd
        })
        {
          if (header != null)
          {
            foreach (Paragraph paragraph in header.Paragraphs)
              paragraph.ReplaceTextWithObject(searchValue, objectToAdd, trackChanges, options, matchFormatting, fo, escapeRegEx, removeEmptyParagraph);
          }
        }
      }
      foreach (Section section in (IEnumerable<Section>) this.Sections)
      {
        foreach (Footer footer in new List<Footer>()
        {
          section.Footers.First,
          section.Footers.Even,
          section.Footers.Odd
        })
        {
          if (footer != null)
          {
            foreach (Paragraph paragraph in footer.Paragraphs)
              paragraph.ReplaceTextWithObject(searchValue, objectToAdd, trackChanges, options, matchFormatting, fo, escapeRegEx, removeEmptyParagraph);
          }
        }
      }
    }

    public override void InsertAtBookmark(
      string toInsert,
      string bookmarkName,
      Formatting formatting = null)
    {
      base.InsertAtBookmark(toInsert, bookmarkName, formatting);
      foreach (Section section in (IEnumerable<Section>) this.Sections)
      {
        Headers headers = section.Headers;
        foreach (Container container in new List<Header>()
        {
          headers.First,
          headers.Even,
          headers.Odd
        }.Where<Header>((Func<Header, bool>) (x => x != null)))
        {
          foreach (Paragraph paragraph in container.Paragraphs)
            paragraph.InsertAtBookmark(toInsert, bookmarkName, formatting);
        }
        Footers footers = section.Footers;
        foreach (Container container in new List<Footer>()
        {
          footers.First,
          footers.Even,
          footers.Odd
        }.Where<Footer>((Func<Footer, bool>) (x => x != null)))
        {
          foreach (Paragraph paragraph in container.Paragraphs)
            paragraph.InsertAtBookmark(toInsert, bookmarkName, formatting);
        }
      }
    }

    public override string[] ValidateBookmarks(params string[] bookmarkNames)
    {
      List<string> list1 = ((IEnumerable<string>) base.ValidateBookmarks(bookmarkNames)).ToList<string>();
      foreach (string bookmarkName1 in bookmarkNames)
      {
        string bookmarkName = bookmarkName1;
        foreach (Section section in (IEnumerable<Section>) this.Sections)
        {
          List<Header> list2 = ((IEnumerable<Header>) new Header[3]
          {
            section.Headers.First,
            section.Headers.Even,
            section.Headers.Odd
          }).Where<Header>((Func<Header, bool>) (h => h != null)).ToList<Header>();
          List<Footer> list3 = ((IEnumerable<Footer>) new Footer[3]
          {
            section.Footers.First,
            section.Footers.Even,
            section.Footers.Odd
          }).Where<Footer>((Func<Footer, bool>) (f => f != null)).ToList<Footer>();
          if (list2.SelectMany<Header, Paragraph>((Func<Header, IEnumerable<Paragraph>>) (h => (IEnumerable<Paragraph>) h.Paragraphs)).Any<Paragraph>((Func<Paragraph, bool>) (p => p.ValidateBookmark(bookmarkName))))
            return new string[0];
          if (list3.SelectMany<Footer, Paragraph>((Func<Footer, IEnumerable<Paragraph>>) (h => (IEnumerable<Paragraph>) h.Paragraphs)).Any<Paragraph>((Func<Paragraph, bool>) (p => p.ValidateBookmark(bookmarkName))))
            return new string[0];
        }
        list1.Add(bookmarkName);
      }
      return list1.ToArray();
    }

    /// <summary>
    ///   <span id="BugEvents">Retrieves the paragraph's style id from the document, using the provided style name.</span>
    /// </summary>
    /// <returns>The style id of the paragraph.</returns>
    /// <param name="document">The document to search in.</param>
    /// <param name="styleName">The style name to search for.</param>
    public static string GetParagraphStyleIdFromStyleName(Xceed.Document.NET.Document document, string styleName)
    {
      if (string.IsNullOrEmpty(styleName) || document == null)
        return (string) null;
      if (document._styles == null)
      {
        using (StreamReader streamReader = new StreamReader(document._package.GetPart(new Uri("/word/styles.xml", UriKind.Relative)).GetStream()))
          document._styles = XDocument.Load((TextReader) streamReader);
      }
      XElement styleFromStyleName = HelperFunctions.GetParagraphStyleFromStyleName(document, styleName);
      if (styleFromStyleName != null)
      {
        XAttribute xattribute = styleFromStyleName.Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null)
          return xattribute.Value;
      }
      return (string) null;
    }

    public EditRestrictions GetProtectionType()
    {
      if (!this.isProtected)
        return EditRestrictions.none;
      return (EditRestrictions) Enum.Parse(typeof (EditRestrictions), this._settings.Descendants(XName.Get("documentProtection", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>().Attribute(XName.Get("edit", Xceed.Document.NET.Document.w.NamespaceName)).Value);
    }

    public void AddProtection(EditRestrictions er)
    {
      this.RemoveProtection();
      if (er == EditRestrictions.none)
        return;
      XElement xelement = new XElement(XName.Get("documentProtection", Xceed.Document.NET.Document.w.NamespaceName));
      xelement.Add((object) new XAttribute(XName.Get("edit", Xceed.Document.NET.Document.w.NamespaceName), (object) er.ToString()));
      xelement.Add((object) new XAttribute(XName.Get("enforcement", Xceed.Document.NET.Document.w.NamespaceName), (object) "1"));
      this._settings.Root.AddFirst((object) xelement);
    }

    public void RemoveProtection() => this._settings.Descendants(XName.Get("documentProtection", Xceed.Document.NET.Document.w.NamespaceName)).Remove<XElement>();

    /// <summary>Insert the contents of another document at the end of this Document.</summary>
    /// <param name="remote_document">The document to insert at the end of this document.</param>
    /// <param name="append">
    /// <strong>true</strong> if the document is added at the end, otherwise <strong>false</strong> if the document is added at the beginning.</param>
    /// <param name="useSectionBreak">
    ///         <strong>true</strong> if each joined document will be located in its own section. otherwise <strong>false</strong> if the documents will remain in the same
    /// section.</param>
    /// <param name="mergingMode">The action to take when merging two documents, and either two styles have the same name but with different attributes, or the resulting document needs to have
    /// headers/footers.</param>
    public void InsertDocument(
      Xceed.Document.NET.Document remote_document,
      bool append = true,
      bool useSectionBreak = true,
      MergingMode mergingMode = MergingMode.Both)
    {
      XDocument remote_mainDoc = new XDocument(remote_document._mainDoc);
      XDocument remote_footnotes = (XDocument) null;
      if (remote_document._footnotes != null)
        remote_footnotes = new XDocument(remote_document._footnotes);
      XDocument remote_endnotes = (XDocument) null;
      if (remote_document._endnotes != null)
        remote_endnotes = new XDocument(remote_document._endnotes);
      XElement xelement = remote_mainDoc.Root.Element(XName.Get("body", Xceed.Document.NET.Document.w.NamespaceName));
      XElement first = this._mainDoc.Root.Element(XName.Get("body", Xceed.Document.NET.Document.w.NamespaceName));
      if (mergingMode == MergingMode.Remote)
      {
        this.DeleteHeadersOrFooters(true, false);
        this.DeleteHeadersOrFooters(false, false);
      }
      PackagePartCollection parts = remote_document._package.GetParts();
      List<string> stringList = new List<string>()
      {
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml",
        "application/vnd.openxmlformats-package.core-properties+xml",
        "application/vnd.openxmlformats-officedocument.extended-properties+xml",
        "application/vnd.openxmlformats-package.relationships+xml"
      };
      using (IEnumerator<PackagePart> enumerator = parts.GetEnumerator())
      {
        while (((IEnumerator) enumerator).MoveNext())
        {
          PackagePart current = enumerator.Current;
          if (!stringList.Contains(current.get_ContentType()) && !Xceed.Document.NET.Document._imageContentTypes.Contains(current.get_ContentType()))
          {
            if (this._package.PartExists(current.get_Uri()))
            {
              PackagePart part = this._package.GetPart(current.get_Uri());
              switch (current.get_ContentType())
              {
                case "application/vnd.ms-word.stylesWithEffects+xml":
                  this.merge_styles(current, part, remote_mainDoc, remote_document, remote_footnotes, remote_endnotes, mergingMode);
                  continue;
                case "application/vnd.openxmlformats-officedocument.custom-properties+xml":
                  this.merge_customs(current, part, remote_mainDoc);
                  continue;
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.endnotes+xml":
                  this.merge_endnotes(current, part, remote_mainDoc, remote_document, remote_endnotes);
                  continue;
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.fontTable+xml":
                  this.merge_fonts(current, part, remote_mainDoc, remote_document);
                  continue;
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml":
                  this.merge_headerFooters(false, current, remote_mainDoc, remote_document, mergingMode);
                  continue;
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml":
                  this.merge_footnotes(current, part, remote_mainDoc, remote_document, remote_footnotes);
                  continue;
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml":
                  this.merge_headerFooters(true, current, remote_mainDoc, remote_document, mergingMode);
                  continue;
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml":
                  this.merge_numbering(current, part, remote_mainDoc, remote_document);
                  continue;
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml":
                  this.merge_styles(current, part, remote_mainDoc, remote_document, this._footnotes, this._endnotes, mergingMode);
                  continue;
                default:
                  continue;
              }
            }
            else
            {
              PackagePart packagePart = this.clonePackagePart(current);
              switch (current.get_ContentType())
              {
                case "application/vnd.ms-word.stylesWithEffects+xml":
                  this._stylesWithEffectsPart = packagePart;
                  using (TextReader textReader = (TextReader) new StreamReader(this._stylesWithEffectsPart.GetStream()))
                  {
                    this._stylesWithEffects = XDocument.Load(textReader);
                    break;
                  }
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.endnotes+xml":
                  this._endnotesPart = packagePart;
                  this._endnotes = remote_endnotes;
                  break;
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.fontTable+xml":
                  this._fontTablePart = packagePart;
                  using (TextReader textReader = (TextReader) new StreamReader(this._fontTablePart.GetStream()))
                  {
                    this._fontTable = XDocument.Load(textReader);
                    break;
                  }
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml":
                  this.merge_headerFooters(false, current, remote_mainDoc, remote_document, mergingMode);
                  break;
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml":
                  this._footnotesPart = packagePart;
                  this._footnotes = remote_footnotes;
                  break;
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml":
                  this.merge_headerFooters(true, current, remote_mainDoc, remote_document, mergingMode);
                  break;
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml":
                  this._numberingPart = packagePart;
                  using (TextReader textReader = (TextReader) new StreamReader(this._numberingPart.GetStream()))
                  {
                    this._numbering = XDocument.Load(textReader);
                    break;
                  }
                case "application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml":
                  this._stylesPart = packagePart;
                  using (TextReader textReader = (TextReader) new StreamReader(this._stylesPart.GetStream()))
                  {
                    this._styles = XDocument.Load(textReader);
                    break;
                  }
              }
              this.clonePackageRelationship(remote_document, current, remote_mainDoc);
            }
          }
        }
      }
      switch (mergingMode)
      {
        case MergingMode.Local:
          this.UpdateHeaderFooterReferences(true, xelement, this._mainDoc.Root);
          this.UpdateHeaderFooterReferences(false, xelement, this._mainDoc.Root);
          break;
        case MergingMode.Remote:
          this.UpdateHeaderFooterReferences(true, this._mainDoc.Root, xelement);
          this.UpdateHeaderFooterReferences(false, this._mainDoc.Root, xelement);
          break;
      }
      if (useSectionBreak)
        this.MoveSectionIntoLastParagraph(append ? first : xelement);
      else if (append)
        this.ReplaceLastSection(first, xelement);
      else
        this.RemoveLastSection(xelement);
      using (IEnumerator<PackageRelationship> enumerator = remote_document.PackagePart.GetRelationshipsByType("http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink").GetEnumerator())
      {
        while (((IEnumerator) enumerator).MoveNext())
        {
          PackageRelationship current = enumerator.Current;
          string id1 = current.get_Id();
          string id2 = this.PackagePart.CreateRelationship(current.get_TargetUri(), current.get_TargetMode(), current.get_RelationshipType()).get_Id();
          foreach (XElement descendant in remote_mainDoc.Descendants(XName.Get("hyperlink", Xceed.Document.NET.Document.w.NamespaceName)))
          {
            XAttribute xattribute = descendant.Attribute(XName.Get("id", Xceed.Document.NET.Document.r.NamespaceName));
            if (xattribute != null && xattribute.Value == id1)
              xattribute.SetValue((object) id2);
          }
        }
      }
      using (IEnumerator<PackageRelationship> enumerator = remote_document.PackagePart.GetRelationshipsByType("http://schemas.openxmlformats.org/officeDocument/2006/relationships/oleObject").GetEnumerator())
      {
        while (((IEnumerator) enumerator).MoveNext())
        {
          PackageRelationship current = enumerator.Current;
          string id1 = current.get_Id();
          string id2 = this.PackagePart.CreateRelationship(current.get_TargetUri(), current.get_TargetMode(), current.get_RelationshipType()).get_Id();
          foreach (XElement descendant in remote_mainDoc.Descendants(XName.Get("OLEObject", "urn:schemas-microsoft-com:office:office")))
          {
            XAttribute xattribute = descendant.Attribute(XName.Get("id", Xceed.Document.NET.Document.r.NamespaceName));
            if (xattribute != null && xattribute.Value == id1)
              xattribute.SetValue((object) id2);
          }
        }
      }
      PackageRelationshipCollection relationshipsByType1 = remote_document.PackagePart.GetRelationshipsByType("http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering");
      PackageRelationshipCollection relationshipsByType2 = this.PackagePart.GetRelationshipsByType("http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering");
      if (((IEnumerable<PackageRelationship>) relationshipsByType1).Count<PackageRelationship>() > 0 && ((IEnumerable<PackageRelationship>) relationshipsByType2).Count<PackageRelationship>() == 0)
      {
        using (IEnumerator<PackageRelationship> enumerator = relationshipsByType1.GetEnumerator())
        {
          while (((IEnumerator) enumerator).MoveNext())
          {
            PackageRelationship current = enumerator.Current;
            this.PackagePart.CreateRelationship(current.get_TargetUri(), current.get_TargetMode(), current.get_RelationshipType());
          }
        }
      }
      PackageRelationshipCollection relationshipsByType3 = remote_document._fontTablePart.GetRelationshipsByType("http://schemas.openxmlformats.org/officeDocument/2006/relationships/font");
      PackageRelationshipCollection relationshipsByType4 = this._fontTablePart.GetRelationshipsByType("http://schemas.openxmlformats.org/officeDocument/2006/relationships/font");
      if (((IEnumerable<PackageRelationship>) relationshipsByType3).Count<PackageRelationship>() > 0 && ((IEnumerable<PackageRelationship>) relationshipsByType4).Count<PackageRelationship>() == 0)
      {
        using (IEnumerator<PackageRelationship> enumerator = relationshipsByType3.GetEnumerator())
        {
          while (((IEnumerator) enumerator).MoveNext())
          {
            PackageRelationship current = enumerator.Current;
            this._fontTablePart.CreateRelationship(current.get_TargetUri(), current.get_TargetMode(), current.get_RelationshipType());
          }
        }
      }
      using (IEnumerator<PackagePart> enumerator = parts.GetEnumerator())
      {
        while (((IEnumerator) enumerator).MoveNext())
        {
          PackagePart current = enumerator.Current;
          if (Xceed.Document.NET.Document._imageContentTypes.Contains(current.get_ContentType()))
            this.merge_images(current, remote_document, remote_mainDoc, current.get_ContentType());
        }
      }
      int num1 = 0;
      foreach (XElement descendant in this._mainDoc.Root.Descendants(XName.Get("docPr", Xceed.Document.NET.Document.wp.NamespaceName)))
      {
        XAttribute xattribute = descendant.Attribute(XName.Get("id"));
        int result;
        if (xattribute != null && HelperFunctions.TryParseInt(xattribute.Value, out result) && result > num1)
          num1 = result;
      }
      int num2 = num1 + 1;
      foreach (XElement descendant in xelement.Descendants(XName.Get("docPr", Xceed.Document.NET.Document.wp.NamespaceName)))
      {
        descendant.SetAttributeValue(XName.Get("id"), (object) num2);
        ++num2;
      }
      if (append)
        first.Add((object) xelement.Elements());
      else
        first.AddFirst((object) xelement.Elements());
      foreach (XAttribute attribute in remote_mainDoc.Root.Attributes())
      {
        if (this._mainDoc.Root.Attribute(attribute.Name) == null)
          this._mainDoc.Root.SetAttributeValue(attribute.Name, (object) attribute.Value);
      }
      this.UpdateCacheSections();
    }

    public new Table InsertTable(int rowCount, int columnCount)
    {
      Table table = rowCount >= 1 && columnCount >= 1 ? base.InsertTable(rowCount, columnCount) : throw new ArgumentOutOfRangeException("Row and Column count must be greater than zero.");
      table.PackagePart = this.PackagePart;
      return table;
    }

    /// <summary>Adds a Table to a Document, using the provided row count and column count for the size.</summary>
    /// <returns>The newly created Table.</returns>
    /// <param name="rowCount">The row count for the new Table.</param>
    /// <param name="columnCount">The column count for the new Table.</param>
    public Table AddTable(int rowCount, int columnCount)
    {
      if (rowCount < 1 || columnCount < 1)
        throw new ArgumentOutOfRangeException("Row and Column count must be greater than zero.");
      Table table = new Table(this, HelperFunctions.CreateTable(rowCount, columnCount), this.PackagePart);
      table.PackagePart = this.PackagePart;
      return table;
    }

    /// <summary>Adds a copy of the provided Table to a Document.</summary>
    /// <returns>The newly created Table.</returns>
    /// <param name="t">The <strong>Table</strong> to copy to create the new Table.</param>
    public Table AddTable(Table t)
    {
      Table table = new Table(this.Document, new XElement(t.Xml), this.PackagePart);
      table.Design = t.Design;
      table.PackagePart = this.PackagePart;
      return table;
    }

    public new Table InsertTable(int index, Table t)
    {
      Table table = base.InsertTable(index, t);
      table.PackagePart = this.PackagePart;
      return table;
    }

    public new Table InsertTable(Table t)
    {
      t = base.InsertTable(t);
      t.PackagePart = this.PackagePart;
      return t;
    }

    public new Table InsertTable(int index, int rowCount, int columnCount)
    {
      if (rowCount < 1 || columnCount < 1)
        throw new ArgumentOutOfRangeException("Row and Column count must be greater than zero.");
      Table table = base.InsertTable(index, rowCount, columnCount);
      table.PackagePart = this.PackagePart;
      return table;
    }

    /// <summary>Adds a Shape to a Document.</summary>
    /// <returns>The newly created Shape.</returns>
    /// <param name="width">The width of the Shape (in points).</param>
    /// <param name="height">The height of the Shape (in points).</param>
    /// <param name="fillColor">The <strong>Color</strong> used to fill the Shape. If not defined, <strong>blue("4472C4")</strong> is used.</param>
    /// <param name="outlineColor">The <strong>Color</strong> used for the outline of the Shape. If not defined, <strong>dark blue("2F528F")</strong> is used.</param>
    /// <param name="outlineWidth">The width used for the outline of the Shape (in points). If not defined, <strong>1</strong> is used.</param>
    /// <param name="outlineDash">The dash style used for the outline of the Shape. If not defined, <strong>Solid</strong> is used.</param>
    public Shape AddShape(
      float width,
      float height,
      Color? fillColor = null,
      Color? outlineColor = null,
      float outlineWidth = 1f,
      DashStyle? outlineDash = null)
    {
      Shape shape = new Shape(this, HelperFunctions.CreateShape(this.GetNextFreeDocPrId(), width, height, fillColor, outlineColor, outlineWidth, outlineDash));
      shape.PackagePart = this.PackagePart;
      return shape;
    }

    /// <summary>Adds a TextBox to a Document.</summary>
    /// <returns>The newly created TextBox.</returns>
    /// <param name="width">The width of the TextBox (in points).</param>
    /// <param name="height">The height of the TextBox (in points).</param>
    /// <param name="text">The text to use in the TextBox. If not defined, an <strong>empty paragraph</strong> is used.</param>
    /// <param name="formatting">The Formatting to use for the text in the TextBox.</param>
    /// <param name="fillColor">The <strong>Color</strong> used to fill the TextBox. If not defined, <strong>white</strong> is used.</param>
    /// <param name="outlineColor">The <strong>Color</strong> used for the outline of the TextBox. If not defined, <strong>black</strong> is used.</param>
    /// <param name="outlineWidth">The width used for the outline of the TextBox (in points). If not defined, <strong>1</strong> is used.</param>
    /// <param name="outlineDash">The dash style used for the outline of the TextBox. If not defined, <strong>Solid</strong> is used.</param>
    public Shape AddTextBox(
      float width,
      float height,
      string text = "",
      Formatting formatting = null,
      Color? fillColor = null,
      Color? outlineColor = null,
      float outlineWidth = 1f,
      DashStyle? outlineDash = null)
    {
      Paragraph paragraph = new Paragraph(this, new XElement(Xceed.Document.NET.Document.w + "p"), 0);
      if (formatting != null)
        paragraph.Append(text, formatting);
      else
        paragraph.Append(text);
      Shape shape = new Shape(this, HelperFunctions.CreateTextBox(this.GetNextFreeDocPrId(), width, height, paragraph, fillColor, outlineColor, outlineWidth, outlineDash));
      shape.PackagePart = this.PackagePart;
      return shape;
    }

    /// <summary>Sets a flag to true, so that when the saved document is opened with MS Word, a popup will appear to ask if the fields should be updated.</summary>
    public void UpdateFields()
    {
      if (this._settingsPart == null)
        return;
      XDocument xdocument;
      using (TextReader textReader = (TextReader) new StreamReader(this._settingsPart.GetStream()))
        xdocument = XDocument.Load(textReader);
      XElement xelement = new XElement(XName.Get("updateFields", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) true));
      xdocument.Root.Add((object) xelement);
      using (TextWriter textWriter = (TextWriter) new StreamWriter((System.IO.Stream) new PackagePartStream(this._settingsPart.GetStream())))
        xdocument.Save(textWriter);
    }

    /// <summary>Adds a CheckBox to a Document.</summary>
    /// <returns>The newly created CheckBox.</returns>
    /// <param name="isChecked">
    /// <strong>true</strong> if the CheckBox is checked, otherwise <strong>false</strong>.</param>
    public CheckBox AddCheckBox(bool isChecked) => new CheckBox(this, new XElement(XName.Get("sdt", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
    {
      (object) new XElement(XName.Get("sdtPr", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("checkbox", Xceed.Document.NET.Document.w14.NamespaceName), new object[3]
      {
        (object) new XElement(XName.Get("checked", Xceed.Document.NET.Document.w14.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w14.NamespaceName), isChecked ? (object) "1" : (object) "0")),
        (object) new XElement(XName.Get("checkedState", Xceed.Document.NET.Document.w14.NamespaceName), new object[2]
        {
          (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w14.NamespaceName), (object) "2612"),
          (object) new XAttribute(XName.Get("font", Xceed.Document.NET.Document.w14.NamespaceName), (object) "MS Gothic")
        }),
        (object) new XElement(XName.Get("uncheckedState", Xceed.Document.NET.Document.w14.NamespaceName), new object[2]
        {
          (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w14.NamespaceName), (object) "2610"),
          (object) new XAttribute(XName.Get("font", Xceed.Document.NET.Document.w14.NamespaceName), (object) "MS Gothic")
        })
      })),
      (object) new XElement(XName.Get("sdtContent", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
      {
        (object) new XElement(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
        {
          (object) new XElement(XName.Get("rFonts", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("ascii", Xceed.Document.NET.Document.w.NamespaceName), (object) "MS Gothic")),
          (object) new XElement(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) "333333"))
        }),
        (object) new XElement(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName), (object) (char) (isChecked ? 9746 : 9744))
      }))
    }));

    public void ApplyTemplate(string templateFilePath) => this.ApplyTemplate(templateFilePath, true);

    public void ApplyTemplate(string templateFilePath, bool includeContent)
    {
      if (!System.IO.File.Exists(templateFilePath))
        throw new FileNotFoundException(string.Format("File could not be found {0}", (object) templateFilePath));
      using (FileStream fileStream = new FileStream(templateFilePath, FileMode.Open, FileAccess.Read))
        this.ApplyTemplate((System.IO.Stream) fileStream, includeContent);
    }

    public void ApplyTemplate(System.IO.Stream templateStream) => this.ApplyTemplate(templateStream, true);

    public void ApplyTemplate(System.IO.Stream templateStream, bool includeContent)
    {
      Package package = Package.Open(templateStream);
      try
      {
        PackagePart packagePart = (PackagePart) null;
        XDocument xdocument = (XDocument) null;
        using (IEnumerator<PackagePart> enumerator = package.GetParts().GetEnumerator())
        {
          while (((IEnumerator) enumerator).MoveNext())
          {
            PackagePart current = enumerator.Current;
            switch (current.get_Uri().ToString())
            {
              case "/word/document.xml":
                packagePart = current;
                using (System.IO.Stream stream = current.GetStream(FileMode.Open, FileAccess.Read))
                {
                  using (XmlReader reader = XmlReader.Create(stream))
                  {
                    xdocument = XDocument.Load(reader);
                    continue;
                  }
                }
              case "/_rels/.rels":
                if (!this._package.PartExists(current.get_Uri()))
                  this._package.CreatePart(current.get_Uri(), current.get_ContentType(), current.get_CompressionOption());
                PackagePart part1 = this._package.GetPart(current.get_Uri());
                using (System.IO.Stream stream = current.GetStream(FileMode.Open, FileAccess.Read))
                {
                  using (StreamReader streamReader = new StreamReader(stream, System.Text.Encoding.UTF8))
                  {
                    using (PackagePartStream packagePartStream = new PackagePartStream(part1.GetStream(FileMode.Create, FileAccess.Write)))
                    {
                      using (StreamWriter streamWriter = new StreamWriter((System.IO.Stream) packagePartStream, System.Text.Encoding.UTF8))
                      {
                        streamWriter.Write(streamReader.ReadToEnd());
                        continue;
                      }
                    }
                  }
                }
              case "/word/_rels/document.xml.rels":
                continue;
              default:
                if (!this._package.PartExists(current.get_Uri()))
                  this._package.CreatePart(current.get_Uri(), current.get_ContentType(), current.get_CompressionOption());
                System.Text.Encoding utF8 = System.Text.Encoding.Default;
                if (current.get_Uri().ToString().EndsWith(".xml") || current.get_Uri().ToString().EndsWith(".rels"))
                  utF8 = System.Text.Encoding.UTF8;
                PackagePart part2 = this._package.GetPart(current.get_Uri());
                using (System.IO.Stream stream = current.GetStream(FileMode.Open, FileAccess.Read))
                {
                  using (StreamReader streamReader = new StreamReader(stream, utF8))
                  {
                    using (PackagePartStream packagePartStream = new PackagePartStream(part2.GetStream(FileMode.Create, FileAccess.Write)))
                    {
                      using (StreamWriter streamWriter = new StreamWriter((System.IO.Stream) packagePartStream, streamReader.CurrentEncoding))
                      {
                        streamWriter.Write(streamReader.ReadToEnd());
                        continue;
                      }
                    }
                  }
                }
            }
          }
        }
        if (packagePart != null)
        {
          string str = packagePart.get_ContentType().Replace("template.main", "document.main");
          if (this._package.PartExists(packagePart.get_Uri()))
            this._package.DeletePart(packagePart.get_Uri());
          PackagePart part = this._package.CreatePart(packagePart.get_Uri(), str, packagePart.get_CompressionOption());
          using (PackagePartStream packagePartStream = new PackagePartStream(part.GetStream(FileMode.Create, FileAccess.Write)))
          {
            using (XmlWriter writer = XmlWriter.Create((System.IO.Stream) packagePartStream))
              xdocument.WriteTo(writer);
          }
          using (IEnumerator<PackageRelationship> enumerator = packagePart.GetRelationships().GetEnumerator())
          {
            while (((IEnumerator) enumerator).MoveNext())
            {
              PackageRelationship current = enumerator.Current;
              part.CreateRelationship(current.get_TargetUri(), current.get_TargetMode(), current.get_RelationshipType(), current.get_Id());
            }
          }
          this.PackagePart = part;
          this._mainDoc = xdocument;
          Xceed.Document.NET.Document.PopulateDocument(this, package);
          this._settingsPart = HelperFunctions.CreateOrGetSettingsPart(this._package);
        }
        if (includeContent)
          return;
        foreach (Paragraph paragraph in this.Paragraphs)
          paragraph.Remove(false);
      }
      finally
      {
        this._package.Flush();
        package.Close();
        Xceed.Document.NET.Document.PopulateDocument(this.Document, this._package);
      }
    }

    public Image AddImage(string filename)
    {
      string contentType;
      switch (Path.GetExtension(filename))
      {
        case ".bmp":
          contentType = "image/png";
          break;
        case ".gif":
          contentType = "image/gif";
          break;
        case ".jpeg":
          contentType = "image/jpeg";
          break;
        case ".jpg":
          contentType = "image/jpg";
          break;
        case ".png":
          contentType = "image/png";
          break;
        case ".tif":
          contentType = "image/tif";
          break;
        case ".tiff":
          contentType = "image/tif";
          break;
        default:
          contentType = "image/jpg";
          break;
      }
      return this.AddImage((object) filename, contentType);
    }

    public Image AddImage(System.IO.Stream stream, string contentType = "image/jpeg")
    {
      stream.Position = 0L;
      return this.AddImage((object) stream, contentType);
    }

    public Hyperlink AddHyperlink(string text, Uri uri, Hyperlink baseHyperlink) => this.AddHyperlinkCore(text, uri, (string) null, baseHyperlink, (Formatting) null);

    public Hyperlink AddHyperlink(string text, string anchor, Hyperlink baseHyperlink) => this.AddHyperlinkCore(text, (Uri) null, anchor, baseHyperlink, (Formatting) null);

    public Hyperlink AddHyperlink(string text, Uri uri, Formatting formatting) => this.AddHyperlinkCore(text, uri, (string) null, (Hyperlink) null, formatting);

    public Hyperlink AddHyperlink(string text, string anchor, Formatting formatting) => this.AddHyperlinkCore(text, (Uri) null, anchor, (Hyperlink) null, formatting);

    /// <summary>Adds a Hyperlink to a Document and creates a Paragraph which uses it.</summary>
    /// <returns>The newly created Hyperlink.</returns>
    /// <param name="text">The text as displayed by the Hyperlink.</param>
    /// <param name="uri">The Uri for the Hyperlink.</param>
    public Hyperlink AddHyperlink(string text, Uri uri) => this.AddHyperlinkCore(text, uri, (string) null, (Hyperlink) null, (Formatting) null);

    /// <summary>Adds a Hyperlink with a Bookmark anchor to a Document and creates a Paragraph which uses it.</summary>
    /// <returns>The newly created Hyperlink.</returns>
    /// <param name="text">The text as displayed by the Hyperlink.</param>
    /// <param name="anchor">The anchor to a Bookmark.</param>
    public Hyperlink AddHyperlink(string text, string anchor) => this.AddHyperlinkCore(text, (Uri) null, anchor, (Hyperlink) null, (Formatting) null);

    /// <summary>Adds three new Headers to the first Section of this Document . One for the first page, one for odd pages, and one for even pages.</summary>
    public void AddHeaders() => this.Sections[0].AddHeadersOrFootersXml(true);

    /// <summary>Adds three new Footers to the first Section of this Document . One for the first page, one for odd pages, and one for even pages.</summary>
    public void AddFooters() => this.Sections[0].AddHeadersOrFootersXml(false);

    public virtual void Save()
    {
    }

    public virtual void SaveAs(string filename)
    {
      this._filename = filename;
      this._stream = (System.IO.Stream) null;
      this.Save();
    }

    public virtual void SaveAs(System.IO.Stream stream)
    {
      this._filename = (string) null;
      this._stream = stream;
      this.Save();
    }

    public void AddCoreProperty(string propertyName, string propertyValue)
    {
      string str1;
      if (!propertyName.Contains(":"))
        str1 = "cp";
      else
        str1 = propertyName.Split(':')[0];
      string prefix = str1;
      string str2;
      if (!propertyName.Contains(":"))
        str2 = propertyName;
      else
        str2 = propertyName.Split(':')[1];
      string propertyLocalName = str2;
      if (!this._package.PartExists(new Uri("/docProps/core.xml", UriKind.Relative)))
        HelperFunctions.CreateCorePropertiesPart(this);
      PackagePart part = this._package.GetPart(new Uri("/docProps/core.xml", UriKind.Relative));
      XDocument xdocument;
      using (TextReader textReader = (TextReader) new StreamReader(part.GetStream(FileMode.Open, FileAccess.Read)))
        xdocument = XDocument.Load(textReader);
      XElement xelement = xdocument.Root.Elements().Where<XElement>((Func<XElement, bool>) (propElement => propElement.Name.LocalName.Equals(propertyLocalName))).SingleOrDefault<XElement>();
      if (xelement != null)
      {
        xelement.SetValue((object) propertyValue);
      }
      else
      {
        XNamespace namespaceOfPrefix = xdocument.Root.GetNamespaceOfPrefix(prefix);
        xdocument.Root.Add((object) new XElement(XName.Get(propertyLocalName, namespaceOfPrefix.NamespaceName), (object) propertyValue));
      }
      using (TextWriter textWriter = (TextWriter) new StreamWriter((System.IO.Stream) new PackagePartStream(part.GetStream(FileMode.Create, FileAccess.Write))))
        xdocument.Save(textWriter);
      Xceed.Document.NET.Document.UpdateCorePropertyValue(this, propertyLocalName, propertyValue);
    }

    public void AddCustomProperty(CustomProperty cp)
    {
      if (!this._package.PartExists(new Uri("/docProps/custom.xml", UriKind.Relative)))
        HelperFunctions.CreateCustomPropertiesPart(this);
      PackagePart part = this._package.GetPart(new Uri("/docProps/custom.xml", UriKind.Relative));
      XDocument xdocument;
      using (TextReader textReader = (TextReader) new StreamReader(part.GetStream(FileMode.Open, FileAccess.Read)))
        xdocument = XDocument.Load(textReader, LoadOptions.PreserveWhitespace);
      IEnumerable<int> source = xdocument.Descendants().Where<XElement>((Func<XElement, bool>) (d => d.Name.LocalName == "property")).Select<XElement, int>((Func<XElement, int>) (d => int.Parse(d.Attribute(XName.Get("pid")).Value)));
      int num = 1;
      if (source.Count<int>() > 0)
        num = source.Max();
      xdocument.Descendants().Where<XElement>((Func<XElement, bool>) (d => d.Name.LocalName == "property" && d.Attribute(XName.Get("name")).Value.Equals(cp.Name, StringComparison.InvariantCultureIgnoreCase))).SingleOrDefault<XElement>()?.Remove();
      xdocument.Element(XName.Get("Properties", Xceed.Document.NET.Document.customPropertiesSchema.NamespaceName)).Add((object) new XElement(XName.Get("property", Xceed.Document.NET.Document.customPropertiesSchema.NamespaceName), new object[4]
      {
        (object) new XAttribute((XName) "fmtid", (object) "{D5CDD505-2E9C-101B-9397-08002B2CF9AE}"),
        (object) new XAttribute((XName) "pid", (object) (num + 1)),
        (object) new XAttribute((XName) "name", (object) cp.Name),
        (object) new XElement(Xceed.Document.NET.Document.customVTypesSchema + cp.Type, cp.Value ?? (object) "")
      }));
      using (TextWriter textWriter = (TextWriter) new StreamWriter((System.IO.Stream) new PackagePartStream(part.GetStream(FileMode.Create, FileAccess.Write))))
        xdocument.Save(textWriter, SaveOptions.None);
      Xceed.Document.NET.Document.UpdateCustomPropertyValue(this, cp);
    }

    public override Paragraph InsertParagraph()
    {
      Paragraph paragraph = base.InsertParagraph();
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    public override Paragraph InsertParagraph(int index, string text, bool trackChanges)
    {
      Paragraph paragraph = base.InsertParagraph(index, text, trackChanges);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    public override Paragraph InsertParagraph(Paragraph p)
    {
      this.InsertParagraphPictures(p);
      p.PackagePart = this.PackagePart;
      return base.InsertParagraph(p);
    }

    public override Paragraph InsertParagraph(int index, Paragraph p)
    {
      this.InsertParagraphPictures(p);
      p.PackagePart = this.PackagePart;
      return base.InsertParagraph(index, p);
    }

    public override Paragraph InsertParagraph(
      int index,
      string text,
      bool trackChanges,
      Formatting formatting)
    {
      Paragraph paragraph = base.InsertParagraph(index, text, trackChanges, formatting);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    public override Paragraph InsertParagraph(string text)
    {
      Paragraph paragraph = base.InsertParagraph(text);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    public override Paragraph InsertParagraph(string text, bool trackChanges)
    {
      Paragraph paragraph = base.InsertParagraph(text, trackChanges);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    public override Paragraph InsertParagraph(
      string text,
      bool trackChanges,
      Formatting formatting)
    {
      Paragraph paragraph = base.InsertParagraph(text, trackChanges, formatting);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    public Paragraph[] InsertParagraphs(string text)
    {
      string[] strArray = text.Split('\n');
      List<Paragraph> paragraphList = new List<Paragraph>();
      foreach (string str in strArray)
      {
        Paragraph paragraph = base.InsertParagraph(text);
        paragraph.PackagePart = this.PackagePart;
        paragraphList.Add(paragraph);
      }
      return paragraphList.ToArray();
    }

    public override Paragraph InsertEquation(string equation, Alignment align = Alignment.center)
    {
      Paragraph paragraph = base.InsertEquation(equation, align);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    public void InsertChart(Chart chart, float width = 432f, float height = 252f) => this.InsertChart(chart, (Paragraph) null, width, height);

    /// <summary>Inserts a chart in the document after the specified paragraph.</summary>
    /// <param name="chart">The <strong>Chart</strong> to insert.</param>
    /// <param name="paragraph">The <strong>Paragraph</strong> after which to insert the chart.</param>
    /// <param name="width">The width of the chart (in points). By default, <strong>432</strong>.</param>
    /// <param name="height">The height of the chart (in points). By default, <strong>252</strong>.</param>
    public void InsertChartAfterParagraph(
      Chart chart,
      Paragraph paragraph,
      float width = 432f,
      float height = 252f)
    {
      this.InsertChart(chart, paragraph, width, height);
    }

    /// <summary>Adds a List to a Document.</summary>
    /// <returns>The newly created List.</returns>
    /// <param name="listText">The text for the new List.</param>
    /// <param name="level">The level of the List.</param>
    /// <param name="listType">The <strong>ListItemType</strong> of the List.</param>
    /// <param name="startNumber">The number at which to start.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="continueNumbering">
    /// <strong>true</strong> if the numbering will continue, otherwise <strong>false</strong>.</param>
    /// <param name="formatting">
    ///   <span id="BugEvents">The Formatting of the item to add. By default, <strong>null</strong>.</span>
    /// </param>
    public List AddList(
      string listText = null,
      int level = 0,
      ListItemType listType = ListItemType.Numbered,
      int? startNumber = null,
      bool trackChanges = false,
      bool continueNumbering = false,
      Formatting formatting = null)
    {
      return this.AddListItem(new List(this, (XElement) null), listText, level, listType, startNumber, trackChanges, continueNumbering, formatting);
    }

    /// <summary>Adds a copy of the provided List to a Document.</summary>
    /// <returns>The newly created List.</returns>
    /// <param name="t">The <strong>List</strong> to copy to create the new List.</param>
    public List AddList(List t)
    {
      List list = new List(this, (XElement) null);
      if (t.Items == null || t.Items.Count == 0)
        return list;
      ListItemType? listType1 = t.ListType;
      int num;
      if (!listType1.HasValue)
      {
        num = 1;
      }
      else
      {
        listType1 = t.ListType;
        num = (int) listType1.Value;
      }
      ListItemType listType2 = (ListItemType) num;
      Paragraph p1 = t.Items.First<Paragraph>();
      int listItemLevel1 = p1.GetListItemLevel();
      int? startNumber1 = listItemLevel1 != -1 ? new int?(int.Parse(HelperFunctions.GetListItemStartValue(t, listItemLevel1))) : new int?();
      List itemInList = HelperFunctions.CreateItemInList(list, p1, listType2, startNumber1);
      Paragraph paragraph1 = itemInList.Items.LastOrDefault<Paragraph>();
      if (paragraph1 != null)
        paragraph1.PackagePart = this.PackagePart;
      for (int index = 1; index < t.Items.Count; ++index)
      {
        Paragraph p2 = t.Items[index];
        int listItemLevel2 = p2.GetListItemLevel();
        int? startNumber2 = listItemLevel2 != -1 ? new int?(int.Parse(HelperFunctions.GetListItemStartValue(t, listItemLevel2))) : new int?();
        itemInList = HelperFunctions.CreateItemInList(itemInList, p2, listType2, startNumber2);
        Paragraph paragraph2 = itemInList.Items.LastOrDefault<Paragraph>();
        if (paragraph2 != null)
          paragraph2.PackagePart = this.PackagePart;
      }
      return itemInList;
    }

    /// <summary>Adds a ListItem to an existing List.</summary>
    /// <returns>The List with the newly created ListItem appended.</returns>
    /// <param name="list">The <strong>List</strong> to which a new LisetItem will be appended.</param>
    /// <param name="listText">The text for the new ListItem.</param>
    /// <param name="level">The level of the List.</param>
    /// <param name="listType">The <strong>ListItemType</strong> of the List.</param>
    /// <param name="startNumber">The number at which to start.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="continueNumbering">
    /// <strong>true</strong> if the numbering will continue, otherwise <strong>false</strong>.</param>
    /// <param name="formatting">
    ///   <span id="BugEvents">The <strong>Formatting</strong> of the item to add. By default, <strong>null</strong>.</span>
    /// </param>
    public List AddListItem(
      List list,
      string listText,
      int level = 0,
      ListItemType listType = ListItemType.Numbered,
      int? startNumber = null,
      bool trackChanges = false,
      bool continueNumbering = false,
      Formatting formatting = null)
    {
      if (startNumber.HasValue & continueNumbering)
        throw new InvalidOperationException("Cannot specify a start number and at the same time continue numbering from another list");
      List itemInList = HelperFunctions.CreateItemInList(list, listText, level, listType, startNumber, trackChanges, continueNumbering, formatting);
      Paragraph paragraph = itemInList.Items.LastOrDefault<Paragraph>();
      if (paragraph == null)
        return itemInList;
      paragraph.PackagePart = this.PackagePart;
      return itemInList;
    }

    public override List InsertList(List list)
    {
      base.InsertList(list);
      return list;
    }

    public override List InsertList(List list, Font fontFamily, double fontSize)
    {
      base.InsertList(list, fontFamily, fontSize);
      return list;
    }

    public override List InsertList(List list, double fontSize)
    {
      base.InsertList(list, fontSize);
      return list;
    }

    public new List InsertList(int index, List list)
    {
      base.InsertList(index, list);
      return list;
    }

    public TableOfContents InsertDefaultTableOfContents() => this.InsertTableOfContents("Table of contents", (IDictionary<TableOfContentsSwitches, string>) TableOfContents.BuildTOCSwitchesDictionary(TableOfContentsSwitches.H | TableOfContentsSwitches.O | TableOfContentsSwitches.U | TableOfContentsSwitches.Z));

    /// <summary>Inserts a table of contents to the document, based on the provided switches.</summary>
    /// <returns>The newly inserted table of contents.</returns>
    /// <param name="title">The title of the table of contents.</param>
    /// <param name="switches">A key-value dictionary where the key is a TableOfContentSwitches and the value
    /// is the parameter of the switch.</param>
    /// <param name="headerStyle">The style to use for the title of the table of contents.</param>
    /// <param name="rightTabPos">The position of the text aligned from the right.</param>
    public TableOfContents InsertTableOfContents(
      string title,
      IDictionary<TableOfContentsSwitches, string> switches,
      string headerStyle = null,
      int? rightTabPos = null)
    {
      TableOfContents tableOfContents = TableOfContents.CreateTableOfContents(this, title, switches, headerStyle, rightTabPos);
      this.AddElementInXml((object) tableOfContents.Xml);
      return tableOfContents;
    }

    [Obsolete("This method is obsolete and should no longer be used. Use the InsertTableOfContents methods containing an IDictionary<TableOfContentsSwitches, string> parameter instead.")]
    public TableOfContents InsertTableOfContents(
      string title,
      TableOfContentsSwitches switches,
      string headerStyle = null,
      int maxIncludeLevel = 3,
      int? rightTabPos = null)
    {
      Dictionary<TableOfContentsSwitches, string> dictionary = TableOfContents.BuildTOCSwitchesDictionary(switches, maxIncludeLevel);
      TableOfContents tableOfContents = TableOfContents.CreateTableOfContents(this, title, (IDictionary<TableOfContentsSwitches, string>) dictionary, headerStyle, rightTabPos);
      this.AddElementInXml((object) tableOfContents.Xml);
      return tableOfContents;
    }

    [Obsolete("This method is obsolete and should no longer be used. Use the InsertTableOfContents methods containing an IDictionary<TableOfContentsSwitches, string> parameter instead.")]
    public TableOfContents InsertTableOfContents(
      Paragraph reference,
      string title,
      TableOfContentsSwitches switches,
      string headerStyle = null,
      int maxIncludeLevel = 3,
      int? rightTabPos = null)
    {
      Dictionary<TableOfContentsSwitches, string> dictionary = TableOfContents.BuildTOCSwitchesDictionary(switches, maxIncludeLevel);
      TableOfContents tableOfContents = TableOfContents.CreateTableOfContents(this, title, (IDictionary<TableOfContentsSwitches, string>) dictionary, headerStyle, rightTabPos);
      reference.Xml.AddBeforeSelf((object) tableOfContents.Xml);
      return tableOfContents;
    }

    /// <summary>Inserts a table of contents to the document prior to the referenced paragraph, based on the provided switches.</summary>
    /// <returns>The newly inserted table of contents.</returns>
    /// <param name="reference">The referenced paragraph to indicate the position of the table of contents.</param>
    /// <param name="title">The title of the table of contents.</param>
    /// <param name="switches">A key-value dictionary where the key is a TableOfContentSwitches and the value
    /// is the parameter of the switch.</param>
    /// <param name="headerStyle">The style to use for the title of the table of contents.</param>
    /// <param name="rightTabPos">The position of the text aligned from the right.</param>
    public TableOfContents InsertTableOfContents(
      Paragraph reference,
      string title,
      IDictionary<TableOfContentsSwitches, string> switches,
      string headerStyle = null,
      int? rightTabPos = null)
    {
      TableOfContents tableOfContents = TableOfContents.CreateTableOfContents(this, title, switches, headerStyle, rightTabPos);
      reference.Xml.AddBeforeSelf((object) tableOfContents.Xml);
      return tableOfContents;
    }

    public virtual Xceed.Document.NET.Document Copy() => (Xceed.Document.NET.Document) null;

    public void AddPasswordProtection(EditRestrictions editRestrictions, string password)
    {
      this.RemoveProtection();
      if (editRestrictions == EditRestrictions.none)
        return;
      int val2 = 15;
      byte[] numArray1 = new byte[16];
      byte[] numArray2 = new byte[14];
      XElement xelement = new XElement(XName.Get("documentProtection", Xceed.Document.NET.Document.w.NamespaceName));
      xelement.Add((object) new XAttribute(XName.Get("edit", Xceed.Document.NET.Document.w.NamespaceName), (object) editRestrictions.ToString()));
      xelement.Add((object) new XAttribute(XName.Get("enforcement", Xceed.Document.NET.Document.w.NamespaceName), (object) "1"));
      int[] numArray3 = new int[15]
      {
        57840,
        7439,
        52380,
        33984,
        4364,
        3600,
        61902,
        12606,
        6258,
        57657,
        54287,
        34041,
        10252,
        43370,
        20163
      };
      int[,] numArray4 = new int[15, 7]
      {
        {
          44796,
          19929,
          39858,
          10053,
          20106,
          40212,
          10761
        },
        {
          31585,
          63170,
          64933,
          60267,
          50935,
          40399,
          11199
        },
        {
          17763,
          35526,
          1453,
          2906,
          5812,
          11624,
          23248
        },
        {
          885,
          1770,
          3540,
          7080,
          14160,
          28320,
          56640
        },
        {
          55369,
          41139,
          20807,
          41614,
          21821,
          43642,
          17621
        },
        {
          28485,
          56970,
          44341,
          19019,
          38038,
          14605,
          29210
        },
        {
          60195,
          50791,
          40175,
          10751,
          21502,
          43004,
          24537
        },
        {
          18387,
          36774,
          3949,
          7898,
          15796,
          31592,
          63184
        },
        {
          47201,
          24803,
          49606,
          37805,
          14203,
          28406,
          56812
        },
        {
          17824,
          35648,
          1697,
          3394,
          6788,
          13576,
          27152
        },
        {
          43601,
          17539,
          35078,
          557,
          1114,
          2228,
          4456
        },
        {
          30388,
          60776,
          51953,
          34243,
          7079,
          14158,
          28316
        },
        {
          14128,
          28256,
          56512,
          43425,
          17251,
          34502,
          7597
        },
        {
          13105,
          26210,
          52420,
          35241,
          883,
          1766,
          3532
        },
        {
          4129,
          8258,
          16516,
          33032,
          4657,
          9314,
          18628
        }
      };
      new RNGCryptoServiceProvider().GetNonZeroBytes(numArray1);
      if (!string.IsNullOrEmpty(password))
      {
        password = password.Substring(0, Math.Min(password.Length, val2));
        byte[] numArray5 = new byte[password.Length];
        for (int index = 0; index < password.Length; ++index)
        {
          int int32 = Convert.ToInt32(password[index]);
          numArray5[index] = Convert.ToByte(int32 & (int) byte.MaxValue);
          if (numArray5[index] == (byte) 0)
            numArray5[index] = Convert.ToByte((int32 & (int) byte.MaxValue) >> 8);
        }
        int num1 = numArray3[numArray5.Length - 1];
        for (int index1 = 0; index1 < numArray5.Length; ++index1)
        {
          int index2 = val2 - numArray5.Length + index1;
          for (int index3 = 0; index3 < 7; ++index3)
          {
            if (((int) numArray5[index1] & 1 << index3) != 0)
              num1 ^= numArray4[index2, index3];
          }
        }
        int num2 = 0;
        for (int index = numArray5.Length - 1; index >= 0; --index)
          num2 = (num2 >> 14 & 1 | num2 << 1 & (int) short.MaxValue) ^ (int) numArray5[index];
        int num3 = (num2 >> 14 & 1 | num2 << 1 & (int) short.MaxValue) ^ numArray5.Length ^ 52811;
        int num4 = (num1 << 16) + num3;
        for (int index = 0; index < 4; ++index)
          numArray2[index] = Convert.ToByte((uint) (num4 & (int) byte.MaxValue << index * 8) >> index * 8);
      }
      StringBuilder stringBuilder = new StringBuilder();
      for (int index = 0; index < 4; ++index)
        stringBuilder.Append(Convert.ToString(numArray2[index], 16));
      byte[] buffer1 = this.MergeArrays(System.Text.Encoding.Unicode.GetBytes(stringBuilder.ToString().ToUpper()), numArray1);
      int num = 100000;
      SHA1Managed shA1Managed = new SHA1Managed();
      byte[] hash = shA1Managed.ComputeHash(buffer1);
      byte[] array1 = new byte[4];
      for (int index = 0; index < num; ++index)
      {
        array1[0] = Convert.ToByte(index & (int) byte.MaxValue);
        array1[1] = Convert.ToByte((index & 65280) >> 8);
        array1[2] = Convert.ToByte((index & 16711680) >> 16);
        array1[3] = Convert.ToByte(((long) index & 4278190080L) >> 24);
        byte[] buffer2 = this.MergeArrays(array1, hash);
        hash = shA1Managed.ComputeHash(buffer2);
      }
      xelement.Add((object) new XAttribute(XName.Get("cryptProviderType", Xceed.Document.NET.Document.w.NamespaceName), (object) "rsaFull"));
      xelement.Add((object) new XAttribute(XName.Get("cryptAlgorithmClass", Xceed.Document.NET.Document.w.NamespaceName), (object) "hash"));
      xelement.Add((object) new XAttribute(XName.Get("cryptAlgorithmType", Xceed.Document.NET.Document.w.NamespaceName), (object) "typeAny"));
      xelement.Add((object) new XAttribute(XName.Get("cryptAlgorithmSid", Xceed.Document.NET.Document.w.NamespaceName), (object) "4"));
      xelement.Add((object) new XAttribute(XName.Get("cryptSpinCount", Xceed.Document.NET.Document.w.NamespaceName), (object) num.ToString()));
      xelement.Add((object) new XAttribute(XName.Get("hash", Xceed.Document.NET.Document.w.NamespaceName), (object) Convert.ToBase64String(hash)));
      xelement.Add((object) new XAttribute(XName.Get("salt", Xceed.Document.NET.Document.w.NamespaceName), (object) Convert.ToBase64String(numArray1)));
      this._settings.Root.AddFirst((object) xelement);
    }

    /// <summary>Sets the default font characteristics of the Document.</summary>
    /// <param name="fontFamily">The <strong>Font</strong> to use by default.</param>
    /// <param name="fontSize">The font size to use by default</param>
    /// <param name="fontColor">The font <strong>Color</strong> to use by default.</param>
    public void SetDefaultFont(Font fontFamily, double fontSize = 11.0, Color? fontColor = null)
    {
      XElement docDefaults = this.GetDocDefaults();
      if (docDefaults == null)
        return;
      XElement xelement1 = docDefaults.Element(XName.Get("rPrDefault", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 == null)
        return;
      XElement xelement2 = xelement1.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 == null)
        return;
      if (fontFamily != null)
      {
        XElement xelement3 = xelement2.Element(XName.Get("rFonts", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement3 == null)
        {
          xelement2.AddFirst((object) new XElement(XName.Get("rFonts", Xceed.Document.NET.Document.w.NamespaceName)));
          xelement3 = xelement2.Element(XName.Get("rFonts", Xceed.Document.NET.Document.w.NamespaceName));
        }
        xelement3.Attributes().Remove();
        xelement3.SetAttributeValue(XName.Get("ascii", Xceed.Document.NET.Document.w.NamespaceName), (object) fontFamily.Name);
        xelement3.SetAttributeValue(XName.Get("hAnsi", Xceed.Document.NET.Document.w.NamespaceName), (object) fontFamily.Name);
        xelement3.SetAttributeValue(XName.Get("cs", Xceed.Document.NET.Document.w.NamespaceName), (object) fontFamily.Name);
        xelement3.SetAttributeValue(XName.Get("eastAsia", Xceed.Document.NET.Document.w.NamespaceName), (object) fontFamily.Name);
      }
      XElement xelement4 = xelement2.Element(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement4 == null)
      {
        xelement2.Add((object) new XElement(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName)));
        xelement4 = xelement2.Element(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName));
      }
      xelement4.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) (fontSize * 2.0));
      XElement xelement5 = xelement2.Element(XName.Get("szCs", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement5 == null)
      {
        xelement2.Add((object) new XElement(XName.Get("szCs", Xceed.Document.NET.Document.w.NamespaceName)));
        xelement5 = xelement2.Element(XName.Get("szCs", Xceed.Document.NET.Document.w.NamespaceName));
      }
      xelement5.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) (fontSize * 2.0));
      if (!fontColor.HasValue || !fontColor.HasValue)
        return;
      XElement xelement6 = xelement2.Element(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement6 == null)
      {
        xelement2.Add((object) new XElement(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName)));
        xelement6 = xelement2.Element(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName));
      }
      xelement6.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) fontColor.Value.ToHex());
    }

    /// <summary>Inserts html text (with the html tags) or rtf text (with the rtf tags) in the Document.</summary>
    /// <param name="data">The text to insert (with the html/rtf tags).</param>
    /// <param name="type">The <strong>ContentType</strong> of the <em>data</em> insert (<strong>Html</strong> or <strong>Rtf</strong>).</param>
    /// <param name="p">The <strong>Paragraph</strong> after which to insert the content. <span id="BugEvents">If <strong>null</strong>, the text will be added at the current position
    /// in the Document.</span></param>
    public void InsertContent(string data, ContentType type, Paragraph p = null)
    {
      if (string.IsNullOrEmpty(data))
        return;
      if (p == null)
      {
        Paragraph paragraph = this.Paragraphs.LastOrDefault<Paragraph>();
        p = paragraph == null ? this.InsertParagraph() : paragraph;
      }
      if (type == ContentType.Html && !data.StartsWith("<!DOCTYPE html>"))
        data = data.Insert(0, "<!DOCTYPE html>");
      int num = 1;
      string str1 = type == ContentType.Html ? ".html" : ".rtf";
      string str2 = type == ContentType.Html ? "application/xhtml+xml" : "application/rtf";
      Uri uri = new Uri("/word/others/data" + num.ToString() + str1, UriKind.Relative);
      while (this._package.PartExists(uri))
        uri = new Uri("/word/others/data" + (++num).ToString() + str1, UriKind.Relative);
      string str3 = "altChunkId" + num.ToString();
      PackagePart part = this._package.CreatePart(uri, str2, (CompressionOption) 0);
      this.PackagePart.CreateRelationship(part.get_Uri(), (TargetMode) 0, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/aFChunk", str3);
      using (StreamWriter streamWriter = new StreamWriter((System.IO.Stream) new PackagePartStream(part.GetStream())))
        streamWriter.Write(data);
      XElement xelement = new XElement(XName.Get("altChunk", Xceed.Document.NET.Document.w.NamespaceName));
      xelement.Add((object) new XAttribute(XName.Get("id", Xceed.Document.NET.Document.r.NamespaceName), (object) str3));
      p.Xml.AddAfterSelf((object) xelement);
    }

    /// <summary>Inserts an html or rtf document in the Document.</summary>
    /// <param name="filename">The <strong>Filename</strong> of the document to insert.</param>
    /// <param name="type">The <strong>ContentType</strong> of the document to insert (<strong>Html</strong> or <strong>Rtf</strong>).</param>
    /// <param name="p">The <strong>Paragraph</strong> after which to insert the document. <span id="BugEvents">If <strong>null</strong>, the document will be added at the current
    /// position in the Document.</span></param>
    public void InsertDocument(string filename, ContentType type, Paragraph p = null)
    {
      if (!System.IO.File.Exists(filename))
        return;
      this.InsertContent(string.Join("", System.IO.File.ReadLines(filename)), type, p);
    }

    internal static void ConvertToPdfInternal(
      Xceed.Document.NET.Document fileToConvert,
      string outputFileName,
      List<PdfExternalFont> externalFonts = null)
    {
      Xceed.Document.NET.Document.ConvertToPdfCore(fileToConvert, outputFileName, externalFonts);
    }

    internal static Xceed.Pdf.Document ConvertToPdfCore(
      Xceed.Document.NET.Document fileToConvert,
      string outputFileName,
      List<PdfExternalFont> externalFonts = null)
    {
      return new PdfConverter(fileToConvert, outputFileName, externalFonts).Convert();
    }

    internal static void ConvertToPdfInternal(
      Xceed.Document.NET.Document fileToConvert,
      System.IO.Stream outputStream,
      List<PdfExternalFont> externalFonts = null)
    {
      Xceed.Document.NET.Document.ConvertToPdfCore(fileToConvert, outputStream, externalFonts);
    }

    internal static Xceed.Pdf.Document ConvertToPdfCore(
      Xceed.Document.NET.Document fileToConvert,
      System.IO.Stream outputStream,
      List<PdfExternalFont> externalFonts = null)
    {
      return new PdfConverter(fileToConvert, outputStream, externalFonts).Convert();
    }

    protected internal virtual void SaveHeadersFooters()
    {
    }

    protected internal override void AddElementInXml(object element) => this._mainDoc.Root.Element(XName.Get("body", Xceed.Document.NET.Document.w.NamespaceName)).Elements(XName.Get("sectPr", Xceed.Document.NET.Document.w.NamespaceName)).Last<XElement>().AddBeforeSelf(element);

    internal string GetCollectiveText(List<PackagePart> list)
    {
      string str = string.Empty;
      using (List<PackagePart>.Enumerator enumerator = list.GetEnumerator())
      {
        while (enumerator.MoveNext())
        {
          using (TextReader textReader = (TextReader) new StreamReader(enumerator.Current.GetStream()))
          {
            XDocument xdocument = XDocument.Load(textReader);
            StringBuilder stringBuilder = new StringBuilder();
            foreach (XElement descendant in xdocument.Descendants())
            {
              switch (descendant.Name.LocalName)
              {
                case "tab":
                  stringBuilder.Append("\t");
                  continue;
                case "br":
                  stringBuilder.Append("\n");
                  continue;
                case "t":
                case "delText":
                  stringBuilder.Append(descendant.Value);
                  continue;
                default:
                  continue;
              }
            }
            str = str + "\n" + stringBuilder?.ToString();
          }
        }
      }
      return str;
    }

    internal static void PostCreation(Package package, DocumentTypes documentType = DocumentTypes.Document)
    {
      PackagePart packagePart = documentType == DocumentTypes.Document || documentType == DocumentTypes.Pdf ? package.CreatePart(new Uri("/word/document.xml", UriKind.Relative), "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml", (CompressionOption) 0) : package.CreatePart(new Uri("/word/document.xml", UriKind.Relative), "application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml", (CompressionOption) 0);
      package.CreateRelationship(packagePart.get_Uri(), (TargetMode) 0, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument");
      XDocument xdocument;
      using ((TextReader) new StreamReader(packagePart.GetStream(FileMode.Create, FileAccess.ReadWrite)))
        xdocument = XDocument.Parse("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\r\n                   <w:document xmlns:ve=\"http://schemas.openxmlformats.org/markup-compatibility/2006\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" xmlns:m=\"http://schemas.openxmlformats.org/officeDocument/2006/math\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:w10=\"urn:schemas-microsoft-com:office:word\" xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:wne=\"http://schemas.microsoft.com/office/word/2006/wordml\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:c=\"http://schemas.openxmlformats.org/drawingml/2006/chart\">\r\n                   <w:body>\r\n                    <w:sectPr w:rsidR=\"003E25F4\" w:rsidSect=\"00FC3028\">\r\n                        <w:pgSz w:w=\"11906\" w:h=\"16838\"/>\r\n                        <w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/>\r\n                        <w:cols w:space=\"708\"/>\r\n                        <w:docGrid w:linePitch=\"360\"/>\r\n                    </w:sectPr>\r\n                   </w:body>\r\n                   </w:document>");
      using (TextWriter textWriter = (TextWriter) new StreamWriter((System.IO.Stream) new PackagePartStream(packagePart.GetStream(FileMode.Create, FileAccess.Write))))
        xdocument.Save(textWriter, SaveOptions.None);
      HelperFunctions.AddDefaultStylesXml(package);
      HelperFunctions.AddDefaultNumberingXml(package);
      package.Close();
    }

    internal static Xceed.Document.NET.Document PostLoad(
      ref Package package,
      Xceed.Document.NET.Document document,
      DocumentTypes documentType)
    {
      document._package = package;
      document.Document = document;
      document.PackagePart = HelperFunctions.GetMainDocumentPart(package);
      using (TextReader textReader = (TextReader) new StreamReader(document.PackagePart.GetStream(FileMode.Open, FileAccess.Read)))
        document._mainDoc = XDocument.Load(textReader, LoadOptions.PreserveWhitespace);
      Xceed.Document.NET.Document.PopulateDocument(document, package);
      using (TextReader textReader = (TextReader) new StreamReader(document._settingsPart.GetStream()))
        document._settings = XDocument.Load(textReader);
      document._paragraphLookup.Clear();
      foreach (Paragraph paragraph in document.Paragraphs)
      {
        if (!document._paragraphLookup.ContainsKey(paragraph._endIndex))
          document._paragraphLookup.Add(paragraph._endIndex, paragraph);
      }
      return document;
    }

    internal static Xceed.Document.NET.Document Load(
      System.IO.Stream stream,
      Xceed.Document.NET.Document document,
      DocumentTypes documentType)
    {
      MemoryStream memoryStream = new MemoryStream();
      try
      {
        stream.Position = 0L;
      }
      catch (Exception ex)
      {
      }
      HelperFunctions.CopyStream(stream, (System.IO.Stream) memoryStream);
      Package package = Package.Open((System.IO.Stream) memoryStream, FileMode.Open, FileAccess.ReadWrite);
      document = Xceed.Document.NET.Document.PostLoad(ref package, document, documentType);
      document._package = package;
      document._memoryStream = memoryStream;
      document._stream = stream;
      return document;
    }

    internal static Xceed.Document.NET.Document Load(
      string filename,
      Xceed.Document.NET.Document document,
      DocumentTypes documentType)
    {
      MemoryStream memoryStream = new MemoryStream();
      if (System.IO.File.Exists(filename))
      {
        using (FileStream fileStream = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.Read))
          HelperFunctions.CopyStream((System.IO.Stream) fileStream, (System.IO.Stream) memoryStream);
      }
      else
      {
        HttpWebResponse httpWebResponse = (HttpWebResponse) null;
        System.IO.Stream input = (System.IO.Stream) null;
        try
        {
          httpWebResponse = (HttpWebResponse) WebRequest.Create(filename).GetResponse();
          input = httpWebResponse.GetResponseStream();
          HelperFunctions.CopyStream(input, (System.IO.Stream) memoryStream);
        }
        catch (Exception ex)
        {
          throw new FileNotFoundException(string.Format("File could not be found {0}", (object) filename));
        }
        finally
        {
          httpWebResponse?.Close();
          input?.Close();
        }
      }
      Package package = Package.Open((System.IO.Stream) memoryStream, FileMode.Open, FileAccess.ReadWrite);
      document = Xceed.Document.NET.Document.PostLoad(ref package, document, documentType);
      document._package = package;
      document._filename = filename;
      document._memoryStream = memoryStream;
      return document;
    }

    internal void AddHyperlinkStyleIfNotPresent()
    {
      Uri uri = new Uri("/word/styles.xml", UriKind.Relative);
      if (!this._package.PartExists(uri))
        HelperFunctions.AddDefaultStylesXml(this._package);
      XDocument xdocument;
      using (TextReader textReader = (TextReader) new StreamReader(this._package.GetPart(uri).GetStream()))
        xdocument = XDocument.Load(textReader);
      if (xdocument.Element(Xceed.Document.NET.Document.w + "styles").Elements().Select(s => new
      {
        s = s,
        styleId = s.Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName))
      }).Where(_param1 => _param1.styleId != null && _param1.styleId.Value == "Hyperlink").Select(_param1 => _param1.s).Count<XElement>() > 0)
        return;
      XElement xelement = new XElement(Xceed.Document.NET.Document.w + "style", new object[8]
      {
        (object) new XAttribute(Xceed.Document.NET.Document.w + "type", (object) "character"),
        (object) new XAttribute(Xceed.Document.NET.Document.w + "styleId", (object) "Hyperlink"),
        (object) new XElement(Xceed.Document.NET.Document.w + "name", (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) "Hyperlink")),
        (object) new XElement(Xceed.Document.NET.Document.w + "basedOn", (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) "DefaultParagraphFont")),
        (object) new XElement(Xceed.Document.NET.Document.w + "uiPriority", (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) "99")),
        (object) new XElement(Xceed.Document.NET.Document.w + "unhideWhenUsed"),
        (object) new XElement(Xceed.Document.NET.Document.w + "rsid", (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) "0005416C")),
        (object) new XElement(Xceed.Document.NET.Document.w + "rPr", new object[2]
        {
          (object) new XElement(Xceed.Document.NET.Document.w + "color", new object[2]
          {
            (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) "0000FF"),
            (object) new XAttribute(Xceed.Document.NET.Document.w + "themeColor", (object) "hyperlink")
          }),
          (object) new XElement(Xceed.Document.NET.Document.w + "u", (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) "single"))
        })
      });
      xdocument.Element(Xceed.Document.NET.Document.w + "styles").Add((object) xelement);
      using (TextWriter textWriter = (TextWriter) new StreamWriter((System.IO.Stream) new PackagePartStream(this._package.GetPart(uri).GetStream())))
        xdocument.Save(textWriter);
    }

    internal void AddHeadersOrFootersXml(bool b)
    {
      string str1 = b ? "hdr" : "ftr";
      string str2 = b ? "header" : "footer";
      this.DeleteHeadersOrFooters(b);
      XElement xelement = this._mainDoc.Root.Element(Xceed.Document.NET.Document.w + "body").Elements(Xceed.Document.NET.Document.w + "sectPr").Last<XElement>();
      for (int index = 1; index < 4; ++index)
      {
        PackagePart part = this._package.CreatePart(new Uri(string.Format("/word/{0}{1}.xml", (object) str2, (object) index), UriKind.Relative), string.Format("application/vnd.openxmlformats-officedocument.wordprocessingml.{0}+xml", (object) str2), (CompressionOption) 0);
        PackageRelationship relationship = this.PackagePart.CreateRelationship(part.get_Uri(), (TargetMode) 0, string.Format("http://schemas.openxmlformats.org/officeDocument/2006/relationships/{0}", (object) str2));
        XDocument xdocument;
        using ((TextReader) new StreamReader(part.GetStream(FileMode.Create, FileAccess.ReadWrite)))
          xdocument = XDocument.Parse(string.Format("<?xml version=\"1.0\" encoding=\"utf-16\" standalone=\"yes\"?>\r\n                       <w:{0} xmlns:ve=\"http://schemas.openxmlformats.org/markup-compatibility/2006\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" xmlns:m=\"http://schemas.openxmlformats.org/officeDocument/2006/math\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:w10=\"urn:schemas-microsoft-com:office:word\" xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:wne=\"http://schemas.microsoft.com/office/word/2006/wordml\">\r\n                         <w:p w:rsidR=\"009D472B\" w:rsidRDefault=\"009D472B\">\r\n                           <w:pPr>\r\n                             <w:pStyle w:val=\"{1}\" />\r\n                           </w:pPr>\r\n                         </w:p>\r\n                       </w:{0}>", (object) str1, (object) str2));
        using (TextWriter textWriter = (TextWriter) new StreamWriter((System.IO.Stream) new PackagePartStream(part.GetStream(FileMode.Create, FileAccess.Write))))
          xdocument.Save(textWriter, SaveOptions.None);
        string str3;
        switch (index)
        {
          case 1:
            str3 = "default";
            break;
          case 2:
            str3 = "even";
            break;
          case 3:
            str3 = "first";
            break;
          default:
            throw new ArgumentOutOfRangeException();
        }
        xelement.Add((object) new XElement(Xceed.Document.NET.Document.w + string.Format("{0}Reference", (object) str2), new object[2]
        {
          (object) new XAttribute(Xceed.Document.NET.Document.w + "type", (object) str3),
          (object) new XAttribute(Xceed.Document.NET.Document.r + "id", (object) relationship.get_Id())
        }));
      }
    }

    internal Image AddImage(object o, string contentType = "image/jpeg")
    {
      System.IO.Stream input = o is string ? (System.IO.Stream) new FileStream(o as string, FileMode.Open, FileAccess.Read) : o as System.IO.Stream;
      using (input)
      {
        string empty = string.Empty;
        string str = contentType.Substring(contentType.LastIndexOf("/") + 1);
        string uriString;
        do
        {
          uriString = string.Format("/word/media/{0}.{1}", (object) Guid.NewGuid(), (object) str);
        }
        while (this._package.PartExists(new Uri(uriString, UriKind.Relative)));
        PackagePart part = this._package.CreatePart(new Uri(uriString, UriKind.Relative), contentType, (CompressionOption) 0);
        PackageRelationship relationship = this.PackagePart.CreateRelationship(part.get_Uri(), (TargetMode) 0, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image");
        using (System.IO.Stream output = (System.IO.Stream) new PackagePartStream(part.GetStream(FileMode.Create, FileAccess.Write)))
          HelperFunctions.CopyStream(input, output, 4096);
        return new Image(this, relationship);
      }
    }

    internal static void UpdateCorePropertyValue(
      Xceed.Document.NET.Document document,
      string corePropertyName,
      string corePropertyValue)
    {
      string lower = string.Format("(DOCPROPERTY)?{0}\\\\\\*MERGEFORMAT", (object) corePropertyName).ToLower();
      foreach (XElement descendant in document._mainDoc.Descendants(XName.Get("fldSimple", Xceed.Document.NET.Document.w.NamespaceName)))
      {
        if (Regex.IsMatch(descendant.Attribute(XName.Get("instr", Xceed.Document.NET.Document.w.NamespaceName)).Value.Replace(" ", string.Empty).Trim().ToLower(), lower))
        {
          XElement xelement1 = descendant.Element(Xceed.Document.NET.Document.w + "r");
          XElement xelement2 = xelement1.Element(Xceed.Document.NET.Document.w + "t").Element(Xceed.Document.NET.Document.w + "rPr");
          descendant.RemoveNodes();
          XElement e = new XElement(Xceed.Document.NET.Document.w + "t", new object[2]
          {
            (object) xelement2,
            (object) corePropertyValue
          });
          Xceed.Document.NET.Text.PreserveSpace(e);
          descendant.Add((object) new XElement(xelement1.Name, new object[3]
          {
            (object) xelement1.Attributes(),
            (object) xelement1.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)),
            (object) e
          }));
        }
      }
      List<XElement> xelementList = new List<XElement>();
      foreach (Section section in (IEnumerable<Section>) document.Sections)
      {
        Headers headers = section.Headers;
        if (headers.First != null)
          xelementList.Add(headers.First.Xml);
        if (headers.Odd != null)
          xelementList.Add(headers.Odd.Xml);
        if (headers.Even != null)
          xelementList.Add(headers.Even.Xml);
        Footers footers = section.Footers;
        if (footers.First != null)
          xelementList.Add(footers.First.Xml);
        if (footers.Odd != null)
          xelementList.Add(footers.Odd.Xml);
        if (footers.Even != null)
          xelementList.Add(footers.Even.Xml);
      }
      foreach (XContainer xcontainer in xelementList)
      {
        foreach (XElement descendant in xcontainer.Descendants(XName.Get("fldSimple", Xceed.Document.NET.Document.w.NamespaceName)))
        {
          if (Regex.IsMatch(descendant.Attribute(XName.Get("instr", Xceed.Document.NET.Document.w.NamespaceName)).Value.Replace(" ", string.Empty).Trim().ToLower(), lower))
          {
            XElement xelement = descendant.Element(Xceed.Document.NET.Document.w + "r");
            descendant.RemoveNodes();
            XElement e = new XElement(Xceed.Document.NET.Document.w + "t", (object) corePropertyValue);
            Xceed.Document.NET.Text.PreserveSpace(e);
            descendant.Add((object) new XElement(xelement.Name, new object[3]
            {
              (object) xelement.Attributes(),
              (object) xelement.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)),
              (object) e
            }));
          }
        }
      }
      document.SaveHeadersFooters();
      Xceed.Document.NET.Document.PopulateDocument(document, document._package);
    }

    internal static void UpdateCustomPropertyValue(Xceed.Document.NET.Document document, CustomProperty cp)
    {
      string name = cp.Name;
      string text = (cp.Value ?? (object) "").ToString();
      List<XElement> xelementList = new List<XElement>()
      {
        document._mainDoc.Root
      };
      foreach (Section section in (IEnumerable<Section>) document.Sections)
      {
        Headers headers = section.Headers;
        if (headers.First != null)
          xelementList.Add(headers.First.Xml);
        if (headers.Odd != null)
          xelementList.Add(headers.Odd.Xml);
        if (headers.Even != null)
          xelementList.Add(headers.Even.Xml);
      }
      foreach (Section section in (IEnumerable<Section>) document.Sections)
      {
        Footers footers = section.Footers;
        if (footers.First != null)
          xelementList.Add(footers.First.Xml);
        if (footers.Odd != null)
          xelementList.Add(footers.Odd.Xml);
        if (footers.Even != null)
          xelementList.Add(footers.Even.Xml);
      }
      string str = string.Format("DOCPROPERTY  {0}  \\* MERGEFORMAT", name.Contains(" ") ? (object) ("\"" + name + "\"") : (object) name).Replace(" ", string.Empty);
      foreach (XElement xelement1 in xelementList)
      {
        using (IEnumerator<XElement> enumerator = xelement1.Descendants(XName.Get("instrText", Xceed.Document.NET.Document.w.NamespaceName)).GetEnumerator())
        {
label_38:
          while (enumerator.MoveNext())
          {
            XElement current = enumerator.Current;
            if (current.Value.Replace(" ", string.Empty).Trim().Equals(str, StringComparison.CurrentCultureIgnoreCase))
            {
              XNode nextNode = current.Parent.NextNode;
              bool flag = false;
              while (true)
              {
                if (nextNode.NodeType == XmlNodeType.Element)
                {
                  XElement xelement2 = nextNode as XElement;
                  IEnumerable<XElement> source1 = xelement2.Descendants(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName));
                  if (source1.Any<XElement>())
                  {
                    if (!flag)
                    {
                      XElement xelement3 = source1.First<XElement>();
                      xelement3.Value = "\n";
                      xelement3.Add((object) HelperFunctions.FormatInput(text, cp.Formatting != null ? cp.Formatting.Xml : (XElement) null));
                      flag = true;
                    }
                    else
                      xelement2.RemoveNodes();
                  }
                  else
                  {
                    IEnumerable<XElement> source2 = xelement2.Descendants(XName.Get("fldChar", Xceed.Document.NET.Document.w.NamespaceName));
                    if (source2.Any<XElement>())
                    {
                      XAttribute xattribute = source2.First<XElement>().Attribute(XName.Get("fldCharType", Xceed.Document.NET.Document.w.NamespaceName));
                      if (xattribute != null && xattribute.Value == "end")
                        goto label_38;
                    }
                  }
                }
                nextNode = nextNode.NextNode;
              }
            }
          }
        }
        foreach (XElement descendant in xelement1.Descendants(XName.Get("fldSimple", Xceed.Document.NET.Document.w.NamespaceName)))
        {
          if (descendant.Attribute(XName.Get("instr", Xceed.Document.NET.Document.w.NamespaceName)).Value.Replace(" ", string.Empty).Trim().Equals(str, StringComparison.CurrentCultureIgnoreCase))
          {
            XElement xelement2 = descendant.Element(Xceed.Document.NET.Document.w + "r");
            XElement xelement3 = xelement2.Element(Xceed.Document.NET.Document.w + "t").Element(Xceed.Document.NET.Document.w + "rPr");
            descendant.RemoveNodes();
            XElement e = new XElement(Xceed.Document.NET.Document.w + "t", new object[2]
            {
              (object) xelement3,
              (object) text
            });
            Xceed.Document.NET.Text.PreserveSpace(e);
            descendant.Add((object) new XElement(xelement2.Name, new object[3]
            {
              (object) xelement2.Attributes(),
              (object) xelement2.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)),
              (object) e
            }));
          }
        }
      }
    }

    internal XDocument AddStylesForList()
    {
      Uri uri = new Uri("/word/styles.xml", UriKind.Relative);
      if (!this._package.PartExists(uri))
        HelperFunctions.AddDefaultStylesXml(this._package);
      XDocument xdocument;
      using (TextReader textReader = (TextReader) new StreamReader(this._package.GetPart(uri).GetStream()))
        xdocument = XDocument.Load(textReader);
      if (!xdocument.Element(Xceed.Document.NET.Document.w + "styles").Elements().Select(s => new
      {
        s = s,
        styleId = s.Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName))
      }).Where(_param1 => _param1.styleId != null && _param1.styleId.Value == "ListParagraph").Select(_param1 => _param1.s).Any<XElement>())
      {
        XElement xelement = new XElement(Xceed.Document.NET.Document.w + "style", new object[8]
        {
          (object) new XAttribute(Xceed.Document.NET.Document.w + "type", (object) "paragraph"),
          (object) new XAttribute(Xceed.Document.NET.Document.w + "styleId", (object) "ListParagraph"),
          (object) new XElement(Xceed.Document.NET.Document.w + "name", (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) "List Paragraph")),
          (object) new XElement(Xceed.Document.NET.Document.w + "basedOn", (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) "Normal")),
          (object) new XElement(Xceed.Document.NET.Document.w + "uiPriority", (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) "34")),
          (object) new XElement(Xceed.Document.NET.Document.w + "qformat"),
          (object) new XElement(Xceed.Document.NET.Document.w + "rsid", (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) "00832EE1")),
          (object) new XElement(Xceed.Document.NET.Document.w + "rPr", new object[2]
          {
            (object) new XElement(Xceed.Document.NET.Document.w + "ind", (object) new XAttribute(Xceed.Document.NET.Document.w + "left", (object) "720")),
            (object) new XElement(Xceed.Document.NET.Document.w + "contextualSpacing")
          })
        });
        xdocument.Element(Xceed.Document.NET.Document.w + "styles").Add((object) xelement);
        using (TextWriter textWriter = (TextWriter) new StreamWriter(this._package.GetPart(uri).GetStream()))
          xdocument.Save(textWriter);
      }
      return xdocument;
    }

    internal XElement GetDocDefaults() => this._styles == null ? (XElement) null : this._styles.Element(XName.Get("styles", Xceed.Document.NET.Document.w.NamespaceName)).Element(XName.Get("docDefaults", Xceed.Document.NET.Document.w.NamespaceName));

    internal long GetNextFreeDocPrId()
    {
      lock (this.nextFreeDocPrIdLock)
      {
        if (this.nextFreeDocPrId.HasValue)
        {
          long? nextFreeDocPrId = this.nextFreeDocPrId;
          this.nextFreeDocPrId = nextFreeDocPrId.HasValue ? new long?(nextFreeDocPrId.GetValueOrDefault() + 1L) : new long?();
          return this.nextFreeDocPrId.Value;
        }
        XName xname1 = XName.Get("bookmarkStart", Xceed.Document.NET.Document.w.NamespaceName);
        XName xname2 = XName.Get("docPr", Xceed.Document.NET.Document.wp.NamespaceName);
        long num = 1;
        HashSet<string> source = new HashSet<string>();
        foreach (XElement descendant in this.Xml.Descendants())
        {
          if (!(descendant.Name != xname1) || !(descendant.Name != xname2))
          {
            XAttribute xattribute = descendant.Attributes().FirstOrDefault<XAttribute>((Func<XAttribute, bool>) (x => x.Name.LocalName == "id"));
            if (xattribute != null)
              source.Add(xattribute.Value);
          }
        }
        if (source.Count > 0)
          num = source.Max<string>((Func<string, long>) (id => long.Parse(id))) + 1L;
        this.nextFreeDocPrId = new long?(num);
        return this.nextFreeDocPrId.Value;
      }
    }

    internal string GetNormalStyleId()
    {
      if (this._defaultParagraphStyleId != null)
        return this._defaultParagraphStyleId;
      XElement xelement = this._styles.Element(XName.Get("styles", Xceed.Document.NET.Document.w.NamespaceName)).Elements().Select(s => new
      {
        s = s,
        type = s.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName))
      }).Select(_param1 => new
      {
        \u003C\u003Eh__TransparentIdentifier0 = _param1,
        def = _param1.s.Attribute(XName.Get("default", Xceed.Document.NET.Document.w.NamespaceName))
      }).Where(_param1 => _param1.\u003C\u003Eh__TransparentIdentifier0.type != null && _param1.\u003C\u003Eh__TransparentIdentifier0.type.Value == "paragraph" && _param1.def != null && _param1.def.Value == "1").Select(_param1 => _param1.\u003C\u003Eh__TransparentIdentifier0.s).FirstOrDefault<XElement>();
      if (xelement != null)
      {
        XAttribute xattribute = xelement.Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null)
          this._defaultParagraphStyleId = xattribute.Value;
      }
      if (this._defaultParagraphStyleId == null)
        this._defaultParagraphStyleId = "Normal";
      return this._defaultParagraphStyleId;
    }

    internal static void PrepareDocument(ref Xceed.Document.NET.Document document, DocumentTypes documentType)
    {
      MemoryStream memoryStream = new MemoryStream();
      Xceed.Document.NET.Document.PostCreation(Package.Open((System.IO.Stream) memoryStream, FileMode.Create, FileAccess.ReadWrite), documentType);
      document = Xceed.Document.NET.Document.Load((System.IO.Stream) memoryStream, document, documentType);
    }

    internal void UpdateCacheSections() => this._cachedSections = this.GetSections();

    private void DeleteHeadersOrFooters(bool isHeader, bool deleteReferences = true)
    {
      string reference = isHeader ? "header" : "footer";
      using (IEnumerator<PackageRelationship> enumerator = this.PackagePart.GetRelationshipsByType(string.Format("http://schemas.openxmlformats.org/officeDocument/2006/relationships/{0}", (object) reference)).GetEnumerator())
      {
        while (((IEnumerator) enumerator).MoveNext())
        {
          PackageRelationship current = enumerator.Current;
          XElement documentBody = this._mainDoc.Descendants(XName.Get("body", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
          if (documentBody != null)
            this.DeleteHeaderOrFooter(current, reference, this._package, documentBody, deleteReferences);
        }
      }
    }

    private void DeleteHeaderOrFooter(
      PackageRelationship header_relationship,
      string reference,
      Package package,
      XElement documentBody,
      bool deleteReferences = true)
    {
      Uri uri = header_relationship.get_TargetUri();
      if (!uri.OriginalString.StartsWith("/word/"))
        uri = new Uri("/word/" + uri.OriginalString, UriKind.Relative);
      if (!package.PartExists(uri))
        return;
      package.DeletePart(uri);
      if (deleteReferences)
        this.RemoveReferences(header_relationship, reference, documentBody);
      package.DeleteRelationship(header_relationship.get_Id());
    }

    private void RemoveReferences(
      PackageRelationship header_relationship,
      string reference,
      XElement documentBody)
    {
      IEnumerable<XElement> source = documentBody.Descendants().Where<XElement>((Func<XElement, bool>) (e => e.Name.LocalName == string.Format("{0}Reference", (object) reference) && e.Attribute(Xceed.Document.NET.Document.r + "id").Value == header_relationship.get_Id()));
      for (int index = 0; index < source.Count<XElement>(); ++index)
        source.ElementAt<XElement>(index).Remove();
    }

    private void InsertParagraphPictures(Paragraph p)
    {
      if (p == null || p.Pictures == null || p.Pictures.Count <= 0)
        return;
      using (IEnumerator<PackagePart> enumerator = p.Document._package.GetParts().GetEnumerator())
      {
        while (((IEnumerator) enumerator).MoveNext())
        {
          PackagePart current = enumerator.Current;
          if (Xceed.Document.NET.Document._imageContentTypes.Contains(current.get_ContentType()))
            this.merge_images(current, p.Document, p.Document._mainDoc, current.get_ContentType());
        }
      }
    }

    private void merge_images(
      PackagePart remote_pp,
      Xceed.Document.NET.Document remote_document,
      XDocument remote_mainDoc,
      string contentType)
    {
      PackageRelationship packageRelationship1 = ((IEnumerable<PackageRelationship>) remote_document.PackagePart.GetRelationships()).Where<PackageRelationship>((Func<PackageRelationship, bool>) (r => r.get_TargetUri().OriginalString.Equals(remote_pp.get_Uri().OriginalString.Replace("/word/", "")))).FirstOrDefault<PackageRelationship>();
      if (packageRelationship1 == null)
      {
        packageRelationship1 = ((IEnumerable<PackageRelationship>) remote_document.PackagePart.GetRelationships()).Where<PackageRelationship>((Func<PackageRelationship, bool>) (r => r.get_TargetUri().OriginalString.Equals(remote_pp.get_Uri().OriginalString))).FirstOrDefault<PackageRelationship>();
        if (packageRelationship1 == null)
        {
          if (remote_document._numberingPart == null)
            return;
          packageRelationship1 = ((IEnumerable<PackageRelationship>) remote_document._numberingPart.GetRelationships()).Where<PackageRelationship>((Func<PackageRelationship, bool>) (r => r.get_TargetUri().OriginalString.Equals(remote_pp.get_Uri().OriginalString.Replace("/word/", "")))).FirstOrDefault<PackageRelationship>();
          if (packageRelationship1 == null)
          {
            packageRelationship1 = ((IEnumerable<PackageRelationship>) remote_document._numberingPart.GetRelationships()).Where<PackageRelationship>((Func<PackageRelationship, bool>) (r => r.get_TargetUri().OriginalString.Equals(remote_pp.get_Uri().OriginalString))).FirstOrDefault<PackageRelationship>();
            if (packageRelationship1 == null)
              return;
          }
        }
      }
      string id1 = packageRelationship1.get_Id();
      bool flag = false;
      using (System.IO.Stream stream1 = remote_pp.GetStream())
      {
        string md5HashString = this.ComputeMD5HashString(stream1);
        using (IEnumerator<PackagePart> enumerator = ((IEnumerable<PackagePart>) this._package.GetParts()).Where<PackagePart>((Func<PackagePart, bool>) (pp => pp.get_ContentType().Equals(contentType))).GetEnumerator())
        {
          while (((IEnumerator) enumerator).MoveNext())
          {
            PackagePart part = enumerator.Current;
            using (System.IO.Stream stream2 = part.GetStream())
            {
              if (this.ComputeMD5HashString(stream2).Equals(md5HashString))
              {
                flag = true;
                PackageRelationship packageRelationship2 = ((IEnumerable<PackageRelationship>) this.PackagePart.GetRelationships()).Where<PackageRelationship>((Func<PackageRelationship, bool>) (r => r.get_TargetUri().OriginalString.Equals(part.get_Uri().OriginalString.Replace("/word/", "")))).FirstOrDefault<PackageRelationship>() ?? ((IEnumerable<PackageRelationship>) this.PackagePart.GetRelationships()).Where<PackageRelationship>((Func<PackageRelationship, bool>) (r => r.get_TargetUri().OriginalString.Equals(part.get_Uri().OriginalString))).FirstOrDefault<PackageRelationship>() ?? ((IEnumerable<PackageRelationship>) this._numberingPart.GetRelationships()).Where<PackageRelationship>((Func<PackageRelationship, bool>) (r => r.get_TargetUri().OriginalString.Equals(part.get_Uri().OriginalString.Replace("/word/", "")))).FirstOrDefault<PackageRelationship>() ?? ((IEnumerable<PackageRelationship>) this._numberingPart.GetRelationships()).Where<PackageRelationship>((Func<PackageRelationship, bool>) (r => r.get_TargetUri().OriginalString.Equals(part.get_Uri().OriginalString))).FirstOrDefault<PackageRelationship>();
                if (packageRelationship2 != null)
                {
                  string id2 = packageRelationship2.get_Id();
                  this.ReplaceAllRemoteID(remote_mainDoc, "blip", "embed", Xceed.Document.NET.Document.a.NamespaceName, id1, id2);
                  this.ReplaceAllRemoteID(remote_mainDoc, "imagedata", "id", Xceed.Document.NET.Document.v.NamespaceName, id1, id2);
                  break;
                }
                break;
              }
            }
          }
        }
      }
      if (flag)
        return;
      string originalString = remote_pp.get_Uri().OriginalString;
      string uriString = originalString.Remove(originalString.LastIndexOf("/")) + "/" + Guid.NewGuid().ToString() + contentType.Replace("image/", ".");
      if (!uriString.StartsWith("/"))
        uriString = "/" + uriString;
      PackagePart part1 = this._package.CreatePart(new Uri(uriString, UriKind.Relative), remote_pp.get_ContentType(), (CompressionOption) 0);
      using (System.IO.Stream stream = remote_pp.GetStream())
      {
        using (System.IO.Stream output = (System.IO.Stream) new PackagePartStream(part1.GetStream(FileMode.Create)))
          HelperFunctions.CopyStream(stream, output);
      }
      string id3 = this.PackagePart.CreateRelationship(new Uri(uriString, UriKind.Relative), (TargetMode) 0, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image").get_Id();
      Match match = Regex.Match(id1, "rId\\d+", RegexOptions.IgnoreCase);
      this.ReplaceAllRemoteID(remote_mainDoc, "blip", "embed", Xceed.Document.NET.Document.a.NamespaceName, id1, id3);
      if (!match.Success)
      {
        this.ReplaceAllRemoteID(this._mainDoc, "blip", "embed", Xceed.Document.NET.Document.a.NamespaceName, id1, id3);
        this.ReplaceAllRemoteID(this._mainDoc, "imagedata", "id", Xceed.Document.NET.Document.v.NamespaceName, id1, id3);
      }
      this.ReplaceAllRemoteID(remote_mainDoc, "imagedata", "id", Xceed.Document.NET.Document.v.NamespaceName, id1, id3);
    }

    private void ReplaceAllRemoteID(
      XDocument remote_mainDoc,
      string localName,
      string localNameAttribute,
      string namespaceName,
      string remote_Id,
      string new_Id)
    {
      foreach (XElement descendant in remote_mainDoc.Descendants(XName.Get(localName, namespaceName)))
      {
        XAttribute xattribute = descendant.Attribute(XName.Get(localNameAttribute, Xceed.Document.NET.Document.r.NamespaceName));
        if (xattribute != null && xattribute.Value == remote_Id)
          xattribute.SetValue((object) new_Id);
      }
    }

    private string ComputeMD5HashString(System.IO.Stream stream)
    {
      byte[] hash = MD5.Create().ComputeHash(stream);
      StringBuilder stringBuilder = new StringBuilder();
      foreach (byte num in hash)
        stringBuilder.Append(num.ToString("X2"));
      return stringBuilder.ToString();
    }

    private void merge_endnotes(
      PackagePart remote_pp,
      PackagePart local_pp,
      XDocument remote_mainDoc,
      Xceed.Document.NET.Document remote,
      XDocument remote_endnotes)
    {
      int num = this._endnotes.Root.Descendants().Where<XElement>((Func<XElement, bool>) (d => d.Name.LocalName == "endnote")).Select<XElement, int>((Func<XElement, int>) (d => int.Parse(d.Attribute(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName)).Value))).Max() + 1;
      IEnumerable<XElement> xelements = remote_mainDoc.Descendants(XName.Get("endnoteReference", Xceed.Document.NET.Document.w.NamespaceName));
      foreach (XElement xelement1 in remote_endnotes.Root.Elements().OrderBy<XElement, XAttribute>((Func<XElement, XAttribute>) (fr => fr.Attribute(XName.Get("id", Xceed.Document.NET.Document.r.NamespaceName)))).Reverse<XElement>())
      {
        XAttribute xattribute1 = xelement1.Attribute(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName));
        int result;
        if (xattribute1 != null && HelperFunctions.TryParseInt(xattribute1.Value, out result) && result > 0)
        {
          foreach (XElement xelement2 in xelements)
          {
            XAttribute xattribute2 = xelement2.Attribute(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName));
            if (xattribute2 != null && int.Parse(xattribute2.Value).Equals(result))
              xattribute2.SetValue((object) num);
          }
          xelement1.SetAttributeValue(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName), (object) num);
          this._endnotes.Root.Add((object) xelement1);
          ++num;
        }
      }
    }

    private void merge_footnotes(
      PackagePart remote_pp,
      PackagePart local_pp,
      XDocument remote_mainDoc,
      Xceed.Document.NET.Document remote,
      XDocument remote_footnotes)
    {
      int num = this._footnotes.Root.Descendants().Where<XElement>((Func<XElement, bool>) (d => d.Name.LocalName == "footnote")).Select<XElement, int>((Func<XElement, int>) (d => int.Parse(d.Attribute(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName)).Value))).Max() + 1;
      IEnumerable<XElement> xelements = remote_mainDoc.Descendants(XName.Get("footnoteReference", Xceed.Document.NET.Document.w.NamespaceName));
      foreach (XElement xelement1 in remote_footnotes.Root.Elements().OrderBy<XElement, XAttribute>((Func<XElement, XAttribute>) (fr => fr.Attribute(XName.Get("id", Xceed.Document.NET.Document.r.NamespaceName)))).Reverse<XElement>())
      {
        XAttribute xattribute1 = xelement1.Attribute(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName));
        int result;
        if (xattribute1 != null && HelperFunctions.TryParseInt(xattribute1.Value, out result) && result > 0)
        {
          foreach (XElement xelement2 in xelements)
          {
            XAttribute xattribute2 = xelement2.Attribute(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName));
            if (xattribute2 != null && int.Parse(xattribute2.Value).Equals(result))
              xattribute2.SetValue((object) num);
          }
          xelement1.SetAttributeValue(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName), (object) num);
          this._footnotes.Root.Add((object) xelement1);
          ++num;
        }
      }
    }

    private void merge_customs(
      PackagePart remote_pp,
      PackagePart local_pp,
      XDocument remote_mainDoc)
    {
      XDocument xdocument1;
      using (TextReader textReader = (TextReader) new StreamReader(remote_pp.GetStream()))
        xdocument1 = XDocument.Load(textReader);
      XDocument xdocument2;
      using (TextReader textReader = (TextReader) new StreamReader(local_pp.GetStream()))
        xdocument2 = XDocument.Load(textReader);
      int num = xdocument1.Root.Descendants().Where<XElement>((Func<XElement, bool>) (d => d.Name.LocalName == "property")).Select<XElement, int>((Func<XElement, int>) (d => int.Parse(d.Attribute(XName.Get("pid")).Value))).Max() + 1;
      foreach (XElement element1 in xdocument1.Root.Elements())
      {
        bool flag = false;
        foreach (XElement element2 in xdocument2.Root.Elements())
        {
          XAttribute xattribute1 = element1.Attribute(XName.Get("name"));
          XName name = XName.Get("name");
          XAttribute xattribute2 = element2.Attribute(name);
          if (element1 != null && xattribute2 != null && xattribute1.Value.Equals(xattribute2.Value))
            flag = true;
        }
        if (!flag)
        {
          element1.SetAttributeValue(XName.Get("pid"), (object) num);
          xdocument2.Root.Add((object) element1);
          ++num;
        }
      }
      using (TextWriter textWriter = (TextWriter) new StreamWriter((System.IO.Stream) new PackagePartStream(local_pp.GetStream(FileMode.Create, FileAccess.Write))))
        xdocument2.Save(textWriter, SaveOptions.None);
    }

    private void merge_numbering(
      PackagePart remote_pp,
      PackagePart local_pp,
      XDocument remote_mainDoc,
      Xceed.Document.NET.Document remote)
    {
      IEnumerable<XElement> source1 = this._numbering.Root.Elements(XName.Get("abstractNum", Xceed.Document.NET.Document.w.NamespaceName));
      IEnumerable<XElement> xelements1 = remote._numbering.Root.Elements(XName.Get("abstractNum", Xceed.Document.NET.Document.w.NamespaceName));
      int num1 = -1;
      foreach (XElement xelement in source1)
      {
        XAttribute xattribute = xelement.Attribute(XName.Get("abstractNumId", Xceed.Document.NET.Document.w.NamespaceName));
        int result;
        if (xattribute != null && HelperFunctions.TryParseInt(xattribute.Value, out result) && result > num1)
          num1 = result;
      }
      int num2 = num1 + 1;
      IEnumerable<XElement> xelements2 = remote._numbering.Root.Elements(XName.Get("num", Xceed.Document.NET.Document.w.NamespaceName));
      IEnumerable<XElement> source2 = this._numbering.Root.Elements(XName.Get("num", Xceed.Document.NET.Document.w.NamespaceName));
      int num3 = 0;
      foreach (XElement xelement in source2)
      {
        XAttribute xattribute = xelement.Attribute(XName.Get("numId", Xceed.Document.NET.Document.w.NamespaceName));
        int result;
        if (xattribute != null && HelperFunctions.TryParseInt(xattribute.Value, out result) && result > num3)
          num3 = result;
      }
      int num4 = num3 + 1;
      foreach (XElement xelement1 in xelements1)
      {
        int num5 = num4;
        XName name = XName.Get("abstractNumId", Xceed.Document.NET.Document.w.NamespaceName);
        XAttribute xattribute1 = xelement1.Attribute(name);
        if (xattribute1 != null)
        {
          string str = xattribute1.Value;
          xattribute1.SetValue((object) num2);
          foreach (XElement xelement2 in xelements2)
          {
            foreach (XElement descendant in remote_mainDoc.Descendants(XName.Get("numId", Xceed.Document.NET.Document.w.NamespaceName)))
            {
              XAttribute xattribute2 = descendant.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
              if (xattribute2 != null && xattribute2.Value.Equals(xelement2.Attribute(XName.Get("numId", Xceed.Document.NET.Document.w.NamespaceName)).Value))
                xattribute2.SetValue((object) num5);
            }
            xelement2.SetAttributeValue(XName.Get("numId", Xceed.Document.NET.Document.w.NamespaceName), (object) num5);
            XAttribute xattribute3 = xelement2.Element(XName.Get("abstractNumId", Xceed.Document.NET.Document.w.NamespaceName)).Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
            if (xattribute3 != null && xattribute3.Value.Equals(str))
              xattribute3.SetValue((object) num2);
            ++num5;
          }
        }
        ++num2;
      }
      if (source1 != null)
      {
        if (source1.Count<XElement>() > 0)
          source1.Last<XElement>().AddAfterSelf((object) xelements1);
        else
          this._numbering.Root.Add((object) xelements1);
      }
      if (source2 == null)
        return;
      if (source2.Count<XElement>() > 0)
        source2.Last<XElement>().AddAfterSelf((object) xelements2);
      else
        this._numbering.Root.Add((object) xelements2);
    }

    private void merge_fonts(
      PackagePart remote_pp,
      PackagePart local_pp,
      XDocument remote_mainDoc,
      Xceed.Document.NET.Document remote)
    {
      IEnumerable<XElement> xelements1 = remote._fontTable.Root.Elements(XName.Get("font", Xceed.Document.NET.Document.w.NamespaceName));
      IEnumerable<XElement> xelements2 = this._fontTable.Root.Elements(XName.Get("font", Xceed.Document.NET.Document.w.NamespaceName));
      foreach (XElement xelement1 in xelements1)
      {
        bool flag = true;
        foreach (XElement xelement2 in xelements2)
        {
          if (xelement2.Attribute(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName)).Value == xelement1.Attribute(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName)).Value)
          {
            flag = false;
            break;
          }
        }
        if (flag)
          this._fontTable.Root.Add((object) xelement1);
      }
    }

    private bool IsDefaultParagraphStyle(XElement style) => style != null && style.Attribute(XName.Get("default", Xceed.Document.NET.Document.w.NamespaceName)) != null && (style.Attribute(XName.Get("default", Xceed.Document.NET.Document.w.NamespaceName)).Value == "1" && style.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName)) != null) && style.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName)).Value == "paragraph";

    private void MergeDefaultParagraphStyles(Xceed.Document.NET.Document remote, XElement remote_style)
    {
      if (remote == null || remote_style == null)
        return;
      XElement docDefaults = remote.GetDocDefaults();
      if (docDefaults == null)
        return;
      XElement xelement1 = docDefaults.Element(XName.Get("rPrDefault", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 != null)
      {
        XElement xelement2 = xelement1.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 != null)
        {
          XElement xelement3 = remote_style.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
          if (xelement3 == null)
          {
            remote_style.Add((object) xelement2);
          }
          else
          {
            foreach (XElement element in xelement2.Elements())
            {
              if (xelement3.Element(element.Name) == null)
                xelement3.Add((object) element);
            }
          }
        }
      }
      XElement xelement4 = docDefaults.Element(XName.Get("pPrDefault", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement4 == null)
        return;
      XElement xelement5 = xelement4.Element(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement5 == null)
        return;
      XElement xelement6 = remote_style.Element(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement6 == null)
      {
        remote_style.Add((object) xelement5);
      }
      else
      {
        foreach (XElement element in xelement5.Elements())
        {
          if (xelement6.Element(element.Name) == null)
            xelement6.Add((object) element);
        }
      }
    }

    private void merge_styles(
      PackagePart remote_pp,
      PackagePart local_pp,
      XDocument remote_mainDoc,
      Xceed.Document.NET.Document remote,
      XDocument remote_footnotes,
      XDocument remote_endnotes,
      MergingMode mergingMode)
    {
      Dictionary<string, XElement> dictionary = new Dictionary<string, XElement>();
      foreach (XElement element in this._styles.Root.Elements(XName.Get("style", Xceed.Document.NET.Document.w.NamespaceName)))
      {
        string key = new XElement(element).Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName)).Value;
        dictionary.Add(key, element);
      }
      foreach (XElement element in remote._styles.Root.Elements(XName.Get("style", Xceed.Document.NET.Document.w.NamespaceName)))
      {
        XAttribute xattribute1 = new XElement(element).Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName));
        string key = xattribute1.Value;
        if (dictionary.ContainsKey(key))
        {
          switch (mergingMode)
          {
            case MergingMode.Local:
              continue;
            case MergingMode.Remote:
              XElement xelement = dictionary[key];
              if (xelement != null)
              {
                xelement.AddAfterSelf((object) element);
                xelement.Remove();
                dictionary[key] = element;
                continue;
              }
              continue;
            case MergingMode.Both:
              if (dictionary[key].ToString() == element.ToString())
                continue;
              break;
          }
        }
        if (this.IsDefaultParagraphStyle(element))
        {
          this.MergeDefaultParagraphStyles(remote, element);
          element.Attribute(XName.Get("default", Xceed.Document.NET.Document.w.NamespaceName)).Remove();
        }
        string str = Guid.NewGuid().ToString();
        element.SetAttributeValue(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName), (object) str);
        element.Element(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName))?.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) str);
        foreach (XElement descendant in remote_mainDoc.Root.Descendants(XName.Get("pStyle", Xceed.Document.NET.Document.w.NamespaceName)))
        {
          XAttribute xattribute2 = descendant.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
          if (xattribute2 != null && xattribute2.Value.Equals(xattribute1.Value))
            xattribute2.SetValue((object) str);
        }
        foreach (XElement descendant in remote_mainDoc.Root.Descendants(XName.Get("rStyle", Xceed.Document.NET.Document.w.NamespaceName)))
        {
          XAttribute xattribute2 = descendant.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
          if (xattribute2 != null && xattribute2.Value.Equals(xattribute1.Value))
            xattribute2.SetValue((object) str);
        }
        foreach (XElement descendant in remote_mainDoc.Root.Descendants(XName.Get("tblStyle", Xceed.Document.NET.Document.w.NamespaceName)))
        {
          XAttribute xattribute2 = descendant.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
          if (xattribute2 != null && xattribute2.Value.Equals(xattribute1.Value))
            xattribute2.SetValue((object) str);
        }
        if (remote_endnotes != null)
        {
          foreach (XElement descendant in remote_endnotes.Root.Descendants(XName.Get("rStyle", Xceed.Document.NET.Document.w.NamespaceName)))
          {
            XAttribute xattribute2 = descendant.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
            if (xattribute2 != null && xattribute2.Value.Equals(xattribute1.Value))
              xattribute2.SetValue((object) str);
          }
          foreach (XElement descendant in remote_endnotes.Root.Descendants(XName.Get("pStyle", Xceed.Document.NET.Document.w.NamespaceName)))
          {
            XAttribute xattribute2 = descendant.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
            if (xattribute2 != null && xattribute2.Value.Equals(xattribute1.Value))
              xattribute2.SetValue((object) str);
          }
        }
        if (remote_footnotes != null)
        {
          foreach (XElement descendant in remote_footnotes.Root.Descendants(XName.Get("rStyle", Xceed.Document.NET.Document.w.NamespaceName)))
          {
            XAttribute xattribute2 = descendant.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
            if (xattribute2 != null && xattribute2.Value.Equals(xattribute1.Value))
              xattribute2.SetValue((object) str);
          }
          foreach (XElement descendant in remote_footnotes.Root.Descendants(XName.Get("pStyle", Xceed.Document.NET.Document.w.NamespaceName)))
          {
            XAttribute xattribute2 = descendant.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
            if (xattribute2 != null && xattribute2.Value.Equals(xattribute1.Value))
              xattribute2.SetValue((object) str);
          }
        }
        if (remote._numbering != null)
        {
          foreach (XElement descendant in remote._numbering.Root.Descendants(XName.Get("pStyle", Xceed.Document.NET.Document.w.NamespaceName)))
          {
            XAttribute xattribute2 = descendant.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
            if (xattribute2 != null && xattribute2.Value.Equals(xattribute1.Value))
              xattribute2.SetValue((object) str);
          }
        }
        if (this._numbering != null)
        {
          foreach (XElement descendant in this._numbering.Root.Descendants(XName.Get("pStyle", Xceed.Document.NET.Document.w.NamespaceName)))
          {
            XAttribute xattribute2 = descendant.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
            if (xattribute2 != null && xattribute2.Value.Equals(xattribute1.Value))
              xattribute2.SetValue((object) str);
          }
        }
        foreach (XElement descendant in remote._styles.Descendants(XName.Get("basedOn", Xceed.Document.NET.Document.w.NamespaceName)))
        {
          XAttribute xattribute2 = descendant.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
          if (xattribute2 != null && xattribute2.Value.Equals(xattribute1.Value))
            xattribute2.SetValue((object) str);
        }
        foreach (XElement descendant in remote._styles.Descendants(XName.Get("next", Xceed.Document.NET.Document.w.NamespaceName)))
        {
          XAttribute xattribute2 = descendant.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
          if (xattribute2 != null && xattribute2.Value.Equals(xattribute1.Value))
            xattribute2.SetValue((object) str);
        }
        xattribute1.SetValue((object) str);
        this._styles.Root.Add((object) element);
      }
    }

    private void merge_headerFooters(
      bool isHeader,
      PackagePart remote_pp,
      XDocument remote_mainDoc,
      Xceed.Document.NET.Document remote_document,
      MergingMode mergingMode)
    {
      if (remote_pp == null || remote_mainDoc == null || remote_document == null)
        return;
      switch (mergingMode)
      {
        case MergingMode.Remote:
        case MergingMode.Both:
          PackageRelationship packageRelationship = ((IEnumerable<PackageRelationship>) remote_document.PackagePart.GetRelationships()).Where<PackageRelationship>((Func<PackageRelationship, bool>) (r => r.get_TargetUri().OriginalString.Equals(remote_pp.get_Uri().OriginalString.Replace("/word/", "")))).FirstOrDefault<PackageRelationship>();
          if (packageRelationship == null)
            break;
          string originalString = remote_pp.get_Uri().OriginalString;
          string uriString = originalString.Remove(originalString.LastIndexOf("/")) + "/" + Guid.NewGuid().ToString();
          if (!uriString.StartsWith("/"))
            uriString = "/" + uriString;
          PackagePart part = this._package.CreatePart(new Uri(uriString, UriKind.Relative), remote_pp.get_ContentType(), (CompressionOption) 0);
          using (System.IO.Stream stream = remote_pp.GetStream())
          {
            using (System.IO.Stream output = (System.IO.Stream) new PackagePartStream(part.GetStream(FileMode.Create)))
              HelperFunctions.CopyStream(stream, output);
          }
          string str = isHeader ? "http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" : "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer";
          string id = this.PackagePart.CreateRelationship(new Uri(uriString, UriKind.Relative), (TargetMode) 0, str).get_Id();
          this.ReplaceAllRemoteID(remote_mainDoc, isHeader ? "headerReference" : "footerReference", "id", Xceed.Document.NET.Document.w.NamespaceName, packageRelationship.get_Id(), id);
          break;
      }
    }

    protected void clonePackageRelationship(
      Xceed.Document.NET.Document remote_document,
      PackagePart pp,
      XDocument remote_mainDoc)
    {
      string str = pp.get_Uri().OriginalString.Replace("/", "");
      using (IEnumerator<PackageRelationship> enumerator = remote_document.PackagePart.GetRelationships().GetEnumerator())
      {
        while (((IEnumerator) enumerator).MoveNext())
        {
          PackageRelationship current = enumerator.Current;
          if (str.Equals("word" + current.get_TargetUri().OriginalString.Replace("/", "")))
          {
            string id1 = current.get_Id();
            string id2 = this.PackagePart.CreateRelationship(current.get_TargetUri(), current.get_TargetMode(), current.get_RelationshipType()).get_Id();
            this.ReplaceAllRemoteID(remote_mainDoc, "blip", "embed", Xceed.Document.NET.Document.a.NamespaceName, id1, id2);
            this.ReplaceAllRemoteID(remote_mainDoc, "imagedata", "id", Xceed.Document.NET.Document.v.NamespaceName, id1, id2);
            break;
          }
        }
      }
    }

    protected PackagePart clonePackagePart(PackagePart pp)
    {
      PackagePart part = this._package.CreatePart(pp.get_Uri(), pp.get_ContentType(), (CompressionOption) 0);
      using (System.IO.Stream stream = pp.GetStream())
      {
        using (System.IO.Stream output = (System.IO.Stream) new PackagePartStream(part.GetStream(FileMode.Create)))
          HelperFunctions.CopyStream(stream, output);
      }
      return part;
    }

    protected string GetMD5HashFromStream(System.IO.Stream stream)
    {
      byte[] hash = new MD5CryptoServiceProvider().ComputeHash(stream);
      StringBuilder stringBuilder = new StringBuilder();
      for (int index = 0; index < hash.Length; ++index)
        stringBuilder.Append(hash[index].ToString("x2"));
      return stringBuilder.ToString();
    }

    private static void PopulateDocument(Xceed.Document.NET.Document document, Package package)
    {
      document.Xml = document._mainDoc.Root.Element(XName.Get("body", Xceed.Document.NET.Document.w.NamespaceName));
      if (document.Xml == null)
        throw new InvalidDataException("Can't find body of document's xml. Make sure document has a body from namespace w:http://schemas.openxmlformats.org/wordprocessingml/2006/main");
      document._settingsPart = HelperFunctions.CreateOrGetSettingsPart(package);
      try
      {
        document.PackagePart.GetRelationships();
      }
      catch (UriFormatException ex)
      {
        Xceed.Document.NET.Document.UpdateRelationshipsUri(package);
      }
      using (IEnumerator<PackageRelationship> enumerator = document.PackagePart.GetRelationships().GetEnumerator())
      {
        while (((IEnumerator) enumerator).MoveNext())
        {
          PackageRelationship current = enumerator.Current;
          string uriString = "/word/" + current.get_TargetUri().OriginalString.Replace("/word/", "").Replace("file://", "");
          switch (current.get_RelationshipType())
          {
            case "http://schemas.openxmlformats.org/officeDocument/2006/relationships/endnotes":
              document._endnotesPart = package.GetPart(new Uri(uriString, UriKind.Relative));
              using (TextReader textReader = (TextReader) new StreamReader(document._endnotesPart.GetStream()))
              {
                document._endnotes = XDocument.Load(textReader);
                continue;
              }
            case "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footnotes":
              document._footnotesPart = package.GetPart(new Uri(uriString, UriKind.Relative));
              using (TextReader textReader = (TextReader) new StreamReader(document._footnotesPart.GetStream()))
              {
                document._footnotes = XDocument.Load(textReader);
                continue;
              }
            case "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles":
              document._stylesPart = package.GetPart(new Uri(uriString, UriKind.Relative));
              using (TextReader textReader = (TextReader) new StreamReader(document._stylesPart.GetStream()))
              {
                document._styles = XDocument.Load(textReader);
                XElement xelement1 = document._styles.Root.Element(XName.Get("docDefaults", Xceed.Document.NET.Document.w.NamespaceName));
                if (xelement1 != null)
                {
                  XElement xelement2 = xelement1.Element(XName.Get("pPrDefault", Xceed.Document.NET.Document.w.NamespaceName));
                  if (xelement2 != null)
                  {
                    XElement pPr = xelement2.Element(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName));
                    if (pPr != null)
                    {
                      Paragraph.SetDefaultValues(pPr);
                      continue;
                    }
                    continue;
                  }
                  continue;
                }
                continue;
              }
            case "http://schemas.microsoft.com/office/2007/relationships/stylesWithEffects":
              document._stylesWithEffectsPart = package.GetPart(new Uri(uriString, UriKind.Relative));
              using (TextReader textReader = (TextReader) new StreamReader(document._stylesWithEffectsPart.GetStream()))
              {
                document._stylesWithEffects = XDocument.Load(textReader);
                continue;
              }
            case "http://schemas.openxmlformats.org/officeDocument/2006/relationships/fontTable":
              document._fontTablePart = package.GetPart(new Uri(uriString, UriKind.Relative));
              using (TextReader textReader = (TextReader) new StreamReader(document._fontTablePart.GetStream()))
              {
                document._fontTable = XDocument.Load(textReader);
                continue;
              }
            case "http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering":
              document._numberingPart = package.GetPart(new Uri(uriString, UriKind.Relative));
              using (TextReader textReader = (TextReader) new StreamReader(document._numberingPart.GetStream()))
              {
                document._numbering = XDocument.Load(textReader);
                continue;
              }
            default:
              continue;
          }
        }
      }
      document._cachedSections = document.GetSections();
    }

    private static void UpdateRelationshipsUri(Package package)
    {
      if (package == null || !package.PartExists(new Uri("/word/_rels/document.xml.rels", UriKind.Relative)))
        return;
      PackagePart part = package.GetPart(new Uri("/word/_rels/document.xml.rels", UriKind.Relative));
      using (StreamReader streamReader = new StreamReader(part.GetStream(FileMode.Open, FileAccess.Read)))
      {
        XDocument xdocument = XDocument.Load((TextReader) streamReader, LoadOptions.PreserveWhitespace);
        IEnumerable<XElement> xelements = xdocument.Descendants(XName.Get("Relationship", Xceed.Document.NET.Document.rel.NamespaceName)).Where<XElement>((Func<XElement, bool>) (relation => relation.Attribute((XName) "TargetMode") != null && (string) relation.Attribute((XName) "TargetMode") == "External"));
        bool flag = false;
        foreach (XElement xelement in xelements)
        {
          string uriString = (string) xelement.Attribute((XName) "Target");
          if (!string.IsNullOrEmpty(uriString))
          {
            try
            {
              Uri uri = new Uri(uriString);
            }
            catch (UriFormatException ex)
            {
              Uri uri = new Uri("http://broken-link/");
              xelement.Attribute((XName) "Target").Value = uri.ToString();
              flag = true;
            }
          }
        }
        if (!flag)
          return;
        using (StreamWriter streamWriter = new StreamWriter((System.IO.Stream) new PackagePartStream(part.GetStream(FileMode.Create, FileAccess.Write))))
          xdocument.Save((TextWriter) streamWriter, SaveOptions.None);
      }
    }

    private string GetNextFreeRelationshipID()
    {
      int result;
      if (HelperFunctions.TryParseInt(((IEnumerable<PackageRelationship>) this.PackagePart.GetRelationships()).Where<PackageRelationship>((Func<PackageRelationship, bool>) (r => r.get_Id().Substring(0, 3).Equals("rId"))).Select<PackageRelationship, int>((Func<PackageRelationship, int>) (r => int.Parse(r.get_Id().Substring(3)))).DefaultIfEmpty<int>().Max().ToString(), out result))
        return "rId" + (result + 1).ToString();
      string empty = string.Empty;
      string str;
      do
      {
        str = Guid.NewGuid().ToString();
      }
      while (char.IsDigit(str[0]));
      return str;
    }

    private byte[] MergeArrays(byte[] array1, byte[] array2)
    {
      byte[] numArray = new byte[array1.Length + array2.Length];
      Buffer.BlockCopy((Array) array2, 0, (Array) numArray, 0, array2.Length);
      Buffer.BlockCopy((Array) array1, 0, (Array) numArray, array2.Length, array1.Length);
      return numArray;
    }

    private void UpdateHeaderFooterReferences(
      bool isHeader,
      XElement elementToModify,
      XElement baseElement)
    {
      if (elementToModify == null || baseElement == null)
        return;
      string localName = isHeader ? "headerReference" : "footerReference";
      List<XElement> list1 = elementToModify.Descendants(XName.Get("sectPr", Xceed.Document.NET.Document.w.NamespaceName)).ToList<XElement>();
      if (!list1.Any<XElement>())
        return;
      List<XElement> list2 = baseElement.Descendants(XName.Get("sectPr", Xceed.Document.NET.Document.w.NamespaceName)).ToList<XElement>();
      for (int index1 = 0; index1 < list2.Count<XElement>(); ++index1)
      {
        IEnumerable<XElement> source = list2[index1].Elements(XName.Get(localName, Xceed.Document.NET.Document.w.NamespaceName));
        int index2 = Math.Min(index1, list1.Count<XElement>() - 1);
        IEnumerable<XElement> xelements = list1[index2].Elements(XName.Get(localName, Xceed.Document.NET.Document.w.NamespaceName));
        List<XElement> xelementList = new List<XElement>();
        foreach (XElement el1 in xelements)
        {
          string elementToModifyHeaderType = el1.GetAttribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName));
          if (elementToModifyHeaderType != null)
          {
            XElement el2 = source.FirstOrDefault<XElement>((Func<XElement, bool>) (reference => reference.GetAttribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName)) == elementToModifyHeaderType));
            if (el2 != null)
              el1.SetAttributeValue(XName.Get("id", Xceed.Document.NET.Document.r.NamespaceName), (object) el2.GetAttribute(XName.Get("id", Xceed.Document.NET.Document.r.NamespaceName)));
            else
              xelementList.Add(el1);
          }
        }
        xelementList.ForEach((System.Action<XElement>) (reference => reference.Remove()));
      }
    }

    private Hyperlink AddHyperlinkCore(
      string text,
      Uri uri,
      string anchor,
      Hyperlink baseHyperlink,
      Formatting formatting)
    {
      XElement i;
      if (baseHyperlink != null)
      {
        i = baseHyperlink.Xml;
        i.SetAttributeValue(XName.Get("id", Xceed.Document.NET.Document.r.NamespaceName), (object) string.Empty);
        if (!string.IsNullOrEmpty(anchor))
          i.SetAttributeValue(XName.Get(nameof (anchor), Xceed.Document.NET.Document.w.NamespaceName), (object) anchor);
        IEnumerable<XElement> source = i.Elements().Where<XElement>((Func<XElement, bool>) (r => r.Name.LocalName == nameof (r)));
        foreach (XContainer xcontainer in source)
          xcontainer.Element(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName)).Remove();
        source.First<XElement>().Add((object) new XElement(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName), (object) text));
      }
      else if (formatting != null)
      {
        if (string.IsNullOrEmpty(formatting.StyleId))
          formatting.StyleId = "Hyperlink";
        i = new XElement(XName.Get("hyperlink", Xceed.Document.NET.Document.w.NamespaceName), new object[3]
        {
          (object) new XAttribute(Xceed.Document.NET.Document.r + "id", (object) string.Empty),
          (object) new XAttribute(Xceed.Document.NET.Document.w + "history", (object) "1"),
          !string.IsNullOrEmpty(anchor) ? (object) new XAttribute(Xceed.Document.NET.Document.w + nameof (anchor), (object) anchor) : (object) (XAttribute) null
        });
        List<XElement> xelementList = HelperFunctions.FormatInput(text, formatting.Xml);
        i.Add((object) xelementList);
      }
      else
        i = new XElement(XName.Get("hyperlink", Xceed.Document.NET.Document.w.NamespaceName), new object[4]
        {
          (object) new XAttribute(Xceed.Document.NET.Document.r + "id", (object) string.Empty),
          (object) new XAttribute(Xceed.Document.NET.Document.w + "history", (object) "1"),
          !string.IsNullOrEmpty(anchor) ? (object) new XAttribute(Xceed.Document.NET.Document.w + nameof (anchor), (object) anchor) : (object) (XAttribute) null,
          (object) new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
          {
            (object) new XElement(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("rStyle", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) "Hyperlink"))),
            (object) new XElement(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName), (object) text)
          })
        });
      Hyperlink hyperlink = new Hyperlink(this, this.PackagePart, i);
      hyperlink.text = text;
      if (uri != (Uri) null)
        hyperlink.uri = uri;
      this.AddHyperlinkStyleIfNotPresent();
      return hyperlink;
    }

    private Section InsertSection(bool trackChanges, bool isPageBreak) => isPageBreak ? this.Sections.Last<Section>().InsertSectionPageBreak(trackChanges) : this.Sections.Last<Section>().InsertSection(trackChanges);

    private void MoveSectionIntoLastParagraph(XElement body)
    {
      XElement xelement1 = body.Elements(XName.Get("sectPr", Xceed.Document.NET.Document.w.NamespaceName)).LastOrDefault<XElement>();
      if (xelement1 == null)
        return;
      XElement xelement2 = body.Elements(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName)).LastOrDefault<XElement>();
      if (xelement2 == null)
      {
        body.AddFirst((object) new XElement(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName)));
        xelement2 = body.Elements(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName)).LastOrDefault<XElement>();
      }
      XElement xelement3 = xelement2.Element(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement3 == null)
      {
        xelement2.Add((object) new XElement(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName)));
        xelement3 = xelement2.Element(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName));
      }
      if (xelement3.Element(XName.Get("sectPr", Xceed.Document.NET.Document.w.NamespaceName)) == null)
        xelement3.Add((object) xelement1);
      xelement1.Remove();
    }

    private void RemoveLastSection(XElement body) => body.Elements(XName.Get("sectPr", Xceed.Document.NET.Document.w.NamespaceName)).LastOrDefault<XElement>()?.Remove();

    private void ReplaceLastSection(XElement first, XElement second)
    {
      XElement xelement1 = first.Elements(XName.Get("sectPr", Xceed.Document.NET.Document.w.NamespaceName)).LastOrDefault<XElement>();
      if (xelement1 == null)
        return;
      XElement xelement2 = second.Elements(XName.Get("sectPr", Xceed.Document.NET.Document.w.NamespaceName)).LastOrDefault<XElement>();
      if (xelement2 == null)
        return;
      xelement2.ReplaceWith((object) xelement1);
      xelement1.Remove();
    }

    private void InsertChart(Chart chart, Paragraph paragraph, float width = 432f, float height = 252f)
    {
      string empty = string.Empty;
      int num1 = 1;
      string uriString;
      do
      {
        uriString = string.Format("/word/charts/chart{0}.xml", (object) num1);
        ++num1;
      }
      while (this._package.PartExists(new Uri(uriString, UriKind.Relative)));
      PackagePart part = this._package.CreatePart(new Uri(uriString, UriKind.Relative), "application/vnd.openxmlformats-officedocument.drawingml.chart+xml", (CompressionOption) 0);
      string freeRelationshipId = this.GetNextFreeRelationshipID();
      this.PackagePart.CreateRelationship(part.get_Uri(), (TargetMode) 0, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart", freeRelationshipId);
      Paragraph paragraph1;
      if (paragraph == null)
      {
        using (TextWriter textWriter = (TextWriter) new StreamWriter((System.IO.Stream) new PackagePartStream(part.GetStream(FileMode.Create, FileAccess.Write))))
          chart.Xml.Save(textWriter);
        paragraph1 = this.InsertParagraph();
      }
      else
      {
        using (TextWriter textWriter = (TextWriter) new StreamWriter(part.GetStream(FileMode.Create, FileAccess.Write)))
          chart.Xml.Save(textWriter);
        paragraph1 = paragraph;
      }
      float num2 = width * 12700f;
      float num3 = height * 12700f;
      XElement xelement = new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("drawing", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("inline", Xceed.Document.NET.Document.wp.NamespaceName), new object[4]
      {
        (object) new XElement(XName.Get("extent", Xceed.Document.NET.Document.wp.NamespaceName), new object[2]
        {
          (object) new XAttribute((XName) "cx", (object) num2),
          (object) new XAttribute((XName) "cy", (object) num3)
        }),
        (object) new XElement(XName.Get("effectExtent", Xceed.Document.NET.Document.wp.NamespaceName), new object[4]
        {
          (object) new XAttribute((XName) "l", (object) "0"),
          (object) new XAttribute((XName) "t", (object) "0"),
          (object) new XAttribute((XName) "r", (object) "19050"),
          (object) new XAttribute((XName) "b", (object) "19050")
        }),
        (object) new XElement(XName.Get("docPr", Xceed.Document.NET.Document.wp.NamespaceName), new object[2]
        {
          (object) new XAttribute((XName) "id", (object) "1"),
          (object) new XAttribute((XName) "name", (object) nameof (chart))
        }),
        (object) new XElement(XName.Get("graphic", Xceed.Document.NET.Document.a.NamespaceName), (object) new XElement(XName.Get("graphicData", Xceed.Document.NET.Document.a.NamespaceName), new object[2]
        {
          (object) new XAttribute((XName) "uri", (object) Xceed.Document.NET.Document.c.NamespaceName),
          (object) new XElement(XName.Get(nameof (chart), Xceed.Document.NET.Document.c.NamespaceName), (object) new XAttribute(XName.Get("id", Xceed.Document.NET.Document.r.NamespaceName), (object) freeRelationshipId))
        }))
      })));
      paragraph1.Xml.Add((object) xelement);
    }

    internal Document(Xceed.Document.NET.Document document, XElement xml)
      : base(document, xml)
    {
      Licenser.VerifyLicense();
      Paragraph.ResetDefaultValues();
    }

    public void Dispose() => this._package.Close();
  }
}
