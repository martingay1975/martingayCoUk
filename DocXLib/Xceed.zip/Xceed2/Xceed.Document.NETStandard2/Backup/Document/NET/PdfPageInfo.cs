﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfPageInfo
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using Xceed.Pdf;

namespace Xceed.Document.NET
{
  internal class PdfPageInfo
  {
    internal Page Page { get; set; }

    internal int PageId { get; set; }

    internal int PageNumber { get; set; }

    internal float PositionY { get; set; }

    internal float HeaderHeight { get; set; }

    internal float FooterHeight { get; set; }

    internal int FirstParagraphId { get; set; }

    internal int FirstParagraphDrawnLinesCount { get; set; }

    internal int FirstParagraphDrawnRowsCount { get; set; }

    internal float FirstParagraphLastSplitRowHeight { get; set; }

    internal int FirstSectionId { get; set; }

    internal IDictionary InitialListItemsDictionary { get; set; }

    internal bool IsTemporaryPage { get; set; }

    internal List<PdfWrappedObjectInfo> WrappedObjects { get; set; }

    internal List<PdfWrappedObjectInfo> DoneWrappedObjects { get; set; }

    internal void Clear()
    {
      this.WrappedObjects.Clear();
      this.DoneWrappedObjects.Clear();
    }

    internal PdfPageInfo()
    {
      this.WrappedObjects = new List<PdfWrappedObjectInfo>();
      this.DoneWrappedObjects = new List<PdfWrappedObjectInfo>();
    }

    internal PdfPageInfo Clone()
    {
      PdfPageInfo pdfPageInfo = new PdfPageInfo();
      foreach (PropertyInfo property in pdfPageInfo.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
      {
        object obj = property.GetValue((object) this, (object[]) null);
        property.SetValue((object) pdfPageInfo, obj, (object[]) null);
      }
      return pdfPageInfo;
    }
  }
}
