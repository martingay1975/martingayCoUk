﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.TableDesign
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

namespace Xceed.Document.NET
{
  /// <summary>Value indicating the design/style to apply to a Table.</summary>
  public enum TableDesign
  {
    /// <summary>The design named in the Table's CustomTableDesignName property will be
    /// used.</summary>
    Custom,
    /// <summary>
    ///   <img border="0" alt="" src="images/TableNormal.png" />
    /// </summary>
    TableNormal,
    /// <summary>
    ///   <img border="0" alt="" src="images/TableGrid.png" />
    /// </summary>
    TableGrid,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightShading.png" />
    /// </summary>
    LightShading,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightShadingAccent1.png" />
    /// </summary>
    LightShadingAccent1,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightShadingAccent2.png" />
    /// </summary>
    LightShadingAccent2,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightShadingAccent3.png" />
    /// </summary>
    LightShadingAccent3,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightShadingAccent4.png" />
    /// </summary>
    LightShadingAccent4,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightShadingAccent5.png" />
    /// </summary>
    LightShadingAccent5,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightShadingAccent6.png" />
    /// </summary>
    LightShadingAccent6,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightList.png" />
    /// </summary>
    LightList,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightListAccent1.png" />
    /// </summary>
    LightListAccent1,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightListAccent2.png" />
    /// </summary>
    LightListAccent2,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightListAccent3.png" />
    /// </summary>
    LightListAccent3,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightListAccent4.png" />
    /// </summary>
    LightListAccent4,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightListAccent5.png" />
    /// </summary>
    LightListAccent5,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightListAccent6.png" />
    /// </summary>
    LightListAccent6,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightGrid.png" />
    /// </summary>
    LightGrid,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightGridAccent1.png" />
    /// </summary>
    LightGridAccent1,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightGridAccent2.png" />
    /// </summary>
    LightGridAccent2,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightGridAccent3.png" />
    /// </summary>
    LightGridAccent3,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightGridAccent4.png" />
    /// </summary>
    LightGridAccent4,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightGridAccent5.png" />
    /// </summary>
    LightGridAccent5,
    /// <summary>
    ///   <img border="0" alt="" src="images/LightGridAccent6.png" />
    /// </summary>
    LightGridAccent6,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumShading1.png" />
    /// </summary>
    MediumShading1,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumShading1Accent1.png" />
    /// </summary>
    MediumShading1Accent1,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumShading1Accent2.png" />
    /// </summary>
    MediumShading1Accent2,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumShading1Accent3.png" />
    /// </summary>
    MediumShading1Accent3,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumShading1Accent4.png" />
    /// </summary>
    MediumShading1Accent4,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumShading1Accent5.png" />
    /// </summary>
    MediumShading1Accent5,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumShading1Accent6.png" />
    /// </summary>
    MediumShading1Accent6,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumShading2.png" />
    /// </summary>
    MediumShading2,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumShading2Accent1.png" />
    /// </summary>
    MediumShading2Accent1,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumShading2Accent2.png" />
    /// </summary>
    MediumShading2Accent2,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumShading2Accent3.png" />
    /// </summary>
    MediumShading2Accent3,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumShading2Accent4.png" />
    /// </summary>
    MediumShading2Accent4,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumShading2Accent5.png" />
    /// </summary>
    MediumShading2Accent5,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumShading2Accent6.png" />
    /// </summary>
    MediumShading2Accent6,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumList1.png" />
    /// </summary>
    MediumList1,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumList1Accent1.png" />
    /// </summary>
    MediumList1Accent1,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumList1Accent2.png" />
    /// </summary>
    MediumList1Accent2,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumList1Accent3.png" />
    /// </summary>
    MediumList1Accent3,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumList1Accent4.png" />
    /// </summary>
    MediumList1Accent4,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumList1Accent5.png" />
    /// </summary>
    MediumList1Accent5,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumList1Accent6.png" />
    /// </summary>
    MediumList1Accent6,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumList2.png" />
    /// </summary>
    MediumList2,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumList2Accent1.png" />
    /// </summary>
    MediumList2Accent1,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumList2Accent2.png" />
    /// </summary>
    MediumList2Accent2,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumList2Accent3.png" />
    /// </summary>
    MediumList2Accent3,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumList2Accent4.png" />
    /// </summary>
    MediumList2Accent4,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumList2Accent5.png" />
    /// </summary>
    MediumList2Accent5,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumList2Accent6.png" />
    /// </summary>
    MediumList2Accent6,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid1.png" />
    /// </summary>
    MediumGrid1,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid1Accent1.png" />
    /// </summary>
    MediumGrid1Accent1,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid1Accent2.png" />
    /// </summary>
    MediumGrid1Accent2,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid1Accent3.png" />
    /// </summary>
    MediumGrid1Accent3,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid1Accent4.png" />
    /// </summary>
    MediumGrid1Accent4,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid1Accent5.png" />
    /// </summary>
    MediumGrid1Accent5,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid1Accent6.png" />
    /// </summary>
    MediumGrid1Accent6,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid2.png" />
    /// </summary>
    MediumGrid2,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid2Accent1.png" />
    /// </summary>
    MediumGrid2Accent1,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid2Accent2.png" />
    /// </summary>
    MediumGrid2Accent2,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid2Accent3.png" />
    /// </summary>
    MediumGrid2Accent3,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid2Accent4.png" />
    /// </summary>
    MediumGrid2Accent4,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid2Accent5.png" />
    /// </summary>
    MediumGrid2Accent5,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid2Accent6.png" />
    /// </summary>
    MediumGrid2Accent6,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid3.png" />
    /// </summary>
    MediumGrid3,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid3Accent1.png" />
    /// </summary>
    MediumGrid3Accent1,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid3Accent2.png" />
    /// </summary>
    MediumGrid3Accent2,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid3Accent3.png" />
    /// </summary>
    MediumGrid3Accent3,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid3Accent4.png" />
    /// </summary>
    MediumGrid3Accent4,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid3Accent5.png" />
    /// </summary>
    MediumGrid3Accent5,
    /// <summary>
    ///   <img border="0" alt="" src="images/MediumGrid3Accent6.png" />
    /// </summary>
    MediumGrid3Accent6,
    /// <summary>
    ///   <img border="0" alt="" src="images/DarkList.png" />
    /// </summary>
    DarkList,
    /// <summary>
    ///   <img border="0" alt="" src="images/DarkListAccent1.png" />
    /// </summary>
    DarkListAccent1,
    /// <summary>
    ///   <img border="0" alt="" src="images/DarkListAccent2.png" />
    /// </summary>
    DarkListAccent2,
    /// <summary>
    ///   <img border="0" alt="" src="images/DarkListAccent3.png" />
    /// </summary>
    DarkListAccent3,
    /// <summary>
    ///   <img border="0" alt="" src="images/DarkListAccent4.png" />
    /// </summary>
    DarkListAccent4,
    /// <summary>
    ///   <img border="0" alt="" src="images/DarkListAccent5.png" />
    /// </summary>
    DarkListAccent5,
    /// <summary>
    ///   <img border="0" alt="" src="images/DarkListAccent6.png" />
    /// </summary>
    DarkListAccent6,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulShading.png" />
    /// </summary>
    ColorfulShading,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulShadingAccent1.png" />
    /// </summary>
    ColorfulShadingAccent1,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulShadingAccent2.png" />
    /// </summary>
    ColorfulShadingAccent2,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulShadingAccent3.png" />
    /// </summary>
    ColorfulShadingAccent3,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulShadingAccent4.png" />
    /// </summary>
    ColorfulShadingAccent4,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulShadingAccent5.png" />
    /// </summary>
    ColorfulShadingAccent5,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulShadingAccent6.png" />
    /// </summary>
    ColorfulShadingAccent6,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulList.png" />
    /// </summary>
    ColorfulList,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulListAccent1.png" />
    /// </summary>
    ColorfulListAccent1,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulListAccent2.png" />
    /// </summary>
    ColorfulListAccent2,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulListAccent3.png" />
    /// </summary>
    ColorfulListAccent3,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulListAccent4.png" />
    /// </summary>
    ColorfulListAccent4,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulListAccent5.png" />
    /// </summary>
    ColorfulListAccent5,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulListAccent6.png" />
    /// </summary>
    ColorfulListAccent6,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulGrid.png" />
    /// </summary>
    ColorfulGrid,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulGridAccent1.png" />
    /// </summary>
    ColorfulGridAccent1,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulGridAccent2.png" />
    /// </summary>
    ColorfulGridAccent2,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulGridAccent3.png" />
    /// </summary>
    ColorfulGridAccent3,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulGridAccent4.png" />
    /// </summary>
    ColorfulGridAccent4,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulGridAccent5.png" />
    /// </summary>
    ColorfulGridAccent5,
    /// <summary>
    ///   <img border="0" alt="" src="images/ColorfulGridAccent6.png" />
    /// </summary>
    ColorfulGridAccent6,
    /// <summary>No design is applied.</summary>
    None,
  }
}
