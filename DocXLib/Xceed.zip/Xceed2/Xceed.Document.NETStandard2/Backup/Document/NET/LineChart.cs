﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.LineChart
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System.IO.Packaging;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a Line Chart.</summary>
  public class LineChart : Chart
  {
    /// <summary>Gets or sets the type of grouping used for this LineChart.</summary>
    public Grouping Grouping
    {
      get => XElementHelpers.GetValueToEnum<Grouping>(this.ChartXml.Element(XName.Get("grouping", Xceed.Document.NET.Document.c.NamespaceName)));
      set => XElementHelpers.SetValueFromEnum<Grouping>(this.ChartXml.Element(XName.Get("grouping", Xceed.Document.NET.Document.c.NamespaceName)), value);
    }

    /// <summary>Initializes a new instance of the <strong>LineChart</strong> class.</summary>
    public LineChart()
    {
    }

    internal LineChart(PackagePart packagePart, XDocument chartDocument)
      : base(packagePart, chartDocument)
    {
    }

    public override void AddSeries(Series series)
    {
      XElement xelement1 = series.Xml.Element(XName.Get("spPr", Xceed.Document.NET.Document.c.NamespaceName));
      if (xelement1 != null)
      {
        XElement xelement2 = xelement1.Elements().First<XElement>();
        XElement xelement3 = new XElement(XName.Get("spPr", Xceed.Document.NET.Document.c.NamespaceName), (object) new XElement(XName.Get("ln", Xceed.Document.NET.Document.a.NamespaceName), (object) xelement2));
        xelement1.AddAfterSelf((object) xelement3);
        xelement1.Remove();
      }
      base.AddSeries(series);
    }

    /// <summary>Creates the XML for this LineChart.</summary>
    /// <returns>The XElement representing the XML for the LineChart.</returns>
    protected override XElement CreateChartXml() => XElement.Parse("<c:lineChart xmlns:c=\"http://schemas.openxmlformats.org/drawingml/2006/chart\">\r\n                    <c:grouping val=\"standard\"/>                    \r\n                  </c:lineChart>");
  }
}
