﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.DocumentElement
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System.IO.Packaging;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents the base class for all Document Elements.</summary>
  public abstract class DocumentElement
  {
    private PackagePart _mainPart;

    /// <summary>Gets or sets the XML for this element.</summary>
    public XElement Xml { get; set; }

    /// <summary>Gets or sets the PackagePart for this element.</summary>
    public PackagePart PackagePart
    {
      get => this._mainPart;
      set => this._mainPart = value;
    }

    internal Xceed.Document.NET.Document Document { get; set; }

    public DocumentElement(Xceed.Document.NET.Document document, XElement xml)
    {
      Licenser.VerifyLicense();
      this.Document = document;
      this.Xml = xml;
    }
  }
}
