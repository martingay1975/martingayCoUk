﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfWrappedObjectInfo
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System.Drawing;

namespace Xceed.Document.NET
{
  internal class PdfWrappedObjectInfo
  {
    internal PdfWrappedObjectInfo(
      WrappedObjectType type,
      string id,
      HeaderFooterType headerFooterType,
      RectangleF dimension,
      PointF marginH,
      PointF marginV,
      WrappingType wrappingType,
      int zOrder)
    {
      this.Type = type;
      this.Id = id;
      this.HeaderFooterType = headerFooterType;
      this.Dimension = dimension;
      this.MarginH = marginH;
      this.MarginV = marginV;
      this.WrappingType = wrappingType;
      this.ZOrder = zOrder;
    }

    internal WrappedObjectType Type { get; private set; }

    internal string Id { get; private set; }

    internal HeaderFooterType HeaderFooterType { get; private set; }

    internal RectangleF Dimension { get; private set; }

    internal PointF MarginH { get; private set; }

    internal PointF MarginV { get; private set; }

    internal WrappingType WrappingType { get; private set; }

    internal int ZOrder { get; private set; }
  }
}
