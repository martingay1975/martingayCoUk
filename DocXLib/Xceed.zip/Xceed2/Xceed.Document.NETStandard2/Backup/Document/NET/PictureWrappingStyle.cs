﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PictureWrappingStyle
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

namespace Xceed.Document.NET
{
  /// <summary>Value indicating the text wrapping style around a picture.</summary>
  public enum PictureWrappingStyle
  {
    /// <summary>The picture is acting like a character in a sentence. The line height will be affected by the picture size.</summary>
    WrapInLineWithText,
    /// <summary>There will be no text on the right or left of the picture. The text will appear above and below the picture.</summary>
    WrapTopAndBottom,
    /// <summary>The picture is considered a square and the text will appear around the picture.</summary>
    WrapSquare,
    /// <summary>The text will appear around the picture and inside a square picture but will not enter the WrapPolygon defined.</summary>
    WrapTight,
    /// <summary>The text will appear around the picture and inside a square picture but will not enter the WrapPolygon defined. Depending on the WrapPolygon size, text could
    /// appear inside the middle of the picture.</summary>
    WrapThrough,
    /// <summary>The picture will be displayed behind the text.</summary>
    WrapBehindText,
    /// <summary>The picture will appear in front of the text.</summary>
    WrapInFrontOfText,
  }
}
