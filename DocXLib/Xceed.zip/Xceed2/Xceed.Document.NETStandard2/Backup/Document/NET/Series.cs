﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Series
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a Series.</summary>
  public class Series
  {
    private XElement _strCache;
    private XElement _numCache;

    /// <summary>Gets or sets the Color for this Series</summary>
    public Color Color
    {
      get
      {
        XElement xelement1 = this.Xml.Element(XName.Get("spPr", Xceed.Document.NET.Document.c.NamespaceName));
        if (xelement1 == null)
          return Color.Transparent;
        XElement xelement2 = xelement1.Descendants(XName.Get("srgbClr", Xceed.Document.NET.Document.a.NamespaceName)).FirstOrDefault<XElement>();
        if (xelement2 != null)
        {
          XAttribute xattribute = xelement2.Attribute(XName.Get("val"));
          if (xattribute != null)
            return Color.FromArgb((int) byte.MaxValue, Color.FromArgb(int.Parse(xattribute.Value, NumberStyles.HexNumber)));
        }
        return Color.Transparent;
      }
      set
      {
        this.Xml.Element(XName.Get("spPr", Xceed.Document.NET.Document.c.NamespaceName))?.Remove();
        XElement xelement1 = new XElement(XName.Get("solidFill", Xceed.Document.NET.Document.a.NamespaceName), (object) new XElement(XName.Get("srgbClr", Xceed.Document.NET.Document.a.NamespaceName), (object) new XAttribute(XName.Get("val"), (object) value.ToHex())));
        XElement xelement2 = this.Xml.Parent == null || !(this.Xml.Parent.Name != (XName) null) || !(this.Xml.Parent.Name.LocalName == "lineChart") ? new XElement(XName.Get("spPr", Xceed.Document.NET.Document.c.NamespaceName), (object) xelement1) : new XElement(XName.Get("spPr", Xceed.Document.NET.Document.c.NamespaceName), (object) new XElement(XName.Get("ln", Xceed.Document.NET.Document.a.NamespaceName), (object) xelement1));
        this.Xml.Element(XName.Get("tx", Xceed.Document.NET.Document.c.NamespaceName)).AddAfterSelf((object) xelement2);
      }
    }

    /// <summary>Gets or sets the list of numeric values (Y axis) for this Series.</summary>
    public IList Values
    {
      get
      {
        List<object> objectList = new List<object>();
        foreach (XContainer element in this._numCache.Elements(XName.Get("pt", Xceed.Document.NET.Document.c.NamespaceName)))
        {
          XElement xelement = element.Element(XName.Get("v", Xceed.Document.NET.Document.c.NamespaceName));
          if (xelement != null)
            objectList.Add((object) xelement.Value);
        }
        return (IList) objectList;
      }
      set
      {
        XElement xelement = this._numCache.Element(XName.Get("formatCode", Xceed.Document.NET.Document.c.NamespaceName));
        this._numCache.RemoveAll();
        if (value == null)
          return;
        this._numCache.Add((object) (xelement ?? new XElement(XName.Get("formatCode", Xceed.Document.NET.Document.c.NamespaceName), (object) "General")));
        this._numCache.Add((object) new XElement(XName.Get("ptCount", Xceed.Document.NET.Document.c.NamespaceName), (object) new XAttribute(XName.Get("val"), (object) value.Count)));
        int num = 0;
        foreach (object obj in (IEnumerable) value)
        {
          this._numCache.Add((object) new XElement(XName.Get("pt", Xceed.Document.NET.Document.c.NamespaceName), new object[2]
          {
            (object) new XAttribute(XName.Get("idx"), (object) num),
            (object) new XElement(XName.Get("v", Xceed.Document.NET.Document.c.NamespaceName), (object) obj.ToString())
          }));
          ++num;
        }
      }
    }

    /// <summary>Gets or sets the list of string categories (X axis) for this Series.</summary>
    public IList Categories
    {
      get
      {
        List<object> objectList = new List<object>();
        foreach (XContainer element in this._strCache.Elements(XName.Get("pt", Xceed.Document.NET.Document.c.NamespaceName)))
        {
          XElement xelement = element.Element(XName.Get("v", Xceed.Document.NET.Document.c.NamespaceName));
          if (xelement != null)
            objectList.Add((object) xelement.Value);
        }
        return (IList) objectList;
      }
      set
      {
        this._strCache.RemoveAll();
        if (value == null)
          return;
        this._strCache.Add((object) new XElement(XName.Get("ptCount", Xceed.Document.NET.Document.c.NamespaceName), (object) new XAttribute(XName.Get("val"), (object) value.Count)));
        int num = 0;
        foreach (object obj in (IEnumerable) value)
        {
          this._strCache.Add((object) new XElement(XName.Get("pt", Xceed.Document.NET.Document.c.NamespaceName), new object[2]
          {
            (object) new XAttribute(XName.Get("idx"), (object) num),
            (object) new XElement(XName.Get("v", Xceed.Document.NET.Document.c.NamespaceName), (object) obj.ToString())
          }));
          ++num;
        }
      }
    }

    internal XElement Xml { get; private set; }

    internal Series(XElement xml)
    {
      this.Xml = xml;
      XElement xelement1 = xml.Element(XName.Get("cat", Xceed.Document.NET.Document.c.NamespaceName));
      if (xelement1 != null)
      {
        this._strCache = xelement1.Descendants(XName.Get("strCache", Xceed.Document.NET.Document.c.NamespaceName)).FirstOrDefault<XElement>();
        if (this._strCache == null)
          this._strCache = xelement1.Descendants(XName.Get("strLit", Xceed.Document.NET.Document.c.NamespaceName)).FirstOrDefault<XElement>();
      }
      XElement xelement2 = xml.Element(XName.Get("val", Xceed.Document.NET.Document.c.NamespaceName));
      if (xelement2 == null)
        return;
      this._numCache = xelement2.Descendants(XName.Get("numCache", Xceed.Document.NET.Document.c.NamespaceName)).FirstOrDefault<XElement>();
      if (this._numCache != null)
        return;
      this._numCache = xelement2.Descendants(XName.Get("numLit", Xceed.Document.NET.Document.c.NamespaceName)).FirstOrDefault<XElement>();
    }

    /// <summary>Initializes a new instance of the <strong>Series</strong> class.</summary>
    /// <param name="name">The Name of the Series.</param>
    public Series(string name)
    {
      this._strCache = new XElement(XName.Get("strCache", Xceed.Document.NET.Document.c.NamespaceName));
      this._numCache = new XElement(XName.Get("numCache", Xceed.Document.NET.Document.c.NamespaceName));
      this.Xml = new XElement(XName.Get("ser", Xceed.Document.NET.Document.c.NamespaceName), new object[4]
      {
        (object) new XElement(XName.Get("tx", Xceed.Document.NET.Document.c.NamespaceName), (object) new XElement(XName.Get("strRef", Xceed.Document.NET.Document.c.NamespaceName), new object[2]
        {
          (object) new XElement(XName.Get("f", Xceed.Document.NET.Document.c.NamespaceName), (object) ""),
          (object) new XElement(XName.Get("strCache", Xceed.Document.NET.Document.c.NamespaceName), (object) new XElement(XName.Get("pt", Xceed.Document.NET.Document.c.NamespaceName), new object[2]
          {
            (object) new XAttribute(XName.Get("idx"), (object) "0"),
            (object) new XElement(XName.Get("v", Xceed.Document.NET.Document.c.NamespaceName), (object) name)
          }))
        })),
        (object) new XElement(XName.Get("invertIfNegative", Xceed.Document.NET.Document.c.NamespaceName), (object) "0"),
        (object) new XElement(XName.Get("cat", Xceed.Document.NET.Document.c.NamespaceName), (object) new XElement(XName.Get("strRef", Xceed.Document.NET.Document.c.NamespaceName), new object[2]
        {
          (object) new XElement(XName.Get("f", Xceed.Document.NET.Document.c.NamespaceName), (object) ""),
          (object) this._strCache
        })),
        (object) new XElement(XName.Get("val", Xceed.Document.NET.Document.c.NamespaceName), (object) new XElement(XName.Get("numRef", Xceed.Document.NET.Document.c.NamespaceName), new object[2]
        {
          (object) new XElement(XName.Get("f", Xceed.Document.NET.Document.c.NamespaceName), (object) ""),
          (object) this._numCache
        }))
      });
    }

    /// <summary>Binds the data for this Series, using the provided list, and the category and value property names.</summary>
    /// <param name="list">The list of categories and values.</param>
    /// <param name="categoryPropertyName">The property name for the category.</param>
    /// <param name="valuePropertyName">The property name for the value.</param>
    public void Bind(ICollection list, string categoryPropertyName, string valuePropertyName)
    {
      XElement xelement1 = new XElement(XName.Get("ptCount", Xceed.Document.NET.Document.c.NamespaceName), (object) new XAttribute(XName.Get("val"), (object) list.Count));
      XElement xelement2 = new XElement(XName.Get("formatCode", Xceed.Document.NET.Document.c.NamespaceName), (object) "General");
      this._strCache.RemoveAll();
      this._numCache.RemoveAll();
      this._strCache.Add((object) xelement1);
      this._numCache.Add((object) xelement2);
      this._numCache.Add((object) xelement1);
      int num = 0;
      foreach (object obj in (IEnumerable) list)
      {
        this._strCache.Add((object) new XElement(XName.Get("pt", Xceed.Document.NET.Document.c.NamespaceName), new object[2]
        {
          (object) new XAttribute(XName.Get("idx"), (object) num),
          (object) new XElement(XName.Get("v", Xceed.Document.NET.Document.c.NamespaceName), obj.GetType().GetProperty(categoryPropertyName).GetValue(obj, (object[]) null))
        }));
        this._numCache.Add((object) new XElement(XName.Get("pt", Xceed.Document.NET.Document.c.NamespaceName), new object[2]
        {
          (object) new XAttribute(XName.Get("idx"), (object) num),
          (object) new XElement(XName.Get("v", Xceed.Document.NET.Document.c.NamespaceName), obj.GetType().GetProperty(valuePropertyName).GetValue(obj, (object[]) null))
        }));
        ++num;
      }
    }

    /// <summary>Binds the data for this Series, using the provided lists of categories and values.</summary>
    /// <param name="categories">The list of categories.</param>
    /// <param name="values">The list of values.</param>
    public void Bind(IList categories, IList values)
    {
      if (categories.Count != values.Count)
        throw new ArgumentException("Categories count must equal to Values count");
      XElement xelement1 = new XElement(XName.Get("ptCount", Xceed.Document.NET.Document.c.NamespaceName), (object) new XAttribute(XName.Get("val"), (object) categories.Count));
      XElement xelement2 = new XElement(XName.Get("formatCode", Xceed.Document.NET.Document.c.NamespaceName), (object) "General");
      this._strCache.RemoveAll();
      this._numCache.RemoveAll();
      this._strCache.Add((object) xelement1);
      this._numCache.Add((object) xelement2);
      this._numCache.Add((object) xelement1);
      for (int index = 0; index < categories.Count; ++index)
      {
        this._strCache.Add((object) new XElement(XName.Get("pt", Xceed.Document.NET.Document.c.NamespaceName), new object[2]
        {
          (object) new XAttribute(XName.Get("idx"), (object) index),
          (object) new XElement(XName.Get("v", Xceed.Document.NET.Document.c.NamespaceName), (object) categories[index].ToString())
        }));
        this._numCache.Add((object) new XElement(XName.Get("pt", Xceed.Document.NET.Document.c.NamespaceName), new object[2]
        {
          (object) new XAttribute(XName.Get("idx"), (object) index),
          (object) new XElement(XName.Get("v", Xceed.Document.NET.Document.c.NamespaceName), (object) values[index].ToString())
        }));
      }
    }
  }
}
