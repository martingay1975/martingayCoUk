﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.List
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a List.</summary>
  public class List : InsertBeforeOrAfter
  {
    /// <summary>Gets the collection of Paragraphs in this List.</summary>
    public List<Paragraph> Items { get; private set; }

    /// <summary>Gets the NumId of this List.</summary>
    public int NumId { get; private set; }

    /// <summary>Gets the List Type of this List.</summary>
    public ListItemType? ListType { get; private set; }

    public int AbstractNumId
    {
      get
      {
        string abstractNumIdValue = HelperFunctions.GetAbstractNumIdValue(this.Document, this.NumId.ToString());
        return abstractNumIdValue == null ? 0 : int.Parse(abstractNumIdValue);
      }
    }

    internal List(Xceed.Document.NET.Document document, XElement xml)
      : base(document, xml)
    {
      this.Items = new List<Paragraph>();
      this.ListType = new ListItemType?();
    }

    /// <summary>Adds an item to this List.</summary>
    /// <param name="paragraph">The item to add to the List.</param>
    public void AddItem(Paragraph paragraph)
    {
      if (!paragraph.IsListItem)
        return;
      int numId = paragraph.GetNumId();
      if (numId == -1)
        return;
      if (!this.CanAddListItem(paragraph))
        throw new InvalidOperationException("New list items can only be added to this list if they are have the same numId.");
      this.NumId = numId;
      if (!this.ListType.HasValue)
      {
        int num;
        switch (HelperFunctions.GetListItemType(paragraph, this.Document))
        {
          case "bullet":
            num = 0;
            break;
          case null:
            goto label_9;
          default:
            num = 1;
            break;
        }
        this.ListType = new ListItemType?((ListItemType) num);
      }
label_9:
      this.Items.Add(paragraph);
    }

    /// <summary>Adds an item with a specific start value to this List.</summary>
    /// <param name="paragraph">The item to add to the List.</param>
    /// <param name="start">The start value for the new item.</param>
    public void AddItemWithStartValue(Paragraph paragraph, int start)
    {
      this.UpdateNumberingForLevelStartNumber(int.Parse(paragraph.IndentLevel.ToString()), start);
      if (this.ContainsLevel(start))
        throw new InvalidOperationException("Cannot add a paragraph with a start value if another element already exists in this list with that level.");
      this.AddItem(paragraph);
    }

    /// <summary>Determines if the provided item can be added to this List.</summary>
    /// <returns>
    /// <strong>true</strong> if the AddItem() method will succeed with the provided item, otherwise <strong>false</strong>.</returns>
    /// <param name="paragraph">The item to validate.</param>
    public bool CanAddListItem(Paragraph paragraph)
    {
      if (!paragraph.IsListItem)
        return false;
      int numId = paragraph.GetNumId();
      return numId != -1 && (this.NumId == 0 || numId == this.NumId && numId > 0);
    }

    /// <summary>Determines if the provided level exists in this List.</summary>
    /// <returns>
    /// <strong>true</strong> if the level exists, otherwise <strong>false</strong>.</returns>
    /// <param name="ilvl">The level to validate.</param>
    public bool ContainsLevel(int ilvl) => this.Items.Any<Paragraph>((Func<Paragraph, bool>) (i => i.ParagraphNumberProperties.Descendants().First<XElement>((Func<XElement, bool>) (el => el.Name.LocalName == nameof (ilvl))).Value == ilvl.ToString()));

    internal void CreateNewNumberingNumId(
      int level = 0,
      ListItemType listType = ListItemType.Numbered,
      int? startNumber = null,
      bool continueNumbering = false)
    {
      this.ValidateDocXNumberingPartExists();
      if (this.Document._numbering.Root == null)
        throw new InvalidOperationException("Numbering section did not instantiate properly.");
      this.ListType = new ListItemType?(listType);
      int numId = this.GetMaxNumId() + 1;
      int abstractNumId = this.GetMaxAbstractNumId() + 1;
      XDocument xdocument;
      if (listType != ListItemType.Bulleted)
      {
        if (listType != ListItemType.Numbered)
          throw new InvalidOperationException(string.Format("Unable to deal with ListItemType: {0}.", (object) listType.ToString()));
        xdocument = HelperFunctions.DecompressXMLResource(HelperFunctions.GetResources(ResourceType.NumberingDecimal));
      }
      else
        xdocument = HelperFunctions.DecompressXMLResource(HelperFunctions.GetResources(ResourceType.NumberingBullet));
      XElement xelement1 = xdocument.Descendants().Single<XElement>((Func<XElement, bool>) (d => d.Name.LocalName == "abstractNum"));
      xelement1.SetAttributeValue(Xceed.Document.NET.Document.w + "abstractNumId", (object) abstractNumId);
      XElement abstractNumXml = this.GetAbstractNumXml(abstractNumId, numId, startNumber, level, continueNumbering);
      XElement xelement2 = this.Document._numbering.Root.Descendants().LastOrDefault<XElement>((Func<XElement, bool>) (xElement => xElement.Name.LocalName == "abstractNum"));
      XElement xelement3 = this.Document._numbering.Root.Descendants().LastOrDefault<XElement>((Func<XElement, bool>) (xElement => xElement.Name.LocalName == "num"));
      if (xelement2 == null || xelement3 == null)
      {
        this.Document._numbering.Root.Add((object) xelement1);
        this.Document._numbering.Root.Add((object) abstractNumXml);
      }
      else
      {
        xelement2.AddAfterSelf((object) xelement1);
        xelement3.AddAfterSelf((object) abstractNumXml);
      }
      this.NumId = numId;
    }

    internal void CreateNewNumberingNumIdFromNumId(
      int baseNumId = 0,
      int level = 0,
      ListItemType listType = ListItemType.Numbered,
      int? startNumber = null,
      bool continueNumbering = false)
    {
      this.ValidateDocXNumberingPartExists();
      if (this.Document._numbering.Root == null)
        throw new InvalidOperationException("Numbering section did not instantiate properly.");
      this.ListType = new ListItemType?(listType);
      int numId = this.GetMaxNumId() + 1;
      XElement abstractNumXml = this.GetAbstractNumXml(int.Parse(HelperFunctions.GetAbstractNumIdValue(this.Document, baseNumId.ToString()) ?? "0"), numId, startNumber, level, continueNumbering);
      XElement xelement = this.Document._numbering.Root.Descendants().LastOrDefault<XElement>((Func<XElement, bool>) (xElement => xElement.Name.LocalName == "num"));
      if (xelement == null)
        this.Document._numbering.Root.Add((object) abstractNumXml);
      else
        xelement.AddAfterSelf((object) abstractNumXml);
      this.NumId = numId;
    }

    internal XElement GetAbstractNum(int numId) => HelperFunctions.GetAbstractNum(this.Document, numId.ToString());

    private void UpdateNumberingForLevelStartNumber(int iLevel, int start)
    {
      XElement xelement1 = this.Document._numbering.Descendants().Where<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "num")).FirstOrDefault<XElement>((Func<XElement, bool>) (node => node.Attribute(Xceed.Document.NET.Document.w + "numId").Value.Equals(this.NumId.ToString())));
      if (xelement1 == null)
        return;
      bool flag = false;
      IEnumerable<XElement> source = xelement1.Elements(XName.Get("lvlOverride", Xceed.Document.NET.Document.w.NamespaceName));
      if (source.Count<XElement>() > 0)
      {
        foreach (XElement el in source)
        {
          string attribute = el.GetAttribute(XName.Get("ilvl", Xceed.Document.NET.Document.w.NamespaceName));
          if (!string.IsNullOrEmpty(attribute) && attribute == iLevel.ToString())
          {
            XElement xelement2 = el.Element(XName.Get("startOverride", Xceed.Document.NET.Document.w.NamespaceName));
            if (xelement2 != null)
              xelement2.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) start);
            else
              el.Add((object) new XElement(XName.Get("startOverride", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) start)));
            flag = true;
            break;
          }
        }
      }
      if (flag)
        return;
      XElement xelement3 = new XElement(XName.Get("startOverride", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) start));
      XElement xelement4 = new XElement(XName.Get("lvlOverride", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
      {
        (object) new XAttribute(Xceed.Document.NET.Document.w + "ilvl", (object) iLevel),
        (object) xelement3
      });
      xelement1.Add((object) xelement4);
    }

    private XElement GetAbstractNumXml(
      int abstractNumId,
      int numId,
      int? startNumber,
      int level,
      bool continueNumbering)
    {
      XElement xelement1 = new XElement(XName.Get("startOverride", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) (startNumber ?? 1)));
      XElement xelement2 = new XElement(XName.Get("lvlOverride", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
      {
        (object) new XAttribute(Xceed.Document.NET.Document.w + "ilvl", (object) level),
        (object) xelement1
      });
      XElement xelement3 = new XElement(XName.Get(nameof (abstractNumId), Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) abstractNumId));
      return !continueNumbering ? new XElement(XName.Get("num", Xceed.Document.NET.Document.w.NamespaceName), new object[3]
      {
        (object) new XAttribute(Xceed.Document.NET.Document.w + nameof (numId), (object) numId),
        (object) xelement3,
        (object) xelement2
      }) : new XElement(XName.Get("num", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
      {
        (object) new XAttribute(Xceed.Document.NET.Document.w + nameof (numId), (object) numId),
        (object) xelement3
      });
    }

    private int GetMaxNumId()
    {
      if (this.Document._numbering == null)
        return 0;
      List<XElement> list = this.Document._numbering.Descendants().Where<XElement>((Func<XElement, bool>) (d => d.Name.LocalName == "num")).ToList<XElement>();
      return list.Any<XElement>() ? list.Attributes(Xceed.Document.NET.Document.w + "numId").Max<XAttribute>((Func<XAttribute, int>) (e => int.Parse(e.Value))) : 0;
    }

    private int GetMaxAbstractNumId()
    {
      if (this.Document._numbering == null)
        return -1;
      List<XElement> list = this.Document._numbering.Descendants().Where<XElement>((Func<XElement, bool>) (d => d.Name.LocalName == "abstractNum")).ToList<XElement>();
      return list.Any<XElement>() ? list.Attributes(Xceed.Document.NET.Document.w + "abstractNumId").Max<XAttribute>((Func<XAttribute, int>) (e => int.Parse(e.Value))) : -1;
    }

    private void ValidateDocXNumberingPartExists()
    {
      Uri uri = new Uri("/word/numbering.xml", UriKind.Relative);
      if (this.Document._package.PartExists(uri))
        return;
      this.Document._numbering = HelperFunctions.AddDefaultNumberingXml(this.Document._package);
      this.Document._numberingPart = this.Document._package.GetPart(uri);
    }
  }
}
