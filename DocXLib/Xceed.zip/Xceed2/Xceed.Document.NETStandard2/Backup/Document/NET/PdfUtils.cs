﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfUtils
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Drawing;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  internal static class PdfUtils
  {
    internal static bool IsWrappingInLineWithText(DocumentElement element)
    {
      if (element == null)
        throw new ArgumentNullException(nameof (element));
      return PdfUtils.GetWrapping(element) == WrappingType.WrapInLineWithText;
    }

    internal static WrappingType GetWrapping(DocumentElement element)
    {
      if (element == null)
        throw new ArgumentNullException(nameof (element));
      if (element.Xml.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (s => s.Name.LocalName == "wrapTopAndBottom")) != null)
        return WrappingType.WrapTopAndBottom;
      if (element.Xml.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (s => s.Name.LocalName == "wrapSquare")) != null)
        return WrappingType.WrapSquare;
      if (element.Xml.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (s => s.Name.LocalName == "wrapTight")) != null)
        return WrappingType.WrapTight;
      if (element.Xml.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (s => s.Name.LocalName == "wrapThrough")) != null)
        return WrappingType.WrapThrough;
      XElement xelement = element.Xml.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Name.LocalName == "anchor"));
      if (xelement != null)
      {
        XAttribute xattribute = xelement.Attribute(XName.Get("behindDoc"));
        if (xattribute != null)
          return xattribute.Value == "1" ? WrappingType.WrapBehindText : WrappingType.WrapInFrontOfText;
      }
      return WrappingType.WrapInLineWithText;
    }

    internal static bool IsWrappingAround(DocumentElement element)
    {
      if (element == null)
        throw new ArgumentNullException(nameof (element));
      return PdfUtils.IsWrappingSquare(element) || PdfUtils.IsWrappingTopBottom(element) || (PdfUtils.IsWrappingTight(element) || PdfUtils.IsWrappingThrough(element)) || PdfUtils.IsWrappingBehindText(element) || PdfUtils.IsWrappingInFrontOfText(element);
    }

    internal static bool IsWrappingSquare(DocumentElement element)
    {
      if (element == null)
        throw new ArgumentNullException(nameof (element));
      return PdfUtils.GetWrapping(element) == WrappingType.WrapSquare;
    }

    internal static bool IsWrappingTopBottom(DocumentElement element)
    {
      if (element == null)
        throw new ArgumentNullException(nameof (element));
      return PdfUtils.GetWrapping(element) == WrappingType.WrapTopAndBottom;
    }

    internal static bool IsWrappingTight(DocumentElement element)
    {
      if (element == null)
        throw new ArgumentNullException(nameof (element));
      return PdfUtils.GetWrapping(element) == WrappingType.WrapTight;
    }

    internal static bool IsWrappingThrough(DocumentElement element)
    {
      if (element == null)
        throw new ArgumentNullException(nameof (element));
      return PdfUtils.GetWrapping(element) == WrappingType.WrapThrough;
    }

    internal static bool IsWrappingBehindText(DocumentElement element)
    {
      if (element == null)
        throw new ArgumentNullException(nameof (element));
      return PdfUtils.GetWrapping(element) == WrappingType.WrapBehindText;
    }

    internal static bool IsWrappingInFrontOfText(DocumentElement element)
    {
      if (element == null)
        throw new ArgumentNullException(nameof (element));
      return PdfUtils.GetWrapping(element) == WrappingType.WrapInFrontOfText;
    }

    internal static int GetZOrder(DocumentElement element)
    {
      if (element == null)
        throw new ArgumentNullException(nameof (element));
      XElement xelement = element.Xml.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Name.LocalName == "anchor"));
      if (xelement != null)
      {
        XAttribute xattribute1 = xelement.Attribute(XName.Get("behindDoc"));
        if (xattribute1 != null)
        {
          XAttribute xattribute2 = xelement.Attribute(XName.Get("relativeHeight"));
          if (xattribute2 != null)
          {
            int int32 = Convert.ToInt32(xattribute2.Value);
            return xattribute1.Value == "0" ? int32 : int.MinValue + int32;
          }
        }
      }
      return 0;
    }

    internal static float GetPositionX(
      Section currentSection,
      PdfPageInfo currentPdfPageInfo,
      DocumentElement element)
    {
      if (currentSection == null)
        throw new ArgumentNullException(nameof (currentSection));
      if (currentPdfPageInfo == null)
        throw new ArgumentNullException(nameof (currentPdfPageInfo));
      double num1;
      switch (element)
      {
        case null:
          throw new ArgumentNullException(nameof (element));
        case Picture _:
          num1 = (double) ((Picture) element).Width;
          break;
        case Shape _:
          num1 = (double) PdfShape.GetActualWidth((Shape) element, element.Document, currentPdfPageInfo.Page.Graphics, currentSection, currentPdfPageInfo.PageNumber);
          break;
        default:
          num1 = 0.0;
          break;
      }
      float num2 = (float) num1;
      XElement xelement1 = element.Xml.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (s => s.Name.LocalName == "positionH"));
      if (xelement1 != null)
      {
        string attribute = xelement1.GetAttribute(XName.Get("relativeFrom"));
        switch (PdfUtils.GetAlignment(xelement1))
        {
          case "left":
            if (string.IsNullOrEmpty(attribute))
              throw new InvalidOperationException("No relativeFrom defined for left alignment.");
            float val1_1 = currentSection.PageWidth - num2;
            switch (attribute)
            {
              case "column":
              case "margin":
                return currentSection.MarginLeft;
              case "insideMargin":
              case "leftMargin":
              case "page":
                return 0.0f;
              case "outsideMargin":
              case "rightMargin":
                return Math.Min(val1_1, currentSection.PageWidth - currentSection.MarginRight);
              default:
                throw new InvalidOperationException("Unknown relativeFrom value for positionH.");
            }
          case "center":
            if (string.IsNullOrEmpty(attribute))
              throw new InvalidOperationException("No relativeFrom defined for center alignment.");
            switch (attribute)
            {
              case "column":
              case "margin":
                return (float) ((double) currentSection.MarginLeft + ((double) currentSection.PageWidth - (double) currentSection.MarginLeft - (double) currentSection.MarginRight) / 2.0 - (double) num2 / 2.0);
              case "insideMargin":
              case "leftMargin":
                return Math.Max(0.0f, (float) ((double) currentSection.MarginLeft / 2.0 - (double) num2 / 2.0));
              case "outsideMargin":
              case "rightMargin":
                return Math.Min(currentSection.PageWidth - num2, (float) ((double) currentSection.PageWidth - (double) currentSection.MarginRight / 2.0 - (double) num2 / 2.0));
              case "page":
                return (float) ((double) currentSection.PageWidth / 2.0 - (double) num2 / 2.0);
              default:
                throw new InvalidOperationException("Unknown relativeFrom value for positionH.");
            }
          case "right":
            if (string.IsNullOrEmpty(attribute))
              throw new InvalidOperationException("No relativeFrom defined for right alignment.");
            switch (attribute)
            {
              case "column":
              case "margin":
                return currentSection.PageWidth - currentSection.MarginRight - num2;
              case "insideMargin":
              case "leftMargin":
                return Math.Max(0.0f, currentSection.MarginLeft - num2);
              case "outsideMargin":
              case "page":
              case "rightMargin":
                return currentSection.PageWidth - num2;
              default:
                throw new InvalidOperationException("Unknown relativeFrom value for positionH.");
            }
          case "inside":
            if (!string.IsNullOrEmpty(attribute))
            {
              if (attribute != null)
              {
                if (attribute == "margin")
                  return currentSection.MarginLeft;
                if (attribute == "page")
                  return 0.0f;
              }
              throw new InvalidOperationException("Unknown relativeFrom value for positionH.");
            }
            throw new InvalidOperationException("No relativeFrom defined for inside alignement.");
          case "outside":
            if (!string.IsNullOrEmpty(attribute))
            {
              if (attribute != null)
              {
                if (attribute == "margin")
                  return currentSection.PageWidth - currentSection.MarginRight - num2;
                if (attribute == "page")
                  return currentSection.PageWidth - num2;
              }
              throw new InvalidOperationException("Unknown relativeFrom value for positionH.");
            }
            throw new InvalidOperationException("No relativeFrom defined for outside alignment.");
          default:
            XElement xelement2 = xelement1.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (s => s.Name.LocalName == "posOffset"));
            if (xelement2 != null)
            {
              if (string.IsNullOrEmpty(attribute))
                throw new InvalidOperationException("No relativeFrom defined for posOffset.");
              float val2 = Convert.ToSingle(xelement2.Value) / Convert.ToSingle(12700);
              float val1_2 = currentSection.PageWidth - num2;
              switch (attribute)
              {
                case "column":
                case "margin":
                  return Math.Max(0.0f, Math.Min(val1_2, currentSection.MarginLeft + val2));
                case "insideMargin":
                case "leftMargin":
                case "page":
                  return Math.Max(0.0f, Math.Min(val1_2, val2));
                case "outsideMargin":
                case "rightMargin":
                  return Math.Max(0.0f, Math.Min(val1_2, currentSection.PageWidth - currentSection.MarginRight + val2));
                default:
                  throw new InvalidOperationException("Unknown relativeFrom value for positionH.");
              }
            }
            else
            {
              XElement xelement3 = xelement1.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (s => s.Name.LocalName == "pctPosHOffset"));
              if (xelement3 != null)
              {
                if (!string.IsNullOrEmpty(attribute))
                {
                  float num3 = Convert.ToSingle(xelement3.Value) / 100000f;
                  float val1_2 = currentSection.PageWidth - num2;
                  if (attribute != null)
                  {
                    if (!(attribute == "margin"))
                    {
                      if (!(attribute == "page"))
                      {
                        if (!(attribute == "leftMargin") && !(attribute == "insideMargin"))
                        {
                          if (attribute == "rightMargin" || attribute == "outsideMargin")
                          {
                            float num4 = num3 * currentSection.MarginRight;
                            return Math.Max(0.0f, Math.Min(val1_2, currentSection.PageWidth - currentSection.MarginRight + num4));
                          }
                        }
                        else
                        {
                          float val2 = num3 * currentSection.MarginLeft;
                          return Math.Max(0.0f, Math.Min(val1_2, val2));
                        }
                      }
                      else
                      {
                        float val2 = num3 * currentSection.PageWidth;
                        return Math.Max(0.0f, Math.Min(val1_2, val2));
                      }
                    }
                    else
                    {
                      float num4 = currentSection.PageWidth - currentSection.MarginLeft - currentSection.MarginRight;
                      float num5 = num3 * num4;
                      return Math.Max(0.0f, Math.Min(val1_2, currentSection.MarginLeft + num5));
                    }
                  }
                  throw new InvalidOperationException("Unknown relativeFrom value for positionH.");
                }
                throw new InvalidOperationException("No relativeFrom defined for pctPosHOffset.");
              }
              break;
            }
        }
      }
      return 0.0f;
    }

    internal static float GetPositionY(
      Section currentSection,
      PdfPageInfo currentPdfPageInfo,
      DocumentElement element)
    {
      if (currentSection == null)
        throw new ArgumentNullException(nameof (currentSection));
      if (currentPdfPageInfo == null)
        throw new ArgumentNullException(nameof (currentPdfPageInfo));
      double num1;
      switch (element)
      {
        case null:
          throw new ArgumentNullException(nameof (element));
        case Picture _:
          num1 = (double) ((Picture) element).Height;
          break;
        case Shape _:
          num1 = (double) PdfShape.GetActualHeight((Shape) element, element.Document, currentPdfPageInfo.Page.Graphics, currentSection, currentPdfPageInfo.PageNumber);
          break;
        default:
          num1 = 0.0;
          break;
      }
      float num2 = (float) num1;
      XElement xelement1 = element.Xml.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (s => s.Name.LocalName == "positionV"));
      if (xelement1 != null)
      {
        string attribute = xelement1.GetAttribute(XName.Get("relativeFrom"));
        switch (PdfUtils.GetAlignment(xelement1))
        {
          case "top":
            if (string.IsNullOrEmpty(attribute))
              throw new InvalidOperationException("No relativeFrom defined for top alignment.");
            switch (attribute)
            {
              case "bottomMargin":
              case "outsideMargin":
                return currentSection.PageHeight - currentSection.MarginBottom;
              case "insideMargin":
              case "page":
              case "topMargin":
                return 0.0f;
              case "line":
              case "margin":
                return currentSection.MarginTop;
              default:
                throw new InvalidOperationException("Unknown relativeFrom value for positionV.");
            }
          case "center":
            if (!string.IsNullOrEmpty(attribute))
            {
              if (attribute != null)
              {
                if (attribute == "margin")
                  return (float) ((double) currentSection.MarginTop + ((double) currentSection.PageHeight - (double) currentSection.MarginBottom - (double) currentSection.MarginTop) / 2.0 - (double) num2 / 2.0);
                if (attribute == "page")
                  return (float) ((double) currentSection.PageHeight / 2.0 - (double) num2 / 2.0);
                if (attribute == "topMargin" || attribute == "insideMargin")
                  return Math.Max(0.0f, (float) ((double) currentSection.MarginTop / 2.0 - (double) num2 / 2.0));
                if (attribute == "bottomMargin" || attribute == "outsideMargin")
                  return Math.Min(currentSection.PageHeight - num2, (float) ((double) currentSection.PageHeight - (double) currentSection.MarginBottom / 2.0 - (double) num2 / 2.0));
              }
              throw new InvalidOperationException("Unknown relativeFrom value for positionV.");
            }
            throw new InvalidOperationException("No relativeFrom defined for center alignment.");
          case "bottom":
            if (!string.IsNullOrEmpty(attribute))
            {
              if (attribute != null)
              {
                if (attribute == "margin")
                  return currentSection.PageHeight - currentSection.MarginBottom - num2;
                if (attribute == "page" || attribute == "bottomMargin" || attribute == "outsideMargin")
                  return currentSection.PageHeight - num2;
                if (attribute == "topMargin" || attribute == "insideMargin")
                  return Math.Max(0.0f, currentSection.MarginTop - num2);
              }
              throw new InvalidOperationException("Unknown relativeFrom value for positionV.");
            }
            throw new InvalidOperationException("No relativeFrom defined for bottom alignment.");
          case "inside":
            if (!string.IsNullOrEmpty(attribute))
            {
              if (attribute != null)
              {
                if (attribute == "margin")
                  return currentSection.MarginTop;
                if (attribute == "page" || attribute == "topMargin" || attribute == "insideMargin")
                  return 0.0f;
                if (attribute == "bottomMargin" || attribute == "outsideMargin")
                  return currentSection.PageHeight - currentSection.MarginBottom;
              }
              throw new InvalidOperationException("Unknown relativeFrom value for positionV.");
            }
            throw new InvalidOperationException("No relativeFrom defined for inside alignment.");
          case "outside":
            if (!string.IsNullOrEmpty(attribute))
            {
              if (attribute != null)
              {
                if (attribute == "margin")
                  return currentSection.PageHeight - currentSection.MarginBottom - num2;
                if (attribute == "page" || attribute == "bottomMargin" || attribute == "outsideMargin")
                  return currentSection.PageHeight - num2;
                if (attribute == "topMargin" || attribute == "insideMargin")
                  return currentSection.MarginTop - num2;
              }
              throw new InvalidOperationException("Unknown relativeFrom value for positionV.");
            }
            throw new InvalidOperationException("No relativeFrom defined for outside alignment.");
          default:
            XElement xelement2 = xelement1.Element(XName.Get("posOffset", Xceed.Document.NET.Document.wp.NamespaceName));
            if (xelement2 != null)
            {
              if (string.IsNullOrEmpty(attribute))
                throw new InvalidOperationException("No relativeFrom defined for posOffset.");
              float val2 = Convert.ToSingle(xelement2.Value) / Convert.ToSingle(12700);
              float val1 = currentSection.PageHeight - num2;
              switch (attribute)
              {
                case "bottomMargin":
                case "outsideMargin":
                  return Math.Max(0.0f, Math.Min(val1, currentSection.PageHeight - currentSection.MarginBottom + val2));
                case "insideMargin":
                case "page":
                case "topMargin":
                  return Math.Max(0.0f, Math.Min(val1, val2));
                case "margin":
                  return Math.Max(0.0f, Math.Min(val1, currentSection.MarginTop + val2));
                case "paragraph":
                  return Math.Max(0.0f, Math.Min(val1, currentPdfPageInfo.PositionY + val2));
                default:
                  throw new InvalidOperationException("Unknown relativeFrom value for positionV.");
              }
            }
            else
            {
              XElement xelement3 = xelement1.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (s => s.Name.LocalName == "pctPosVOffset"));
              if (xelement3 != null)
              {
                if (!string.IsNullOrEmpty(attribute))
                {
                  float num3 = Convert.ToSingle(xelement3.Value) / 100000f;
                  float val1 = currentSection.PageHeight - num2;
                  if (attribute != null)
                  {
                    if (!(attribute == "margin"))
                    {
                      if (!(attribute == "page"))
                      {
                        if (!(attribute == "topMargin") && !(attribute == "insideMargin"))
                        {
                          if (attribute == "bottomMargin" || attribute == "outsideMargin")
                          {
                            float num4 = num3 * currentSection.MarginBottom;
                            return Math.Max(0.0f, Math.Min(val1, currentSection.PageHeight - currentSection.MarginBottom + num4));
                          }
                        }
                        else
                        {
                          float val2 = num3 * currentSection.MarginTop;
                          return Math.Max(0.0f, Math.Min(val1, val2));
                        }
                      }
                      else
                      {
                        float val2 = num3 * currentSection.PageHeight;
                        return Math.Max(0.0f, Math.Min(val1, val2));
                      }
                    }
                    else
                    {
                      float num4 = currentSection.PageHeight - currentSection.MarginBottom - currentSection.MarginTop;
                      float num5 = num3 * num4;
                      return Math.Max(0.0f, Math.Min(val1, currentSection.MarginTop + num5));
                    }
                  }
                  throw new InvalidOperationException("Unknown relativeFrom value for positionH.");
                }
                throw new InvalidOperationException("No relativeFrom defined for pctPosVOffset.");
              }
              break;
            }
        }
      }
      return 0.0f;
    }

    internal static PointF GetHorizontalMargins(DocumentElement element)
    {
      if (element == null)
        throw new ArgumentNullException(nameof (element));
      PointF pointF = new PointF();
      XElement xelement = element.Xml.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Name.LocalName == "anchor"));
      if (xelement != null)
      {
        XAttribute xattribute1 = xelement.Attribute(XName.Get("distL"));
        if (xattribute1 != null)
          pointF.X = Convert.ToSingle(xattribute1.Value) / Convert.ToSingle(12700);
        XAttribute xattribute2 = xelement.Attribute(XName.Get("distR"));
        if (xattribute2 != null)
          pointF.Y = Convert.ToSingle(xattribute2.Value) / Convert.ToSingle(12700);
      }
      return pointF;
    }

    internal static PointF GetVerticalMargins(DocumentElement element)
    {
      if (element == null)
        throw new ArgumentNullException(nameof (element));
      PointF pointF = new PointF();
      XElement xelement = element.Xml.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Name.LocalName == "anchor"));
      if (xelement != null)
      {
        XAttribute xattribute1 = xelement.Attribute(XName.Get("distT"));
        if (xattribute1 != null)
          pointF.X = Convert.ToSingle(xattribute1.Value) / Convert.ToSingle(12700);
        XAttribute xattribute2 = xelement.Attribute(XName.Get("distB"));
        if (xattribute2 != null)
          pointF.Y = Convert.ToSingle(xattribute2.Value) / Convert.ToSingle(12700);
      }
      return pointF;
    }

    internal static bool IsRelativeFromPageInY(DocumentElement element)
    {
      if (element == null)
        throw new ArgumentNullException(nameof (element));
      XElement el = element.Xml.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (s => s.Name.LocalName == "positionV"));
      return el != null && el.GetAttribute(XName.Get("relativeFrom")) == "page";
    }

    private static string GetAlignment(XElement pos)
    {
      if (pos == null)
        throw new NullReferenceException(nameof (pos));
      XElement xelement = pos.Element(XName.Get("align", Xceed.Document.NET.Document.wp.NamespaceName));
      return xelement != null ? xelement.Value : string.Empty;
    }
  }
}
