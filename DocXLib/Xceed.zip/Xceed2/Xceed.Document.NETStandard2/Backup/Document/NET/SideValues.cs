﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.SideValues
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

namespace Xceed.Document.NET
{
  /// <summary>Represents a group of 4 values, one for each side.</summary>
  public class SideValues
  {
    /// <summary>Gets or sets the left value.</summary>
    public float Left { get; set; }

    /// <summary>Gets or sets the top value.</summary>
    public float Top { get; set; }

    /// <summary>Gets or sets the right value.</summary>
    public float Right { get; set; }

    /// <summary>Gets or sets the bottom value.</summary>
    public float Bottom { get; set; }
  }
}
