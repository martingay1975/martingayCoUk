﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Text
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  internal class Text : DocumentElement
  {
    private int startIndex;
    private int endIndex;
    private string text;

    public int StartIndex => this.startIndex;

    public int EndIndex => this.endIndex;

    public string Value => this.text;

    internal Text(Xceed.Document.NET.Document document, XElement xml, int startIndex)
      : base(document, xml)
    {
      this.startIndex = startIndex;
      switch (this.Xml.Name.LocalName)
      {
        case "t":
        case "delText":
          this.endIndex = startIndex + xml.Value.Length;
          this.text = xml.Value;
          break;
        case "br":
          if (!HelperFunctions.IsLineBreak(this.Xml))
            break;
          this.text = "\n";
          this.endIndex = startIndex + 1;
          break;
        case "tab":
          this.text = "\t";
          this.endIndex = startIndex + 1;
          break;
      }
    }

    public static void PreserveSpace(XElement e)
    {
      if (!e.Name.Equals((object) (Xceed.Document.NET.Document.w + "t")) && !e.Name.Equals((object) (Xceed.Document.NET.Document.w + "delText")))
        throw new ArgumentException("SplitText can only split elements of type t or delText", nameof (e));
      XAttribute xattribute = e.Attributes().Where<XAttribute>((Func<XAttribute, bool>) (a => a.Name.Equals((object) (XNamespace.Xml + "space")))).SingleOrDefault<XAttribute>();
      if (e.Value.StartsWith(" ") || e.Value.EndsWith(" "))
      {
        if (xattribute != null)
          return;
        e.Add((object) new XAttribute(XNamespace.Xml + "space", (object) "preserve"));
      }
      else
        xattribute?.Remove();
    }

    internal static XElement[] SplitText(Text t, int index)
    {
      if (index < t.startIndex || index > t.EndIndex)
        throw new ArgumentOutOfRangeException(nameof (index));
      XElement e1 = (XElement) null;
      XElement e2 = (XElement) null;
      if (t.Xml.Name.LocalName == nameof (t) || t.Xml.Name.LocalName == "delText")
      {
        e1 = new XElement(t.Xml.Name, new object[2]
        {
          (object) t.Xml.Attributes(),
          (object) t.Xml.Value.Substring(0, index - t.startIndex)
        });
        if (e1.Value.Length == 0)
          e1 = (XElement) null;
        else
          Text.PreserveSpace(e1);
        e2 = new XElement(t.Xml.Name, new object[2]
        {
          (object) t.Xml.Attributes(),
          (object) t.Xml.Value.Substring(index - t.startIndex, t.Xml.Value.Length - (index - t.startIndex))
        });
        if (e2.Value.Length == 0)
          e2 = (XElement) null;
        else
          Text.PreserveSpace(e2);
      }
      else if (index == t.EndIndex)
        e1 = t.Xml;
      else
        e2 = t.Xml;
      return new XElement[2]{ e1, e2 };
    }
  }
}
