﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfChart
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  internal class PdfChart : PdfParagraphPart
  {
    internal PdfChart(PdfParagraph p)
      : base(p)
    {
    }

    internal override void UpdateText(Xceed.Pdf.Layout.Text.Text text, bool isMeasuring = false)
    {
      XElement xelement = this._pdfParagraph.GetOriginalParagraph()._runs.Descendants<XElement>().FirstOrDefault<XElement>((Func<XElement, bool>) (el => el.Name.LocalName == "chart"));
      if (xelement == null)
        return;
      string str = xelement.Attribute(Xceed.Document.NET.Document.r + "id").Value;
      if (str == null)
        return;
      Xceed.Document.NET.Document fileToConvert = this._pdfParagraph.GetFileToConvert();
      Uri targetUri = fileToConvert.PackagePart.GetRelationship(str).get_TargetUri();
      using (TextReader textReader = (TextReader) new StreamReader((Stream) new PackagePartStream(fileToConvert._package.GetPart(PackUriHelper.ResolvePartUri(fileToConvert.PackagePart.get_Uri(), targetUri)).GetStream(FileMode.Open, FileAccess.Read))))
        XDocument.Load(textReader).Root.Elements(XName.Get("chart", Xceed.Document.NET.Document.c.NamespaceName)).FirstOrDefault<XElement>();
    }
  }
}
