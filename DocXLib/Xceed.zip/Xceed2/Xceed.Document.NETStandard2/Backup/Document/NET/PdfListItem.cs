﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfListItem
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Xml.Linq;
using Xceed.Pdf;
using Xceed.Pdf.Layout;
using Xceed.Pdf.Layout.Text.Atoms;

namespace Xceed.Document.NET
{
  internal class PdfListItem : PdfParagraphPart
  {
    private static PdfListsInfo _listsInfo;
    private static List<List> _fileToConvertLists;
    private Style _style;

    internal PdfListItem(PdfParagraph p, Style style)
      : base(p)
      => this._style = style;

    internal override void UpdateText(Xceed.Pdf.Layout.Text.Text text, bool isMeasuring = false)
    {
      if (PdfListItem._fileToConvertLists == null)
        PdfListItem._fileToConvertLists = this._pdfParagraph.GetFileToConvert().Lists;
      List list = PdfListItem._fileToConvertLists.FirstOrDefault<List>((Func<List, bool>) (l => l.Items.FirstOrDefault<Paragraph>((Func<Paragraph, bool>) (i => XNode.DeepEquals((XNode) i.Xml, (XNode) this._pdfParagraph.GetXml()))) != null));
      if (list == null || list.NumId == 0)
        return;
      if (PdfListItem._listsInfo == null)
        PdfListItem._listsInfo = new PdfListsInfo(list, this._pdfParagraph.GetLevel());
      else if (!PdfListItem._listsInfo.IsListAndLevelDefined(list.AbstractNumId, this._pdfParagraph.GetLevel()))
        PdfListItem._listsInfo.AddListData(list, this._pdfParagraph.GetLevel());
      this.InsertListItemNumber(text, list);
      this.SetAlignment(list, this._pdfParagraph.GetLevel());
    }

    internal static PdfListsInfo GetListsInfo() => PdfListItem._listsInfo;

    internal static void CleanListsInfo()
    {
      PdfListItem._listsInfo = (PdfListsInfo) null;
      PdfListItem._fileToConvertLists = (List<List>) null;
    }

    internal static string GetListItemNumberFromParagraph(
      Paragraph headingParagraph,
      Xceed.Document.NET.Document document)
    {
      if (headingParagraph == null || document == null)
        return (string) null;
      PdfParagraph p = new PdfParagraph(headingParagraph, (Paragraph) null, (Paragraph) null, 0, 0, (Graphics) null, document, document.Sections[0]);
      XElement rPr = headingParagraph.GetOrCreate_pPr().Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
      PdfListItem pdfListItem = new PdfListItem(p, p.GetLayoutStyle(new FormattedText()
      {
        formatting = Formatting.Parse(rPr)
      }));
      Xceed.Pdf.Layout.Text.Text text1 = new Xceed.Pdf.Layout.Text.Text();
      Xceed.Pdf.Layout.Text.Text text2 = text1;
      pdfListItem.UpdateText(text2, false);
      if (text1.Atoms != null && text1.Atoms.Buffer != null)
      {
        IEnumerable<Atom> source = ((IEnumerable<Atom>) text1.Atoms.Buffer).Where<Atom>((Func<Atom, bool>) (x => x != null));
        if (source != null)
          return string.Concat<char>(source.Select<Atom, char>((Func<Atom, char>) (x => ((CharAtom) x).Char))).Replace("\t", "");
      }
      return (string) null;
    }

    private void InsertListItemNumber(Xceed.Pdf.Layout.Text.Text text, List list)
    {
      string listItemType = HelperFunctions.GetListItemType(this._pdfParagraph.GetOriginalParagraph(), this._pdfParagraph.GetFileToConvert());
      if (listItemType != null)
      {
        if (!(listItemType == "decimal"))
        {
          if (!(listItemType == "lowerLetter"))
          {
            if (!(listItemType == "upperLetter"))
            {
              if (!(listItemType == "lowerRoman"))
              {
                if (!(listItemType == "upperRoman"))
                {
                  if (listItemType == "bullet")
                  {
                    float num = this._style != null ? this._style.Font.get_Size() : 12f;
                    Brush brush = this._style != null ? this._style.Brush : Brushes.get_Black();
                    Pen pen = this._style != null ? this._style.Pen : Pens.get_Black();
                    char ch = char.MinValue;
                    Formatting formatting = (Formatting) null;
                    string listItemTextFormat = HelperFunctions.GetListItemTextFormat(list, this._pdfParagraph.GetLevel(), out formatting);
                    System.Drawing.Font font = formatting == null || formatting.FontFamily == null ? (System.Drawing.Font) null : new System.Drawing.Font(formatting.FontFamily.Name, num);
                    if (listItemTextFormat == null || font == null)
                    {
                      switch (this._pdfParagraph.GetLevel() % 3)
                      {
                        case 0:
                          ch = '·';
                          font = new System.Drawing.Font("Symbol", num);
                          break;
                        case 1:
                          ch = 'o';
                          font = new System.Drawing.Font("Courier New", num);
                          break;
                        case 2:
                          ch = '§';
                          font = new System.Drawing.Font("Wingdings", num);
                          break;
                      }
                    }
                    else
                      ch = listItemTextFormat[0];
                    if (this._style != null)
                    {
                      this._style.Font = font;
                      this._style.Brush = brush;
                      this._style.Pen = pen;
                    }
                    text.AddContent(ch.ToString() + "\t", this._style);
                  }
                }
                else
                {
                  string roman = this.ConvertTextDigitToRoman(PdfListItem._listsInfo.GetValue(list.AbstractNumId, this._pdfParagraph.GetLevel()), true);
                  text.AddContent(roman + "\t", this._style);
                }
              }
              else
              {
                string roman = this.ConvertTextDigitToRoman(PdfListItem._listsInfo.GetValue(list.AbstractNumId, this._pdfParagraph.GetLevel()), false);
                text.AddContent(roman + "\t", this._style);
              }
            }
            else
            {
              string letter = this.ConvertTextDigitToLetter(PdfListItem._listsInfo.GetValue(list.AbstractNumId, this._pdfParagraph.GetLevel()), true);
              text.AddContent(letter + "\t", this._style);
            }
          }
          else
          {
            string letter = this.ConvertTextDigitToLetter(PdfListItem._listsInfo.GetValue(list.AbstractNumId, this._pdfParagraph.GetLevel()), false);
            text.AddContent(letter + "\t", this._style);
          }
        }
        else
          text.AddContent(PdfListItem._listsInfo.GetValue(list.AbstractNumId, this._pdfParagraph.GetLevel()) + "\t", this._style);
      }
      string str1 = this._pdfParagraph.GetOriginalParagraph().ParagraphNumberProperties.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (el => el.Name.LocalName == "ilvl"))?.Attribute(Xceed.Document.NET.Document.w + "val").Value;
      string str2 = this._pdfParagraph.GetOriginalParagraph().GetOrCreate_pPr().Element(XName.Get("outlineLvl", Xceed.Document.NET.Document.w.NamespaceName))?.Attribute(Xceed.Document.NET.Document.w + "val").Value;
      if (listItemType == null && (listItemType != null || !(str1 == str2) || string.IsNullOrEmpty(this._pdfParagraph.GetOriginalParagraph().Text)))
        return;
      PdfListItem._listsInfo.IncrementValue(list, this._pdfParagraph.GetLevel());
    }

    private void SetAlignment(List list, int itemLevel)
    {
      string listItemType = HelperFunctions.GetListItemType(this._pdfParagraph.GetOriginalParagraph(), this._pdfParagraph.GetFileToConvert());
      if (list == null || itemLevel < 0 || listItemType == null)
        return;
      Paragraph originalParagraph = this._pdfParagraph.GetOriginalParagraph();
      XElement xelement = originalParagraph.GetOrCreate_pPr().Element(XName.Get("ind", Xceed.Document.NET.Document.w.NamespaceName));
      XElement listItemAlignment = HelperFunctions.GetListItemAlignment(list, itemLevel);
      if (listItemAlignment != null)
      {
        if (xelement != null)
        {
          foreach (XAttribute attribute in listItemAlignment.Attributes())
          {
            if (xelement.Attribute(attribute.Name) == null)
              xelement.Add((object) attribute);
          }
        }
        else
          originalParagraph.GetOrCreate_pPr().Add((object) listItemAlignment);
      }
      if (this._style == null)
        return;
      this._style.PositionAfterTab = originalParagraph.IndentationBefore;
    }
  }
}
