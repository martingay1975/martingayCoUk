﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.TableOfContentsSwitches
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.ComponentModel;

namespace Xceed.Document.NET
{
  /// <summary>Value indicating the Table of Content Switch to use.</summary>
  [Flags]
  public enum TableOfContentsSwitches
  {
    /// <summary>No switch is specified.</summary>
    None = 0,
    /// <summary>Includes captioned items, but omits caption labels and numbers. The identifier designated by text in the specified value corresponds to the caption label.</summary>
    [Description("\\a")] A = 1,
    /// <summary>Includes entries only from the portion of the document identified by the specified bookmark.</summary>
    [Description("\\b")] B = 2,
    /// <summary>Includes figures, tables, charts, and other items that are numbered by a SEQ field.</summary>
    [Description("\\c")] C = 4,
    /// <summary>When used with \s, the text in the specified value defines the separator between sequence and page numbers. By default, the separator is a hyphen (-).</summary>
    [Description("\\d")] D = 8,
    /// <summary>Includes only those TC fields whose identifier exactly matches the specified value.</summary>
    [Description("\\f")] F = 16, // 0x00000010
    /// <summary>Makes the table of contents entries hyperlinks.</summary>
    [Description("\\h")] H = 32, // 0x00000020
    /// <summary>Includes TC fields that assign entries to one of the levels specified by text in the specified value.</summary>
    [Description("\\l")] L = 64, // 0x00000040
    /// <summary>Page numbers are omitted from all levels unless a range of entry levels is specified by text in the specified value. If no value is specified, omits page
    /// numbers from the table of contents.</summary>
    [Description("\\n")] N = 128, // 0x00000080
    /// <summary>Uses paragraphs formatted with all or the specified range of built-in heading styles.</summary>
    [Description("\\o")] O = 256, // 0x00000100
    /// <summary>Specifies a sequence of characters that separate an entry and its page number. By default, a tab with leader dots.</summary>
    [Description("\\p")] P = 512, // 0x00000200
    /// <summary>Adds a prefix to the page number for entries numbered with a SEQ field.</summary>
    [Description("\\s")] S = 1024, // 0x00000400
    /// <summary>Uses paragraphs formatted with styles, indicated in the specified value, other than the built-in heading styles.</summary>
    [Description("\\t")] T = 2048, // 0x00000800
    /// <summary>Uses the applied paragraph outline level.</summary>
    [Description("\\u")] U = 4096, // 0x00001000
    /// <summary>Preserves tab entries within table entries.</summary>
    [Description("\\w")] W = 8192, // 0x00002000
    /// <summary>Preserves newline characters within table entries.</summary>
    [Description("\\x")] X = 16384, // 0x00004000
    /// <summary>Hides tab leader and page numbers in web layout view.</summary>
    [Description("\\z")] Z = 32768, // 0x00008000
  }
}
