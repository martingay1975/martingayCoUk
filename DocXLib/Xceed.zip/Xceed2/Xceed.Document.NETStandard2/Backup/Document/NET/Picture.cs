﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Picture
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a Picture.</summary>
  public class Picture : DocumentElement, IPictureWrappingObject, IWrappingObject
  {
    private string _id;
    private string _name;
    private string _descr;
    private long _cx;
    private long _cy;
    private uint _rotation;
    private bool _hFlip;
    private bool _vFlip;
    private object _pictureShape;
    private XElement _xfrm;
    private XElement _prstGeom;
    private float _alpha;
    private SideValues _cropping;
    private IPictureWrappingObject _wrappingObjectHelper;
    private Hyperlink _hyperlink;
    private const int InchToEmuFactor = 914400;
    private const double EmuToInchFactor = 1.09361329833771E-06;
    internal const int EmusInPixel = 12700;
    internal Image _img;

    /// <summary>Gets the Id of this Picture.</summary>
    public string Id => this._id;

    /// <summary>Gets or sets if this Picture is Flipped Horizontally.</summary>
    public bool FlipHorizontal
    {
      get => this._hFlip;
      set
      {
        this._hFlip = value;
        if (this._xfrm.Attribute(XName.Get("flipH")) == null)
          this._xfrm.Add((object) new XAttribute(XName.Get("flipH"), (object) "0"));
        this._xfrm.Attribute(XName.Get("flipH")).Value = this._hFlip ? "1" : "0";
      }
    }

    /// <summary>Gets or sets if this Picture is Flipped Vertically.</summary>
    public bool FlipVertical
    {
      get => this._vFlip;
      set
      {
        this._vFlip = value;
        if (this._xfrm.Attribute(XName.Get("flipV")) == null)
          this._xfrm.Add((object) new XAttribute(XName.Get("flipV"), (object) "0"));
        this._xfrm.Attribute(XName.Get("flipV")).Value = this._vFlip ? "1" : "0";
      }
    }

    /// <summary>Gets or sets the Rotation of this Picture (in degrees).</summary>
    public uint Rotation
    {
      get => this._rotation / 60000U;
      set
      {
        this._rotation = value % 360U * 60000U;
        XElement xelement = this.Xml.Descendants().Where<XElement>((Func<XElement, bool>) (d => d.Name.LocalName.Equals("xfrm"))).Single<XElement>();
        if (xelement.Attribute(XName.Get("rot")) == null)
          xelement.Add((object) new XAttribute(XName.Get("rot"), (object) 0));
        xelement.Attribute(XName.Get("rot")).Value = this._rotation.ToString();
      }
    }

    /// <summary>
    ///   <span id="BugEvents">Gets or sets the transparency of this Picture.</span>
    /// </summary>
    public float Alpha
    {
      get => this._alpha;
      set
      {
        this._alpha = Math.Min(Math.Max(0.0f, value), 1f);
        XElement xelement1 = this.Xml.Descendants(XName.Get("blipFill", Xceed.Document.NET.Document.pic.NamespaceName)).FirstOrDefault<XElement>();
        if (xelement1 == null)
          return;
        XElement xelement2 = xelement1.Element(XName.Get("blip", Xceed.Document.NET.Document.a.NamespaceName));
        if (xelement2 == null)
          return;
        XElement xelement3 = xelement2.Element(XName.Get("alphaModFix", Xceed.Document.NET.Document.a.NamespaceName));
        if (xelement3 == null)
        {
          xelement2.Add((object) new XElement(XName.Get("alphaModFix", Xceed.Document.NET.Document.a.NamespaceName)));
          xelement3 = xelement2.Element(XName.Get("alphaModFix", Xceed.Document.NET.Document.a.NamespaceName));
        }
        xelement3.SetAttributeValue((XName) "amt", (object) Math.Round((1.0 - (double) this._alpha) * 100000.0));
      }
    }

    /// <summary>Gets or sets the portion of the unscaled original image to draw (from 0 to 100 on the 4 sides).</summary>
    public SideValues Cropping
    {
      get => this._cropping;
      set
      {
        this._cropping = value;
        XElement xelement1 = this.Xml.Descendants(XName.Get("blipFill", Xceed.Document.NET.Document.pic.NamespaceName)).FirstOrDefault<XElement>();
        if (xelement1 == null)
          return;
        XElement xelement2 = xelement1.Element(XName.Get("srcRect", Xceed.Document.NET.Document.a.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.Add((object) new XElement(XName.Get("srcRect", Xceed.Document.NET.Document.a.NamespaceName)));
          xelement2 = xelement1.Element(XName.Get("srcRect", Xceed.Document.NET.Document.a.NamespaceName));
        }
        xelement2.SetAttributeValue((XName) "l", (object) (float) ((double) this._cropping.Left * 1000.0));
        xelement2.SetAttributeValue((XName) "t", (object) (float) ((double) this._cropping.Top * 1000.0));
        xelement2.SetAttributeValue((XName) "r", (object) (float) ((double) this._cropping.Right * 1000.0));
        xelement2.SetAttributeValue((XName) "b", (object) (float) ((double) this._cropping.Bottom * 1000.0));
      }
    }

    /// <summary>
    ///   <span id="BugEvents">Gets or sets the hyperlink associated to the picture.</span>
    /// </summary>
    public Hyperlink Hyperlink
    {
      get => this._hyperlink;
      set
      {
        this._hyperlink = value;
        XElement xelement1 = this.Xml.Descendants(XName.Get("pic", Xceed.Document.NET.Document.pic.NamespaceName)).FirstOrDefault<XElement>();
        if (xelement1 == null)
          return;
        XElement xelement2 = xelement1.Element(XName.Get("nvPicPr", Xceed.Document.NET.Document.pic.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.Add((object) new XElement(XName.Get("nvPicPr", Xceed.Document.NET.Document.pic.NamespaceName)));
          xelement2 = xelement1.Element(XName.Get("nvPicPr", Xceed.Document.NET.Document.pic.NamespaceName));
        }
        XElement xelement3 = xelement2.Element(XName.Get("cNvPr", Xceed.Document.NET.Document.pic.NamespaceName));
        if (xelement3 == null)
        {
          xelement2.Add((object) new XElement(XName.Get("cNvPr", Xceed.Document.NET.Document.pic.NamespaceName)));
          xelement3 = xelement1.Element(XName.Get("cNvPr", Xceed.Document.NET.Document.pic.NamespaceName));
        }
        string orGenerateRel = Paragraph.GetOrGenerateRel(this._hyperlink, this.PackagePart != null ? this.PackagePart : this.Document.PackagePart);
        XElement xelement4 = new XElement(XName.Get("hlinkClick", Xceed.Document.NET.Document.a.NamespaceName));
        xelement4.SetAttributeValue(XName.Get("id", Xceed.Document.NET.Document.r.NamespaceName), (object) orGenerateRel);
        xelement3.Add((object) xelement4);
        this.Xml.Descendants(XName.Get("docPr", Xceed.Document.NET.Document.wp.NamespaceName)).FirstOrDefault<XElement>()?.Add((object) xelement4);
      }
    }

    /// <summary>Gets or sets the Name of this Picture.</summary>
    public string Name
    {
      get => this._name;
      set
      {
        this._name = value;
        foreach (XAttribute attribute in this.Xml.Descendants().Attributes(XName.Get("name")))
          attribute.Value = this._name;
      }
    }

    /// <summary>Gets or sets the Description of this Picture.</summary>
    public string Description
    {
      get => this._descr;
      set
      {
        this._descr = value;
        foreach (XAttribute attribute in this.Xml.Descendants().Attributes(XName.Get("descr")))
          attribute.Value = this._descr;
      }
    }

    /// <summary>Gets the File Name of this Picture.</summary>
    public string FileName => this._img.FileName;

    /// <summary>Gets or sets the Width of this Picture (in points).</summary>
    public float Width
    {
      get => (float) (this._cx / 12700L);
      set
      {
        this._cx = Convert.ToInt64(value * 12700f);
        foreach (XAttribute attribute in this.Xml.Descendants().Attributes(XName.Get("cx")))
          attribute.Value = this._cx.ToString();
      }
    }

    /// <summary>Gets or sets the Width of this Picture (in inches).</summary>
    public float WidthInches
    {
      get => this.Width / 72f;
      set => this.Width = value * 72f;
    }

    /// <summary>Gets or sets the Height of this Picture (in points).</summary>
    public float Height
    {
      get => (float) (this._cy / 12700L);
      set
      {
        this._cy = Convert.ToInt64(value * 12700f);
        foreach (XAttribute attribute in this.Xml.Descendants().Attributes(XName.Get("cy")))
          attribute.Value = this._cy.ToString();
      }
    }

    /// <summary>Gets or sets the Height of this Picture (in inches).</summary>
    public float HeightInches
    {
      get => this.Height / 72f;
      set => this.Height = value * 72f;
    }

    /// <summary>
    ///   <span id="BugEvents">Gets the stream of this picture.</span>
    /// </summary>
    public Stream Stream => this._img.GetStream(FileMode.Open, FileAccess.Read);

    internal Picture(Xceed.Document.NET.Document document, XElement i, Image image)
      : base(document, i)
    {
      this._img = image;
      this._id = this.Xml.Descendants().Where<XElement>((Func<XElement, bool>) (e => e.Name.LocalName.Equals("blip"))).Select<XElement, string>((Func<XElement, string>) (e => e.Attribute(XName.Get("embed", "http://schemas.openxmlformats.org/officeDocument/2006/relationships")).Value)).SingleOrDefault<string>() ?? this.Xml.Descendants().Where<XElement>((Func<XElement, bool>) (e => e.Name.LocalName.Equals("imagedata"))).Select<XElement, string>((Func<XElement, string>) (e => e.Attribute(XName.Get("id", "http://schemas.openxmlformats.org/officeDocument/2006/relationships")).Value)).FirstOrDefault<string>();
      this._name = this.Xml.Descendants().Select(e => new
      {
        e = e,
        a = e.Attribute(XName.Get("name"))
      }).Where(_param1 => _param1.a != null).Select(_param1 => _param1.a.Value).FirstOrDefault<string>() ?? this.Xml.Descendants().Select(e => new
      {
        e = e,
        a = e.Attribute(XName.Get("title"))
      }).Where(_param1 => _param1.a != null).Select(_param1 => _param1.a.Value).FirstOrDefault<string>();
      this._descr = this.Xml.Descendants().Select(e => new
      {
        e = e,
        a = e.Attribute(XName.Get("descr"))
      }).Where(_param1 => _param1.a != null).Select(_param1 => _param1.a.Value).FirstOrDefault<string>();
      this._cx = this.Xml.Descendants().Select(e => new
      {
        e = e,
        a = e.Attribute(XName.Get("cx"))
      }).Where(_param1 => _param1.a != null).Select(_param1 => long.Parse(_param1.a.Value)).FirstOrDefault<long>();
      if (this._cx == 0L)
      {
        XAttribute xattribute = this.Xml.Descendants().Select(e => new
        {
          e = e,
          a = e.Attribute(XName.Get("style"))
        }).Where(_param1 => _param1.a != null).Select(_param1 => _param1.a).FirstOrDefault<XAttribute>();
        if (xattribute != null)
        {
          string str = xattribute.Value.Substring(xattribute.Value.IndexOf("width:") + 6);
          int length = str.IndexOf("pt");
          if (length >= 0)
            this._cx = long.Parse(str.Substring(0, length), (IFormatProvider) CultureInfo.InvariantCulture) * 12700L;
        }
      }
      this._cy = this.Xml.Descendants().Select(e => new
      {
        e = e,
        a = e.Attribute(XName.Get("cy"))
      }).Where(_param1 => _param1.a != null).Select(_param1 => long.Parse(_param1.a.Value)).FirstOrDefault<long>();
      if (this._cy == 0L)
      {
        XAttribute xattribute = this.Xml.Descendants().Select(e => new
        {
          e = e,
          a = e.Attribute(XName.Get("style"))
        }).Where(_param1 => _param1.a != null).Select(_param1 => _param1.a).FirstOrDefault<XAttribute>();
        if (xattribute != null)
        {
          string str = xattribute.Value.Substring(xattribute.Value.IndexOf("height:") + 7);
          int length = str.IndexOf("pt");
          if (length >= 0)
            this._cy = long.Parse(str.Substring(0, length), (IFormatProvider) CultureInfo.InvariantCulture) * 12700L;
        }
      }
      this._xfrm = this.Xml.Descendants().Where<XElement>((Func<XElement, bool>) (d => d.Name.LocalName.Equals("xfrm"))).FirstOrDefault<XElement>();
      this._prstGeom = this.Xml.Descendants().Where<XElement>((Func<XElement, bool>) (d => d.Name.LocalName.Equals("prstGeom"))).FirstOrDefault<XElement>();
      if (this._xfrm != null)
        this._rotation = this._xfrm.Attribute(XName.Get("rot")) == null ? 0U : uint.Parse(this._xfrm.Attribute(XName.Get("rot")).Value);
      XElement xelement1 = this.Xml.Descendants(XName.Get("blip", Xceed.Document.NET.Document.a.NamespaceName)).FirstOrDefault<XElement>();
      if (xelement1 != null)
      {
        XElement xelement2 = xelement1.Element(XName.Get("alphaModFix", Xceed.Document.NET.Document.a.NamespaceName));
        if (xelement2 != null)
          this._alpha = xelement2.Attribute(XName.Get("amt")) != null ? (float) (1.0 - (double) Convert.ToSingle(xelement2.Attribute(XName.Get("amt")).Value) / 100000.0) : 0.0f;
      }
      XElement i1 = this.Xml.Descendants(XName.Get("hlinkClick", Xceed.Document.NET.Document.a.NamespaceName)).FirstOrDefault<XElement>();
      if (i1 != null)
      {
        PackagePart mainPart = this.PackagePart != null ? this.PackagePart : this.Document.PackagePart;
        this._hyperlink = new Hyperlink(this.Document, mainPart, i1);
        this._hyperlink.PackagePart = mainPart;
      }
      XElement xelement3 = this.Xml.Descendants(XName.Get("srcRect", Xceed.Document.NET.Document.a.NamespaceName)).FirstOrDefault<XElement>();
      if (xelement3 != null)
      {
        this._cropping = new SideValues();
        this._cropping.Left = xelement3.Attribute(XName.Get("l")) != null ? Convert.ToSingle(xelement3.Attribute(XName.Get("l")).Value) / 1000f : 0.0f;
        this._cropping.Top = xelement3.Attribute(XName.Get("t")) != null ? Convert.ToSingle(xelement3.Attribute(XName.Get("t")).Value) / 1000f : 0.0f;
        this._cropping.Right = xelement3.Attribute(XName.Get("r")) != null ? Convert.ToSingle(xelement3.Attribute(XName.Get("r")).Value) / 1000f : 0.0f;
        this._cropping.Bottom = xelement3.Attribute(XName.Get("b")) != null ? Convert.ToSingle(xelement3.Attribute(XName.Get("b")).Value) / 1000f : 0.0f;
      }
      this._wrappingObjectHelper = (IPictureWrappingObject) new PictureWrappingObjectHelper(this.Xml);
    }

    /// <summary>Removes this Picture from the Document.</summary>
    public void Remove() => this.Xml.Remove();

    /// <summary>Sets the shape of this Picture to one of the <see cref="Xceed.Document.NET~Xceed.Document.NET.BasicShapes.html">BasicShapes</see>.</summary>
    /// <param name="shape">The shape to apply to the Picture.</param>
    public void SetPictureShape(BasicShapes shape) => this.SetPictureShape((object) shape);

    /// <summary>Sets the shape of this Picture to one of the <see cref="Xceed.Document.NET~Xceed.Document.NET.RectangleShapes.html">RectangleShapes</see>.</summary>
    /// <param name="shape">The shape to apply to the Picture.</param>
    public void SetPictureShape(RectangleShapes shape) => this.SetPictureShape((object) shape);

    /// <summary>Sets the shape of this Picture to one of the <see cref="Xceed.Document.NET~Xceed.Document.NET.BlockArrowShapes.html">BlockArrowShapes</see>.</summary>
    /// <param name="shape">The shape to apply to the Picture.</param>
    public void SetPictureShape(BlockArrowShapes shape) => this.SetPictureShape((object) shape);

    /// <summary>Sets the shape of this Picture to one of the <see cref="Xceed.Document.NET~Xceed.Document.NET.EquationShapes.html">EquationShapes</see>.</summary>
    /// <param name="shape">The shape to apply to the Picture.</param>
    public void SetPictureShape(EquationShapes shape) => this.SetPictureShape((object) shape);

    /// <summary>Sets the shape of this Picture to one of the <see cref="Xceed.Document.NET~Xceed.Document.NET.FlowchartShapes.html">FlowchartShapes</see>.</summary>
    /// <param name="shape">The shape to apply to the Picture.</param>
    public void SetPictureShape(FlowchartShapes shape) => this.SetPictureShape((object) shape);

    /// <summary>Sets the shape of this Picture to one of the <see cref="Xceed.Document.NET~Xceed.Document.NET.StarAndBannerShapes.html">StarAndBannerShapes</see>.</summary>
    /// <param name="shape">The shape to apply to the Picture.</param>
    public void SetPictureShape(StarAndBannerShapes shape) => this.SetPictureShape((object) shape);

    /// <summary>Sets the shape of this Picture to one of the CalloutShapes.</summary>
    /// <param name="shape">The shape to apply to the Picture.</param>
    public void SetPictureShape(CalloutShapes shape) => this.SetPictureShape((object) shape);

    internal bool IsJpegImage()
    {
      if (string.IsNullOrEmpty(this.FileName))
        return false;
      return this.FileName.EndsWith("jpg") || this.FileName.EndsWith("jpeg");
    }

    private void SetPictureShape(object shape)
    {
      this._pictureShape = shape;
      if (this._prstGeom.Attribute(XName.Get("prst")) == null)
        this._prstGeom.Add((object) new XAttribute(XName.Get("prst"), (object) "rectangle"));
      this._prstGeom.Attribute(XName.Get("prst")).Value = shape.ToString();
    }

    /// <summary>
    ///   <span id="BugEvents">Gets or sets the text wrapping style.</span>
    /// </summary>
    public PictureWrappingStyle WrappingStyle
    {
      get => this._wrappingObjectHelper.WrappingStyle;
      set => this._wrappingObjectHelper.WrappingStyle = value;
    }

    /// <summary>Gets or sets the text wrapping position.</summary>
    public PictureWrapText WrapText
    {
      get => this._wrappingObjectHelper.WrapText;
      set => this._wrappingObjectHelper.WrapText = value;
    }

    /// <summary>Gets or sets the horizontal alignment for the picture.</summary>
    public WrappingHorizontalAlignment HorizontalAlignment
    {
      get => this._wrappingObjectHelper.HorizontalAlignment;
      set => this._wrappingObjectHelper.HorizontalAlignment = value;
    }

    /// <summary>Gets or sets the horizontal offset (in points) of the picture relative to the element identified in the HorizontalOffsetAlignmentFrom property.</summary>
    public double HorizontalOffset
    {
      get => this._wrappingObjectHelper.HorizontalOffset;
      set => this._wrappingObjectHelper.HorizontalOffset = value;
    }

    /// <summary>Gets or sets the element from which the HorizontalOffset is calculated.</summary>
    public WrappingHorizontalOffsetAlignmentFrom HorizontalOffsetAlignmentFrom
    {
      get => this._wrappingObjectHelper.HorizontalOffsetAlignmentFrom;
      set => this._wrappingObjectHelper.HorizontalOffsetAlignmentFrom = value;
    }

    /// <summary>Gets or sets the vertical alignment for the picture.</summary>
    public WrappingVerticalAlignment VerticalAlignment
    {
      get => this._wrappingObjectHelper.VerticalAlignment;
      set => this._wrappingObjectHelper.VerticalAlignment = value;
    }

    /// <summary>Gets or sets the vertical offset (in points) of the picture relative to the element identified in the VerticalOffsetAlignmentFrom property.</summary>
    public double VerticalOffset
    {
      get => this._wrappingObjectHelper.VerticalOffset;
      set => this._wrappingObjectHelper.VerticalOffset = value;
    }

    /// <summary>Gets or sets the element from which the VerticalOffset is calculated.</summary>
    public WrappingVerticalOffsetAlignmentFrom VerticalOffsetAlignmentFrom
    {
      get => this._wrappingObjectHelper.VerticalOffsetAlignmentFrom;
      set => this._wrappingObjectHelper.VerticalOffsetAlignmentFrom = value;
    }

    /// <summary>Gets or sets the distance of the text from the left of the picture (in points).</summary>
    public double DistanceFromTextLeft
    {
      get => this._wrappingObjectHelper.DistanceFromTextLeft;
      set => this._wrappingObjectHelper.DistanceFromTextLeft = value;
    }

    /// <summary>Gets or sets the distance of the text from the right of the picture (in points).</summary>
    public double DistanceFromTextRight
    {
      get => this._wrappingObjectHelper.DistanceFromTextRight;
      set => this._wrappingObjectHelper.DistanceFromTextRight = value;
    }

    /// <summary>Gets or sets the distance of the text from the top of the picture (in points).</summary>
    public double DistanceFromTextTop
    {
      get => this._wrappingObjectHelper.DistanceFromTextTop;
      set => this._wrappingObjectHelper.DistanceFromTextTop = value;
    }

    /// <summary>Gets or sets the distance of the text from the bottom of the picture (in points).</summary>
    public double DistanceFromTextBottom
    {
      get => this._wrappingObjectHelper.DistanceFromTextBottom;
      set => this._wrappingObjectHelper.DistanceFromTextBottom = value;
    }

    /// <summary>Gets or sets the list of points to use to define the polygon inside the picture where no text can be drawn.</summary>
    public List<Point> WrapPolygon
    {
      get => this._wrappingObjectHelper.WrapPolygon;
      set => this._wrappingObjectHelper.WrapPolygon = value;
    }
  }
}
