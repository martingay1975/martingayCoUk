﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Section
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a Section.</summary>
  public class Section : Container
  {
    internal static XNamespace w = (XNamespace) "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
    internal static XNamespace r = (XNamespace) "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    private static float _pageSizeMultiplier = 20f;

    /// <summary>Gets or sets if the first page of this Section uses an independent Header and Footer.</summary>
    public bool DifferentFirstPage
    {
      get => this.Xml.Element(Section.w + "titlePg") != null;
      set
      {
        XElement xelement = this.Xml.Element(Section.w + "titlePg");
        if (xelement == null)
        {
          if (!value)
            return;
          this.Xml.Add((object) new XElement(Section.w + "titlePg", (object) string.Empty));
        }
        else
        {
          if (value)
            return;
          xelement.Remove();
        }
      }
    }

    /// <summary>Gets the Footers of this Section.</summary>
    public Footers Footers { get; internal set; }

    /// <summary>Gets the Headers of this Section.</summary>
    public Headers Headers { get; internal set; }

    /// <summary>Gets or sets the bottom margin (in points) of this Section.</summary>
    public float MarginBottom
    {
      get => this.GetMarginAttribute(XName.Get("bottom", Section.w.NamespaceName));
      set => this.SetMarginAttribute(XName.Get("bottom", Section.w.NamespaceName), value);
    }

    /// <summary>Gets or sets the footer margin (in points) of this Section.</summary>
    public float MarginFooter
    {
      get => this.GetMarginAttribute(XName.Get("footer", Section.w.NamespaceName));
      set => this.SetMarginAttribute(XName.Get("footer", Section.w.NamespaceName), value);
    }

    /// <summary>Gets or sets the header margin (in points) of this Section.</summary>
    public float MarginHeader
    {
      get => this.GetMarginAttribute(XName.Get("header", Section.w.NamespaceName));
      set => this.SetMarginAttribute(XName.Get("header", Section.w.NamespaceName), value);
    }

    /// <summary>Gets or sets the left margin (in points) of this Section.</summary>
    public float MarginLeft
    {
      get => this.GetMarginAttribute(XName.Get("left", Section.w.NamespaceName));
      set => this.SetMarginAttribute(XName.Get("left", Section.w.NamespaceName), value);
    }

    /// <summary>Gets or sets the right margin (in points) of this Section.</summary>
    public float MarginRight
    {
      get => this.GetMarginAttribute(XName.Get("right", Section.w.NamespaceName));
      set => this.SetMarginAttribute(XName.Get("right", Section.w.NamespaceName), value);
    }

    /// <summary>Gets or sets the top margin (in points) of this Section.</summary>
    public float MarginTop
    {
      get => this.GetMarginAttribute(XName.Get("top", Section.w.NamespaceName));
      set => this.SetMarginAttribute(XName.Get("top", Section.w.NamespaceName), value);
    }

    /// <summary>Gets or sets if the mirror margins option is enabled for this Section.</summary>
    public bool MirrorMargins
    {
      get => this.GetMirrorMargins(XName.Get("mirrorMargins", Section.w.NamespaceName));
      set => this.SetMirrorMargins(XName.Get("mirrorMargins", Section.w.NamespaceName), value);
    }

    /// <summary>Gets or sets the Borders to use for all the pages of this Section.</summary>
    public Borders PageBorders
    {
      get
      {
        XElement xelement = this.Xml.Element(XName.Get("pgBorders", Section.w.NamespaceName));
        if (xelement == null)
          return (Borders) null;
        Borders borders = new Borders();
        XElement xml1 = xelement.Element(XName.Get("top", Section.w.NamespaceName));
        if (xml1 != null)
          borders.Top = HelperFunctions.GetBorderFromXml(xml1);
        XElement xml2 = xelement.Element(XName.Get("bottom", Section.w.NamespaceName));
        if (xml2 != null)
          borders.Bottom = HelperFunctions.GetBorderFromXml(xml2);
        XElement xml3 = xelement.Element(XName.Get("left", Section.w.NamespaceName));
        if (xml3 != null)
          borders.Left = HelperFunctions.GetBorderFromXml(xml3);
        XElement xml4 = xelement.Element(XName.Get("right", Section.w.NamespaceName));
        if (xml4 != null)
          borders.Right = HelperFunctions.GetBorderFromXml(xml4);
        return borders;
      }
      set
      {
        XElement xelement = this.Xml.Element(XName.Get("pgBorders", Section.w.NamespaceName));
        if (xelement == null)
        {
          xelement = new XElement(XName.Get("pgBorders", Xceed.Document.NET.Document.w.NamespaceName));
          this.Xml.Add((object) xelement);
        }
        if (value == null)
          return;
        object[] borderAttributes1 = this.GetBorderAttributes(value.Top);
        if (borderAttributes1 != null)
          xelement.Add((object) new XElement(XName.Get("top", Xceed.Document.NET.Document.w.NamespaceName), borderAttributes1));
        object[] borderAttributes2 = this.GetBorderAttributes(value.Bottom);
        if (borderAttributes2 != null)
          xelement.Add((object) new XElement(XName.Get("bottom", Xceed.Document.NET.Document.w.NamespaceName), borderAttributes2));
        object[] borderAttributes3 = this.GetBorderAttributes(value.Left);
        if (borderAttributes3 != null)
          xelement.Add((object) new XElement(XName.Get("left", Xceed.Document.NET.Document.w.NamespaceName), borderAttributes3));
        object[] borderAttributes4 = this.GetBorderAttributes(value.Right);
        if (borderAttributes4 == null)
          return;
        xelement.Add((object) new XElement(XName.Get("right", Xceed.Document.NET.Document.w.NamespaceName), borderAttributes4));
      }
    }

    /// <summary>Gets or sets the page height (in points) of this Section.</summary>
    public float PageHeight
    {
      get
      {
        XElement xelement = this.Xml.Element(XName.Get("pgSz", Section.w.NamespaceName));
        if (xelement != null)
        {
          XAttribute xattribute = xelement.Attribute(XName.Get("h", Xceed.Document.NET.Document.w.NamespaceName));
          float result;
          if (xattribute != null && HelperFunctions.TryParseFloat(xattribute.Value, out result))
            return (float) (int) ((double) result / (double) Section._pageSizeMultiplier);
        }
        return 15840f / Section._pageSizeMultiplier;
      }
      set => this.Xml.Element(XName.Get("pgSz", Section.w.NamespaceName))?.SetAttributeValue(XName.Get("h", Section.w.NamespaceName), (object) (float) ((double) value * (double) Convert.ToInt32(Section._pageSizeMultiplier)));
    }

    /// <summary>Gets the <strong>PageLayout</strong> of this Section.</summary>
    public PageLayout PageLayout { get; private set; }

    /// <summary>
    ///   <span id="BugEvents">Gets or sets the starting page number for the current section in a document.</span>
    /// </summary>
    public int PageNumberStart
    {
      get
      {
        XElement xelement = this.Xml.Element(XName.Get("pgNumType", Section.w.NamespaceName));
        if (xelement != null)
        {
          XAttribute xattribute = xelement.Attribute(XName.Get("start", Xceed.Document.NET.Document.w.NamespaceName));
          int result;
          if (xattribute != null && HelperFunctions.TryParseInt(xattribute.Value, out result))
            return result;
        }
        return -1;
      }
      set
      {
        XElement xelement = this.Xml.Element(XName.Get("pgNumType", Section.w.NamespaceName));
        if (xelement == null)
        {
          this.Xml.Add((object) new XElement(XName.Get("pgNumType", Section.w.NamespaceName)));
          xelement = this.Xml.Element(XName.Get("pgNumType", Section.w.NamespaceName));
        }
        xelement.SetAttributeValue(XName.Get("start", Section.w.NamespaceName), (object) value);
      }
    }

    /// <summary>Gets or sets the page width (in points) of this Section.</summary>
    public float PageWidth
    {
      get
      {
        XElement xelement = this.Xml.Element(XName.Get("pgSz", Section.w.NamespaceName));
        if (xelement != null)
        {
          XAttribute xattribute = xelement.Attribute(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName));
          float result;
          if (xattribute != null && HelperFunctions.TryParseFloat(xattribute.Value, out result))
            return (float) (int) ((double) result / (double) Section._pageSizeMultiplier);
        }
        return 12240f / Section._pageSizeMultiplier;
      }
      set => this.Xml.Element(XName.Get("pgSz", Section.w.NamespaceName))?.SetAttributeValue(XName.Get("w", Section.w.NamespaceName), (object) (float) ((double) value * (double) Convert.ToInt32(Section._pageSizeMultiplier)));
    }

    public SectionBreakType SectionBreakType
    {
      get
      {
        XElement el = this.Xml.Element(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName));
        if (el != null)
        {
          switch (el.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)))
          {
            case "continuous":
              return SectionBreakType.continuous;
            case "evenPage":
              return SectionBreakType.evenPage;
            case "oddPage":
              return SectionBreakType.oddPage;
          }
        }
        return SectionBreakType.defaultNextPage;
      }
      set
      {
        string str = "nextPage";
        switch (value)
        {
          case SectionBreakType.evenPage:
            str = "evenPage";
            break;
          case SectionBreakType.oddPage:
            str = "oddPage";
            break;
          case SectionBreakType.continuous:
            str = "continuous";
            break;
        }
        XElement xelement = this.Xml.Element(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement == null)
        {
          this.Xml.Add((object) new XElement(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName)));
          xelement = this.Xml.Element(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName));
        }
        xelement.SetAttributeValue(XName.Get("val", Section.w.NamespaceName), (object) str);
      }
    }

    /// <summary>Gets or sets the collection of Paragraphs in this
    /// Section.</summary>
    public List<Paragraph> SectionParagraphs { get; set; }

    internal Section(Xceed.Document.NET.Document document, XElement xml, IEnumerable<XElement> lastSectionsXml)
      : base(document, xml)
    {
      this.PageLayout = new PageLayout(document, xml);
      XElement xml1 = new XElement(xml);
      if (lastSectionsXml != null)
      {
        List<XElement> list = lastSectionsXml.ToList<XElement>();
        for (int index = list.Count - 1; index >= 0; --index)
        {
          foreach (XElement element in list[index].Elements())
          {
            if (xml1.Element(element.Name) == null && element.Name.LocalName != "headerReference" && element.Name.LocalName != "footerReference")
              xml1.Add((object) element);
          }
        }
      }
      this.UpdateXmlReferenceFromLastSection(xml1, lastSectionsXml, true);
      this.UpdateXmlReferenceFromLastSection(xml1, lastSectionsXml, false);
      this.AddHeadersContainer(xml1);
      this.AddFootersContainer(xml1);
    }

    /// <summary>Inserts a Section to this Section, and optionally track
    /// this change.</summary>
    /// <returns>The section that was inserted.</returns>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public override Section InsertSection(bool trackChanges) => this.InsertSection(trackChanges, false);

    /// <summary>Inserts a section page break to this Section, and optionally track this change.</summary>
    /// <returns>The section that was inserted.</returns>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public override Section InsertSectionPageBreak(bool trackChanges = false) => this.InsertSection(trackChanges, true);

    protected internal override void AddElementInXml(object element)
    {
      if (this.SectionParagraphs.Count<Paragraph>() > 0)
        this.SectionParagraphs.Last<Paragraph>().Xml.AddBeforeSelf(element);
      else
        this.Xml.AddBeforeSelf(element);
    }

    /// <summary>Adds three new Headers to this Section. One for the first page, one for odd pages, and one for even pages.</summary>
    public void AddHeaders() => this.AddHeadersOrFootersXml(true);

    /// <summary>Adds three new Footers to this Section. One for the first page, one for odd pages, and one for even pages.</summary>
    public void AddFooters() => this.AddHeadersOrFootersXml(false);

    internal void AddHeadersOrFootersXml(bool b)
    {
      string str1 = b ? "hdr" : "ftr";
      string str2 = b ? "header" : "footer";
      this.DeleteHeadersOrFooters(b);
      XElement xml = this.Xml;
      int val1 = 0;
      using (IEnumerator<PackageRelationship> enumerator = this.Document.PackagePart.GetRelationshipsByType(string.Format("http://schemas.openxmlformats.org/officeDocument/2006/relationships/{0}", (object) str2)).GetEnumerator())
      {
        while (((IEnumerator) enumerator).MoveNext())
        {
          Uri uri = enumerator.Current.get_TargetUri();
          if (!uri.OriginalString.StartsWith("/word/"))
            uri = new Uri("/word/" + uri.OriginalString, UriKind.Relative);
          if (this.Document._package.PartExists(uri))
          {
            string s = Regex.Match(uri.OriginalString, "\\d+").Value;
            val1 = Math.Max(val1, int.Parse(s));
          }
        }
      }
      for (int index = val1 + 1; index < val1 + 4; ++index)
      {
        PackagePart part = this.Document._package.CreatePart(new Uri(string.Format("/word/{0}{1}.xml", (object) str2, (object) index), UriKind.Relative), string.Format("application/vnd.openxmlformats-officedocument.wordprocessingml.{0}+xml", (object) str2), (CompressionOption) 0);
        PackageRelationship relationship = this.Document.PackagePart.CreateRelationship(part.get_Uri(), (TargetMode) 0, string.Format("http://schemas.openxmlformats.org/officeDocument/2006/relationships/{0}", (object) str2));
        XDocument xdocument;
        using ((TextReader) new StreamReader(part.GetStream(FileMode.Create, FileAccess.ReadWrite)))
          xdocument = XDocument.Parse(string.Format("<?xml version=\"1.0\" encoding=\"utf-16\" standalone=\"yes\"?>\r\n                       <w:{0} xmlns:ve=\"http://schemas.openxmlformats.org/markup-compatibility/2006\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" xmlns:m=\"http://schemas.openxmlformats.org/officeDocument/2006/math\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:w10=\"urn:schemas-microsoft-com:office:word\" xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:wne=\"http://schemas.microsoft.com/office/word/2006/wordml\">\r\n                         <w:p w:rsidR=\"009D472B\" w:rsidRDefault=\"009D472B\">\r\n                           <w:pPr>\r\n                             <w:pStyle w:val=\"{1}\" />\r\n                           </w:pPr>\r\n                         </w:p>\r\n                       </w:{0}>", (object) str1, (object) str2));
        using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(part.GetStream(FileMode.Create, FileAccess.Write))))
          xdocument.Save(textWriter, SaveOptions.None);
        string str3;
        switch (index % 3)
        {
          case 0:
            str3 = "default";
            break;
          case 1:
            str3 = "even";
            break;
          case 2:
            str3 = "first";
            break;
          default:
            throw new ArgumentOutOfRangeException();
        }
        xml.Add((object) new XElement(Section.w + string.Format("{0}Reference", (object) str2), new object[2]
        {
          (object) new XAttribute(Section.w + "type", (object) str3),
          (object) new XAttribute(Section.r + "id", (object) relationship.get_Id())
        }));
      }
      if (b)
        this.AddHeadersContainer(xml);
      else
        this.AddFootersContainer(xml);
    }

    private void UpdateXmlReferenceFromLastSection(
      XElement xml,
      IEnumerable<XElement> lastSectionsXml,
      bool isHeader)
    {
      if (xml == null || lastSectionsXml == null || lastSectionsXml.Count<XElement>() == 0)
        return;
      IEnumerable<XElement> xelements = xml.Elements(XName.Get(isHeader ? "headerReference" : "footerReference", Section.w.NamespaceName));
      List<XElement> source1 = new List<XElement>()
      {
        (XElement) null,
        (XElement) null,
        (XElement) null
      };
      foreach (XElement xelement in xelements)
      {
        switch (xelement.Attribute(Section.w + "type").Value)
        {
          case "first":
            source1[0] = xelement;
            continue;
          case "even":
            source1[1] = xelement;
            continue;
          default:
            source1[2] = xelement;
            continue;
        }
      }
      if (!source1.Any<XElement>((Func<XElement, bool>) (r => r == null)))
        return;
      List<XElement> list = lastSectionsXml.ToList<XElement>();
      for (int index = list.Count - 1; index >= 0; --index)
      {
        IEnumerable<XElement> source2 = list[index].Elements(XName.Get(isHeader ? "headerReference" : "footerReference", Section.w.NamespaceName));
        if (source1[0] == null)
        {
          XElement xelement = source2.FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Attribute(Section.w + "type").Value == "first"));
          if (xelement != null)
          {
            xml.Add((object) xelement);
            source1[0] = xelement;
          }
        }
        if (source1[1] == null)
        {
          XElement xelement = source2.FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Attribute(Section.w + "type").Value == "even"));
          if (xelement != null)
          {
            xml.Add((object) xelement);
            source1[1] = xelement;
          }
        }
        if (source1[2] == null)
        {
          XElement xelement = source2.FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Attribute(Section.w + "type").Value == "default"));
          if (xelement != null)
          {
            xml.Add((object) xelement);
            source1[2] = xelement;
          }
        }
        if (source1.All<XElement>((Func<XElement, bool>) (r => r != null)))
          break;
      }
    }

    private void AddHeadersContainer(XElement xml)
    {
      this.Headers = new Headers();
      foreach (XElement element in xml.Elements(XName.Get("headerReference", Section.w.NamespaceName)))
      {
        string id = element.Attribute(Section.r + "id").Value;
        string str = element.Attribute(Section.w + "type").Value;
        Uri uri = this.Document.PackagePart.GetRelationship(id).get_TargetUri();
        if (!uri.OriginalString.StartsWith("/word/"))
          uri = new Uri("/word/" + uri.OriginalString, UriKind.Relative);
        PackagePart part = this.Document._package.GetPart(uri);
        using (TextReader textReader = (TextReader) new StreamReader(part.GetStream()))
        {
          Header header = new Header(this.Document, XDocument.Load(textReader).Element(Section.w + "hdr"), part, id);
          if (str != null)
          {
            if (!(str == "even"))
            {
              if (str == "first")
              {
                this.Headers.First = header;
                continue;
              }
            }
            else
            {
              this.Headers.Even = header;
              continue;
            }
          }
          this.Headers.Odd = header;
        }
      }
    }

    private void AddFootersContainer(XElement xml)
    {
      this.Footers = new Footers();
      foreach (XElement element in xml.Elements(XName.Get("footerReference", Section.w.NamespaceName)))
      {
        string id = element.Attribute(Section.r + "id").Value;
        string str = element.Attribute(Section.w + "type").Value;
        Uri uri = this.Document.PackagePart.GetRelationship(id).get_TargetUri();
        if (!uri.OriginalString.StartsWith("/word/"))
          uri = new Uri("/word/" + uri.OriginalString, UriKind.Relative);
        PackagePart part = this.Document._package.GetPart(uri);
        using (TextReader textReader = (TextReader) new StreamReader(part.GetStream()))
        {
          Footer footer = new Footer(this.Document, XDocument.Load(textReader).Element(Section.w + "ftr"), part, id);
          if (str != null)
          {
            if (!(str == "even"))
            {
              if (str == "first")
              {
                this.Footers.First = footer;
                continue;
              }
            }
            else
            {
              this.Footers.Even = footer;
              continue;
            }
          }
          this.Footers.Odd = footer;
        }
      }
    }

    private void DeleteHeadersOrFooters(bool b)
    {
      string reference = b ? "header" : "footer";
      this.Xml.Elements(XName.Get(string.Format("{0}Reference", (object) reference), Section.w.NamespaceName)).Remove<XElement>();
      using (IEnumerator<PackageRelationship> enumerator = this.Document.PackagePart.GetRelationshipsByType(string.Format("http://schemas.openxmlformats.org/officeDocument/2006/relationships/{0}", (object) reference)).GetEnumerator())
      {
        while (((IEnumerator) enumerator).MoveNext())
        {
          PackageRelationship header_relationship = enumerator.Current;
          Uri uri = header_relationship.get_TargetUri();
          if (!uri.OriginalString.StartsWith("/word/"))
            uri = new Uri("/word/" + uri.OriginalString, UriKind.Relative);
          if (this.Document._package.PartExists(uri) && this.Document._mainDoc.Descendants(XName.Get("body", Section.w.NamespaceName)).Descendants<XElement>().Where<XElement>((Func<XElement, bool>) (e => e.Name.LocalName == string.Format("{0}Reference", (object) reference) && e.Attribute(Section.r + "id").Value == header_relationship.get_Id())).Count<XElement>() == 0)
          {
            this.Document._package.DeletePart(uri);
            this.Document._package.DeleteRelationship(header_relationship.get_Id());
          }
        }
      }
    }

    private float GetMarginAttribute(XName name)
    {
      XAttribute xattribute = this.Xml.Element(XName.Get("pgMar", Section.w.NamespaceName))?.Attribute(name);
      float result;
      return xattribute != null && HelperFunctions.TryParseFloat(xattribute.Value, out result) ? (float) (int) ((double) result / (double) Section._pageSizeMultiplier) : 0.0f;
    }

    private void SetMarginAttribute(XName xName, float value) => this.Xml.Element(XName.Get("pgMar", Section.w.NamespaceName))?.Attribute(xName)?.SetValue((object) (float) ((double) value * (double) Convert.ToInt32(Section._pageSizeMultiplier)));

    private bool GetMirrorMargins(XName name) => this.Xml.Element(XName.Get("mirrorMargins", Xceed.Document.NET.Document.w.NamespaceName)) != null;

    private void SetMirrorMargins(XName name, bool value)
    {
      XElement xelement = this.Xml.Element(XName.Get("mirrorMargins", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement == null)
      {
        this.Xml.Add((object) new XElement(Section.w + "mirrorMargins", (object) string.Empty));
      }
      else
      {
        if (value)
          return;
        xelement.Remove();
      }
    }

    private object[] GetBorderAttributes(Border border)
    {
      if (border == null)
        return (object[]) null;
      return new object[4]
      {
        (object) new XAttribute(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName), (object) border.Color.ToHex()),
        (object) new XAttribute(XName.Get("space", Xceed.Document.NET.Document.w.NamespaceName), (object) border.Space),
        (object) new XAttribute(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName), (object) Border.GetNumericSize(border.Size)),
        (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) border.Tcbs.ToString().Remove(0, 5))
      };
    }

    private Section InsertSection(bool trackChanges, bool isPageBreak)
    {
      int num = this.Document.Sections.Last<Section>() == this ? 1 : 0;
      this.Document.SaveHeadersFooters();
      XElement sctPr = new XElement(this.Xml);
      this.Xml.Elements(XName.Get("headerReference", Xceed.Document.NET.Document.w.NamespaceName)).Remove<XElement>();
      this.Xml.Elements(XName.Get("footerReference", Xceed.Document.NET.Document.w.NamespaceName)).Remove<XElement>();
      if (!isPageBreak)
        sctPr.Add((object) new XElement(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) "continuous")));
      if (num != 0)
      {
        XElement xelement1 = new XElement(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName), (object) this.Xml));
        if (this.SectionParagraphs.Count > 0)
          this.SectionParagraphs.Last<Paragraph>().Xml.AddAfterSelf((object) xelement1);
        else
          this.Xml.AddBeforeSelf((object) xelement1);
        this.Xml.Remove();
        this.Xml = xelement1;
        XElement xelement2 = sctPr;
        if (trackChanges)
          xelement2 = HelperFunctions.CreateEdit(EditType.ins, DateTime.Now, (object) xelement2);
        xelement1.AddAfterSelf((object) xelement2);
      }
      else
      {
        XElement xelement = new XElement(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName), (object) sctPr));
        if (trackChanges)
          xelement = HelperFunctions.CreateEdit(EditType.ins, DateTime.Now, (object) xelement);
        this.SectionParagraphs.Last<Paragraph>().Xml.AddAfterSelf((object) xelement);
      }
      this.Document.UpdateCacheSections();
      return this.Document.Sections.FirstOrDefault<Section>((Func<Section, bool>) (section => section.Xml == sctPr));
    }
  }
}
