﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.BookmarkCollection
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a collection of Bookmarks.</summary>
  public class BookmarkCollection : List<Bookmark>
  {
    /// <summary>Initializes a new instance of the <strong>BookmarkCollection</strong> class.</summary>
    public BookmarkCollection() => Licenser.VerifyLicense();

    public Bookmark this[string name] => this.FirstOrDefault<Bookmark>((Func<Bookmark, bool>) (x => x.Name.Equals(name, StringComparison.CurrentCultureIgnoreCase)));
  }
}
