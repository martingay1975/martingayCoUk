﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.TableWrappingObjectHelper
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  internal class TableWrappingObjectHelper : 
    WrappingObjectHelper,
    ITableWrappingObject,
    IWrappingObject
  {
    private TableWrappingStyle _wrappingStyle;

    public TableWrappingStyle WrappingStyle
    {
      get => this._wrappingStyle;
      set
      {
        this._wrappingStyle = value;
        this.UpdateTextWrapping();
      }
    }

    internal TableWrappingObjectHelper(XElement xml)
      : base(xml)
    {
    }

    internal override void UpdateHorizontalAlignment()
    {
      if (this.WrappingStyle == TableWrappingStyle.WrapNone)
        return;
      XElement xelement1 = this.GetXml().Descendants(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
      if (xelement1 == null)
        return;
      XElement xelement2 = xelement1.Element(XName.Get("tblpPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 == null)
        return;
      xelement2.SetAttributeValue(XName.Get("horzAnchor", Xceed.Document.NET.Document.w.NamespaceName), (object) this.GetHorizontalRelativeFrom());
      if (this.HorizontalAlignment != WrappingHorizontalAlignment.None)
      {
        xelement2.SetAttributeValue(XName.Get("tblpXSpec", Xceed.Document.NET.Document.w.NamespaceName), (object) this.GetHorizontalAlignment());
        xelement2.SetAttributeValue(XName.Get("tblpX", Xceed.Document.NET.Document.w.NamespaceName), (object) null);
      }
      else
      {
        xelement2.SetAttributeValue(XName.Get("tblpX", Xceed.Document.NET.Document.w.NamespaceName), (object) (this.HorizontalOffset * 20.0));
        xelement2.SetAttributeValue(XName.Get("tblpXSpec", Xceed.Document.NET.Document.w.NamespaceName), (object) null);
      }
    }

    internal override string GetHorizontalRelativeFrom()
    {
      if (this.HorizontalAlignment != WrappingHorizontalAlignment.None)
      {
        switch (this.HorizontalAlignment)
        {
          case WrappingHorizontalAlignment.LeftRelativeToMargin:
          case WrappingHorizontalAlignment.CenteredRelativeToMargin:
          case WrappingHorizontalAlignment.RightRelativeToMargin:
          case WrappingHorizontalAlignment.InsideOfMargin:
          case WrappingHorizontalAlignment.OutsideOfMargin:
            return "margin";
          case WrappingHorizontalAlignment.LeftRelativeToPage:
          case WrappingHorizontalAlignment.CenteredRelativeToPage:
          case WrappingHorizontalAlignment.RightRelativeToPage:
          case WrappingHorizontalAlignment.InsideOfPage:
          case WrappingHorizontalAlignment.OutsideOfPage:
            return "page";
          case WrappingHorizontalAlignment.LeftRelativeToColumn:
          case WrappingHorizontalAlignment.CenteredRelativeToColumn:
          case WrappingHorizontalAlignment.RightRelativeToColumn:
            return "text";
          default:
            throw new InvalidOperationException("Unknown HorizontalAlignment for Shape. Available values are Margin, Page or Column.");
        }
      }
      else
      {
        switch (this.HorizontalOffsetAlignmentFrom)
        {
          case WrappingHorizontalOffsetAlignmentFrom.Margin:
            return "margin";
          case WrappingHorizontalOffsetAlignmentFrom.Page:
            return "page";
          case WrappingHorizontalOffsetAlignmentFrom.Column:
            return "column";
          default:
            throw new InvalidOperationException("Unknown HorizontalOffsetAlignmentFrom for Shape. Available values are Margin, Page or Column.");
        }
      }
    }

    internal override void UpdateVerticalAlignment()
    {
      if (this.WrappingStyle == TableWrappingStyle.WrapNone)
        return;
      XElement xelement1 = this.GetXml().Descendants(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
      if (xelement1 == null)
        return;
      XElement xelement2 = xelement1.Element(XName.Get("tblpPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 == null)
        return;
      xelement2.SetAttributeValue(XName.Get("vertAnchor", Xceed.Document.NET.Document.w.NamespaceName), (object) this.GetVerticalRelativeFrom());
      if (this.VerticalAlignment != WrappingVerticalAlignment.None)
      {
        xelement2.SetAttributeValue(XName.Get("tblpYSpec", Xceed.Document.NET.Document.w.NamespaceName), (object) this.GetVerticalAlignment());
        xelement2.SetAttributeValue(XName.Get("tblpY", Xceed.Document.NET.Document.w.NamespaceName), (object) null);
      }
      else
      {
        xelement2.SetAttributeValue(XName.Get("tblpY", Xceed.Document.NET.Document.w.NamespaceName), (object) (this.VerticalOffset * 20.0));
        xelement2.SetAttributeValue(XName.Get("tblpYSpec", Xceed.Document.NET.Document.w.NamespaceName), (object) null);
      }
    }

    internal override string GetVerticalRelativeFrom()
    {
      if (this.VerticalAlignment != WrappingVerticalAlignment.None)
      {
        switch (this.VerticalAlignment)
        {
          case WrappingVerticalAlignment.TopRelativeToMargin:
          case WrappingVerticalAlignment.CenteredRelativeToMargin:
          case WrappingVerticalAlignment.BottomRelativeToMargin:
          case WrappingVerticalAlignment.InsideRelativeToMargin:
          case WrappingVerticalAlignment.OutsideRelativeToMargin:
            return "margin";
          case WrappingVerticalAlignment.TopRelativeToPage:
          case WrappingVerticalAlignment.CenteredRelativeToPage:
          case WrappingVerticalAlignment.BottomRelativeToPage:
          case WrappingVerticalAlignment.InsideRelativeToPage:
          case WrappingVerticalAlignment.OutsideRelativeToPage:
            return "page";
          default:
            throw new InvalidOperationException("Unknown VerticalAlignment for Shape. Available values are Margin or Page.");
        }
      }
      else
      {
        switch (this.VerticalOffsetAlignmentFrom)
        {
          case WrappingVerticalOffsetAlignmentFrom.Margin:
            return "margin";
          case WrappingVerticalOffsetAlignmentFrom.Page:
            return "page";
          case WrappingVerticalOffsetAlignmentFrom.Paragraph:
            return "paragraph";
          default:
            throw new InvalidOperationException("Unknown VerticalOffsetAlignmentFrom for Shape. Available values are Margin, Page or Paragraph.");
        }
      }
    }

    internal override void UpdateDistanceFromText()
    {
      if (this.WrappingStyle == TableWrappingStyle.WrapNone)
        return;
      XElement xelement1 = this.GetXml().Descendants(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
      if (xelement1 == null)
        return;
      XElement xelement2 = xelement1.Element(XName.Get("tblpPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 == null)
        return;
      xelement2.SetAttributeValue(XName.Get("topFromText", Xceed.Document.NET.Document.w.NamespaceName), (object) (this.DistanceFromTextTop * 20.0));
      xelement2.SetAttributeValue(XName.Get("bottomFromText", Xceed.Document.NET.Document.w.NamespaceName), (object) (this.DistanceFromTextBottom * 20.0));
      xelement2.SetAttributeValue(XName.Get("leftFromText", Xceed.Document.NET.Document.w.NamespaceName), (object) (this.DistanceFromTextLeft * 20.0));
      xelement2.SetAttributeValue(XName.Get("rightFromText", Xceed.Document.NET.Document.w.NamespaceName), (object) (this.DistanceFromTextRight * 20.0));
    }

    private void UpdateTextWrapping()
    {
      XElement xelement1 = this.GetXml().Descendants(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
      if (xelement1 == null)
        return;
      XElement xelement2 = xelement1.Element(XName.Get("tblpPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (this.WrappingStyle == TableWrappingStyle.WrapNone)
      {
        xelement2?.Remove();
      }
      else
      {
        if (this.WrappingStyle != TableWrappingStyle.WrapAround)
          throw new InvalidOperationException("Unknown WrappingStyle for Table. Only WrapNone and WrapAround are valid.");
        if (xelement2 != null)
          return;
        XElement xelement3 = new XElement(XName.Get("tblpPr", Xceed.Document.NET.Document.w.NamespaceName));
        xelement1.Add((object) xelement3);
      }
    }
  }
}
