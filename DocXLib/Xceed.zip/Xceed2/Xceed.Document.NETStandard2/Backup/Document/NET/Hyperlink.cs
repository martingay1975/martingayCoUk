﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Hyperlink
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.IO.Packaging;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a Hyperlink.</summary>
  public class Hyperlink : DocumentElement
  {
    internal Uri uri;
    internal string text;
    internal Dictionary<PackagePart, PackageRelationship> hyperlink_rels;
    internal int type;
    internal string id;
    internal XElement instrText;
    internal List<XElement> runs;

    /// <summary>Gets or sets the Text for this Hyperlink.</summary>
    public string Text
    {
      get => this.text;
      set
      {
        XElement rPr = new XElement(Xceed.Document.NET.Document.w + "rPr", (object) new XElement(Xceed.Document.NET.Document.w + "rStyle", (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) nameof (Hyperlink))));
        List<XElement> xelementList = HelperFunctions.FormatInput(value, rPr);
        if (this.type == 0)
        {
          IEnumerable<XElement> source = this.Xml.Elements().Where<XElement>((Func<XElement, bool>) (r => r.Name.LocalName == nameof (r)));
          for (int index = 0; index < source.Count<XElement>(); ++index)
            source.Remove<XElement>();
          this.Xml.Add((object) xelementList);
        }
        else
        {
          XElement xelement1 = XElement.Parse("\r\n                    <w:r xmlns:w='http://schemas.openxmlformats.org/wordprocessingml/2006/main'>\r\n                        <w:fldChar w:fldCharType='separate'/> \r\n                    </w:r>");
          XElement xelement2 = XElement.Parse("\r\n                    <w:r xmlns:w='http://schemas.openxmlformats.org/wordprocessingml/2006/main'>\r\n                        <w:fldChar w:fldCharType='end' /> \r\n                    </w:r>");
          this.runs.Last<XElement>().AddAfterSelf((object) xelement1, (object) xelementList, (object) xelement2);
          this.runs.ForEach((Action<XElement>) (r => r.Remove()));
        }
        this.text = value;
      }
    }

    /// <summary>Gets or sets the Uri for this Hyperlink.</summary>
    public Uri Uri
    {
      get => this.type == 0 && !string.IsNullOrEmpty(this.id) ? this.PackagePart.GetRelationship(this.id).get_TargetUri() : this.uri;
      set
      {
        if (this.type == 0)
        {
          PackageRelationship relationship = this.PackagePart.GetRelationship(this.id);
          TargetMode targetMode = relationship.get_TargetMode();
          string relationshipType = relationship.get_RelationshipType();
          string id = relationship.get_Id();
          this.PackagePart.DeleteRelationship(id);
          this.PackagePart.CreateRelationship(value, targetMode, relationshipType, id);
        }
        else
        {
          XElement instrText = this.instrText;
          Uri uri = value;
          string str = "HYPERLINK \"" + ((object) uri != null ? uri.ToString() : (string) null) + "\"";
          instrText.Value = str;
        }
        this.uri = value;
      }
    }

    internal List<XElement> Runs => this.Xml == null ? (List<XElement>) null : this.Xml.Elements().Where<XElement>((Func<XElement, bool>) (r => r.Name.LocalName == nameof (r))).ToList<XElement>();

    internal Hyperlink(Xceed.Document.NET.Document document, PackagePart mainPart, XElement i)
      : base(document, i)
    {
      Licenser.VerifyLicense();
      this.type = 0;
      XAttribute xattribute = i.Attribute(XName.Get(nameof (id), Xceed.Document.NET.Document.r.NamespaceName));
      if (xattribute != null)
        this.id = xattribute.Value;
      StringBuilder sb = new StringBuilder();
      HelperFunctions.GetTextRecursive(i, ref sb);
      this.text = sb.ToString();
    }

    internal Hyperlink(Xceed.Document.NET.Document document, XElement instrText, List<XElement> runs)
      : base(document, (XElement) null)
    {
      Licenser.VerifyLicense();
      this.type = 1;
      this.instrText = instrText;
      this.runs = runs;
      try
      {
        int num1 = instrText.Value.IndexOf("HYPERLINK \"");
        if (num1 != -1)
          num1 += "HYPERLINK \"".Length;
        int num2 = instrText.Value.IndexOf("\"", Math.Max(0, num1));
        if (num1 == -1 || num2 == -1)
          return;
        this.uri = new Uri(instrText.Value.Substring(num1, num2 - num1), UriKind.Absolute);
        StringBuilder sb = new StringBuilder();
        HelperFunctions.GetTextRecursive(new XElement(XName.Get("temp", Xceed.Document.NET.Document.w.NamespaceName), (object) runs), ref sb);
        this.text = sb.ToString();
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    /// <summary>Removes a Hyperlink.</summary>
    public void Remove() => this.Xml.Remove();
  }
}
