﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfHeader
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace Xceed.Document.NET
{
  internal class PdfHeader : PdfHeaderFooterBase
  {
    internal PdfHeader(PdfIConverter pdfConverterInterface)
      : base(pdfConverterInterface)
    {
    }

    internal override void CreatePdfParagraphs(Container container)
    {
      Section currentSection = this._pdfConverterInterface.GetCurrentSection();
      PdfPageInfo currentPdfPageInfo = this._pdfConverterInterface.GetCurrentPdfPageInfo();
      currentPdfPageInfo.PositionY = currentSection.MarginHeader;
      this.CreatePdfParagraphsCore(container, currentSection.MarginHeader);
      List<PdfWrappedObjectInfo> all = currentPdfPageInfo.WrappedObjects.FindAll((Predicate<PdfWrappedObjectInfo>) (o => o.HeaderFooterType == HeaderFooterType.Header));
      float val2 = all.Count > 0 ? all.Select<PdfWrappedObjectInfo, float>((Func<PdfWrappedObjectInfo, float>) (o =>
      {
        RectangleF dimension = o.Dimension;
        double y = (double) dimension.Y;
        dimension = o.Dimension;
        double height = (double) dimension.Height;
        return (float) (y + height);
      })).Max() : 0.0f;
      currentPdfPageInfo.HeaderHeight = Math.Max(Math.Max(currentPdfPageInfo.PositionY, currentPdfPageInfo.HeaderHeight), val2);
    }

    internal override void Draw()
    {
      Section currentSection = this._pdfConverterInterface.GetCurrentSection();
      PdfPageInfo currentPdfPageInfo = this._pdfConverterInterface.GetCurrentPdfPageInfo();
      if (currentSection.Headers == null)
        return;
      if (currentPdfPageInfo.PageId == 1)
      {
        if (currentSection.DifferentFirstPage)
        {
          if (currentSection.Headers.First == null)
            return;
          this.CreatePdfParagraphs((Container) currentSection.Headers.First);
        }
        else
        {
          if (currentSection.Headers.Odd == null)
            return;
          this.CreatePdfParagraphs((Container) currentSection.Headers.Odd);
        }
      }
      else if (currentPdfPageInfo.PageId % 2 == 0 && this._pdfConverterInterface.GetFileToConvert().DifferentOddAndEvenPages)
      {
        if (currentSection.Headers.Even == null)
          return;
        this.CreatePdfParagraphs((Container) currentSection.Headers.Even);
      }
      else
      {
        if (currentSection.Headers.Odd == null)
          return;
        this.CreatePdfParagraphs((Container) currentSection.Headers.Odd);
      }
    }
  }
}
