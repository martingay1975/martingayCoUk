﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.TableOfContents
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a table of contents.</summary>
  public class TableOfContents : DocumentElement
  {
    private const string HeaderStyle = "TOCHeading";
    private const int RightTabPos = 9010;

    internal static TableOfContents CreateTableOfContents(
      Xceed.Document.NET.Document document,
      string title,
      IDictionary<TableOfContentsSwitches, string> switchesDictionary,
      string headerStyle = null,
      int? rightTabPos = null)
    {
      XElement xml = XElement.Load(XmlReader.Create((TextReader) new StringReader(string.Format("\r\n        <w:sdt xmlns:w='http://schemas.openxmlformats.org/wordprocessingml/2006/main'>\r\n            <w:sdtPr>\r\n            <w:docPartObj>\r\n                <w:docPartGallery w:val='Table of Contents'/>\r\n                <w:docPartUnique/>\r\n            </w:docPartObj>\\\r\n            </w:sdtPr>\r\n            <w:sdtEndPr>\r\n            <w:rPr>\r\n                <w:rFonts w:asciiTheme='minorHAnsi' w:cstheme='minorBidi' w:eastAsiaTheme='minorHAnsi' w:hAnsiTheme='minorHAnsi'/>\r\n                <w:color w:val='auto'/>\r\n                <w:sz w:val='22'/>\r\n                <w:szCs w:val='22'/>\r\n                <w:lang w:eastAsia='en-US'/>\r\n            </w:rPr>\r\n            </w:sdtEndPr>\r\n            <w:sdtContent>\r\n            <w:p>\r\n                <w:pPr>\r\n                <w:pStyle w:val='{0}'/>\r\n                </w:pPr>\r\n                <w:r>\r\n                <w:t>{1}</w:t>\r\n                </w:r>\r\n            </w:p>\r\n            <w:p>\r\n                <w:pPr>\r\n                <w:pStyle w:val='TOC1'/>\r\n                <w:tabs>\r\n                    <w:tab w:val='right' w:leader='dot' w:pos='{2}'/>\r\n                </w:tabs>\r\n                <w:rPr>\r\n                    <w:noProof/>\r\n                </w:rPr>\r\n                </w:pPr>\r\n                <w:r>\r\n                <w:fldChar w:fldCharType='begin' w:dirty='true'/>\r\n                </w:r>\r\n                <w:r>\r\n                <w:instrText xml:space='preserve'> {3} </w:instrText>\r\n                </w:r>\r\n                <w:r>\r\n                <w:fldChar w:fldCharType='separate'/>\r\n                </w:r>\r\n            </w:p>\r\n            <w:p>\r\n                <w:r>\r\n                <w:rPr>\r\n                    <w:b/>\r\n                    <w:bCs/>\r\n                    <w:noProof/>\r\n                </w:rPr>\r\n                <w:fldChar w:fldCharType='end'/>\r\n                </w:r>\r\n            </w:p>\r\n            </w:sdtContent>\r\n        </w:sdt>\r\n        ", (object) (headerStyle ?? "TOCHeading"), (object) title, (object) (rightTabPos ?? 9010), (object) TableOfContents.BuildSwitchString(switchesDictionary)))));
      return new TableOfContents(document, xml, headerStyle);
    }

    internal static bool IsDocumentContainingTableOfContentToUpdate(Xceed.Document.NET.Document document)
    {
      if (document == null || document._settings == null || TableOfContents.GetTOCFromDocument(document) == null)
        return false;
      XElement xelement = document._settings.Root.Element(XName.Get("updateFields", Xceed.Document.NET.Document.w.NamespaceName));
      return xelement != null && xelement.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)).Value == "true";
    }

    internal static IEnumerable<XElement> UpdateTOCParagraphs(Xceed.Document.NET.Document document)
    {
      if (document == null)
        return (IEnumerable<XElement>) null;
      List<Paragraph> headingParagraphs = TableOfContents.GetHeadingParagraphs(document);
      if (headingParagraphs.Count<Paragraph>() > 0)
      {
        XElement tocFromDocument = TableOfContents.GetTOCFromDocument(document);
        if (tocFromDocument != null)
        {
          XElement sdtContent = tocFromDocument.Element(XName.Get("sdtContent", Xceed.Document.NET.Document.w.NamespaceName));
          if (sdtContent != null)
          {
            XElement xelement1 = new XElement(XName.Get("sdtContent", Xceed.Document.NET.Document.w.NamespaceName));
            foreach (XElement element in sdtContent.Elements(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName)))
            {
              if (TableOfContents.GetTOCRefInstrText(element) == null)
                xelement1.Add((object) new XElement(element));
              else
                break;
            }
            int num = 0;
            bool flag = true;
            foreach (Paragraph headingParagraph in headingParagraphs)
            {
              if (!string.IsNullOrEmpty(headingParagraph.Text))
              {
                string tocHeadingStyleId = TableOfContents.GetTOCHeadingStyleId(document, headingParagraph);
                XElement fromStyleIdAndText = TableOfContents.GetTOCStyledParagraphXmlFromStyleIdAndText(sdtContent, tocHeadingStyleId, headingParagraph.Text);
                XElement contentToUpdate;
                if (fromStyleIdAndText == null)
                {
                  contentToUpdate = new XElement(TableOfContents.GetFirstTOCStyledParagraph(document, sdtContent));
                  XElement xelement2 = contentToUpdate.Descendants(XName.Get("pStyle", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
                  if (xelement2 != null)
                  {
                    string str = TableOfContents.GetTOCHeadingCorrespondingName(TableOfContents.GetStyleNameFromStyleId(document, headingParagraph.StyleId)).ToUpper().Replace(" ", "");
                    xelement2.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) str);
                    TableOfContents.InitElement("styles", document);
                  }
                }
                else
                {
                  contentToUpdate = new XElement(fromStyleIdAndText);
                  TableOfContents.InitElement("styles", document);
                }
                headingParagraph.ClearBookmarks();
                string bookmarkName = "_Toc" + num++.ToString();
                headingParagraph.SetAsBookmark(bookmarkName);
                XElement xelement3 = contentToUpdate.Elements(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Element(XName.Get("instrText", Xceed.Document.NET.Document.w.NamespaceName)) != null && x.Value.Contains("TOC")));
                if (flag)
                {
                  if (xelement3 == null)
                  {
                    XElement xelement2 = new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("fldChar", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("fldCharType", Xceed.Document.NET.Document.w.NamespaceName), (object) "begin")));
                    XElement xelement4 = new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("instrText", Xceed.Document.NET.Document.w.NamespaceName), (object) "TOC \\h \\o \"1-3\" \\u \\z "));
                    XElement xelement5 = new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("fldChar", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("fldCharType", Xceed.Document.NET.Document.w.NamespaceName), (object) "separate")));
                    contentToUpdate.Add((object) xelement2);
                    contentToUpdate.Add((object) xelement4);
                    contentToUpdate.Add((object) xelement5);
                  }
                }
                else if (xelement3 != null)
                {
                  xelement3.ElementsBeforeSelf().Last<XElement>().Remove();
                  xelement3.ElementsAfterSelf().First<XElement>().Remove();
                  xelement3.Remove();
                }
                TableOfContents.UpdateTOCParagraphContent(contentToUpdate, headingParagraph, document, bookmarkName);
                xelement1.Add((object) contentToUpdate);
                flag = false;
              }
            }
            PdfListItem.CleanListsInfo();
            XElement xelement6 = new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("fldChar", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("fldCharType", Xceed.Document.NET.Document.w.NamespaceName), (object) "end")));
            XElement xelement7 = new XElement(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName), (object) xelement6);
            xelement1.Add((object) xelement7);
            sdtContent.ReplaceWith((object) xelement1);
            return xelement1.Descendants(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName));
          }
        }
      }
      return (IEnumerable<XElement>) null;
    }

    internal static XElement GetPageRefInstrText(XElement element) => element == null ? (XElement) null : element.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Name == XName.Get("instrText", Xceed.Document.NET.Document.w.NamespaceName) && x.Value.Contains("PAGEREF ")));

    internal static string GetPageRefInstrTextBookmarkId(XElement element)
    {
      XElement pageRefInstrText = TableOfContents.GetPageRefInstrText(element);
      if (pageRefInstrText == null || pageRefInstrText.Value == null)
        return (string) null;
      return ((IEnumerable<string>) pageRefInstrText.Value.Split(' ')).FirstOrDefault<string>((Func<string, bool>) (w => w.StartsWith("_")));
    }

    internal static Dictionary<TableOfContentsSwitches, string> BuildTOCSwitchesDictionary(
      TableOfContentsSwitches switches,
      int maxIncludeLevel = 3)
    {
      Dictionary<TableOfContentsSwitches, string> dictionary = new Dictionary<TableOfContentsSwitches, string>();
      foreach (TableOfContentsSwitches key in Enum.GetValues(typeof (TableOfContentsSwitches)).Cast<TableOfContentsSwitches>().Where<TableOfContentsSwitches>((Func<TableOfContentsSwitches, bool>) (s => s != TableOfContentsSwitches.None && switches.HasFlag((Enum) s))))
      {
        if (key == TableOfContentsSwitches.O)
          dictionary.Add(key, "1-" + maxIncludeLevel.ToString());
        else
          dictionary.Add(key, "");
      }
      return dictionary;
    }

    private static void InitElement(string elementName, Xceed.Document.NET.Document document, string headerStyle = "")
    {
      if (elementName == "updateFields")
      {
        if (document._settings.Descendants().Any<XElement>((Func<XElement, bool>) (x => x.Name.Equals((object) (Xceed.Document.NET.Document.w + elementName)))))
          return;
        XElement xelement = new XElement(XName.Get(elementName, Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) true));
        document._settings.Root.Add((object) xelement);
      }
      else
      {
        if (!(elementName == "styles"))
          return;
        if (!TableOfContents.HasStyle(document, headerStyle, "paragraph"))
        {
          XElement xelement = XElement.Load(XmlReader.Create((TextReader) new StringReader(string.Format("\r\n        <w:style w:type='paragraph' w:styleId='{0}' xmlns:w='http://schemas.openxmlformats.org/wordprocessingml/2006/main'>\r\n            <w:name w:val='TOC Heading'/>\r\n            <w:basedOn w:val='Heading1'/>\r\n            <w:next w:val='Normal'/>\r\n            <w:uiPriority w:val='39'/>\r\n            <w:semiHidden/>\r\n            <w:unhideWhenUsed/>\r\n            <w:qFormat/>\r\n            <w:rsid w:val='00E67AA6'/>\r\n            <w:pPr>\r\n            <w:outlineLvl w:val='9'/>\r\n            </w:pPr>\r\n            <w:rPr>\r\n            <w:lang w:eastAsia='nb-NO'/>\r\n            </w:rPr>\r\n        </w:style>\r\n        ", (object) (headerStyle ?? "TOCHeading")))));
          document._styles.Root.Add((object) xelement);
        }
        if (!TableOfContents.HasStyle(document, "TOC1", "paragraph"))
        {
          XElement xelement = XElement.Load(XmlReader.Create((TextReader) new StringReader(string.Format("  \r\n        <w:style w:type='paragraph' w:styleId='{0}' xmlns:w='http://schemas.openxmlformats.org/wordprocessingml/2006/main'>\r\n            <w:name w:val='{1}' />\r\n            <w:basedOn w:val='Normal' />\r\n            <w:next w:val='Normal' />\r\n            <w:autoRedefine />\r\n            <w:uiPriority w:val='39' />\r\n            <w:unhideWhenUsed />\r\n            <w:pPr>\r\n            <w:spacing w:after='100' />\r\n            <w:ind w:left='{2}' />\r\n            </w:pPr>\r\n        </w:style>\r\n        ", (object) "TOC1", (object) "toc 1", (object) 0))));
          document._styles.Root.Add((object) xelement);
        }
        if (!TableOfContents.HasStyle(document, "TOC2", "paragraph"))
        {
          XElement xelement = XElement.Load(XmlReader.Create((TextReader) new StringReader(string.Format("  \r\n        <w:style w:type='paragraph' w:styleId='{0}' xmlns:w='http://schemas.openxmlformats.org/wordprocessingml/2006/main'>\r\n            <w:name w:val='{1}' />\r\n            <w:basedOn w:val='Normal' />\r\n            <w:next w:val='Normal' />\r\n            <w:autoRedefine />\r\n            <w:uiPriority w:val='39' />\r\n            <w:unhideWhenUsed />\r\n            <w:pPr>\r\n            <w:spacing w:after='100' />\r\n            <w:ind w:left='{2}' />\r\n            </w:pPr>\r\n        </w:style>\r\n        ", (object) "TOC2", (object) "toc 2", (object) 220))));
          document._styles.Root.Add((object) xelement);
        }
        if (!TableOfContents.HasStyle(document, "TOC3", "paragraph"))
        {
          XElement xelement = XElement.Load(XmlReader.Create((TextReader) new StringReader(string.Format("  \r\n        <w:style w:type='paragraph' w:styleId='{0}' xmlns:w='http://schemas.openxmlformats.org/wordprocessingml/2006/main'>\r\n            <w:name w:val='{1}' />\r\n            <w:basedOn w:val='Normal' />\r\n            <w:next w:val='Normal' />\r\n            <w:autoRedefine />\r\n            <w:uiPriority w:val='39' />\r\n            <w:unhideWhenUsed />\r\n            <w:pPr>\r\n            <w:spacing w:after='100' />\r\n            <w:ind w:left='{2}' />\r\n            </w:pPr>\r\n        </w:style>\r\n        ", (object) "TOC3", (object) "toc 3", (object) 440))));
          document._styles.Root.Add((object) xelement);
        }
        if (!TableOfContents.HasStyle(document, "TOC4", "paragraph"))
        {
          XElement xelement = XElement.Load(XmlReader.Create((TextReader) new StringReader(string.Format("  \r\n        <w:style w:type='paragraph' w:styleId='{0}' xmlns:w='http://schemas.openxmlformats.org/wordprocessingml/2006/main'>\r\n            <w:name w:val='{1}' />\r\n            <w:basedOn w:val='Normal' />\r\n            <w:next w:val='Normal' />\r\n            <w:autoRedefine />\r\n            <w:uiPriority w:val='39' />\r\n            <w:unhideWhenUsed />\r\n            <w:pPr>\r\n            <w:spacing w:after='100' />\r\n            <w:ind w:left='{2}' />\r\n            </w:pPr>\r\n        </w:style>\r\n        ", (object) "TOC4", (object) "toc 4", (object) 660))));
          document._styles.Root.Add((object) xelement);
        }
        if (TableOfContents.HasStyle(document, "Hyperlink", "character"))
          return;
        XElement xelement1 = XElement.Load(XmlReader.Create((TextReader) new StringReader(string.Format("  \r\n        <w:style w:type='character' w:styleId='Hyperlink' xmlns:w='http://schemas.openxmlformats.org/wordprocessingml/2006/main'>\r\n            <w:name w:val='Hyperlink' />\r\n            <w:basedOn w:val='Normal' />\r\n            <w:uiPriority w:val='99' />\r\n            <w:unhideWhenUsed />\r\n            <w:rPr>\r\n            <w:color w:val='0000FF' w:themeColor='hyperlink' />\r\n            <w:u w:val='single' />\r\n            </w:rPr>\r\n        </w:style>\r\n        "))));
        document._styles.Root.Add((object) xelement1);
      }
    }

    private static bool HasStyle(Xceed.Document.NET.Document document, string value, string type) => document._styles.Descendants().Any<XElement>((Func<XElement, bool>) (x => x.Name.Equals((object) (Xceed.Document.NET.Document.w + "style")) && (x.Attribute(Xceed.Document.NET.Document.w + nameof (type)) == null || x.Attribute(Xceed.Document.NET.Document.w + nameof (type)).Value.Equals(type)) && x.Attribute(Xceed.Document.NET.Document.w + "styleId") != null && x.Attribute(Xceed.Document.NET.Document.w + "styleId").Value.Equals(value)));

    private static string BuildSwitchString(
      IDictionary<TableOfContentsSwitches, string> switchesDictionray)
    {
      string str = "TOC";
      foreach (KeyValuePair<TableOfContentsSwitches, string> keyValuePair in (IEnumerable<KeyValuePair<TableOfContentsSwitches, string>>) switchesDictionray)
      {
        str = str + " " + keyValuePair.Key.EnumDescription();
        if (!string.IsNullOrEmpty(keyValuePair.Value) && keyValuePair.Key != TableOfContentsSwitches.H && (keyValuePair.Key != TableOfContentsSwitches.U && keyValuePair.Key != TableOfContentsSwitches.W) && (keyValuePair.Key != TableOfContentsSwitches.X && keyValuePair.Key != TableOfContentsSwitches.Z))
          str = str + " \"" + keyValuePair.Value + "\"";
      }
      return str;
    }

    private static XElement GetTOCRefInstrText(XElement element) => element == null ? (XElement) null : element.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Name == XName.Get("instrText", Xceed.Document.NET.Document.w.NamespaceName) && x.Value.Contains("TOC ")));

    private static List<Paragraph> GetHeadingParagraphs(Xceed.Document.NET.Document document)
    {
      List<Paragraph> paragraphList = new List<Paragraph>();
      IEnumerable<string> documentHeadingStyleIds = TableOfContents.GetDocumentHeadingStyleIds(document);
      if (documentHeadingStyleIds != null)
      {
        foreach (Paragraph paragraph in document.Paragraphs)
        {
          if (!string.IsNullOrEmpty(paragraph.Text) && !paragraph.IsInTOC() && documentHeadingStyleIds.Contains<string>(paragraph.StyleId))
            paragraphList.Add(paragraph);
        }
      }
      return paragraphList;
    }

    private static IEnumerable<string> GetDocumentHeadingStyleIds(Xceed.Document.NET.Document document)
    {
      if (document != null)
      {
        XElement xelement = document._styles.Element(XName.Get("styles", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement != null)
        {
          List<string> stringList = new List<string>();
          IEnumerable<XElement> xelements = xelement.Elements(XName.Get("style", Xceed.Document.NET.Document.w.NamespaceName));
          foreach (XElement style in xelements.Where<XElement>((Func<XElement, bool>) (s => s.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName)) != null && s.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName)).Value == "paragraph")))
          {
            if (TableOfContents.GetStyleOrBasedOnStyleContainingString(style, "heading", xelements) != null)
            {
              XAttribute xattribute = style.Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName));
              if (xattribute != null && !string.IsNullOrEmpty(xattribute.Value))
                stringList.Add(xattribute.Value);
            }
          }
          return (IEnumerable<string>) stringList;
        }
      }
      return (IEnumerable<string>) null;
    }

    private static XElement GetStyleOrBasedOnStyleContainingString(
      XElement style,
      string stringToFind,
      IEnumerable<XElement> styleList)
    {
      if (style == null || string.IsNullOrEmpty(stringToFind))
        return (XElement) null;
      XElement xelement1 = style.Element(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 != null)
      {
        XAttribute xattribute = xelement1.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null && !string.IsNullOrEmpty(xattribute.Value) && xattribute.Value.Contains(stringToFind))
          return style;
      }
      XElement xelement2 = style.Element(XName.Get("basedOn", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 != null)
      {
        XAttribute basedOnValue = xelement2.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        if (basedOnValue != null && !string.IsNullOrEmpty(basedOnValue.Value) && styleList != null)
          return TableOfContents.GetStyleOrBasedOnStyleContainingString(styleList.FirstOrDefault<XElement>((Func<XElement, bool>) (s => s.Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName)) != null && s.Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName)).Value == basedOnValue.Value)), stringToFind, styleList);
      }
      return (XElement) null;
    }

    private static XElement GetTOCFromDocument(Xceed.Document.NET.Document document)
    {
      if (document == null)
        return (XElement) null;
      foreach (XElement element in document.Xml.Elements(XName.Get("sdt", Xceed.Document.NET.Document.w.NamespaceName)))
      {
        XElement xelement1 = element.Element(XName.Get("sdtPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 != null)
        {
          XElement xelement2 = xelement1.Element(XName.Get("docPartObj", Xceed.Document.NET.Document.w.NamespaceName));
          if (xelement2 != null)
          {
            XElement xelement3 = xelement2.Element(XName.Get("docPartGallery", Xceed.Document.NET.Document.w.NamespaceName));
            if (xelement3 != null && xelement3.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)).Value == "Table of Contents")
              return element;
          }
        }
      }
      return (XElement) null;
    }

    private static XElement GetTOCStyledParagraphXmlFromStyleIdAndText(
      XElement sdtContent,
      string styleId,
      string text)
    {
      if (sdtContent == null || string.IsNullOrEmpty(styleId))
        return (XElement) null;
      IEnumerable<XElement> source1 = sdtContent.Elements(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName)).Where<XElement>((Func<XElement, bool>) (p => p.Descendants(XName.Get("pStyle", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>((Func<XElement, bool>) (s => s.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)).Value == styleId)) != null));
      if (source1.Count<XElement>() == 0)
        return (XElement) null;
      if (!string.IsNullOrEmpty(text))
      {
        foreach (XElement xelement in source1)
        {
          IEnumerable<XElement> source2 = xelement.Descendants(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName));
          if (source2.Count<XElement>() > 0 && string.Concat(source2.Select<XElement, string>((Func<XElement, string>) (x => x.Value))).Contains(text.Trim()))
            return xelement;
        }
      }
      return source1.FirstOrDefault<XElement>();
    }

    private static XElement GetFirstTOCStyledParagraph(
      Xceed.Document.NET.Document document,
      XElement sdtContent)
    {
      if (document == null || sdtContent == null)
        return (XElement) null;
      foreach (XElement element in sdtContent.Elements(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName)))
      {
        XElement xelement = element.Descendants(XName.Get("pStyle", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
        if (xelement != null)
        {
          XAttribute xattribute = xelement.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
          if (xattribute != null)
          {
            string styleNameFromStyleId = TableOfContents.GetStyleNameFromStyleId(document, xattribute.Value);
            if (styleNameFromStyleId.StartsWith("toc ") && char.IsDigit(styleNameFromStyleId[4]))
              return element;
          }
        }
      }
      return (XElement) null;
    }

    private static string GetTOCHeadingStyleId(Xceed.Document.NET.Document document, Paragraph headingParagraph)
    {
      string styleNameFromStyleId = TableOfContents.GetStyleNameFromStyleId(document, headingParagraph.StyleId);
      if (string.IsNullOrEmpty(styleNameFromStyleId))
        return (string) null;
      if (!styleNameFromStyleId.Contains("heading"))
      {
        IEnumerable<XElement> xelements = document._styles.Element(XName.Get("styles", Xceed.Document.NET.Document.w.NamespaceName)).Elements(XName.Get("style", Xceed.Document.NET.Document.w.NamespaceName));
        XElement containingString = TableOfContents.GetStyleOrBasedOnStyleContainingString(xelements.FirstOrDefault<XElement>((Func<XElement, bool>) (s => s.Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName)) != null && s.Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName)).Value == headingParagraph.StyleId)), "heading", xelements);
        if (containingString != null)
        {
          XElement xelement = containingString.Element(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName));
          if (xelement != null)
          {
            XAttribute xattribute = xelement.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
            if (xattribute != null)
              styleNameFromStyleId = xattribute.Value;
          }
        }
      }
      string correspondingName = TableOfContents.GetTOCHeadingCorrespondingName(styleNameFromStyleId);
      return TableOfContents.GetStyleIdFromStyleName(document, correspondingName);
    }

    private static string GetTOCHeadingCorrespondingName(string headingStyleName)
    {
      switch (headingStyleName)
      {
        case "heading 1":
          return "toc 1";
        case "heading 2":
          return "toc 2";
        case "heading 3":
          return "toc 3";
        case "heading 4":
          return "toc 4";
        case "heading 5":
          return "toc 5";
        case "heading 6":
          return "toc 6";
        default:
          return "toc 1";
      }
    }

    private static string GetStyleIdFromStyleName(Xceed.Document.NET.Document document, string styleName)
    {
      if (document == null || string.IsNullOrEmpty(styleName))
        return (string) null;
      XElement xelement = document._styles.Element(XName.Get("styles", Xceed.Document.NET.Document.w.NamespaceName)).Elements(XName.Get("style", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Element(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName)) != null && x.Element(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName)).Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)) != null && x.Element(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName)).Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)).Value.Equals(styleName)));
      if (xelement != null)
      {
        XAttribute xattribute = xelement.Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null)
          return xattribute.Value;
      }
      return (string) null;
    }

    private static string GetStyleNameFromStyleId(Xceed.Document.NET.Document document, string styleId)
    {
      if (document == null || string.IsNullOrEmpty(styleId))
        return (string) null;
      XElement xelement1 = document._styles.Element(XName.Get("styles", Xceed.Document.NET.Document.w.NamespaceName)).Elements(XName.Get("style", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Attribute(XName.Get(nameof (styleId), Xceed.Document.NET.Document.w.NamespaceName)) != null && x.Attribute(XName.Get(nameof (styleId), Xceed.Document.NET.Document.w.NamespaceName)).Value.Equals(styleId)));
      if (xelement1 != null)
      {
        XElement xelement2 = xelement1.Element(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 != null)
        {
          XAttribute xattribute = xelement2.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
          if (xattribute != null)
            return xattribute.Value;
        }
      }
      return (string) null;
    }

    private static void UpdateTOCParagraphContent(
      XElement contentToUpdate,
      Paragraph headingParagraph,
      Xceed.Document.NET.Document document,
      string bookmarkName)
    {
      if (contentToUpdate == null || headingParagraph == null || (document == null || string.IsNullOrEmpty(bookmarkName)))
        return;
      string str = " PAGEREF " + bookmarkName + " \\h ";
      contentToUpdate.Element(XName.Get("hyperlink", Xceed.Document.NET.Document.w.NamespaceName))?.SetAttributeValue(XName.Get("anchor", Xceed.Document.NET.Document.w.NamespaceName), (object) bookmarkName);
      TableOfContents.GetPageRefInstrText(contentToUpdate)?.SetValue((object) str);
      IEnumerable<XElement> xelements = contentToUpdate.Descendants(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName));
      IEnumerable<XElement> source1 = xelements.Where<XElement>((Func<XElement, bool>) (r => r.Element(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName)) != null));
      IEnumerable<XElement> source2 = source1.Select<XElement, XElement>((Func<XElement, XElement>) (r => r.Element(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName))));
      if (headingParagraph.IsListItem)
      {
        string numberFromParagraph = PdfListItem.GetListItemNumberFromParagraph(headingParagraph, document);
        if (source2.Count<XElement>() == 3)
        {
          source2.First<XElement>().SetValue((object) numberFromParagraph);
          source2.ElementAt<XElement>(1).SetValue((object) headingParagraph.Text);
        }
        else if (source2.Count<XElement>() == 2)
        {
          XElement beginRun = TableOfContents.GetBeginRun(xelements);
          if (beginRun == null)
            return;
          List<XElement> list = xelements.ToList<XElement>();
          if (list.IndexOf(beginRun) < list.IndexOf(source1.Last<XElement>()))
          {
            source2.First<XElement>().SetValue((object) (numberFromParagraph + "   " + headingParagraph.Text));
          }
          else
          {
            source2.First<XElement>().SetValue((object) numberFromParagraph);
            source2.ElementAt<XElement>(1).SetValue((object) headingParagraph.Text);
            XElement xelement = xelements.Last<XElement>();
            xelement.AddBeforeSelf((object) new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("tab", Xceed.Document.NET.Document.w.NamespaceName))));
            xelement.AddBeforeSelf((object) new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName), (object) "1")));
          }
        }
        else
          TableOfContents.UpdateContentTextsCore(numberFromParagraph + "   " + headingParagraph.Text, contentToUpdate, bookmarkName);
      }
      else if (source2.Count<XElement>() == 2)
        source2.First<XElement>().SetValue((object) headingParagraph.Text);
      else
        TableOfContents.UpdateContentTextsCore(headingParagraph.Text, contentToUpdate, bookmarkName);
    }

    private static void UpdateContentTextsCore(
      string textToUpdate,
      XElement contentToUpdate,
      string bookmarkName)
    {
      if (string.IsNullOrEmpty(textToUpdate) || contentToUpdate == null)
        return;
      IEnumerable<XElement> source1 = contentToUpdate.Descendants(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName));
      IEnumerable<XElement> source2 = source1.Where<XElement>((Func<XElement, bool>) (r => r.Element(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName)) != null)).Select<XElement, XElement>((Func<XElement, XElement>) (r => r.Element(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName))));
      if (source2.Count<XElement>() == 1)
      {
        source2.First<XElement>().SetValue((object) textToUpdate);
        XElement xelement = source1.Last<XElement>();
        xelement.AddBeforeSelf((object) new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("tab", Xceed.Document.NET.Document.w.NamespaceName))));
        xelement.AddBeforeSelf((object) new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName), (object) "1")));
      }
      else if (source2.Count<XElement>() == 0)
      {
        XElement hyperlinkWithPageNumber = TableOfContents.CreateHyperlinkWithPageNumber(bookmarkName, textToUpdate);
        if (hyperlinkWithPageNumber == null)
          return;
        contentToUpdate.Add((object) hyperlinkWithPageNumber);
      }
      else
      {
        XElement pageRefInstrText = TableOfContents.GetPageRefInstrText(contentToUpdate);
        if (pageRefInstrText == null)
          return;
        List<XElement> list = source1.ToList<XElement>();
        int num1 = list.IndexOf(pageRefInstrText.Parent);
        XElement tocRefInstrText = TableOfContents.GetTOCRefInstrText(contentToUpdate);
        int num2 = tocRefInstrText != null ? list.IndexOf(tocRefInstrText.Parent) + 1 : -1;
        bool flag = false;
        int index = num1 - 1;
        int num3 = 0;
        for (; index >= 0 && index > num2; --index)
        {
          XElement xelement1 = source1.ElementAt<XElement>(index);
          if (flag)
          {
            xelement1.Remove();
          }
          else
          {
            XElement xelement2 = xelement1.Element(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName));
            if (xelement2 != null)
            {
              xelement2.SetValue((object) textToUpdate);
              flag = true;
            }
            else if (xelement1.Element(XName.Get("tab", Xceed.Document.NET.Document.w.NamespaceName)) != null)
              ++num3;
          }
        }
        IEnumerable<XElement> source3 = contentToUpdate.Descendants(XName.Get("tabs", Xceed.Document.NET.Document.w.NamespaceName));
        if (source3.Count<XElement>() <= 0)
          return;
        IEnumerable<XElement> source4 = source3.Elements<XElement>(XName.Get("tab", Xceed.Document.NET.Document.w.NamespaceName));
        int count = source4.Count<XElement>() - num3;
        if (count <= 0)
          return;
        source4.Take<XElement>(count).Remove<XElement>();
      }
    }

    private static XElement CreateHyperlinkWithPageNumber(
      string bookmarkName,
      string content)
    {
      if (string.IsNullOrEmpty(bookmarkName) || string.IsNullOrEmpty(content))
        return (XElement) null;
      string str = " PAGEREF " + bookmarkName + " \\h ";
      XElement xelement = new XElement(XName.Get("hyperlink", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
      {
        (object) new XAttribute(XName.Get("anchor", Xceed.Document.NET.Document.w.NamespaceName), (object) bookmarkName),
        (object) new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
        {
          (object) new XElement(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("rStyle", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) "Hyperlink"))),
          (object) new XElement(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName), (object) content)
        })
      });
      xelement.Add((object) new XElement(XName.Get("tab", Xceed.Document.NET.Document.w.NamespaceName)));
      xelement.Add((object) new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("fldChar", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("fldCharType", Xceed.Document.NET.Document.w.NamespaceName), (object) "begin"))));
      xelement.Add((object) new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("instrText", Xceed.Document.NET.Document.w.NamespaceName), (object) str)));
      xelement.Add((object) new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("fldChar", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("fldCharType", Xceed.Document.NET.Document.w.NamespaceName), (object) "separate"))));
      xelement.Add((object) new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName), (object) "1")));
      xelement.Add((object) new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("fldChar", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("fldCharType", Xceed.Document.NET.Document.w.NamespaceName), (object) "end"))));
      return xelement;
    }

    private static XElement GetBeginRun(IEnumerable<XElement> runs) => runs == null ? (XElement) null : runs.FirstOrDefault<XElement>((Func<XElement, bool>) (r => r.Element(XName.Get("fldChar", Xceed.Document.NET.Document.w.NamespaceName)) != null && r.Element(XName.Get("fldChar", Xceed.Document.NET.Document.w.NamespaceName)).Attribute(XName.Get("fldCharType", Xceed.Document.NET.Document.w.NamespaceName)) != null && r.Element(XName.Get("fldChar", Xceed.Document.NET.Document.w.NamespaceName)).Attribute(XName.Get("fldCharType", Xceed.Document.NET.Document.w.NamespaceName)).Value == "begin"));

    private TableOfContents(Xceed.Document.NET.Document document, XElement xml, string headerStyle)
      : base(document, xml)
    {
      TableOfContents.InitElement("updateFields", document);
      TableOfContents.InitElement("styles", document, headerStyle);
    }
  }
}
