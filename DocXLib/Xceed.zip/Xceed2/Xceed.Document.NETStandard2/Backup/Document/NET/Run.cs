﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Run
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a Run.</summary>
  public class Run : DocumentElement
  {
    private Dictionary<int, Text> textLookup = new Dictionary<int, Text>();
    private int startIndex;
    private int endIndex;
    private string text;

    /// <summary>Gets the Start Index of this Run's text.</summary>
    public int StartIndex => this.startIndex;

    /// <summary>Gets the End Index of this Run's text.</summary>
    public int EndIndex => this.endIndex;

    internal string Value
    {
      set => this.text = value;
      get => this.text;
    }

    internal Run(Xceed.Document.NET.Document document, XElement xml, int startIndex)
      : base(document, xml)
    {
      this.startIndex = startIndex;
      IEnumerable<XElement> xelements = xml.Descendants();
      int startIndex1 = startIndex;
      foreach (XElement xml1 in xelements)
      {
        switch (xml1.Name.LocalName)
        {
          case "tab":
            this.textLookup.Add(startIndex1 + 1, new Text(this.Document, xml1, startIndex1));
            this.text += "\t";
            ++startIndex1;
            continue;
          case "br":
            if (HelperFunctions.IsLineBreak(xml1))
            {
              this.textLookup.Add(startIndex1 + 1, new Text(this.Document, xml1, startIndex1));
              this.text += "\n";
              ++startIndex1;
              continue;
            }
            continue;
          case "t":
          case "delText":
            if (xml1.Value.Length > 0)
            {
              this.textLookup.Add(startIndex1 + xml1.Value.Length, new Text(this.Document, xml1, startIndex1));
              this.text += xml1.Value;
              startIndex1 += xml1.Value.Length;
              continue;
            }
            continue;
          default:
            continue;
        }
      }
      this.endIndex = startIndex1;
    }

    internal static XElement[] SplitRun(Run r, int index, EditType type = EditType.ins)
    {
      index -= r.StartIndex;
      Text textEffectedByEdit = r.GetFirstTextEffectedByEdit(index, type);
      XElement[] xelementArray = Text.SplitText(textEffectedByEdit, index);
      XElement run1 = new XElement(r.Xml.Name, new object[4]
      {
        (object) r.Xml.Attributes(),
        (object) r.Xml.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)),
        (object) textEffectedByEdit.Xml.ElementsBeforeSelf().Where<XElement>((Func<XElement, bool>) (n => n.Name.LocalName != "rPr")),
        (object) xelementArray[0]
      });
      if (Paragraph.GetElementTextLength(run1) == 0)
        run1 = (XElement) null;
      XElement run2 = new XElement(r.Xml.Name, new object[4]
      {
        (object) r.Xml.Attributes(),
        (object) r.Xml.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)),
        (object) xelementArray[1],
        (object) textEffectedByEdit.Xml.ElementsAfterSelf().Where<XElement>((Func<XElement, bool>) (n => n.Name.LocalName != "rPr"))
      });
      if (Paragraph.GetElementTextLength(run2) == 0)
        run2 = (XElement) null;
      return new XElement[2]{ run1, run2 };
    }

    internal Text GetFirstTextEffectedByEdit(int index, EditType type = EditType.ins)
    {
      if (index < 0 || index > HelperFunctions.GetText(this.Xml).Length)
        throw new ArgumentOutOfRangeException();
      int count = 0;
      Text theOne = (Text) null;
      this.GetFirstTextEffectedByEditRecursive(this.Xml, index, ref count, ref theOne, type);
      return theOne;
    }

    internal void GetFirstTextEffectedByEditRecursive(
      XElement Xml,
      int index,
      ref int count,
      ref Text theOne,
      EditType type = EditType.ins)
    {
      count += HelperFunctions.GetSize(Xml);
      if (count > 0 && (type == EditType.del && count > index || type == EditType.ins && count >= index))
      {
        theOne = new Text(this.Document, Xml, count - HelperFunctions.GetSize(Xml));
      }
      else
      {
        if (!Xml.HasElements)
          return;
        foreach (XElement element in Xml.Elements())
        {
          if (theOne == null)
            this.GetFirstTextEffectedByEditRecursive(element, index, ref count, ref theOne);
        }
      }
    }
  }
}
