﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Cell
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a Cell in a Table.</summary>
  public class Cell : Container
  {
    internal Row _row;

    /// <summary>Gets the collection of Paragraphs in this Cell.</summary>
    public override ReadOnlyCollection<Paragraph> Paragraphs
    {
      get
      {
        ReadOnlyCollection<Paragraph> paragraphs = base.Paragraphs;
        foreach (DocumentElement documentElement in paragraphs)
          documentElement.PackagePart = this._row._table.PackagePart;
        return paragraphs;
      }
    }

    /// <summary>Gets or sets the vertical alignment of this Cell.</summary>
    public VerticalAlignment VerticalAlignment
    {
      get
      {
        XAttribute xattribute = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("vAlign", Xceed.Document.NET.Document.w.NamespaceName))?.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute == null)
          return VerticalAlignment.Top;
        try
        {
          return (VerticalAlignment) Enum.Parse(typeof (VerticalAlignment), xattribute.Value, true);
        }
        catch
        {
          xattribute.Remove();
          return VerticalAlignment.Top;
        }
      }
      set
      {
        XElement xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 == null)
        {
          this.Xml.SetElementValue(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement2 = xelement1.Element(XName.Get("vAlign", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.SetElementValue(XName.Get("vAlign", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement2 = xelement1.Element(XName.Get("vAlign", Xceed.Document.NET.Document.w.NamespaceName));
        }
        xelement2.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) value.ToString().ToLower());
      }
    }

    /// <summary>Gets or sets the color to use for the shading of this Cell.</summary>
    public Color Shading
    {
      get
      {
        XAttribute xattribute = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("shd", Xceed.Document.NET.Document.w.NamespaceName))?.Attribute(XName.Get("fill", Xceed.Document.NET.Document.w.NamespaceName));
        return xattribute == null ? Color.White : HelperFunctions.GetColorFromHtml(xattribute.Value);
      }
      set
      {
        XElement xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 == null)
        {
          this.Xml.SetElementValue(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement2 = xelement1.Element(XName.Get("shd", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.SetElementValue(XName.Get("shd", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement2 = xelement1.Element(XName.Get("shd", Xceed.Document.NET.Document.w.NamespaceName));
        }
        xelement2.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) "clear");
        xelement2.SetAttributeValue(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName), (object) "auto");
        xelement2.SetAttributeValue(XName.Get("fill", Xceed.Document.NET.Document.w.NamespaceName), (object) value.ToHex());
      }
    }

    /// <summary>Gets or sets the width of this Cell (in points).</summary>
    public double Width
    {
      get
      {
        XElement xelement = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("tcW", Xceed.Document.NET.Document.w.NamespaceName));
        XAttribute xattribute1 = xelement?.Attribute(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName));
        XAttribute xattribute2 = xelement?.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute1 == null)
          return double.NaN;
        double result;
        if (!HelperFunctions.TryParseDouble(xattribute1.Value, out result))
        {
          xattribute1.Remove();
          return double.NaN;
        }
        if (xattribute2 != null)
        {
          if (xattribute2.Value == "pct")
          {
            if (this._row._table.ColumnWidths != null)
              return result / 5000.0 * this._row._table.ColumnWidths.Sum();
          }
          else if (xattribute2.Value == "auto")
          {
            int index = this._row.Cells.FindIndex((Predicate<Cell>) (x => x.Xml == this.Xml));
            if (index >= 0 && this._row._table.ColumnWidths != null)
              return this._row._table.ColumnWidths[index];
          }
        }
        return result / 20.0;
      }
      set
      {
        XElement xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 == null)
        {
          this.Xml.SetElementValue(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement2 = xelement1.Element(XName.Get("tcW", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.SetElementValue(XName.Get("tcW", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement2 = xelement1.Element(XName.Get("tcW", Xceed.Document.NET.Document.w.NamespaceName));
        }
        if (value == -1.0)
        {
          xelement2.Remove();
        }
        else
        {
          xelement2.SetAttributeValue(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName), (object) "dxa");
          xelement2.SetAttributeValue(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName), (object) (value * 20.0).ToString((IFormatProvider) CultureInfo.InvariantCulture));
        }
      }
    }

    /// <summary>Gets or sets the left margin of this Cell (in points).</summary>
    public double MarginLeft
    {
      get
      {
        XElement xelement = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement == null)
          return double.NaN;
        XAttribute xattribute = xelement.Element(XName.Get("tcMar", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("left", Xceed.Document.NET.Document.w.NamespaceName))?.Attribute(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute == null)
          return double.NaN;
        double result;
        if (HelperFunctions.TryParseDouble(xattribute.Value, out result))
          return result / 20.0;
        xattribute.Remove();
        return double.NaN;
      }
      set
      {
        XElement xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 == null)
        {
          this.Xml.SetElementValue(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement2 = xelement1.Element(XName.Get("tcMar", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.SetElementValue(XName.Get("tcMar", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement2 = xelement1.Element(XName.Get("tcMar", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement3 = xelement2.Element(XName.Get("left", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement3 == null)
        {
          xelement2.SetElementValue(XName.Get("left", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement3 = xelement2.Element(XName.Get("left", Xceed.Document.NET.Document.w.NamespaceName));
        }
        xelement3.SetAttributeValue(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName), (object) "dxa");
        xelement3.SetAttributeValue(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName), (object) (value * 20.0).ToString((IFormatProvider) CultureInfo.InvariantCulture));
      }
    }

    /// <summary>Gets or sets the right margin of this Cell (in points).</summary>
    public double MarginRight
    {
      get
      {
        XElement xelement = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement == null)
          return double.NaN;
        XAttribute xattribute = xelement.Element(XName.Get("tcMar", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("right", Xceed.Document.NET.Document.w.NamespaceName))?.Attribute(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute == null)
          return double.NaN;
        double result;
        if (HelperFunctions.TryParseDouble(xattribute.Value, out result))
          return result / 20.0;
        xattribute.Remove();
        return double.NaN;
      }
      set
      {
        XElement xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 == null)
        {
          this.Xml.SetElementValue(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement2 = xelement1.Element(XName.Get("tcMar", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.SetElementValue(XName.Get("tcMar", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement2 = xelement1.Element(XName.Get("tcMar", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement3 = xelement2.Element(XName.Get("right", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement3 == null)
        {
          xelement2.SetElementValue(XName.Get("right", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement3 = xelement2.Element(XName.Get("right", Xceed.Document.NET.Document.w.NamespaceName));
        }
        xelement3.SetAttributeValue(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName), (object) "dxa");
        xelement3.SetAttributeValue(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName), (object) (value * 20.0).ToString((IFormatProvider) CultureInfo.InvariantCulture));
      }
    }

    /// <summary>Gets or sets the top margin of this Cell (in points).</summary>
    public double MarginTop
    {
      get
      {
        XElement xelement = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement == null)
          return double.NaN;
        XAttribute xattribute = xelement.Element(XName.Get("tcMar", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("top", Xceed.Document.NET.Document.w.NamespaceName))?.Attribute(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute == null)
          return double.NaN;
        double result;
        if (HelperFunctions.TryParseDouble(xattribute.Value, out result))
          return result / 20.0;
        xattribute.Remove();
        return double.NaN;
      }
      set
      {
        XElement xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 == null)
        {
          this.Xml.SetElementValue(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement2 = xelement1.Element(XName.Get("tcMar", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.SetElementValue(XName.Get("tcMar", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement2 = xelement1.Element(XName.Get("tcMar", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement3 = xelement2.Element(XName.Get("top", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement3 == null)
        {
          xelement2.SetElementValue(XName.Get("top", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement3 = xelement2.Element(XName.Get("top", Xceed.Document.NET.Document.w.NamespaceName));
        }
        xelement3.SetAttributeValue(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName), (object) "dxa");
        xelement3.SetAttributeValue(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName), (object) (value * 20.0).ToString((IFormatProvider) CultureInfo.InvariantCulture));
      }
    }

    /// <summary>Gets or sets the bottom margin of this Cell (in points).</summary>
    public double MarginBottom
    {
      get
      {
        XElement xelement = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement == null)
          return double.NaN;
        XAttribute xattribute = xelement.Element(XName.Get("tcMar", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("bottom", Xceed.Document.NET.Document.w.NamespaceName))?.Attribute(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute == null)
          return double.NaN;
        double result;
        if (HelperFunctions.TryParseDouble(xattribute.Value, out result))
          return result / 20.0;
        xattribute.Remove();
        return double.NaN;
      }
      set
      {
        XElement xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 == null)
        {
          this.Xml.SetElementValue(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement2 = xelement1.Element(XName.Get("tcMar", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.SetElementValue(XName.Get("tcMar", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement2 = xelement1.Element(XName.Get("tcMar", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement3 = xelement2.Element(XName.Get("bottom", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement3 == null)
        {
          xelement2.SetElementValue(XName.Get("bottom", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement3 = xelement2.Element(XName.Get("bottom", Xceed.Document.NET.Document.w.NamespaceName));
        }
        xelement3.SetAttributeValue(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName), (object) "dxa");
        xelement3.SetAttributeValue(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName), (object) (value * 20.0).ToString((IFormatProvider) CultureInfo.InvariantCulture));
      }
    }

    /// <summary>Gets or sets the color to use to fill the background of this Cell.</summary>
    public Color FillColor
    {
      get
      {
        XAttribute xattribute = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("shd", Xceed.Document.NET.Document.w.NamespaceName))?.Attribute(XName.Get("fill", Xceed.Document.NET.Document.w.NamespaceName));
        return xattribute == null ? Color.Empty : Color.FromArgb(int.Parse(xattribute.Value.Replace("#", ""), NumberStyles.HexNumber));
      }
      set
      {
        XElement xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 == null)
        {
          this.Xml.SetElementValue(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement2 = xelement1.Element(XName.Get("shd", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.SetElementValue(XName.Get("shd", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement2 = xelement1.Element(XName.Get("shd", Xceed.Document.NET.Document.w.NamespaceName));
        }
        xelement2.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) "clear");
        xelement2.SetAttributeValue(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName), (object) "auto");
        xelement2.SetAttributeValue(XName.Get("fill", Xceed.Document.NET.Document.w.NamespaceName), (object) value.ToHex());
      }
    }

    /// <summary>Gets or sets the direction for the text in this Cell.</summary>
    public TextDirection TextDirection
    {
      get
      {
        XAttribute xattribute = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("textDirection", Xceed.Document.NET.Document.w.NamespaceName))?.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null)
        {
          TextDirection result;
          if (Enum.TryParse<TextDirection>(xattribute.Value, out result))
            return result;
          xattribute.Remove();
        }
        return TextDirection.right;
      }
      set
      {
        XName name1 = XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName);
        XName name2 = XName.Get("textDirection", Xceed.Document.NET.Document.w.NamespaceName);
        XElement xelement1 = this.Xml.Element(name1);
        if (xelement1 == null)
        {
          this.Xml.SetElementValue(name1, (object) string.Empty);
          xelement1 = this.Xml.Element(name1);
        }
        XElement xelement2 = xelement1.Element(name2);
        if (xelement2 == null)
        {
          xelement1.SetElementValue(name2, (object) string.Empty);
          xelement2 = xelement1.Element(name2);
        }
        xelement2.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) value.ToString());
      }
    }

    /// <summary>Gets the grid span of this cell (how many cells are merged).</summary>
    public int GridSpan
    {
      get
      {
        int num = 0;
        XElement xelement = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("gridSpan", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement != null)
        {
          XAttribute xattribute = xelement.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
          int result;
          if (xattribute != null && HelperFunctions.TryParseInt(xattribute.Value, out result))
            num = result;
        }
        return num;
      }
    }

    /// <summary>
    ///   <span id="BugEvents">Gets the number of cells vertically merged, starting from the current cell.</span>
    /// </summary>
    public int RowSpan
    {
      get
      {
        int num = 0;
        XElement xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("vMerge", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 != null)
        {
          XAttribute xattribute1 = xelement1.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
          if (xattribute1 != null && xattribute1.Value == "restart")
          {
            List<Row> rows = this._row._table.Rows;
            int index1 = rows.FindIndex((Predicate<Row>) (row => row.Xml == this._row.Xml));
            int index2 = this._row.Cells.FindIndex((Predicate<Cell>) (cell => cell.Xml == this.Xml));
            if (index1 >= 0 && index2 >= 0)
            {
              num = 1;
              for (int index3 = index1 + 1; index3 < rows.Count; ++index3)
              {
                XElement xelement2 = rows[index3].Cells[index2].Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("vMerge", Xceed.Document.NET.Document.w.NamespaceName));
                if (xelement2 != null)
                {
                  XAttribute xattribute2 = xelement2.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
                  if (xattribute2 == null || !(xattribute2.Value == "restart"))
                    ++num;
                  else
                    break;
                }
                else
                  break;
              }
            }
          }
        }
        return num;
      }
    }

    internal Cell(Row row, Xceed.Document.NET.Document document, XElement xml)
      : base(document, xml)
    {
      this._row = row;
      this.PackagePart = row.PackagePart;
    }

    /// <summary>Sets the Border on this Cell.</summary>
    /// <param name="borderType">A TableCellBorderType value representing the
    /// type of border to set.</param>
    /// <param name="border">The Border to set.</param>
    public void SetBorder(TableCellBorderType borderType, Border border)
    {
      XElement xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 == null)
      {
        this.Xml.SetElementValue(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
        xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
      }
      XElement xelement2 = xelement1.Element(XName.Get("tcBorders", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 == null)
      {
        xelement1.SetElementValue(XName.Get("tcBorders", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
        xelement2 = xelement1.Element(XName.Get("tcBorders", Xceed.Document.NET.Document.w.NamespaceName));
      }
      string str1 = borderType.ToString();
      string localName;
      switch (borderType)
      {
        case TableCellBorderType.TopLeftToBottomRight:
          localName = "tl2br";
          break;
        case TableCellBorderType.TopRightToBottomLeft:
          localName = "tr2bl";
          break;
        default:
          localName = str1.Substring(0, 1).ToLower() + str1.Substring(1);
          break;
      }
      XElement xelement3 = xelement2.Element(XName.Get(borderType.ToString(), Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement3 == null)
      {
        xelement2.SetElementValue(XName.Get(localName, Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
        xelement3 = xelement2.Element(XName.Get(localName, Xceed.Document.NET.Document.w.NamespaceName));
      }
      string str2 = border.Tcbs.ToString().Substring(5);
      string str3 = str2.Substring(0, 1).ToLower() + str2.Substring(1);
      xelement3.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) str3);
      int num;
      switch (border.Size)
      {
        case BorderSize.one:
          num = 2;
          break;
        case BorderSize.two:
          num = 4;
          break;
        case BorderSize.three:
          num = 6;
          break;
        case BorderSize.four:
          num = 8;
          break;
        case BorderSize.five:
          num = 12;
          break;
        case BorderSize.six:
          num = 18;
          break;
        case BorderSize.seven:
          num = 24;
          break;
        case BorderSize.eight:
          num = 36;
          break;
        case BorderSize.nine:
          num = 48;
          break;
        default:
          num = 2;
          break;
      }
      xelement3.SetAttributeValue(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName), (object) num.ToString());
      xelement3.SetAttributeValue(XName.Get("space", Xceed.Document.NET.Document.w.NamespaceName), (object) border.Space.ToString());
      xelement3.SetAttributeValue(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName), (object) border.Color.ToHex());
    }

    /// <summary>Gets the Border of this Cell.</summary>
    /// <returns>The Border of the Cell.</returns>
    /// <param name="borderType">A TableCellBorderType value representing the type of border to get.</param>
    public Border GetBorder(TableCellBorderType borderType)
    {
      Border border = new Border();
      XElement xelement1 = this.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 == null)
        return border;
      XElement xelement2 = xelement1.Element(XName.Get("tcBorders", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 == null)
        return border;
      string str1 = borderType.ToString();
      string localName;
      if (str1 != null)
      {
        if (!(str1 == "TopLeftToBottomRight"))
        {
          if (str1 == "TopRightToBottomLeft")
          {
            localName = "tr2bl";
            goto label_10;
          }
        }
        else
        {
          localName = "tl2br";
          goto label_10;
        }
      }
      localName = str1.Substring(0, 1).ToLower() + str1.Substring(1);
label_10:
      XElement xelement3 = xelement2.Element(XName.Get(localName, Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement3 == null)
        return border;
      XAttribute xattribute1 = xelement3.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute1 != null)
      {
        try
        {
          string str2 = "Tcbs_" + xattribute1.Value;
          border.Tcbs = (BorderStyle) Enum.Parse(typeof (BorderStyle), str2);
        }
        catch
        {
          xattribute1.Remove();
        }
      }
      XAttribute xattribute2 = xelement3.Attribute(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute2 != null)
      {
        int result;
        if (!HelperFunctions.TryParseInt(xattribute2.Value, out result))
        {
          xattribute2.Remove();
        }
        else
        {
          switch (result)
          {
            case 2:
              border.Size = BorderSize.one;
              break;
            case 4:
              border.Size = BorderSize.two;
              break;
            case 6:
              border.Size = BorderSize.three;
              break;
            case 8:
              border.Size = BorderSize.four;
              break;
            case 12:
              border.Size = BorderSize.five;
              break;
            case 18:
              border.Size = BorderSize.six;
              break;
            case 24:
              border.Size = BorderSize.seven;
              break;
            case 36:
              border.Size = BorderSize.eight;
              break;
            case 48:
              border.Size = BorderSize.nine;
              break;
            default:
              border.Size = BorderSize.one;
              break;
          }
        }
      }
      XAttribute xattribute3 = xelement3.Attribute(XName.Get("space", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute3 != null)
      {
        float result;
        if (!HelperFunctions.TryParseFloat(xattribute3.Value, out result))
          xattribute3.Remove();
        else
          border.Space = result;
      }
      XAttribute xattribute4 = xelement3.Attribute(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute4 != null)
      {
        try
        {
          border.Color = HelperFunctions.GetColorFromHtml(xattribute4.Value);
        }
        catch
        {
          xattribute4.Remove();
        }
      }
      return border;
    }

    /// <summary>Inserts a Table in this Cell.</summary>
    /// <returns>A reference to the newly created Table.</returns>
    /// <param name="rowCount">The number of rows.</param>
    /// <param name="columnCount">The number of columns.</param>
    public override Table InsertTable(int rowCount, int columnCount)
    {
      Table table = base.InsertTable(rowCount, columnCount);
      table.PackagePart = this.PackagePart;
      this.InsertParagraph();
      return table;
    }

    public override Table InsertTable(Table t)
    {
      Table table = base.InsertTable(t);
      table.PackagePart = this.PackagePart;
      this.InsertParagraph();
      return table;
    }
  }
}
