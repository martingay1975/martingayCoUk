﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Formatting
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Drawing;
using System.Globalization;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a group of formatting options that can be applied to text.</summary>
  public class Formatting : IComparable
  {
    private XElement _rPr;
    private bool? _hidden;
    private bool? _bold;
    private bool? _italic;
    private Xceed.Document.NET.StrikeThrough? _strikethrough;
    private Xceed.Document.NET.Script? _script;
    private Xceed.Document.NET.Highlight? _highlight;
    private Color? _shading;
    private Border _border;
    private double? _size;
    private Color? _fontColor;
    private Color? _underlineColor;
    private Xceed.Document.NET.UnderlineStyle? _underlineStyle;
    private Xceed.Document.NET.Misc? _misc;
    private Xceed.Document.NET.CapsStyle? _capsStyle;
    private Font _fontFamily;
    private float? _percentageScale;
    private float? _kerning;
    private float? _position;
    private double? _spacing;
    private string _styleId;
    private CultureInfo _language;

    /// <summary>Initializes a new instance of the <strong>Formatting</strong> class.</summary>
    public Formatting()
    {
      Licenser.VerifyLicense();
      this._language = CultureInfo.CurrentCulture;
      this._rPr = new XElement(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
    }

    /// <summary>Gets or sets the Language applied in this Formatting.</summary>
    public CultureInfo Language
    {
      get => this._language;
      set => this._language = value;
    }

    /// <summary>Gets or sets if the Bold format is applied in this Formatting.</summary>
    public bool? Bold
    {
      get => this._bold;
      set => this._bold = value;
    }

    /// <summary>Gets or sets if the Italic format is applied in this Formatting.</summary>
    public bool? Italic
    {
      get => this._italic;
      set => this._italic = value;
    }

    /// <summary>Gets or sets the StrikeThrough format applied in this Formatting.</summary>
    public Xceed.Document.NET.StrikeThrough? StrikeThrough
    {
      get => this._strikethrough;
      set => this._strikethrough = value;
    }

    /// <summary>Gets or sets the Script format applied in this Formatting.</summary>
    public Xceed.Document.NET.Script? Script
    {
      get => this._script;
      set => this._script = value;
    }

    /// <summary>Gets or sets the Size applied in this Formatting (in points).</summary>
    public double? Size
    {
      get => this._size;
      set
      {
        double? nullable1 = value;
        double num1 = 2.0;
        double? nullable2 = nullable1.HasValue ? new double?(nullable1.GetValueOrDefault() * num1) : new double?();
        double? nullable3 = nullable2;
        double num2 = (double) (int) nullable2.Value;
        double? nullable4 = nullable3.HasValue ? new double?(nullable3.GetValueOrDefault() - num2) : new double?();
        double num3 = 0.0;
        if (nullable4.GetValueOrDefault() == num3 & nullable4.HasValue)
        {
          nullable4 = value;
          double num4 = 0.0;
          if (nullable4.GetValueOrDefault() > num4 & nullable4.HasValue)
          {
            nullable4 = value;
            double num5 = 1639.0;
            if (nullable4.GetValueOrDefault() < num5 & nullable4.HasValue)
            {
              this._size = value;
              return;
            }
          }
          throw new ArgumentException(nameof (Size), "Value must be in the range 0 - 1638");
        }
        throw new ArgumentException(nameof (Size), "Value must be either a whole or half number, examples: 32, 32.5");
      }
    }

    /// <summary>Gets or sets the Percentage Scale applied in this Formatting.</summary>
    public float? PercentageScale
    {
      get => this._percentageScale;
      set
      {
        if (!value.HasValue)
        {
          this._percentageScale = new float?();
        }
        else
        {
          float? nullable = value;
          float num1 = 1f;
          if ((double) nullable.GetValueOrDefault() >= (double) num1 & nullable.HasValue)
          {
            nullable = value;
            float num2 = 600f;
            if ((double) nullable.GetValueOrDefault() <= (double) num2 & nullable.HasValue)
            {
              this._percentageScale = value;
              return;
            }
          }
          throw new ArgumentException(nameof (PercentageScale), "Value must be in the range 1 - 600");
        }
      }
    }

    /// <summary>Gets or sets the Kerning applied in this Formatting.</summary>
    public float? Kerning
    {
      get => this._kerning;
      set => this._kerning = value;
    }

    /// <summary>Gets or sets the Position applied in this Formatting.</summary>
    public float? Position
    {
      get => this._position;
      set
      {
        float? nullable1 = value;
        float num1 = -1585f;
        if ((double) nullable1.GetValueOrDefault() > (double) num1 & nullable1.HasValue)
        {
          float? nullable2 = value;
          float num2 = 1585f;
          if ((double) nullable2.GetValueOrDefault() < (double) num2 & nullable2.HasValue)
          {
            this._position = value;
            return;
          }
        }
        throw new ArgumentOutOfRangeException(nameof (Position), "Value must be in the range -1585 - 1585");
      }
    }

    /// <summary>Gets or sets the text Spacing applied in this Formatting (in points).</summary>
    public double? Spacing
    {
      get => this._spacing;
      set
      {
        double? nullable1 = value;
        double num1 = 20.0;
        double? nullable2 = nullable1.HasValue ? new double?(nullable1.GetValueOrDefault() * num1) : new double?();
        double? nullable3 = nullable2;
        double num2 = (double) (int) nullable2.Value;
        double? nullable4 = nullable3.HasValue ? new double?(nullable3.GetValueOrDefault() - num2) : new double?();
        double num3 = 0.0;
        if (nullable4.GetValueOrDefault() == num3 & nullable4.HasValue)
        {
          nullable4 = value;
          double num4 = -1585.0;
          if (nullable4.GetValueOrDefault() > num4 & nullable4.HasValue)
          {
            nullable4 = value;
            double num5 = 1585.0;
            if (nullable4.GetValueOrDefault() < num5 & nullable4.HasValue)
            {
              this._spacing = value;
              return;
            }
          }
          throw new ArgumentException(nameof (Spacing), "Value must be in the range: -1584 - 1584");
        }
        throw new ArgumentException(nameof (Spacing), "Value must be either a whole or acurate to one decimal, examples: 32, 32.1, 32.2, 32.9");
      }
    }

    /// <summary>Gets or sets the Font Color applied in this Formatting.</summary>
    public Color? FontColor
    {
      get => this._fontColor;
      set => this._fontColor = value;
    }

    /// <summary>Gets or sets the Highlight Color applied in this Formatting.</summary>
    public Xceed.Document.NET.Highlight? Highlight
    {
      get => this._highlight;
      set => this._highlight = value;
    }

    /// <summary>
    ///   <span id="BugEvents">Gets or sets the color for the shading of the text.</span>
    /// </summary>
    public Color? Shading
    {
      get => this._shading;
      set => this._shading = value;
    }

    /// <summary>Gets or sets the Border applied in this Formatting.</summary>
    public Border Border
    {
      get => this._border;
      set => this._border = value;
    }

    [Obsolete("This property is obsolete and should no longer be used. Use StyleId instead.")]
    public string StyleName
    {
      get => this._styleId;
      set => this._styleId = value;
    }

    /// <summary>
    ///   <span id="BugEvents">Gets or sets the id of the style for this formatting.</span>
    /// </summary>
    public string StyleId
    {
      get => this._styleId;
      set => this._styleId = value;
    }

    /// <summary>Gets or sets the Underline Style applied in this Formatting.</summary>
    public Xceed.Document.NET.UnderlineStyle? UnderlineStyle
    {
      get => this._underlineStyle;
      set => this._underlineStyle = value;
    }

    /// <summary>Gets or sets the Underline Color applied in this Formatting.</summary>
    public Color? UnderlineColor
    {
      get => this._underlineColor;
      set => this._underlineColor = value;
    }

    /// <summary>Gets or sets the Misc settings applied in this Formatting.</summary>
    public Xceed.Document.NET.Misc? Misc
    {
      get => this._misc;
      set => this._misc = value;
    }

    /// <summary>Gets or sets if the text is Hidden in this Formatting.</summary>
    public bool? Hidden
    {
      get => this._hidden;
      set => this._hidden = value;
    }

    /// <summary>Gets or sets the CapsStyle applied in this Formatting.</summary>
    public Xceed.Document.NET.CapsStyle? CapsStyle
    {
      get => this._capsStyle;
      set => this._capsStyle = value;
    }

    /// <summary>Gets or sets the Font Family applied in this Formatting.</summary>
    public Font FontFamily
    {
      get => this._fontFamily;
      set => this._fontFamily = value;
    }

    internal XElement Xml
    {
      get
      {
        this._rPr = new XElement(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (this._language != null)
          this._rPr.Add((object) new XElement(XName.Get("lang", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) this._language.Name)));
        if (this._spacing.HasValue)
          this._rPr.Add((object) new XElement(XName.Get("spacing", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) (this._spacing.Value * 20.0))));
        if (!string.IsNullOrEmpty(this._styleId))
          this._rPr.Add((object) new XElement(XName.Get("rStyle", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) this._styleId)));
        if (this._position.HasValue)
          this._rPr.Add((object) new XElement(XName.Get("position", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) (float) ((double) this._position.Value * 2.0))));
        if (this._kerning.HasValue)
          this._rPr.Add((object) new XElement(XName.Get("kern", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) (float) ((double) this._kerning.Value * 2.0))));
        if (this._percentageScale.HasValue)
          this._rPr.Add((object) new XElement(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) this._percentageScale)));
        if (this._fontFamily != null)
          this._rPr.Add((object) new XElement(XName.Get("rFonts", Xceed.Document.NET.Document.w.NamespaceName), new object[4]
          {
            (object) new XAttribute(XName.Get("ascii", Xceed.Document.NET.Document.w.NamespaceName), (object) this._fontFamily.Name),
            (object) new XAttribute(XName.Get("hAnsi", Xceed.Document.NET.Document.w.NamespaceName), (object) this._fontFamily.Name),
            (object) new XAttribute(XName.Get("cs", Xceed.Document.NET.Document.w.NamespaceName), (object) this._fontFamily.Name),
            (object) new XAttribute(XName.Get("eastAsia", Xceed.Document.NET.Document.w.NamespaceName), (object) this._fontFamily.Name)
          }));
        if (this._hidden.HasValue && this._hidden.Value)
          this._rPr.Add((object) new XElement(XName.Get("vanish", Xceed.Document.NET.Document.w.NamespaceName)));
        if (this._bold.HasValue && this._bold.Value)
          this._rPr.Add((object) new XElement(XName.Get("b", Xceed.Document.NET.Document.w.NamespaceName)));
        if (this._italic.HasValue && this._italic.Value)
          this._rPr.Add((object) new XElement(XName.Get("i", Xceed.Document.NET.Document.w.NamespaceName)));
        Xceed.Document.NET.UnderlineStyle? underlineStyle1;
        if (this._underlineStyle.HasValue)
        {
          underlineStyle1 = this._underlineStyle;
          if (underlineStyle1.HasValue)
          {
            switch (underlineStyle1.GetValueOrDefault())
            {
              case Xceed.Document.NET.UnderlineStyle.none:
                goto label_26;
              case Xceed.Document.NET.UnderlineStyle.singleLine:
                this._rPr.Add((object) new XElement(XName.Get("u", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) "single")));
                goto label_26;
              case Xceed.Document.NET.UnderlineStyle.doubleLine:
                this._rPr.Add((object) new XElement(XName.Get("u", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) "double")));
                goto label_26;
            }
          }
          this._rPr.Add((object) new XElement(XName.Get("u", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) this._underlineStyle.ToString())));
        }
label_26:
        if (this._underlineColor.HasValue)
        {
          if (this._underlineStyle.HasValue)
          {
            underlineStyle1 = this._underlineStyle;
            Xceed.Document.NET.UnderlineStyle underlineStyle2 = Xceed.Document.NET.UnderlineStyle.none;
            if (!(underlineStyle1.GetValueOrDefault() == underlineStyle2 & underlineStyle1.HasValue))
              goto label_30;
          }
          this._underlineStyle = new Xceed.Document.NET.UnderlineStyle?(Xceed.Document.NET.UnderlineStyle.singleLine);
          this._rPr.Add((object) new XElement(XName.Get("u", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) "single")));
label_30:
          this._rPr.Element(XName.Get("u", Xceed.Document.NET.Document.w.NamespaceName)).Add((object) new XAttribute(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName), (object) this._underlineColor.Value.ToHex()));
        }
        if (this._strikethrough.HasValue)
        {
          Xceed.Document.NET.StrikeThrough? strikethrough = this._strikethrough;
          if (strikethrough.HasValue)
          {
            switch (strikethrough.GetValueOrDefault())
            {
              case Xceed.Document.NET.StrikeThrough.strike:
                this._rPr.Add((object) new XElement(XName.Get("strike", Xceed.Document.NET.Document.w.NamespaceName)));
                break;
              case Xceed.Document.NET.StrikeThrough.doubleStrike:
                this._rPr.Add((object) new XElement(XName.Get("dstrike", Xceed.Document.NET.Document.w.NamespaceName)));
                break;
            }
          }
        }
        if (this._script.HasValue)
        {
          Xceed.Document.NET.Script? script = this._script;
          if (!script.HasValue || script.GetValueOrDefault() != Xceed.Document.NET.Script.none)
            this._rPr.Add((object) new XElement(XName.Get("vertAlign", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) this._script.ToString())));
        }
        if (this._size.HasValue)
        {
          XElement rPr1 = this._rPr;
          XName name1 = XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName);
          XName name2 = XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName);
          double? size = this._size;
          double num1 = 2.0;
          string str1 = (size.HasValue ? new double?(size.GetValueOrDefault() * num1) : new double?()).ToString();
          XAttribute xattribute1 = new XAttribute(name2, (object) str1);
          XElement xelement1 = new XElement(name1, (object) xattribute1);
          rPr1.Add((object) xelement1);
          XElement rPr2 = this._rPr;
          XName name3 = XName.Get("szCs", Xceed.Document.NET.Document.w.NamespaceName);
          XName name4 = XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName);
          size = this._size;
          double num2 = 2.0;
          string str2 = (size.HasValue ? new double?(size.GetValueOrDefault() * num2) : new double?()).ToString();
          XAttribute xattribute2 = new XAttribute(name4, (object) str2);
          XElement xelement2 = new XElement(name3, (object) xattribute2);
          rPr2.Add((object) xelement2);
        }
        if (this._fontColor.HasValue)
          this._rPr.Add((object) new XElement(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) this._fontColor.Value.ToHex())));
        if (this._highlight.HasValue)
        {
          Xceed.Document.NET.Highlight? highlight = this._highlight;
          if (!highlight.HasValue || highlight.GetValueOrDefault() != Xceed.Document.NET.Highlight.none)
            this._rPr.Add((object) new XElement(XName.Get("highlight", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) this._highlight.ToString())));
        }
        if (this._shading.HasValue)
          this._rPr.Add((object) new XElement(XName.Get("shd", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("fill", Xceed.Document.NET.Document.w.NamespaceName), (object) this._shading.Value.ToHex())));
        if (this._border != null)
          this._rPr.Add((object) new XElement(XName.Get("bdr", Xceed.Document.NET.Document.w.NamespaceName), new object[4]
          {
            (object) new XAttribute(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName), (object) this._border.Color),
            (object) new XAttribute(XName.Get("space", Xceed.Document.NET.Document.w.NamespaceName), (object) this._border.Space),
            (object) new XAttribute(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName), (object) this._border.Size),
            (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) this._border.Tcbs)
          }));
        if (this._capsStyle.HasValue)
        {
          Xceed.Document.NET.CapsStyle? capsStyle = this._capsStyle;
          if (!capsStyle.HasValue || capsStyle.GetValueOrDefault() != Xceed.Document.NET.CapsStyle.none)
            this._rPr.Add((object) new XElement(XName.Get(this._capsStyle.ToString(), Xceed.Document.NET.Document.w.NamespaceName)));
        }
        if (this._misc.HasValue)
        {
          Xceed.Document.NET.Misc? misc = this._misc;
          if (misc.HasValue)
          {
            switch (misc.GetValueOrDefault())
            {
              case Xceed.Document.NET.Misc.none:
                goto label_59;
              case Xceed.Document.NET.Misc.outlineShadow:
                this._rPr.Add((object) new XElement(XName.Get("outline", Xceed.Document.NET.Document.w.NamespaceName)));
                this._rPr.Add((object) new XElement(XName.Get("shadow", Xceed.Document.NET.Document.w.NamespaceName)));
                goto label_59;
              case Xceed.Document.NET.Misc.engrave:
                this._rPr.Add((object) new XElement(XName.Get("imprint", Xceed.Document.NET.Document.w.NamespaceName)));
                goto label_59;
            }
          }
          this._rPr.Add((object) new XElement(XName.Get(this._misc.ToString(), Xceed.Document.NET.Document.w.NamespaceName)));
        }
label_59:
        return this._rPr;
      }
    }

    /// <summary>Creates a clone of this Formatting instance.</summary>
    public Formatting Clone()
    {
      Formatting formatting = new Formatting();
      formatting.Bold = this._bold;
      formatting.CapsStyle = this._capsStyle;
      formatting.FontColor = this._fontColor;
      formatting.FontFamily = this._fontFamily;
      formatting.Hidden = this._hidden;
      formatting.Highlight = this._highlight;
      formatting.Shading = this._shading;
      formatting.Border = this._border;
      formatting.Italic = this._italic;
      if (this._kerning.HasValue)
        formatting.Kerning = this._kerning;
      formatting.Language = this._language;
      formatting.Misc = this._misc;
      if (this._percentageScale.HasValue)
        formatting.PercentageScale = this._percentageScale;
      if (this._position.HasValue)
        formatting.Position = this._position;
      formatting.Script = this._script;
      if (this._size.HasValue)
        formatting.Size = this._size;
      if (this._spacing.HasValue)
        formatting.Spacing = this._spacing;
      if (!string.IsNullOrEmpty(this._styleId))
        formatting.StyleId = this._styleId;
      formatting.StrikeThrough = this._strikethrough;
      formatting.UnderlineColor = this._underlineColor;
      formatting.UnderlineStyle = this._underlineStyle;
      return formatting;
    }

    /// <summary>Creates a Formatting object using the provided XElement, and base Formatting if any.</summary>
    /// <returns>A Formatting object.</returns>
    /// <param name="rPr">The XElement that contains the options to use for the Formatting object.</param>
    /// <param name="formatting">
    ///   <span id="BugEvents">The base Formatting object to use, if any. By default, <strong>null</strong>.</span>
    /// </param>
    public static Formatting Parse(XElement rPr, Formatting formatting = null)
    {
      if (formatting == null)
        formatting = new Formatting();
      if (rPr == null)
        return formatting;
      foreach (XElement element in rPr.Elements())
      {
        string localName = element.Name.LocalName;
        if (localName != null)
        {
          // ISSUE: reference to a compiler-generated method
          switch (\u003CPrivateImplementationDetails\u003E.ComputeStringHash(localName))
          {
            case 480244007:
              if (localName == "highlight")
              {
                switch (element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)))
                {
                  case "black":
                    formatting.Highlight = new Xceed.Document.NET.Highlight?(Xceed.Document.NET.Highlight.black);
                    continue;
                  case "blue":
                    formatting.Highlight = new Xceed.Document.NET.Highlight?(Xceed.Document.NET.Highlight.blue);
                    continue;
                  case "cyan":
                    formatting.Highlight = new Xceed.Document.NET.Highlight?(Xceed.Document.NET.Highlight.cyan);
                    continue;
                  case "darkBlue":
                    formatting.Highlight = new Xceed.Document.NET.Highlight?(Xceed.Document.NET.Highlight.darkBlue);
                    continue;
                  case "darkCyan":
                    formatting.Highlight = new Xceed.Document.NET.Highlight?(Xceed.Document.NET.Highlight.darkCyan);
                    continue;
                  case "darkGray":
                    formatting.Highlight = new Xceed.Document.NET.Highlight?(Xceed.Document.NET.Highlight.darkGray);
                    continue;
                  case "darkGreen":
                    formatting.Highlight = new Xceed.Document.NET.Highlight?(Xceed.Document.NET.Highlight.darkGreen);
                    continue;
                  case "darkMagenta":
                    formatting.Highlight = new Xceed.Document.NET.Highlight?(Xceed.Document.NET.Highlight.darkMagenta);
                    continue;
                  case "darkRed":
                    formatting.Highlight = new Xceed.Document.NET.Highlight?(Xceed.Document.NET.Highlight.darkRed);
                    continue;
                  case "darkYellow":
                    formatting.Highlight = new Xceed.Document.NET.Highlight?(Xceed.Document.NET.Highlight.darkYellow);
                    continue;
                  case "green":
                    formatting.Highlight = new Xceed.Document.NET.Highlight?(Xceed.Document.NET.Highlight.green);
                    continue;
                  case "lightGray":
                    formatting.Highlight = new Xceed.Document.NET.Highlight?(Xceed.Document.NET.Highlight.lightGray);
                    continue;
                  case "magenta":
                    formatting.Highlight = new Xceed.Document.NET.Highlight?(Xceed.Document.NET.Highlight.magenta);
                    continue;
                  case "red":
                    formatting.Highlight = new Xceed.Document.NET.Highlight?(Xceed.Document.NET.Highlight.red);
                    continue;
                  case "yellow":
                    formatting.Highlight = new Xceed.Document.NET.Highlight?(Xceed.Document.NET.Highlight.yellow);
                    continue;
                  default:
                    formatting.Highlight = new Xceed.Document.NET.Highlight?(Xceed.Document.NET.Highlight.none);
                    continue;
                }
              }
              else
                continue;
            case 632598351:
              if (localName == "strike")
              {
                formatting.StrikeThrough = new Xceed.Document.NET.StrikeThrough?(element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)) == "0" ? Xceed.Document.NET.StrikeThrough.none : Xceed.Document.NET.StrikeThrough.strike);
                continue;
              }
              continue;
            case 815960553:
              if (localName == "rFonts")
              {
                string name = element.GetAttribute(XName.Get("ascii", Xceed.Document.NET.Document.w.NamespaceName), (string) null) ?? element.GetAttribute(XName.Get("hAnsi", Xceed.Document.NET.Document.w.NamespaceName), (string) null) ?? element.GetAttribute(XName.Get("cs", Xceed.Document.NET.Document.w.NamespaceName), (string) null) ?? element.GetAttribute(XName.Get("hint", Xceed.Document.NET.Document.w.NamespaceName), (string) null) ?? element.GetAttribute(XName.Get("eastAsia", Xceed.Document.NET.Document.w.NamespaceName), (string) null);
                formatting.FontFamily = name != null ? new Font(name) : (formatting.FontFamily == null ? new Font(Xceed.Pdf.Layout.Text.Text.DefaultStyle.Font.get_FontFamily().get_Name()) : formatting.FontFamily);
                continue;
              }
              continue;
            case 1031692888:
              if (localName == "color")
              {
                try
                {
                  string attribute = element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
                  formatting.FontColor = new Color?(attribute == "auto" ? Color.Black : HelperFunctions.GetColorFromHtml(attribute));
                  continue;
                }
                catch (Exception ex)
                {
                  continue;
                }
              }
              else
                continue;
            case 1091859373:
              if (localName == "smallCaps")
              {
                formatting.CapsStyle = new Xceed.Document.NET.CapsStyle?(element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)) == "0" ? Xceed.Document.NET.CapsStyle.none : Xceed.Document.NET.CapsStyle.smallCaps);
                continue;
              }
              continue;
            case 1297229160:
              if (localName == "sz")
              {
                formatting.Size = new double?(double.Parse(element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName))) / 2.0);
                continue;
              }
              continue;
            case 1622187699:
              if (localName == "bdr")
              {
                formatting.Border = HelperFunctions.GetBorderFromXml(element);
                continue;
              }
              continue;
            case 1894398805:
              if (localName == "lang")
              {
                string name = element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (string) null) ?? element.GetAttribute(XName.Get("eastAsia", Xceed.Document.NET.Document.w.NamespaceName), (string) null) ?? element.GetAttribute(XName.Get("bidi", Xceed.Document.NET.Document.w.NamespaceName));
                try
                {
                  formatting.Language = new CultureInfo(name);
                  continue;
                }
                catch (Exception ex)
                {
                  formatting.Language = CultureInfo.CurrentCulture;
                  continue;
                }
              }
              else
                continue;
            case 2228260358:
              if (localName == "rStyle")
              {
                string attribute = element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (string) null);
                formatting.StyleId = attribute;
                continue;
              }
              continue;
            case 2471448074:
              if (localName == "position")
              {
                formatting.Position = new float?((float) int.Parse(element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName))) / 2f);
                continue;
              }
              continue;
            case 2770536920:
              if (localName == "caps")
              {
                formatting.CapsStyle = new Xceed.Document.NET.CapsStyle?(element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)) == "0" ? Xceed.Document.NET.CapsStyle.none : Xceed.Document.NET.CapsStyle.caps);
                continue;
              }
              continue;
            case 3369314814:
              if (localName == "spacing")
              {
                formatting.Spacing = new double?(double.Parse(element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName))) / 20.0);
                continue;
              }
              continue;
            case 3876335077:
              if (localName == "b")
              {
                formatting.Bold = new bool?(element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)) != "0");
                continue;
              }
              continue;
            case 3895326798:
              if (localName == "shd")
              {
                string attribute = element.GetAttribute(XName.Get("fill", Xceed.Document.NET.Document.w.NamespaceName));
                if (!string.IsNullOrEmpty(attribute))
                {
                  formatting.Shading = new Color?(HelperFunctions.GetColorFromHtml(attribute));
                  continue;
                }
                continue;
              }
              continue;
            case 3933891603:
              if (localName == "vertAlign")
              {
                string attribute = element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (string) null);
                Xceed.Document.NET.Script result;
                formatting.Script = new Xceed.Document.NET.Script?(Enum.TryParse<Xceed.Document.NET.Script>(attribute, out result) ? result : Xceed.Document.NET.Script.none);
                continue;
              }
              continue;
            case 3960223172:
              if (localName == "i")
              {
                formatting.Italic = new bool?(element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)) != "0");
                continue;
              }
              continue;
            case 4027333648:
              if (localName == "u")
              {
                formatting.UnderlineStyle = new Xceed.Document.NET.UnderlineStyle?(HelperFunctions.GetUnderlineStyle(element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName))));
                try
                {
                  string attribute1 = element.GetAttribute(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName));
                  if (!string.IsNullOrEmpty(attribute1))
                  {
                    formatting.UnderlineColor = new Color?(HelperFunctions.GetColorFromHtml(attribute1));
                    continue;
                  }
                  XElement el = rPr.Element(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName));
                  if (el != null)
                  {
                    string attribute2 = el.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
                    formatting.UnderlineColor = new Color?(attribute2 == "auto" || attribute2 == "" ? Color.Black : HelperFunctions.GetColorFromHtml(attribute2));
                    continue;
                  }
                  continue;
                }
                catch (Exception ex)
                {
                  continue;
                }
              }
              else
                continue;
            case 4060888886:
              if (localName == "w")
              {
                formatting.PercentageScale = new float?((float) int.Parse(element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName))));
                continue;
              }
              continue;
            case 4138139626:
              if (localName == "vanish")
              {
                formatting._hidden = new bool?(element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)) != "0");
                continue;
              }
              continue;
            case 4161521353:
              if (localName == "dstrike")
              {
                formatting.StrikeThrough = new Xceed.Document.NET.StrikeThrough?(element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)) == "0" ? Xceed.Document.NET.StrikeThrough.none : Xceed.Document.NET.StrikeThrough.doubleStrike);
                continue;
              }
              continue;
            case 4268091177:
              if (localName == "kern")
              {
                formatting.Kerning = new float?((float) int.Parse(element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName))) / 2f);
                continue;
              }
              continue;
            default:
              continue;
          }
        }
      }
      return formatting;
    }

    /// <summary>Compares this Formatting to another object.</summary>
    /// <returns>
    /// <strong>0</strong> if both Formatting objects have the same property values, otherwise <strong>-1</strong>.</returns>
    /// <param name="obj">The object with which the Formatting is compared to.</param>
    public int CompareTo(object obj)
    {
      Formatting formatting = (Formatting) obj;
      bool? hidden1 = formatting._hidden;
      bool? hidden2 = this._hidden;
      if (!(hidden1.GetValueOrDefault() == hidden2.GetValueOrDefault() & hidden1.HasValue == hidden2.HasValue))
        return -1;
      bool? bold = formatting._bold;
      bool? nullable1 = this._bold;
      if (!(bold.GetValueOrDefault() == nullable1.GetValueOrDefault() & bold.HasValue == nullable1.HasValue))
        return -1;
      nullable1 = formatting._italic;
      bool? italic = this._italic;
      if (!(nullable1.GetValueOrDefault() == italic.GetValueOrDefault() & nullable1.HasValue == italic.HasValue))
        return -1;
      Xceed.Document.NET.StrikeThrough? strikethrough1 = formatting._strikethrough;
      Xceed.Document.NET.StrikeThrough? strikethrough2 = this._strikethrough;
      if (!(strikethrough1.GetValueOrDefault() == strikethrough2.GetValueOrDefault() & strikethrough1.HasValue == strikethrough2.HasValue))
        return -1;
      Xceed.Document.NET.Script? script1 = formatting._script;
      Xceed.Document.NET.Script? script2 = this._script;
      if (!(script1.GetValueOrDefault() == script2.GetValueOrDefault() & script1.HasValue == script2.HasValue))
        return -1;
      Xceed.Document.NET.Highlight? highlight1 = formatting._highlight;
      Xceed.Document.NET.Highlight? highlight2 = this._highlight;
      if (!(highlight1.GetValueOrDefault() == highlight2.GetValueOrDefault() & highlight1.HasValue == highlight2.HasValue))
        return -1;
      Color? shading = formatting._shading;
      Color? nullable2 = this._shading;
      if ((shading.HasValue == nullable2.HasValue ? (shading.HasValue ? (shading.GetValueOrDefault() != nullable2.GetValueOrDefault() ? 1 : 0) : 0) : 1) != 0 || formatting._border != this._border)
        return -1;
      double? size = formatting._size;
      double? nullable3 = this._size;
      if (!(size.GetValueOrDefault() == nullable3.GetValueOrDefault() & size.HasValue == nullable3.HasValue))
        return -1;
      nullable2 = formatting._fontColor;
      Color? nullable4 = this._fontColor;
      if ((nullable2.HasValue == nullable4.HasValue ? (nullable2.HasValue ? (nullable2.GetValueOrDefault() != nullable4.GetValueOrDefault() ? 1 : 0) : 0) : 1) != 0)
        return -1;
      nullable4 = formatting._underlineColor;
      nullable2 = this._underlineColor;
      if ((nullable4.HasValue == nullable2.HasValue ? (nullable4.HasValue ? (nullable4.GetValueOrDefault() != nullable2.GetValueOrDefault() ? 1 : 0) : 0) : 1) != 0)
        return -1;
      Xceed.Document.NET.UnderlineStyle? underlineStyle1 = formatting._underlineStyle;
      Xceed.Document.NET.UnderlineStyle? underlineStyle2 = this._underlineStyle;
      if (!(underlineStyle1.GetValueOrDefault() == underlineStyle2.GetValueOrDefault() & underlineStyle1.HasValue == underlineStyle2.HasValue))
        return -1;
      Xceed.Document.NET.Misc? misc1 = formatting._misc;
      Xceed.Document.NET.Misc? misc2 = this._misc;
      if (!(misc1.GetValueOrDefault() == misc2.GetValueOrDefault() & misc1.HasValue == misc2.HasValue))
        return -1;
      Xceed.Document.NET.CapsStyle? capsStyle1 = formatting._capsStyle;
      Xceed.Document.NET.CapsStyle? capsStyle2 = this._capsStyle;
      if (!(capsStyle1.GetValueOrDefault() == capsStyle2.GetValueOrDefault() & capsStyle1.HasValue == capsStyle2.HasValue) || formatting._fontFamily != this._fontFamily)
        return -1;
      float? percentageScale = formatting._percentageScale;
      float? nullable5 = this._percentageScale;
      if (!((double) percentageScale.GetValueOrDefault() == (double) nullable5.GetValueOrDefault() & percentageScale.HasValue == nullable5.HasValue))
        return -1;
      nullable5 = formatting._kerning;
      float? nullable6 = this._kerning;
      if (!((double) nullable5.GetValueOrDefault() == (double) nullable6.GetValueOrDefault() & nullable5.HasValue == nullable6.HasValue))
        return -1;
      nullable6 = formatting._position;
      nullable5 = this._position;
      if (!((double) nullable6.GetValueOrDefault() == (double) nullable5.GetValueOrDefault() & nullable6.HasValue == nullable5.HasValue))
        return -1;
      nullable3 = formatting._spacing;
      double? spacing = this._spacing;
      return !(nullable3.GetValueOrDefault() == spacing.GetValueOrDefault() & nullable3.HasValue == spacing.HasValue) || formatting._styleId != this._styleId || !formatting._language.Equals((object) this._language) ? -1 : 0;
    }
  }
}
