﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.MergingMode
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

namespace Xceed.Document.NET
{
  /// <summary>Value indicating the action to take when two documents are merged, and either they both contain a style with the same name but with different attributes, or
  /// they both contain headers/footers.</summary>
  public enum MergingMode
  {
    /// <summary>The style and headers/footers from the local document are kept.</summary>
    Local,
    /// <summary>The style and headers/footers from the remote document are kept.</summary>
    Remote,
    /// <summary>The style from the local document is kept. The style of the remote document is given a new name and added to the merged document. The headers/footers from each
    /// document are kept when <em>useSectionBreak</em> is <strong>true</strong>, otherwise the headers/footers from the local document are kept.</summary>
    Both,
  }
}
