﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.WrappingVerticalOffsetAlignmentFrom
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

namespace Xceed.Document.NET
{
  /// <summary>
  ///         <span style="FONT-SIZE: 13px; FONT-FAMILY: &amp;quot;Segoe UI&amp;quot;, Verdana, Arial; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; FLOAT: none; FONT-WEIGHT: 400; COLOR: rgb(0,0,0); FONT-STYLE: normal; ORPHANS: 2; WIDOWS: 2; DISPLAY: inline !important; LETTER-SPACING: normal; TEXT-INDENT: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
  /// Value indicating the element from which the vertical offset of an element is calculated.</span>
  ///       </summary>
  public enum WrappingVerticalOffsetAlignmentFrom
  {
    /// <summary>Not using any vertical offset alignment from.</summary>
    None,
    /// <summary>Element's VerticalOffset is calculated relative to the margin.</summary>
    Margin,
    /// <summary>Element's VerticalOffset is calculated relative to the page top position.</summary>
    Page,
    /// <summary>Element's VerticalOffset is calculated relative to the paragraph.</summary>
    Paragraph,
    /// <summary>Element's VerticalOffset is calculated relative to the line.</summary>
    Line,
    /// <summary>Element's VerticalOffset is calculated relative to the top margin.</summary>
    TopMargin,
    /// <summary>Element's VerticalOffset is calculated relative to the bottom margin.</summary>
    BottomMargin,
    /// <summary>Element's VerticalOffset is calculated relative to the inside margin.</summary>
    InsideMargin,
    /// <summary>Element's VerticalOffset is calculated relative to the outside margin.</summary>
    OutSideMargin,
  }
}
