﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Chart
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents the base class for a Chart.</summary>
  public abstract class Chart
  {
    private PackagePart _packagePart;
    private XDocument _chartDocument;

    /// <summary>Gets the XML for this Chart.</summary>
    public XDocument Xml { get; private set; }

    /// <summary>Gets the collection of Series in this Chart.</summary>
    public List<Xceed.Document.NET.Series> Series
    {
      get
      {
        List<Xceed.Document.NET.Series> seriesList = new List<Xceed.Document.NET.Series>();
        XName name = XName.Get("ser", Xceed.Document.NET.Document.c.NamespaceName);
        int num = 1;
        foreach (XElement element in this.ChartXml.Elements(name))
        {
          element.Add((object) new XElement(XName.Get("idx", Xceed.Document.NET.Document.c.NamespaceName)), (object) num.ToString());
          seriesList.Add(new Xceed.Document.NET.Series(element));
          ++num;
        }
        return seriesList;
      }
    }

    /// <summary>Gets the maximum number of Series in this Chart.</summary>
    public virtual short MaxSeriesCount => short.MaxValue;

    /// <summary>Gets the Legend of this Chart.</summary>
    public ChartLegend Legend { get; internal set; }

    /// <summary>Gets the category axis of this Chart.</summary>
    public CategoryAxis CategoryAxis { get; private set; }

    /// <summary>Gets the value axis of this Chart.</summary>
    public ValueAxis ValueAxis { get; private set; }

    /// <summary>Gets if the Axis exists in this Chart.</summary>
    public virtual bool IsAxisExist => true;

    /// <summary>Gets or sets if this is a 3D Chart.</summary>
    public bool View3D
    {
      get => this.ChartXml.Name.LocalName.Contains("3D");
      set
      {
        if (value)
        {
          if (this.View3D)
            return;
          this.ChartXml.Name = XName.Get(this.ChartXml.Name.LocalName.Replace(nameof (Chart), "3DChart"), Xceed.Document.NET.Document.c.NamespaceName);
        }
        else
        {
          if (!this.View3D)
            return;
          this.ChartXml.Name = XName.Get(this.ChartXml.Name.LocalName.Replace("3DChart", nameof (Chart)), Xceed.Document.NET.Document.c.NamespaceName);
        }
      }
    }

    /// <summary>Gets or sets how blank cells are displayed in this Chart.</summary>
    public DisplayBlanksAs DisplayBlanksAs
    {
      get => XElementHelpers.GetValueToEnum<DisplayBlanksAs>(this.ChartRootXml.Element(XName.Get("dispBlanksAs", Xceed.Document.NET.Document.c.NamespaceName)));
      set => XElementHelpers.SetValueFromEnum<DisplayBlanksAs>(this.ChartRootXml.Element(XName.Get("dispBlanksAs", Xceed.Document.NET.Document.c.NamespaceName)), value);
    }

    /// <summary>Gets or sets the XML for this Chart.</summary>
    protected internal XElement ChartXml { get; private set; }

    /// <summary>Gets or sets the Root XML for this Chart.</summary>
    protected internal XElement ChartRootXml { get; private set; }

    public Chart()
    {
      Licenser.VerifyLicense();
      this.Xml = XDocument.Parse("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\r\n                   <c:chartSpace xmlns:c=\"http://schemas.openxmlformats.org/drawingml/2006/chart\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">  \r\n                       <c:roundedCorners val=\"0\"/>\r\n                       <c:chart>\r\n                           <c:autoTitleDeleted val=\"0\"/>\r\n                           <c:plotVisOnly val=\"1\"/>\r\n                           <c:dispBlanksAs val=\"gap\"/>\r\n                           <c:showDLblsOverMax val=\"0\"/>\r\n                       </c:chart>\r\n                   </c:chartSpace>");
      this.ChartXml = this.CreateChartXml();
      XElement xelement1 = new XElement(XName.Get("plotArea", Xceed.Document.NET.Document.c.NamespaceName), new object[2]
      {
        (object) new XElement(XName.Get("layout", Xceed.Document.NET.Document.c.NamespaceName)),
        (object) this.ChartXml
      });
      this.ChartXml.Add((object) XElement.Parse("<c:dLbls xmlns:c=\"http://schemas.openxmlformats.org/drawingml/2006/chart\">\r\n                    <c:showLegendKey val=\"0\"/>\r\n                    <c:showVal val=\"0\"/>\r\n                    <c:showCatName val=\"0\"/>\r\n                    <c:showSerName val=\"0\"/>\r\n                    <c:showPercent val=\"0\"/>\r\n                    <c:showBubbleSize val=\"0\"/>\r\n                    <c:showLeaderLines val=\"1\"/>\r\n                </c:dLbls>"));
      if (this.IsAxisExist)
      {
        this.CategoryAxis = new CategoryAxis("148921728");
        this.ValueAxis = new ValueAxis("154227840");
        XElement xelement2 = XElement.Parse(string.Format("<c:axId val=\"{0}\" xmlns:c=\"http://schemas.openxmlformats.org/drawingml/2006/chart\"/>", (object) this.CategoryAxis.Id));
        XElement xelement3 = XElement.Parse(string.Format("<c:axId val=\"{0}\" xmlns:c=\"http://schemas.openxmlformats.org/drawingml/2006/chart\"/>", (object) this.ValueAxis.Id));
        XElement xelement4 = this.ChartXml.Element(XName.Get("gapWidth", Xceed.Document.NET.Document.c.NamespaceName));
        if (xelement4 != null)
        {
          xelement4.AddAfterSelf((object) xelement3);
          xelement4.AddAfterSelf((object) xelement2);
        }
        else
        {
          this.ChartXml.Add((object) xelement2);
          this.ChartXml.Add((object) xelement3);
        }
        xelement1.Add((object) this.CategoryAxis.Xml);
        xelement1.Add((object) this.ValueAxis.Xml);
      }
      this.ChartRootXml = this.Xml.Root.Element(XName.Get("chart", Xceed.Document.NET.Document.c.NamespaceName));
      this.ChartRootXml.Element(XName.Get("autoTitleDeleted", Xceed.Document.NET.Document.c.NamespaceName)).AddAfterSelf((object) xelement1);
    }

    internal Chart(PackagePart packagePart, XDocument chartDocument)
      : this()
    {
      this._packagePart = packagePart;
      this._chartDocument = chartDocument;
    }

    /// <summary>Adds a new Series to this Chart.</summary>
    /// <param name="series">The Series to add to the Chart.</param>
    public virtual void AddSeries(Xceed.Document.NET.Series series)
    {
      int num1 = this.ChartXml.Elements(XName.Get("ser", Xceed.Document.NET.Document.c.NamespaceName)).Count<XElement>();
      if (num1 >= (int) this.MaxSeriesCount)
        throw new InvalidOperationException("Maximum series for this chart is" + this.MaxSeriesCount.ToString() + "and have exceeded!");
      int num2 = num1 + 1;
      XAttribute xattribute = new XAttribute(XName.Get("val"), (object) num2.ToString());
      series.Xml.AddFirst((object) new XElement(XName.Get("order", Xceed.Document.NET.Document.c.NamespaceName), (object) xattribute));
      series.Xml.AddFirst((object) new XElement(XName.Get("idx", Xceed.Document.NET.Document.c.NamespaceName), (object) xattribute));
      this.ChartXml.Add((object) series.Xml);
    }

    /// <summary>Adds a standard ChartLegend to this Chart.</summary>
    public void AddLegend() => this.AddLegend(ChartLegendPosition.Right, false);

    /// <summary>Adds a ChartLegend to this Chart, using the provided
    /// ChartLegendPosition, and specifying if overlapping is allowed.</summary>
    /// <param name="position">A ChartLegendPosition value indicating the position of the <see cref="Xceed.Document.NET~Xceed.Document.NET.ChartLegend.html">ChartLegend</see>.</param>
    /// <param name="overlay">
    ///         <strong>true</strong> if other chart elements are allowed to overlap the ChartLegend,
    /// otherwise <strong>false</strong>.</param>
    public void AddLegend(ChartLegendPosition position, bool overlay)
    {
      if (this.Legend != null)
        this.RemoveLegend();
      this.Legend = new ChartLegend(position, overlay);
      this.ChartRootXml.Element(XName.Get("plotArea", Xceed.Document.NET.Document.c.NamespaceName)).AddAfterSelf((object) this.Legend.Xml);
    }

    /// <summary>Removes the ChartLegend from this Chart.</summary>
    public void RemoveLegend()
    {
      if (this.Legend == null)
        return;
      this.Legend.Xml.Remove();
      this.Legend = (ChartLegend) null;
    }

    /// <summary>Saves the modifications done to a Chart as an xml file.</summary>
    public void Save()
    {
      if (this._packagePart == null || this._chartDocument == null)
        return;
      using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(this._packagePart.GetStream())))
        this._chartDocument.Save(textWriter);
    }

    /// <summary>Creates the XML for this Chart.</summary>
    /// <returns>An XElement value representing the XML for the Chart.</returns>
    protected abstract XElement CreateChartXml();

    internal static XElement GetChartXml(XElement xml) => xml == null ? (XElement) null : ((((xml.Element(XName.Get("barChart", Xceed.Document.NET.Document.c.NamespaceName)) ?? xml.Element(XName.Get("bar3DChart", Xceed.Document.NET.Document.c.NamespaceName))) ?? xml.Element(XName.Get("lineChart", Xceed.Document.NET.Document.c.NamespaceName))) ?? xml.Element(XName.Get("line3DChart", Xceed.Document.NET.Document.c.NamespaceName))) ?? xml.Element(XName.Get("pieChart", Xceed.Document.NET.Document.c.NamespaceName))) ?? xml.Element(XName.Get("pie3DChart", Xceed.Document.NET.Document.c.NamespaceName));

    internal void SetXml(XElement chartRootXml, XElement chartXml)
    {
      this.ChartRootXml = chartRootXml;
      this.ChartXml = chartXml;
    }
  }
}
