﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.XElementHelpers
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  internal static class XElementHelpers
  {
    internal static T GetValueToEnum<T>(XElement element)
    {
      string str = element != null ? element.Attribute(XName.Get("val")).Value : throw new ArgumentNullException(nameof (element));
      foreach (T obj in Enum.GetValues(typeof (T)))
      {
        FieldInfo field = typeof (T).GetField(obj.ToString());
        if (((IEnumerable<object>) field.GetCustomAttributes(typeof (XmlNameAttribute), false)).Count<object>() == 0)
          throw new Exception(string.Format("Attribute 'XmlNameAttribute' is not assigned to {0} fields!", (object) typeof (T).Name));
        if (((XmlNameAttribute) ((IEnumerable<object>) field.GetCustomAttributes(typeof (XmlNameAttribute), false)).First<object>()).XmlName == str)
          return obj;
      }
      throw new ArgumentException("Invalid element value!");
    }

    internal static void SetValueFromEnum<T>(XElement element, T value)
    {
      if (element == null)
        throw new ArgumentNullException(nameof (element));
      element.Attribute(XName.Get("val")).Value = XElementHelpers.GetXmlNameFromEnum<T>(value);
    }

    internal static string GetXmlNameFromEnum<T>(T value)
    {
      if ((object) value == null)
        throw new ArgumentNullException(nameof (value));
      FieldInfo field = typeof (T).GetField(value.ToString());
      return ((IEnumerable<object>) field.GetCustomAttributes(typeof (XmlNameAttribute), false)).Count<object>() != 0 ? ((XmlNameAttribute) ((IEnumerable<object>) field.GetCustomAttributes(typeof (XmlNameAttribute), false)).First<object>()).XmlName : throw new Exception(string.Format("Attribute 'XmlNameAttribute' is not assigned to {0} fields!", (object) typeof (T).Name));
    }
  }
}
