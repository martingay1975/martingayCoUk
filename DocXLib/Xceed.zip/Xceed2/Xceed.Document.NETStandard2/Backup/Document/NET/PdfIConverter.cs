﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfIConverter
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

namespace Xceed.Document.NET
{
  internal interface PdfIConverter
  {
    PdfPageInfo GetCurrentPdfPageInfo();

    Section GetCurrentSection();

    Xceed.Document.NET.Document GetFileToConvert();

    Xceed.Pdf.Document GetOutputPdfDocument();

    void SetCurrentPdfPageInfo(PdfPageInfo pdfPageInfo);

    void DrawInitialTables(
      Container container,
      PdfIDrawContent drawContentInterface,
      float marginTop = 0.0f,
      float marginBottom = 0.0f);

    void DrawPdfParagraph(
      PdfParagraph paragraph,
      PdfIDrawContent drawContentInterface,
      float marginTop,
      float marginBottom);

    DocumentElement GetUndrawnWrappedObjectFromParagraph(
      Paragraph p,
      HeaderFooterType headerFooterType = HeaderFooterType.None);

    void UdpatePdfPageForWrappedObject(
      DocumentElement wrappedObject,
      PdfParagraph pdfParagraph,
      bool resetPdfPage = true,
      HeaderFooterType headerFooterType = HeaderFooterType.None);

    void DrawTextWithPosition(Xceed.Pdf.Layout.Text.Text text);
  }
}
