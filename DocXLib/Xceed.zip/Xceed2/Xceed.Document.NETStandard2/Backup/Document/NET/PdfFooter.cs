﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfFooter
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;

namespace Xceed.Document.NET
{
  internal class PdfFooter : PdfHeaderFooterBase
  {
    internal PdfFooter(PdfIConverter pdfConverterInterface)
      : base(pdfConverterInterface)
    {
    }

    internal override void CreatePdfParagraphs(Container container)
    {
      PdfPageInfo currentPdfPageInfo = this._pdfConverterInterface.GetCurrentPdfPageInfo();
      Section currentSection = this._pdfConverterInterface.GetCurrentSection();
      this._pdfConverterInterface.SetCurrentPdfPageInfo(new PdfPageInfo()
      {
        IsTemporaryPage = true,
        PositionY = 0.0f,
        PageNumber = this._pdfConverterInterface.GetCurrentPdfPageInfo().PageNumber,
        Page = this._pdfConverterInterface.GetOutputPdfDocument().Pages.AddPage(currentSection.PageWidth, currentSection.PageHeight),
        HeaderHeight = currentSection.MarginTop,
        FooterHeight = currentSection.MarginBottom
      });
      this.CreatePdfParagraphsCore(container, 0.0f, false);
      float positionY = this._pdfConverterInterface.GetCurrentPdfPageInfo().PositionY;
      this._pdfConverterInterface.GetOutputPdfDocument().Pages.Content.Remove(this._pdfConverterInterface.GetOutputPdfDocument().Pages.Content.Size - 1);
      this._pdfConverterInterface.SetCurrentPdfPageInfo(currentPdfPageInfo);
      this._pdfConverterInterface.GetCurrentPdfPageInfo().FooterHeight = Math.Max(positionY, this._pdfConverterInterface.GetCurrentPdfPageInfo().FooterHeight);
      this._pdfConverterInterface.GetCurrentSection().MarginFooter = currentSection.PageHeight - positionY;
      this._pdfConverterInterface.GetCurrentPdfPageInfo().PositionY = this._pdfConverterInterface.GetCurrentSection().MarginFooter;
      this.CreatePdfParagraphsCore(container, this._pdfConverterInterface.GetCurrentSection().MarginFooter);
    }

    internal override void Draw()
    {
      Section currentSection = this._pdfConverterInterface.GetCurrentSection();
      PdfPageInfo currentPdfPageInfo = this._pdfConverterInterface.GetCurrentPdfPageInfo();
      if (currentSection.Footers == null)
        return;
      if (currentPdfPageInfo.PageId == 1)
      {
        if (currentSection.DifferentFirstPage)
        {
          if (currentSection.Footers.First == null)
            return;
          this.CreatePdfParagraphs((Container) currentSection.Footers.First);
        }
        else
        {
          if (currentSection.Footers.Odd == null)
            return;
          this.CreatePdfParagraphs((Container) currentSection.Footers.Odd);
        }
      }
      else if (currentPdfPageInfo.PageId % 2 == 0 && this._pdfConverterInterface.GetFileToConvert().DifferentOddAndEvenPages)
      {
        if (currentSection.Footers.Even == null)
          return;
        this.CreatePdfParagraphs((Container) currentSection.Footers.Even);
      }
      else
      {
        if (currentSection.Footers.Odd == null)
          return;
        this.CreatePdfParagraphs((Container) currentSection.Footers.Odd);
      }
    }
  }
}
