﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.WrappingVerticalAlignment
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

namespace Xceed.Document.NET
{
  /// <summary>
  ///         <span style="FONT-SIZE: 13px; FONT-FAMILY: &amp;quot;Segoe UI&amp;quot;, Verdana, Arial; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; FLOAT: none; FONT-WEIGHT: 400; COLOR: rgb(0,0,0); FONT-STYLE: normal; ORPHANS: 2; WIDOWS: 2; DISPLAY: inline !important; LETTER-SPACING: normal; TEXT-INDENT: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
  /// Value indicating the vertical alignment of an element.</span>
  ///       </summary>
  public enum WrappingVerticalAlignment
  {
    /// <summary>Not using any vertical alignment.</summary>
    None,
    /// <summary>Element is vertically aligned from its Top relative to the margin.</summary>
    TopRelativeToMargin,
    /// <summary>Element is vertically aligned from its Top relative to the page top position.</summary>
    TopRelativeToPage,
    /// <summary>Element is vertically aligned from its Top relative to the line.</summary>
    TopRelativeToLine,
    /// <summary>Element is vertically aligned from its Top relative to the top margin.</summary>
    TopRelativeToTopMargin,
    /// <summary>Element is vertically aligned from its Top relative to the bottom margin.</summary>
    TopRelativeToBottomMargin,
    /// <summary>Element is vertically aligned from its Top relative to the inside margin.</summary>
    TopRelativeToInsideMargin,
    /// <summary>Element is vertically aligned from its Top relative to the outside margin.</summary>
    TopRelativeToOutsideMargin,
    /// <summary>Element is vertically aligned from its Center relative to the margin.</summary>
    CenteredRelativeToMargin,
    /// <summary>Element is vertically aligned from its Center relative to the page center position.</summary>
    CenteredRelativeToPage,
    /// <summary>Element is vertically aligned from its Center relative to the line.</summary>
    CenteredRelativeToLine,
    /// <summary>Element is vertically aligned from its Center relative to the top margin.</summary>
    CenteredRelativeToTopMargin,
    /// <summary>Element is vertically aligned from its Center relative to the bottom margin.</summary>
    CenteredRelativeToBottomMargin,
    /// <summary>Element is vertically aligned from its Center relative to the inside margin.</summary>
    CenteredRelativeToInsideMargin,
    /// <summary>Element is vertically aligned from its Center relative to the outside margin.</summary>
    CenteredRelativeToOutsideMargin,
    /// <summary>Element is vertically aligned from its Bottom relative to the margin.</summary>
    BottomRelativeToMargin,
    /// <summary>Element is vertically aligned from its Bottom relative to the page bottom position.</summary>
    BottomRelativeToPage,
    /// <summary>Element is vertically aligned from its Bottom relative to the line.</summary>
    BottomRelativeToLine,
    /// <summary>Element is vertically aligned from its Bottom relative to the top margin.</summary>
    BottomRelativeToTopMargin,
    /// <summary>Element is vertically aligned from its Bottom relative to the bottom margin.</summary>
    BottomRelativeToBottomMargin,
    /// <summary>Element is vertically aligned from its Bottom relative to the inside margin.</summary>
    BottomRelativeToInsideMargin,
    /// <summary>Element is vertically aligned from its Bottom relative to the outside margin.</summary>
    BottomRelativeToOutsideMargin,
    /// <summary>Element is vertically aligned from its Inside relative to the margin.</summary>
    InsideRelativeToMargin,
    /// <summary>Element is vertically aligned from its Inside relative to the page inside position.</summary>
    InsideRelativeToPage,
    /// <summary>Element is vertically aligned from its Inside relative to the line.</summary>
    InsideRelativeToLine,
    /// <summary>Element is vertically aligned from its Inside relative to the top margin.</summary>
    InsideRelativeToTopMargin,
    /// <summary>Element is vertically aligned from its Inside relative to the bottom margin.</summary>
    InsideRelativeToBottomMargin,
    /// <summary>Element is vertically aligned from its Inside relative to the inside margin.</summary>
    InsideRelativeToInsideMargin,
    /// <summary>Element is vertically aligned from its Inside relative to the outside margin.</summary>
    InsideRelativeToOutsideMargin,
    /// <summary>Element is vertically aligned from its Outside relative to the margin.</summary>
    OutsideRelativeToMargin,
    /// <summary>Element is vertically aligned from its Outside relative to the page outside position.</summary>
    OutsideRelativeToPage,
    /// <summary>Element is vertically aligned from its Outside relative to the line.</summary>
    OutsideRelativeToLine,
    /// <summary>Element is vertically aligned from its Outside relative to the top margin.</summary>
    OutsideRelativeToTopMargin,
    /// <summary>Element is vertically aligned from its Outside relative to the bottom margin.</summary>
    OutsideRelativeToBottomMargin,
    /// <summary>Element is vertically aligned from its Outside relative to the inside margin.</summary>
    OutsideRelativeToInsideMargin,
    /// <summary>Element is vertically aligned from its Outside relative to the outside margin.</summary>
    OutsideRelativeToOutsideMargin,
  }
}
