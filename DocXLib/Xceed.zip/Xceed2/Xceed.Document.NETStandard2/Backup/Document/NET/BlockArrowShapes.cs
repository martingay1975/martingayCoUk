﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.BlockArrowShapes
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

namespace Xceed.Document.NET
{
  /// <summary>Value indicating a block arrow shape to apply to a Picture.</summary>
  public enum BlockArrowShapes
  {
    rightArrow,
    leftArrow,
    upArrow,
    downArrow,
    leftRightArrow,
    upDownArrow,
    quadArrow,
    leftRightUpArrow,
    bentArrow,
    uturnArrow,
    leftUpArrow,
    bentUpArrow,
    curvedRightArrow,
    curvedLeftArrow,
    curvedUpArrow,
    curvedDownArrow,
    stripedRightArrow,
    notchedRightArrow,
    homePlate,
    chevron,
    rightArrowCallout,
    downArrowCallout,
    leftArrowCallout,
    upArrowCallout,
    leftRightArrowCallout,
    quadArrowCallout,
    circularArrow,
  }
}
