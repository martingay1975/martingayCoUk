﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfEndnote
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System.Xml.Linq;

namespace Xceed.Document.NET
{
  internal class PdfEndnote : PdfNote
  {
    private static Xceed.Pdf.Layout.Text.Text _endnotesContent;

    internal PdfEndnote(PdfParagraph p, XElement run)
      : base(p, run)
    {
    }

    internal override string GetReferenceNoteType() => "endnoteReference";

    internal override string GetNoteType() => "endnote";

    internal override string GetNotePropertiesType() => "endnotePr";

    internal override string GetDefaultNumberedText(string id) => this.ConvertTextDigitToRoman(id, false);

    internal override XDocument GetNoteFile() => this._pdfParagraph.GetFileToConvert()._endnotes;

    internal override Xceed.Pdf.Layout.Text.Text GetNotesContent() => PdfEndnote.GetEndnotesContent();

    internal override void CreateNotesContent() => PdfEndnote._endnotesContent = new Xceed.Pdf.Layout.Text.Text();

    internal static Xceed.Pdf.Layout.Text.Text GetEndnotesContent() => PdfEndnote._endnotesContent;

    internal static float GetEndnotesContentHeight() => PdfEndnote._endnotesContent == null ? 0.0f : PdfEndnote._endnotesContent.Height;

    internal static void CleanEndnotes() => PdfEndnote._endnotesContent = (Xceed.Pdf.Layout.Text.Text) null;
  }
}
