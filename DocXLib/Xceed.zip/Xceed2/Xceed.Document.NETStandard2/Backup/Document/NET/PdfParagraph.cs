﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfParagraph
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;
using Xceed.Pdf;
using Xceed.Pdf.Atoms;
using Xceed.Pdf.Layout;
using Xceed.Pdf.Layout.Text.Atoms;

namespace Xceed.Document.NET
{
  internal class PdfParagraph
  {
    private Paragraph _paragraph;
    private Paragraph _previousParagraph;
    private Paragraph _nextParagraph;
    private int _paragraphId;
    private int _pageNumber;
    private Graphics _graphics;
    private Xceed.Document.NET.Document _fileToConvert;
    private Section _currentSection;
    private bool _isFirstParagraphOnPage;
    private bool _containsTotalPageNumber;
    internal const float DefaultTabSpacing = 36f;

    internal PdfParagraph(
      Paragraph current,
      Paragraph previous,
      Paragraph next,
      int paragraphId,
      int pageNumber,
      Graphics graphics,
      Xceed.Document.NET.Document fileToConvert,
      Section currentSection,
      bool isFirstParagraphOnPage = false)
    {
      if (current == null)
        throw new ArgumentNullException(nameof (current));
      if (fileToConvert == null)
        throw new ArgumentNullException(nameof (fileToConvert));
      if (currentSection == null)
        throw new ArgumentNullException(nameof (currentSection));
      this._paragraph = current;
      this._previousParagraph = previous;
      this._nextParagraph = next;
      this._paragraphId = paragraphId;
      this._pageNumber = pageNumber;
      this._graphics = graphics;
      this._fileToConvert = fileToConvert;
      this._isFirstParagraphOnPage = isFirstParagraphOnPage;
      this._currentSection = currentSection;
    }

    internal Xceed.Document.NET.Document GetFileToConvert() => this._fileToConvert;

    internal Section GetCurrentSection() => this._currentSection;

    internal int GetParagraphId() => this._paragraphId;

    internal void SetIsFirstParagraphOnPage(bool isFirst) => this._isFirstParagraphOnPage = isFirst;

    internal bool IsParagraphContainingPageBreak() => this.IsParagraphContainingPageBreakInMiddle() || this.IsParagraphContainingPageBreakBefore() || this.IsParagraphContainingSectionBreak();

    internal bool IsParagraphContainingPageBreakInMiddle()
    {
      foreach (XContainer run in this._paragraph._runs)
      {
        XElement xelement = run.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (el => el.Name.LocalName == "br"));
        if (xelement != null && (!xelement.HasAttributes || xelement.Attribute(Xceed.Document.NET.Document.w + "type") == null ? (string) null : xelement.Attribute(Xceed.Document.NET.Document.w + "type").Value) == "page")
          return true;
      }
      return false;
    }

    internal bool IsParagraphContainingPageBreakBefore()
    {
      XElement el = this._paragraph.GetOrCreate_pPr().Element(XName.Get("pageBreakBefore", Xceed.Document.NET.Document.w.NamespaceName));
      if (el != null)
      {
        string attribute = el.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        if (string.IsNullOrEmpty(attribute) || attribute == "1")
          return true;
      }
      return false;
    }

    internal bool IsParagraphContainingSectionBreak() => this._paragraph.GetOrCreate_pPr().Element(XName.Get("sectPr", Xceed.Document.NET.Document.w.NamespaceName)) != null;

    internal int GetPageBreakRunId()
    {
      for (int index = 0; index < this._paragraph._runs.Count; ++index)
      {
        XElement xelement = this._paragraph._runs[index].Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (el => el.Name.LocalName == "br"));
        if (xelement != null && (xelement.HasAttributes ? xelement.Attribute(Xceed.Document.NET.Document.w + "type").Value : (string) null) == "page")
          return index;
      }
      return 0;
    }

    internal bool IsParagraphKeepWithNextParagraph()
    {
      XElement el = this._paragraph.GetOrCreate_pPr().Descendants(XName.Get("keepNext", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
      if (el == null)
        return false;
      string attribute = el.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
      return string.IsNullOrEmpty(attribute) || attribute == "1";
    }

    internal Xceed.Pdf.Layout.Text.Text CreatePdfText(
      IList wrappedObjectInfoList,
      bool isMeasuring = false)
    {
      Xceed.Pdf.Layout.Text.Text text = new Xceed.Pdf.Layout.Text.Text(PdfParagraphPart.CreateBlockedRegions(this.GetCurrentSection(), wrappedObjectInfoList));
      this.ApplyParagraphBorders(text);
      this.ApplyParagraphShading(text);
      this.UpdateParagraphPageNumber();
      this.FillContent(text, isMeasuring);
      return text;
    }

    internal bool IsParagraphKeepingLinesTogether() => this._paragraph.GetOrCreate_pPr().Descendants(XName.Get("keepLines", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>() != null;

    internal float GetLineSpacingBefore(Xceed.Pdf.Layout.Text.Text text = null) => this.IsFirst() ? (!this._paragraph.IsLineSpacingRuleAuto() && (double) this.GetFontAscent(text) > 0.0 ? Math.Max(this._paragraph.LineSpacingBefore, this._paragraph.LineSpacing * 0.8f - this.GetFontAscent(text)) : this._paragraph.LineSpacingBefore) : (this._isFirstParagraphOnPage || this.IgnoreSpacing(this._previousParagraph, this._paragraph) || (double) this._paragraph.LineSpacingBefore <= (double) this._previousParagraph.LineSpacingAfter && this._previousParagraph.FollowingTables == null ? 0.0f : this._paragraph.LineSpacingBefore);

    internal float GetLineSpacingAfter(Xceed.Pdf.Layout.Text.Text text = null)
    {
      float num = this._paragraph.IsLineSpacingRuleAuto() ? this.GetLineSpacingFromFont(this._paragraph.LineSpacing) : ((double) this._paragraph.LineSpacing >= (double) this.GetFontHeight(text) ? this._paragraph.LineSpacing - this.GetFontHeight(text) : 0.0f);
      if (this.IsLast() || this._paragraph.FollowingTables != null)
        return this._paragraph.LineSpacingAfter;
      return this.IgnoreSpacing(this._paragraph, this._nextParagraph) || (double) this._paragraph.LineSpacingAfter < (double) this._nextParagraph.LineSpacingBefore ? num : this._paragraph.LineSpacingAfter + num;
    }

    internal bool ContainsUnwrappedTables()
    {
      if (this._paragraph.FollowingTables != null)
      {
        foreach (Table followingTable in this._paragraph.FollowingTables)
        {
          if (!PdfTable.IsTableWrappingAround(followingTable))
            return true;
        }
      }
      return false;
    }

    internal bool ContainsWrappedTables()
    {
      if (this._paragraph.FollowingTables != null)
      {
        foreach (Table followingTable in this._paragraph.FollowingTables)
        {
          if (PdfTable.IsTableWrappingAround(followingTable))
            return true;
        }
      }
      return false;
    }

    internal List<Table> GetUnwrappedTables()
    {
      List<Table> tableList = (List<Table>) null;
      if (this._paragraph.FollowingTables != null)
      {
        foreach (Table followingTable in this._paragraph.FollowingTables)
        {
          if (!PdfTable.IsTableWrappingAround(followingTable))
          {
            if (tableList == null)
              tableList = new List<Table>();
            tableList.Add(followingTable);
          }
        }
      }
      return tableList;
    }

    internal List<Table> GetWrappedTables()
    {
      List<Table> tableList = (List<Table>) null;
      if (this._paragraph.FollowingTables != null)
      {
        foreach (Table followingTable in this._paragraph.FollowingTables)
        {
          if (PdfTable.IsTableWrappingAround(followingTable))
          {
            if (tableList == null)
              tableList = new List<Table>();
            tableList.Add(followingTable);
          }
        }
      }
      return tableList;
    }

    internal List<Table> GetTables() => this._paragraph.FollowingTables;

    internal PdfParagraphPart CreatePdfTable(
      Table table,
      PdfPageInfo currentPdfPageInfo,
      bool isMeasuring = false)
    {
      if (table == null)
        return (PdfParagraphPart) null;
      PdfTable pdfTable = new PdfTable(this, table, currentPdfPageInfo.Page.Graphics, currentPdfPageInfo.PageNumber);
      pdfTable.UpdateText((Xceed.Pdf.Layout.Text.Text) null, isMeasuring);
      return (PdfParagraphPart) pdfTable;
    }

    internal PdfParagraphPart CreatePdfShape(
      Shape shape,
      PdfPageInfo currentPdfPageInfo)
    {
      if (shape == null)
        return (PdfParagraphPart) null;
      PdfShape pdfShape = new PdfShape(this, shape, currentPdfPageInfo.Page.Graphics, currentPdfPageInfo.PageNumber);
      pdfShape.UpdateText((Xceed.Pdf.Layout.Text.Text) null, false);
      return (PdfParagraphPart) pdfShape;
    }

    internal bool ValidateBookmark(string bookmark) => this._paragraph.ValidateBookmark(bookmark);

    internal Paragraph GetOriginalParagraph() => this._paragraph;

    internal XElement GetXml() => this._paragraph.Xml;

    internal int GetLevel() => this._paragraph.IndentLevel.Value;

    internal void InsertText(int index, string text, Formatting formatting = null) => this._paragraph.InsertText(index, text, formatting: formatting);

    internal void FillContent(Xceed.Pdf.Layout.Text.Text text, bool isMeasuring = false)
    {
      if (!this._isFirstParagraphOnPage && this._paragraph.IsBeforeAutoSpacing() && (this._previousParagraph != null && !this._previousParagraph.IsAfterAutoSpacing()))
        this.AddEndOfLine(text);
      if (!isMeasuring && this._paragraph.IsListItem)
      {
        XElement rPr = this._paragraph.GetOrCreate_pPr().Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
        new PdfListItem(this, this.GetLayoutStyle(new FormattedText()
        {
          formatting = Formatting.Parse(rPr)
        })).UpdateText(text, false);
      }
      if (this.ContainsChart())
        new PdfChart(this).UpdateText(text, false);
      bool flag1 = this._paragraph.Pictures.Count > 0 && this._paragraph.Pictures.Exists((Predicate<Picture>) (x => PdfUtils.IsWrappingInLineWithText((DocumentElement) x)));
      bool flag2 = this._paragraph.Shapes.Count > 0;
      if (flag1 | flag2)
      {
        List<FormattedText> remainingMagicText = new List<FormattedText>((IEnumerable<FormattedText>) this._paragraph.MagicText);
        foreach (XElement run in this._paragraph._runs)
        {
          string pictureIdFromXelement = PdfPicture.GetPictureIdFromXElement(run);
          if (!string.IsNullOrEmpty(pictureIdFromXelement))
          {
            this.UpdateParagraphPicture(pictureIdFromXelement, text);
          }
          else
          {
            XElement shapeFromXelement = PdfShape.GetShapeFromXElement(run);
            if (shapeFromXelement != null)
              this.UpdateParagraphShape(shapeFromXelement, text);
            else if (remainingMagicText.Count > 0)
              this.FillTextContentForRun(text, run, ref remainingMagicText);
          }
        }
        if (flag1)
        {
          string pictureIdFromXelement1 = PdfPicture.GetPictureIdFromXElement(this._paragraph.Xml);
          if (!string.IsNullOrEmpty(pictureIdFromXelement1))
            this.UpdateParagraphPicture(pictureIdFromXelement1, text);
          foreach (Hyperlink hyperlink in this._paragraph.Hyperlinks)
          {
            List<XElement> runs = hyperlink.Runs;
            if (runs != null)
            {
              foreach (XElement xElement in runs)
              {
                string pictureIdFromXelement2 = PdfPicture.GetPictureIdFromXElement(xElement);
                if (!string.IsNullOrEmpty(pictureIdFromXelement2))
                  this.UpdateParagraphPicture(pictureIdFromXelement2, text);
              }
            }
          }
          List<XElement> sdtContentRuns = this._paragraph.GetSdtContentRuns();
          if (sdtContentRuns != null)
          {
            foreach (XElement xElement in sdtContentRuns)
            {
              string pictureIdFromXelement2 = PdfPicture.GetPictureIdFromXElement(xElement);
              if (!string.IsNullOrEmpty(pictureIdFromXelement2))
                this.UpdateParagraphPicture(pictureIdFromXelement2, text);
            }
          }
        }
      }
      else if (this._paragraph.Xml.Descendants().Where<XElement>((Func<XElement, bool>) (x => x.Name.LocalName.Equals("endnoteReference") || x.Name.LocalName.Equals("footnoteReference"))).Count<XElement>() > 0 && this._paragraph.MagicText.Count > 0)
      {
        List<FormattedText> remainingMagicText = new List<FormattedText>((IEnumerable<FormattedText>) this._paragraph.MagicText);
        foreach (XElement run in this._paragraph._runs)
        {
          this.FillTextContentForRun(text, run, ref remainingMagicText);
          if (!isMeasuring)
          {
            if (this.ContainsFootnotes(run))
              new PdfFootnote(this, run).UpdateText(text, false);
            if (this.ContainsEndnotes(run))
              new PdfEndnote(this, run).UpdateText(text, false);
          }
        }
      }
      else
      {
        foreach (FormattedText formattedText in this._paragraph.MagicText)
          this.FillTextContent(text, formattedText);
      }
      this.SetAlignment(text);
      if (this._paragraph.MagicText.Count == 0 && !this.IsParagraphContainingPageBreak())
        this.AddEndOfLine(text);
      else if (this._paragraph.MagicText.Count > 0 && this._paragraph.MagicText.Last<FormattedText>().text.Last<char>() == '\n')
      {
        this.AddEndOfLine(text, this._paragraph.MagicText.Last<FormattedText>());
      }
      else
      {
        if (!this._paragraph.IsAfterAutoSpacing() || this._nextParagraph == null)
          return;
        this.AddEndOfLine(text);
        this.AddEndOfLine(text);
      }
    }

    internal Style GetLayoutStyle(string styleId) => this.GetLayoutStyle((FormattedText) null, styleId);

    internal Style GetLayoutStyle(FormattedText magicText, string styleId = null, Style textStyle = null)
    {
      Formatting currentFormatting = this.GetFormattingFromStyle(!string.IsNullOrEmpty(styleId) ? styleId : this._paragraph.StyleId) ?? new Formatting();
      if (magicText != null && magicText.formatting != null)
      {
        if (!string.IsNullOrEmpty(magicText.formatting.StyleId))
        {
          Formatting formattingFromStyle = this.GetFormattingFromStyle(magicText.formatting.StyleId);
          this.UpdateFormattingFromFormatting(ref currentFormatting, formattingFromStyle);
        }
        this.UpdateFormattingFromFormatting(ref currentFormatting, magicText.formatting);
      }
      string fontFamily = currentFormatting.FontFamily != null ? currentFormatting.FontFamily.Name : (string) null;
      if (fontFamily == null)
      {
        Formatting formattingFromStyle = this.GetFormattingFromStyle(this._paragraph.Document.GetNormalStyleId());
        fontFamily = formattingFromStyle == null || formattingFromStyle.FontFamily == null ? this.GetDocDefaultFontFamily() : formattingFromStyle.FontFamily.Name;
      }
      Brush brush = currentFormatting.FontColor.HasValue ? (Brush) new SolidBrush(currentFormatting.FontColor.Value) : (textStyle == null || textStyle.Brush == null ? this.GetDocDefaultFontColor() : textStyle.Brush);
      double num1 = currentFormatting.Size ?? this.GetDocDefaultFontSize();
      FontStyle fontStyle = (FontStyle) 0;
      Pen pen1 = new Pen(brush, 1f);
      bool flag1 = false;
      bool flag2 = false;
      CapsStyle? capsStyle1 = currentFormatting.CapsStyle;
      if (capsStyle1.HasValue)
      {
        capsStyle1 = currentFormatting.CapsStyle;
        CapsStyle capsStyle2 = CapsStyle.none;
        if (!(capsStyle1.GetValueOrDefault() == capsStyle2 & capsStyle1.HasValue))
        {
          if (magicText != null)
            magicText.text = magicText.text.ToUpper();
          capsStyle1 = currentFormatting.CapsStyle;
          CapsStyle capsStyle3 = CapsStyle.smallCaps;
          if (capsStyle1.GetValueOrDefault() == capsStyle3 & capsStyle1.HasValue)
            num1 *= 0.8;
        }
      }
      if (currentFormatting.Bold.HasValue && currentFormatting.Bold.Value)
        fontStyle = (FontStyle) (fontStyle | 1);
      if (currentFormatting.Italic.HasValue && currentFormatting.Italic.Value)
        fontStyle = (FontStyle) (fontStyle | 2);
      if (currentFormatting.UnderlineStyle.HasValue)
      {
        UnderlineStyle? underlineStyle1 = currentFormatting.UnderlineStyle;
        UnderlineStyle underlineStyle2 = UnderlineStyle.none;
        if (!(underlineStyle1.GetValueOrDefault() == underlineStyle2 & underlineStyle1.HasValue))
        {
          fontStyle = (FontStyle) (fontStyle | 4);
          Pen pen2 = pen1;
          underlineStyle1 = currentFormatting.UnderlineStyle;
          int num2 = (int) underlineStyle1.Value;
          double fontSize = num1;
          int num3 = (fontStyle & 1) == 1 ? 1 : 0;
          this.UpdateUnderlinePen(pen2, (UnderlineStyle) num2, fontSize, num3 != 0);
          underlineStyle1 = currentFormatting.UnderlineStyle;
          flag1 = underlineStyle1.Value == UnderlineStyle.doubleLine;
        }
      }
      if (currentFormatting.UnderlineColor.HasValue)
        pen1.set_Color(currentFormatting.UnderlineColor.Value);
      if (currentFormatting.StrikeThrough.HasValue)
      {
        StrikeThrough? strikeThrough1 = currentFormatting.StrikeThrough;
        StrikeThrough strikeThrough2 = StrikeThrough.none;
        if (!(strikeThrough1.GetValueOrDefault() == strikeThrough2 & strikeThrough1.HasValue))
        {
          fontStyle = (FontStyle) (fontStyle | 8);
          strikeThrough1 = currentFormatting.StrikeThrough;
          flag2 = strikeThrough1.Value == StrikeThrough.doubleStrike;
        }
      }
      System.Drawing.Font font;
      if (((IEnumerable<FontFamily>) FontFamily.get_Families()).FirstOrDefault<FontFamily>((Func<FontFamily, bool>) (f => f.get_Name() == fontFamily)) != null)
      {
        font = new System.Drawing.Font(fontFamily, Convert.ToSingle(num1), fontStyle);
      }
      else
      {
        PdfExternalFont pdfExternalFont = PdfConverter.GetExternalFonts().FirstOrDefault<PdfExternalFont>((Func<PdfExternalFont, bool>) (f => f.Name == fontFamily));
        font = string.IsNullOrEmpty(pdfExternalFont.Name) ? new System.Drawing.Font(fontFamily, Convert.ToSingle(num1), fontStyle) : PdfParagraph.LoadFont(pdfExternalFont.Path, Convert.ToInt32(num1), fontStyle).Font;
      }
      Style layoutStyle = new Style(font, brush, pen1);
      layoutStyle.IsDoubleUnderline = flag1;
      layoutStyle.IsDoubleStrikeThrough = flag2;
      double? spacing = currentFormatting.Spacing;
      if (spacing.HasValue)
      {
        Style style = layoutStyle;
        spacing = currentFormatting.Spacing;
        double single = (double) Convert.ToSingle(spacing.Value);
        style.CharSpacing = (float) single;
      }
      if (currentFormatting.Highlight.HasValue && currentFormatting.Highlight.Value != Highlight.none)
        layoutStyle.Highlight = this.GetLayoutStyleHighlight(currentFormatting.Highlight);
      if (currentFormatting.Shading.HasValue)
      {
        Color white = currentFormatting.Shading.Value;
        int argb1 = white.ToArgb();
        white = Color.White;
        int argb2 = white.ToArgb();
        if (argb1 != argb2)
          layoutStyle.Shading = currentFormatting.Shading.Value;
      }
      if (currentFormatting.Border != null)
        layoutStyle.Border = PdfConverter.WordsBorderToPdfBorder(currentFormatting.Border);
      if (currentFormatting.Script.HasValue && currentFormatting.Script.Value != Script.none)
        layoutStyle.FontVariant = currentFormatting.Script.Value == Script.subscript ? FontVariant.Subscript : FontVariant.Superscript;
      if (currentFormatting.Position.HasValue)
        layoutStyle.Position = currentFormatting.Position.Value;
      if (currentFormatting.Hidden.HasValue)
        layoutStyle.Hidden = currentFormatting.Hidden.Value;
      layoutStyle.TabSpacing = 36f;
      if (magicText != null && magicText.text != null)
      {
        if (magicText.text.IndexOf("\t") != -1)
          this.UpdateLayoutStyleTabPositions(layoutStyle);
        if (magicText.text.IndexOf("\v") != -1)
          this.UpdateLayoutStyleTabPositions(layoutStyle, true);
      }
      return layoutStyle;
    }

    internal void UpdateFormattingFromFormatting(
      ref Formatting currentFormatting,
      Formatting newFormatting,
      Formatting initialFormatting = null)
    {
      if (newFormatting == null)
        return;
      if (currentFormatting == null)
        currentFormatting = new Formatting();
      PropertyInfo[] properties = newFormatting.GetType().GetProperties();
      object instance = Activator.CreateInstance(typeof (Formatting));
      foreach (PropertyInfo propertyInfo in properties)
      {
        object obj1 = typeof (Formatting).GetProperty(propertyInfo.Name).GetValue(instance, (object[]) null);
        object obj2 = propertyInfo.GetValue((object) currentFormatting, (object[]) null);
        object obj3 = propertyInfo.GetValue((object) newFormatting, (object[]) null);
        object obj4 = initialFormatting != null ? propertyInfo.GetValue((object) initialFormatting, (object[]) null) : (object) null;
        if (obj3 != null && !obj3.Equals(obj2) && (obj4 == null || obj4.Equals(obj1)))
          currentFormatting.GetType().GetProperty(propertyInfo.Name).SetValue((object) currentFormatting, obj3, (object[]) null);
      }
    }

    internal void UpdateParagraphPageNumber()
    {
      if (this.IsInTOC() && PdfConverter.IsTotalPageNumberCalculated())
      {
        string bookmarkId = TableOfContents.GetPageRefInstrTextBookmarkId(this._paragraph.Xml);
        if (bookmarkId != null)
        {
          PdfPageNumberParagraphInfo numberParagraphInfo = PdfConverter._pageNumberParagraphs.FirstOrDefault<PdfPageNumberParagraphInfo>((Func<PdfPageNumberParagraphInfo, bool>) (x => x.PageRefId == bookmarkId));
          if (numberParagraphInfo != null)
          {
            XElement xelement = this._paragraph.Xml.Descendants(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName)).LastOrDefault<XElement>();
            if (xelement != null)
              xelement.Value = this.GetUpdatedPageNumberString(xelement.Value, numberParagraphInfo.PageRefNumber);
          }
        }
        this._paragraph.ClearMagicTextCache();
      }
      else
      {
        bool flag1 = false;
        foreach (XElement el in this._paragraph.Xml.Descendants().Where<XElement>((Func<XElement, bool>) (s => s.Name.LocalName == "fldSimple")))
        {
          string attribute = el.GetAttribute(XName.Get("instr", Xceed.Document.NET.Document.w.NamespaceName));
          if (attribute != null)
          {
            if (attribute.Contains("NUMPAGES"))
            {
              this.SetContainsTotalPageNumber(true);
              if (PdfConverter.IsTotalPageNumberCalculated())
              {
                XElement xelement = el.Descendants(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
                if (xelement != null)
                {
                  xelement.Value = this.GetUpdatedPageNumberString(xelement.Value, PdfConverter.GetTotalPageNumberCalculated());
                  this._paragraph.ClearMagicTextCache();
                }
              }
            }
            else if (attribute.Contains("PAGE"))
            {
              XElement xelement = el.Descendants(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
              if (xelement != null)
              {
                xelement.Value = this.GetUpdatedPageNumberString(xelement.Value, this._pageNumber);
                this._paragraph.ClearMagicTextCache();
                flag1 = true;
              }
            }
          }
        }
        bool flag2 = false;
        if (flag1 && this.ContainsTotalPageNumber())
          return;
        bool flag3 = false;
        List<XElement> runs = this._paragraph._runs;
        List<XElement> sdtContentRuns = this._paragraph.GetSdtContentRuns();
        if (sdtContentRuns != null)
          runs.AddRange((IEnumerable<XElement>) sdtContentRuns);
        foreach (XElement run in this._paragraph._runs)
        {
          XElement xelement1 = run.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (s => s.Name.LocalName == "instrText"));
          if (xelement1 != null && !xelement1.Value.Contains("Toc"))
          {
            if (xelement1.Value.Contains("NUMPAGES"))
            {
              this.SetContainsTotalPageNumber(true);
              flag2 = true;
            }
            else if (xelement1.Value.Contains("PAGE"))
              flag3 = true;
          }
          if (flag3)
          {
            XElement xelement2 = run.Element(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName));
            if (xelement2 != null)
            {
              string pageNumberString = this.GetUpdatedPageNumberString(xelement2.Value, this._pageNumber);
              if (!string.IsNullOrEmpty(pageNumberString))
              {
                xelement2.Value = pageNumberString;
                this._paragraph.ClearMagicTextCache();
                flag3 = false;
              }
            }
          }
          if (flag2 && PdfConverter.IsTotalPageNumberCalculated())
          {
            XElement xelement2 = run.Element(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName));
            if (xelement2 != null)
            {
              xelement2.Value = this.GetUpdatedPageNumberString(xelement2.Value, PdfConverter.GetTotalPageNumberCalculated());
              this._paragraph.ClearMagicTextCache();
              flag2 = false;
            }
          }
        }
      }
    }

    internal bool ContainsTotalPageNumber() => this._containsTotalPageNumber;

    internal void SetContainsTotalPageNumber(bool containsTotalPageNumber) => this._containsTotalPageNumber = containsTotalPageNumber;

    internal bool IsInTOC() => this._paragraph.IsInTOC();

    internal bool IsLastTextPageNumber() => !string.IsNullOrEmpty(this._paragraph.Text) && char.IsDigit(this._paragraph.Text[this._paragraph.Text.Length - 1]);

    private static PdfParagraph.LoadedFont LoadFont(
      string file,
      int fontSize,
      FontStyle fontStyle)
    {
      PrivateFontCollection privateFontCollection = new PrivateFontCollection();
      privateFontCollection.AddFontFile(file);
      PdfParagraph.LoadedFont loadedFont = ((FontCollection) privateFontCollection).get_Families().Length >= 0 ? new PdfParagraph.LoadedFont()
      {
        FontFamily = ((FontCollection) privateFontCollection).get_Families()[0]
      } : throw new InvalidOperationException("No font familiy found when loading font.");
      loadedFont.Font = new System.Drawing.Font(loadedFont.FontFamily, (float) fontSize, fontStyle, (GraphicsUnit) 2);
      return loadedFont;
    }

    private bool IsFirst() => this._previousParagraph == null;

    private bool IsLast() => this._nextParagraph == null;

    private bool ContainsChart() => this._paragraph._runs.Descendants<XElement>().FirstOrDefault<XElement>((Func<XElement, bool>) (el => el.Name.LocalName == "chart")) != null;

    private bool ContainsFootnotes(XElement run) => run != null && run.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (el => el.Name.LocalName == "footnoteReference")) != null;

    private bool ContainsEndnotes(XElement run) => run != null && run.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (el => el.Name.LocalName == "endnoteReference")) != null;

    private void SetAlignment(Xceed.Pdf.Layout.Text.Text text)
    {
      switch (this._paragraph.Alignment)
      {
        case Alignment.left:
          text.Alignment = TextAlignment.Left;
          break;
        case Alignment.center:
          text.Alignment = TextAlignment.Center;
          break;
        case Alignment.right:
          text.Alignment = TextAlignment.Right;
          break;
        default:
          text.Alignment = TextAlignment.Justify;
          break;
      }
      if ((double) this._paragraph.LineSpacing != 12.0)
        text.Interval = this._paragraph.IsLineSpacingRuleAuto() ? this.GetLineSpacingFromFont(this._paragraph.LineSpacing, text) : Math.Abs(this._paragraph.LineSpacing - this.GetFontHeight(text));
      text.Indents.Left = this._paragraph.IndentationBefore;
      text.Indents.Right = this._paragraph.IndentationAfter;
      text.Indents.First = (double) this._paragraph.IndentationHanging == 0.0 ? this._paragraph.IndentationFirstLine : -this._paragraph.IndentationHanging;
    }

    private float GetLineSpacingFromFont(float paragraphLineSpacing, Xceed.Pdf.Layout.Text.Text text = null) => (float) (((double) paragraphLineSpacing - 12.0) / 12.0) * this.GetFontHeight(text);

    private float GetFontAscent(Xceed.Pdf.Layout.Text.Text text)
    {
      if (text != null && text.Atoms.Size > 0 && text.Atoms[0] is CharAtom atom)
      {
        System.Drawing.Font font = atom.Style.Font;
        int cellAscent = font.get_FontFamily().GetCellAscent(font.get_Style());
        int emHeight = font.get_FontFamily().GetEmHeight(font.get_Style());
        return font.get_SizeInPoints() * (float) cellAscent / (float) emHeight;
      }
      return this._graphics != null ? this._graphics.FontMetrics.Ascent : 0.0f;
    }

    private float GetFontHeight(Xceed.Pdf.Layout.Text.Text text)
    {
      if (text != null && text.Atoms.Size > 0 && text.Atoms[0] is CharAtom atom)
      {
        System.Drawing.Font font = atom.Style.Font;
        int emHeight = font.get_FontFamily().GetEmHeight(font.get_Style());
        int lineSpacing = font.get_FontFamily().GetLineSpacing(font.get_Style());
        return font.get_SizeInPoints() * (float) lineSpacing / (float) emHeight;
      }
      return this._graphics != null ? this._graphics.FontMetrics.Height : 0.0f;
    }

    private void FillTextContent(Xceed.Pdf.Layout.Text.Text text, FormattedText formattedText)
    {
      Xceed.Pdf.Layout.Text.Hyperlink hyperlink = this.GetHyperlink(formattedText.text);
      Style layoutStyle = this.GetLayoutStyle(formattedText, textStyle: text.Style);
      text.AddContent(formattedText.text, layoutStyle, hyperlink);
    }

    private void FillTextContentForRun(
      Xceed.Pdf.Layout.Text.Text text,
      XElement run,
      ref List<FormattedText> remainingMagicText)
    {
      foreach (XElement element in run.Elements())
      {
        XElement el = element;
        if (el.Name.Equals((object) XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName)))
        {
          FormattedText formattedText = remainingMagicText.FirstOrDefault<FormattedText>((Func<FormattedText, bool>) (x => x.text.Contains(el.Value)));
          if (formattedText != null)
          {
            string text1 = formattedText.text;
            int startIndex = formattedText.text.IndexOf(el.Value);
            formattedText.text = formattedText.text.Substring(startIndex, el.Value.Length);
            this.FillTextContent(text, formattedText);
            int num = formattedText.text.Equals(text1) ? 1 : (startIndex + el.Value.Length == text1.Length ? 1 : 0);
            formattedText.text = text1;
            if (num != 0)
              remainingMagicText.Remove(formattedText);
          }
        }
        else if (el.Name.Equals((object) XName.Get("tab", Xceed.Document.NET.Document.w.NamespaceName)))
        {
          FormattedText formattedText = remainingMagicText.FirstOrDefault<FormattedText>((Func<FormattedText, bool>) (x => x.text.Contains("\t")));
          if (formattedText != null)
          {
            string text1 = formattedText.text;
            int startIndex = formattedText.text.IndexOf("\t");
            formattedText.text = formattedText.text.Substring(startIndex, 1);
            this.FillTextContent(text, formattedText);
            int num = formattedText.text.Equals(text1) ? 1 : (startIndex + 1 == text1.Length ? 1 : 0);
            formattedText.text = text1;
            if (num != 0)
              remainingMagicText.Remove(formattedText);
          }
        }
        else if (el.Name.Equals((object) XName.Get("br", Xceed.Document.NET.Document.w.NamespaceName)))
        {
          FormattedText formattedText = remainingMagicText.FirstOrDefault<FormattedText>((Func<FormattedText, bool>) (x => x.text.Contains("\n")));
          if (formattedText != null)
          {
            string text1 = formattedText.text;
            int startIndex = formattedText.text.IndexOf("\n");
            formattedText.text = formattedText.text.Substring(startIndex, 1);
            this.FillTextContent(text, formattedText);
            int num = formattedText.text.Equals(text1) ? 1 : (startIndex + 1 == text1.Length ? 1 : 0);
            formattedText.text = text1;
            if (num != 0)
              remainingMagicText.Remove(formattedText);
          }
        }
      }
    }

    private Xceed.Pdf.Layout.Text.Hyperlink GetHyperlink(string paragraphText)
    {
      if (this._paragraph.Hyperlinks.Count > 0)
      {
        Hyperlink hyperlink = this._paragraph.Hyperlinks.FirstOrDefault<Hyperlink>((Func<Hyperlink, bool>) (x => x.Text != null && x.Text.Contains(paragraphText)));
        if (hyperlink != null)
        {
          if (hyperlink.Uri != (Uri) null)
            return new Xceed.Pdf.Layout.Text.Hyperlink(hyperlink.Uri.AbsoluteUri);
          string attribute = hyperlink.Xml.GetAttribute(XName.Get("anchor", Xceed.Document.NET.Document.w.NamespaceName));
          if (!string.IsNullOrEmpty(attribute))
          {
            if (PdfConverter._hyperlinkAnchorsDictionary.ContainsKey(attribute))
              return new Xceed.Pdf.Layout.Text.Hyperlink((Destination) PdfConverter._hyperlinkAnchorsDictionary[attribute]);
            XYZDestination xyzDestination = new XYZDestination();
            PdfConverter._hyperlinkAnchorsDictionary.Add(attribute, xyzDestination);
            return new Xceed.Pdf.Layout.Text.Hyperlink((Destination) xyzDestination);
          }
        }
      }
      return (Xceed.Pdf.Layout.Text.Hyperlink) null;
    }

    private string GetDocDefaultFontFamily()
    {
      XElement docDefaults = this._fileToConvert.GetDocDefaults();
      if (docDefaults != null)
      {
        XElement xelement1 = docDefaults.Element(XName.Get("rPrDefault", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 != null)
        {
          XElement xelement2 = xelement1.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
          if (xelement2 != null)
          {
            XElement el = xelement2.Element(XName.Get("rFonts", Xceed.Document.NET.Document.w.NamespaceName));
            if (el != null)
            {
              string str = el.GetAttribute(XName.Get("ascii", Xceed.Document.NET.Document.w.NamespaceName)) ?? el.GetAttribute(XName.Get("hAnsi", Xceed.Document.NET.Document.w.NamespaceName)) ?? el.GetAttribute(XName.Get("cs", Xceed.Document.NET.Document.w.NamespaceName)) ?? el.GetAttribute(XName.Get("hint", Xceed.Document.NET.Document.w.NamespaceName)) ?? el.GetAttribute(XName.Get("eastAsia", Xceed.Document.NET.Document.w.NamespaceName));
              if (!string.IsNullOrEmpty(str))
                return str;
            }
          }
        }
      }
      return Xceed.Pdf.Layout.Text.Text.DefaultStyle.Font.get_FontFamily().get_Name();
    }

    private double GetDocDefaultFontSize()
    {
      XElement docDefaults = this._fileToConvert.GetDocDefaults();
      if (docDefaults != null)
      {
        XElement xelement1 = docDefaults.Element(XName.Get("rPrDefault", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 != null)
        {
          XElement xelement2 = xelement1.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
          if (xelement2 != null)
          {
            XElement el = xelement2.Element(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName));
            if (el != null)
              return Convert.ToDouble(el.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName))) / 2.0;
          }
        }
      }
      return (double) Xceed.Pdf.Layout.Text.Text.DefaultStyle.Font.get_Size();
    }

    private Brush GetDocDefaultFontColor()
    {
      XElement docDefaults = this._fileToConvert.GetDocDefaults();
      if (docDefaults != null)
      {
        XElement xelement1 = docDefaults.Element(XName.Get("rPrDefault", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 != null)
        {
          XElement xelement2 = xelement1.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
          if (xelement2 != null)
          {
            XElement el = xelement2.Element(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName));
            if (el != null)
            {
              string attribute = el.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
              if (!string.IsNullOrEmpty(attribute))
                return (Brush) new SolidBrush(HelperFunctions.GetColorFromHtml(attribute));
            }
          }
        }
      }
      return Xceed.Pdf.Layout.Text.Text.DefaultStyle.Brush;
    }

    private static object GetDefault(Type type)
    {
      if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof (Nullable<>))
        type = type.GetProperty("Value").PropertyType;
      return !type.IsValueType ? (object) null : Activator.CreateInstance(type);
    }

    private Formatting GetFormattingFromStyle(string styleId)
    {
      XElement style = HelperFunctions.GetStyle(this._fileToConvert, styleId);
      if (style == null)
        return (Formatting) null;
      Formatting formatting = (Formatting) null;
      XElement el = style.Element(XName.Get("basedOn", Xceed.Document.NET.Document.w.NamespaceName));
      if (el != null)
        formatting = this.GetFormattingFromStyle(el.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)));
      return Formatting.Parse(style.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)), formatting);
    }

    private void UpdateUnderlinePen(
      Pen pen,
      UnderlineStyle underlineStyle,
      double fontSize,
      bool isBold)
    {
      float[] numArray = (float[]) null;
      float num1 = 0.5f;
      DashStyle dashStyle;
      switch (underlineStyle)
      {
        case UnderlineStyle.singleLine:
          dashStyle = (DashStyle) 0;
          break;
        case UnderlineStyle.doubleLine:
          dashStyle = (DashStyle) 0;
          break;
        case UnderlineStyle.dotted:
          dashStyle = (DashStyle) 2;
          num1 = 1f;
          break;
        case UnderlineStyle.thick:
          dashStyle = (DashStyle) 0;
          num1 = 1f;
          break;
        case UnderlineStyle.dash:
          dashStyle = (DashStyle) 1;
          num1 = 1f;
          break;
        case UnderlineStyle.dotDash:
          dashStyle = (DashStyle) 3;
          num1 = 1f;
          break;
        case UnderlineStyle.dotDotDash:
          dashStyle = (DashStyle) 4;
          num1 = 1f;
          break;
        case UnderlineStyle.dottedHeavy:
          dashStyle = (DashStyle) 2;
          num1 = 1.5f;
          break;
        case UnderlineStyle.dashedHeavy:
          dashStyle = (DashStyle) 1;
          num1 = 1.5f;
          break;
        case UnderlineStyle.dashDotHeavy:
          dashStyle = (DashStyle) 3;
          num1 = 1.5f;
          break;
        case UnderlineStyle.dashDotDotHeavy:
          dashStyle = (DashStyle) 4;
          num1 = 1.5f;
          break;
        case UnderlineStyle.dashLongHeavy:
          dashStyle = (DashStyle) 5;
          numArray = new float[2]{ 12f, 6f };
          num1 = 1.5f;
          break;
        case UnderlineStyle.dashLong:
          dashStyle = (DashStyle) 5;
          numArray = new float[2]{ 12f, 6f };
          num1 = 1f;
          break;
        default:
          dashStyle = (DashStyle) 0;
          break;
      }
      pen.set_DashStyle(dashStyle);
      if (numArray != null)
        pen.set_DashPattern(numArray);
      float num2 = isBold ? 2f : 1f;
      pen.set_Width(num2 * (num1 * Convert.ToSingle(fontSize / this.GetDocDefaultFontSize())));
    }

    private Color GetLayoutStyleHighlight(Highlight? highlight)
    {
      if (highlight.HasValue)
      {
        switch (highlight.GetValueOrDefault())
        {
          case Highlight.yellow:
            return Color.Yellow;
          case Highlight.green:
            return Color.Green;
          case Highlight.cyan:
            return Color.Cyan;
          case Highlight.magenta:
            return Color.Magenta;
          case Highlight.blue:
            return Color.Blue;
          case Highlight.red:
            return Color.Red;
          case Highlight.darkBlue:
            return Color.DarkBlue;
          case Highlight.darkCyan:
            return Color.DarkCyan;
          case Highlight.darkGreen:
            return Color.DarkGreen;
          case Highlight.darkMagenta:
            return Color.DarkMagenta;
          case Highlight.darkRed:
            return Color.DarkRed;
          case Highlight.darkYellow:
            return Color.DarkSeaGreen;
          case Highlight.darkGray:
            return Color.DarkGray;
          case Highlight.lightGray:
            return Color.LightGray;
          case Highlight.black:
            return Color.Black;
        }
      }
      throw new InvalidDataException("highlight color is not supported");
    }

    private void UpdateLayoutStyleTabPositions(Style layoutStyle, bool isAbsoluteTab = false)
    {
      if (isAbsoluteTab)
      {
        foreach (XElement descendant in this._paragraph._runs.Descendants<XElement>(XName.Get("ptab", Xceed.Document.NET.Document.w.NamespaceName)))
        {
          TabPosition tabPosition = new TabPosition();
          string attribute1 = descendant.GetAttribute(XName.Get("alignment", Xceed.Document.NET.Document.w.NamespaceName));
          if (!string.IsNullOrEmpty(attribute1) && attribute1 != null)
          {
            if (!(attribute1 == "center"))
            {
              if (!(attribute1 == "left"))
              {
                if (attribute1 == "right")
                  tabPosition.Alignment = HorizontalAlignment.Right;
              }
              else
                tabPosition.Alignment = HorizontalAlignment.Left;
            }
            else
              tabPosition.Alignment = HorizontalAlignment.Center;
          }
          string attribute2 = descendant.GetAttribute(XName.Get("leader", Xceed.Document.NET.Document.w.NamespaceName));
          if (!string.IsNullOrEmpty(attribute2) && attribute2 != null)
          {
            if (!(attribute2 == "none"))
            {
              if (!(attribute2 == "dot"))
              {
                if (!(attribute2 == "underscore"))
                {
                  if (attribute2 == "hyphen")
                    tabPosition.Leader = LeaderCharacter.Hyphen;
                }
                else
                  tabPosition.Leader = LeaderCharacter.Underscore;
              }
              else
                tabPosition.Leader = LeaderCharacter.Dot;
            }
            else
              tabPosition.Leader = LeaderCharacter.None;
          }
          layoutStyle.TabPositions.Add(tabPosition);
        }
      }
      else
      {
        XElement xelement = this._paragraph.GetOrCreate_pPr().Element(XName.Get("tabs", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement == null)
          return;
        foreach (XElement element in xelement.Elements())
        {
          TabPosition tabPosition = new TabPosition();
          string attribute1 = element.GetAttribute(XName.Get("pos", Xceed.Document.NET.Document.w.NamespaceName));
          float result;
          if (attribute1 != null && HelperFunctions.TryParseFloat(attribute1, out result))
            tabPosition.Value = result / 20f;
          string attribute2 = element.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
          if (!string.IsNullOrEmpty(attribute2) && attribute2 != null)
          {
            if (!(attribute2 == "center"))
            {
              if (!(attribute2 == "left"))
              {
                if (!(attribute2 == "right"))
                {
                  if (attribute2 == "clear")
                    tabPosition.IsClear = true;
                }
                else
                  tabPosition.Alignment = HorizontalAlignment.Right;
              }
              else
                tabPosition.Alignment = HorizontalAlignment.Left;
            }
            else
              tabPosition.Alignment = HorizontalAlignment.Center;
          }
          string attribute3 = element.GetAttribute(XName.Get("leader", Xceed.Document.NET.Document.w.NamespaceName));
          if (!string.IsNullOrEmpty(attribute3) && attribute3 != null)
          {
            if (!(attribute3 == "none"))
            {
              if (!(attribute3 == "dot"))
              {
                if (!(attribute3 == "underscore"))
                {
                  if (attribute3 == "hyphen")
                    tabPosition.Leader = LeaderCharacter.Hyphen;
                }
                else
                  tabPosition.Leader = LeaderCharacter.Underscore;
              }
              else
                tabPosition.Leader = LeaderCharacter.Dot;
            }
            else
              tabPosition.Leader = LeaderCharacter.None;
          }
          layoutStyle.TabPositions.Add(tabPosition);
        }
      }
    }

    private void ApplyParagraphBorders(Xceed.Pdf.Layout.Text.Text text)
    {
      XElement xelement1 = this._paragraph.GetOrCreate_pPr().Element(XName.Get("pBdr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 == null)
        return;
      bool flag1 = true;
      bool flag2 = true;
      if (this._previousParagraph != null && this._previousParagraph.StyleId == this._paragraph.StyleId)
      {
        XElement xelement2 = this._previousParagraph.GetOrCreate_pPr().Element(XName.Get("pBdr", Xceed.Document.NET.Document.w.NamespaceName));
        if (XNode.DeepEquals((XNode) xelement1, (XNode) xelement2))
          flag1 = false;
      }
      if (this._nextParagraph != null && this._nextParagraph.StyleId == this._paragraph.StyleId)
      {
        XElement xelement2 = this._nextParagraph.GetOrCreate_pPr().Element(XName.Get("pBdr", Xceed.Document.NET.Document.w.NamespaceName));
        if (XNode.DeepEquals((XNode) xelement1, (XNode) xelement2))
          flag2 = false;
      }
      foreach (XElement descendant in xelement1.Descendants())
      {
        DashStyle dashStyle = (DashStyle) 0;
        float[] dashPattern = (float[]) null;
        float width = 1f;
        Color color = Color.Black;
        float distance = 1f;
        bool isDouble = false;
        if ((!(descendant.Name.LocalName == "top") || flag1) && (!(descendant.Name.LocalName == "bottom") || flag2))
        {
          XAttribute xattribute1 = descendant.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
          if (xattribute1 != null)
          {
            switch (xattribute1.Value)
            {
              case "dashSmallGap":
                dashStyle = (DashStyle) 5;
                dashPattern = new float[2]{ 3f, 2f };
                break;
              case "dashed":
                dashStyle = (DashStyle) 5;
                dashPattern = new float[2]{ 4f, 4f };
                break;
              case "dotDash":
                dashStyle = (DashStyle) 3;
                break;
              case "dotDotDash":
                dashStyle = (DashStyle) 4;
                break;
              case "dotted":
                dashStyle = (DashStyle) 2;
                break;
              case "double":
                dashStyle = (DashStyle) 0;
                isDouble = true;
                break;
              case "nil":
              case "none":
                continue;
              case "single":
                dashStyle = (DashStyle) 0;
                break;
            }
          }
          XAttribute xattribute2 = descendant.Attribute(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName));
          if (xattribute2 != null && xattribute2.Value != "auto")
            color = HelperFunctions.GetColorFromHtml(xattribute2.Value);
          XAttribute xattribute3 = descendant.Attribute(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName));
          if (xattribute3 != null)
            width = Convert.ToSingle(xattribute3.Value) / 8f;
          XAttribute xattribute4 = descendant.Attribute(XName.Get("space", Xceed.Document.NET.Document.w.NamespaceName));
          if (xattribute4 != null)
            distance = Convert.ToSingle(xattribute4.Value);
          Xceed.Pdf.Layout.Border border = new Xceed.Pdf.Layout.Border(width, color, distance, dashStyle, dashPattern, isDouble);
          switch (descendant.Name.LocalName)
          {
            case "top":
              text.Borders.Top = border;
              continue;
            case "bottom":
              text.Borders.Bottom = border;
              continue;
            case "left":
              text.Borders.Left = border;
              continue;
            case "right":
              text.Borders.Right = border;
              continue;
            default:
              continue;
          }
        }
      }
    }

    private void ApplyParagraphShading(Xceed.Pdf.Layout.Text.Text text)
    {
      XElement xelement = this._paragraph.GetOrCreate_pPr().Element(XName.Get("shd", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement == null)
        return;
      XAttribute xattribute = xelement.Attribute(XName.Get("fill", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute == null || !(xattribute.Value != "FFFFFF"))
        return;
      text.BackColor = HelperFunctions.GetColorFromHtml(xattribute.Value);
    }

    private bool IgnoreSpacing(Paragraph p1, Paragraph p2)
    {
      if (p1 == null || p2 == null || !(p1.StyleId == p2.StyleId))
        return false;
      XElement xelement1 = p1.GetOrCreate_pPr().Element(XName.Get("contextualSpacing", Xceed.Document.NET.Document.w.NamespaceName));
      XElement xelement2 = p2.GetOrCreate_pPr().Element(XName.Get("contextualSpacing", Xceed.Document.NET.Document.w.NamespaceName));
      return xelement1 != null && xelement2 != null;
    }

    private void AddEndOfLine(Xceed.Pdf.Layout.Text.Text text)
    {
      if (text == null)
        return;
      Formatting formatting = Formatting.Parse(this._paragraph.GetOrCreate_pPr().Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)));
      formatting.UnderlineColor = new Color?(Color.Transparent);
      formatting.Highlight = new Highlight?(Highlight.none);
      FormattedText magicText = new FormattedText()
      {
        text = "\n",
        formatting = formatting
      };
      Style layoutStyle = this.GetLayoutStyle(magicText);
      text.AddContent(magicText.text, layoutStyle);
    }

    private void AddEndOfLine(Xceed.Pdf.Layout.Text.Text text, FormattedText formattedText)
    {
      if (text == null)
        return;
      Style layoutStyle = this.GetLayoutStyle(formattedText);
      text.AddContent("\n", layoutStyle);
    }

    private void UpdateParagraphPicture(string pictureId, Xceed.Pdf.Layout.Text.Text text)
    {
      Picture picture = this._paragraph.Pictures.FirstOrDefault<Picture>((Func<Picture, bool>) (x => x.Id == pictureId));
      if (picture == null)
        return;
      new PdfPicture(this, picture).UpdateText(text, false);
    }

    private void UpdateParagraphShape(XElement shapeXmlFromRun, Xceed.Pdf.Layout.Text.Text text)
    {
      Shape shape = this._paragraph.Shapes.FirstOrDefault<Shape>((Func<Shape, bool>) (x => x.Xml.Equals((object) shapeXmlFromRun)));
      if (shape == null || !PdfUtils.IsWrappingInLineWithText((DocumentElement) shape))
        return;
      new PdfShape(this, shape, this._graphics, this._pageNumber).UpdateText(text, false);
    }

    private string GetUpdatedPageNumberString(string pageNumberString, int pageNumber)
    {
      if (string.IsNullOrEmpty(pageNumberString))
        return string.Empty;
      IEnumerable<char> source = pageNumberString.Where<char>((Func<char, bool>) (x => char.IsDigit(x)));
      if (source.Count<char>() == 0)
        return string.Empty;
      int startIndex = pageNumberString.IndexOf(source.First<char>());
      foreach (char ch in source)
        pageNumberString = pageNumberString.Replace(ch.ToString(), "");
      return pageNumberString.Insert(startIndex, pageNumber.ToString());
    }

    private struct LoadedFont
    {
      public System.Drawing.Font Font { get; set; }

      public FontFamily FontFamily { get; set; }
    }
  }
}
