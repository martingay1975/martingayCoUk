﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.MatchFormattingOptions
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

namespace Xceed.Document.NET
{
  /// <summary>Value indicating the match formatting option to use.</summary>
  public enum MatchFormattingOptions
  {
    ExactMatch,
    SubsetMatch,
  }
}
