﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.ChartLegend
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represent a Chart's Legend.</summary>
  public class ChartLegend
  {
    /// <summary>Gets or sets if other chart elements are allowed to overlap this ChartLegend.</summary>
    public bool Overlay
    {
      get => this.Xml.Element(XName.Get("overlay", Xceed.Document.NET.Document.c.NamespaceName)).Attribute((XName) "val").Value == "1";
      set => this.Xml.Element(XName.Get("overlay", Xceed.Document.NET.Document.c.NamespaceName)).Attribute((XName) "val").Value = this.GetOverlayValue(value);
    }

    /// <summary>Gets or sets the position of this ChartLegend in its associated Chart.</summary>
    public ChartLegendPosition Position
    {
      get => XElementHelpers.GetValueToEnum<ChartLegendPosition>(this.Xml.Element(XName.Get("legendPos", Xceed.Document.NET.Document.c.NamespaceName)));
      set => XElementHelpers.SetValueFromEnum<ChartLegendPosition>(this.Xml.Element(XName.Get("legendPos", Xceed.Document.NET.Document.c.NamespaceName)), value);
    }

    internal XElement Xml { get; private set; }

    internal ChartLegend(ChartLegendPosition position, bool overlay) => this.Xml = new XElement(XName.Get("legend", Xceed.Document.NET.Document.c.NamespaceName), new object[2]
    {
      (object) new XElement(XName.Get("legendPos", Xceed.Document.NET.Document.c.NamespaceName), (object) new XAttribute((XName) "val", (object) XElementHelpers.GetXmlNameFromEnum<ChartLegendPosition>(position))),
      (object) new XElement(XName.Get(nameof (overlay), Xceed.Document.NET.Document.c.NamespaceName), (object) new XAttribute((XName) "val", (object) this.GetOverlayValue(overlay)))
    });

    internal ChartLegend(XElement Xml)
      : this(ChartLegendPosition.Right, false)
      => this.Xml = Xml;

    internal void SetXml(XElement xml) => this.Xml = xml;

    private string GetOverlayValue(bool overlay) => overlay ? "1" : "0";
  }
}
