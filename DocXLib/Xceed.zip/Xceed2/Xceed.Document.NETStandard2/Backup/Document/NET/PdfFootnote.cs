﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfFootnote
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System.Xml.Linq;

namespace Xceed.Document.NET
{
  internal class PdfFootnote : PdfNote
  {
    private static Xceed.Pdf.Layout.Text.Text _footnotesContent;

    internal PdfFootnote(PdfParagraph p, XElement run)
      : base(p, run)
    {
    }

    internal override string GetReferenceNoteType() => "footnoteReference";

    internal override string GetNoteType() => "footnote";

    internal override string GetNotePropertiesType() => "footnotePr";

    internal override string GetDefaultNumberedText(string id) => id;

    internal override XDocument GetNoteFile() => this._pdfParagraph.GetFileToConvert()._footnotes;

    internal override Xceed.Pdf.Layout.Text.Text GetNotesContent() => PdfFootnote.GetFootnotesContent();

    internal override void CreateNotesContent() => PdfFootnote._footnotesContent = new Xceed.Pdf.Layout.Text.Text();

    internal static Xceed.Pdf.Layout.Text.Text GetFootnotesContent() => PdfFootnote._footnotesContent;

    internal static float GetFootnotesContentHeight() => PdfFootnote._footnotesContent == null ? 0.0f : PdfFootnote._footnotesContent.Height;

    internal static void CleanFootnotes() => PdfFootnote._footnotesContent = (Xceed.Pdf.Layout.Text.Text) null;
  }
}
