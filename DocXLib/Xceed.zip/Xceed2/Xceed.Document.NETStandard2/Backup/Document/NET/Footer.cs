﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Footer
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO.Packaging;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a Footer.</summary>
  public class Footer : Container, IParagraphContainer
  {
    public bool PageNumbers
    {
      get => false;
      set => this.Xml.AddFirst((object) XElement.Parse("<w:sdt xmlns:w='http://schemas.openxmlformats.org/wordprocessingml/2006/main'>\r\n                    <w:sdtPr>\r\n                      <w:id w:val='157571950' />\r\n                      <w:docPartObj>\r\n                        <w:docPartGallery w:val='Page Numbers (Top of Page)' />\r\n                        <w:docPartUnique />\r\n                      </w:docPartObj>\r\n                    </w:sdtPr>\r\n                    <w:sdtContent>\r\n                      <w:p w:rsidR='008D2BFB' w:rsidRDefault='008D2BFB'>\r\n                        <w:pPr>\r\n                          <w:pStyle w:val='Header' />\r\n                          <w:jc w:val='center' />\r\n                        </w:pPr>\r\n                        <w:fldSimple w:instr=' PAGE \\* MERGEFORMAT'>\r\n                          <w:r>\r\n                            <w:rPr>\r\n                              <w:noProof />\r\n                            </w:rPr>\r\n                            <w:t>1</w:t>\r\n                          </w:r>\r\n                        </w:fldSimple>\r\n                      </w:p>\r\n                    </w:sdtContent>\r\n                  </w:sdt>"));
    }

    /// <summary>Gets the list of Paragraphs in this Footer.</summary>
    public override ReadOnlyCollection<Paragraph> Paragraphs
    {
      get
      {
        ReadOnlyCollection<Paragraph> paragraphs = base.Paragraphs;
        foreach (DocumentElement documentElement in paragraphs)
          documentElement.PackagePart = this.PackagePart;
        return paragraphs;
      }
    }

    /// <summary>Gets the list of Tables in this Footer.</summary>
    public override List<Table> Tables
    {
      get
      {
        List<Table> tables = base.Tables;
        tables.ForEach((Action<Table>) (x => x.PackagePart = this.PackagePart));
        return tables;
      }
    }

    /// <summary>Gets the list of Images in this Footer.</summary>
    public List<Image> Images
    {
      get
      {
        PackageRelationshipCollection relationshipsByType = this.PackagePart.GetRelationshipsByType("http://schemas.openxmlformats.org/officeDocument/2006/relationships/image");
        return ((IEnumerable<PackageRelationship>) relationshipsByType).Count<PackageRelationship>() > 0 ? ((IEnumerable<PackageRelationship>) relationshipsByType).Select<PackageRelationship, Image>((Func<PackageRelationship, Image>) (i => new Image(this.Document, i))).ToList<Image>() : new List<Image>();
      }
    }

    internal string Id { get; private set; }

    internal Footer(Xceed.Document.NET.Document document, XElement xml, PackagePart mainPart, string id)
      : base(document, xml)
    {
      this.PackagePart = mainPart;
      this.Id = id;
    }

    /// <summary>Inserts a blank Paragraph in this Footer.</summary>
    public override Paragraph InsertParagraph()
    {
      Paragraph paragraph = base.InsertParagraph();
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    /// <summary>Inserts a Paragraph at a specific location in this
    /// Footer, using the provided text, and optionally track this change.</summary>
    /// <param name="index">The index of the Paragraph where the new Paragraph is to be inserted.</param>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public override Paragraph InsertParagraph(int index, string text, bool trackChanges)
    {
      Paragraph paragraph = base.InsertParagraph(index, text, trackChanges);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    /// <summary>Inserts the provided Paragraph in this Footer.</summary>
    /// <param name="p">The Paragraph to insert.</param>
    public override Paragraph InsertParagraph(Paragraph p)
    {
      p.PackagePart = this.PackagePart;
      return base.InsertParagraph(p);
    }

    /// <summary>Inserts the provided Paragraph at a specific location in
    /// this Footer.</summary>
    /// <param name="index">The index of the Paragraph where the new Paragraph is to be inserted.</param>
    /// <param name="p">The Paragraph to insert.</param>
    public override Paragraph InsertParagraph(int index, Paragraph p)
    {
      p.PackagePart = this.PackagePart;
      return base.InsertParagraph(index, p);
    }

    /// <summary>Inserts a Paragraph at a specific location in this
    /// Footer, using the provided text and formatting, and optionally track this change.</summary>
    /// <param name="index">The index of the Paragraph where the new Paragraph is to be inserted.</param>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="formatting">The format to apply to the new Paragraph.</param>
    public override Paragraph InsertParagraph(
      int index,
      string text,
      bool trackChanges,
      Formatting formatting)
    {
      Paragraph paragraph = base.InsertParagraph(index, text, trackChanges, formatting);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    /// <summary>Inserts a Paragraph in this Footer, using the provided
    /// text.</summary>
    /// <param name="text">The text for the new Paragraph.</param>
    public override Paragraph InsertParagraph(string text)
    {
      Paragraph paragraph = base.InsertParagraph(text);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    /// <summary>Inserts a Paragraph in this Footer, using the provided
    /// text, and optionally track this change.</summary>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public override Paragraph InsertParagraph(string text, bool trackChanges)
    {
      Paragraph paragraph = base.InsertParagraph(text, trackChanges);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    /// <summary>Inserts a Paragraph in this Footer, using the provided
    /// text and formatting, and optionally track this change.</summary>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="formatting">The format to apply to the new Paragraph.</param>
    public override Paragraph InsertParagraph(
      string text,
      bool trackChanges,
      Formatting formatting)
    {
      Paragraph paragraph = base.InsertParagraph(text, trackChanges, formatting);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    /// <summary>Inserts an equation to this Footer.</summary>
    /// <returns>A Paragraph with the new equation inserted.</returns>
    /// <param name="equation">The equation to insert.</param>
    public override Paragraph InsertEquation(string equation, Alignment align = Alignment.center)
    {
      Paragraph paragraph = base.InsertEquation(equation, align);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    /// <summary>Inserts a Table of a specific size to this Footer.</summary>
    /// <param name="rowCount">The row count for the new Table.</param>
    /// <param name="columnCount">The column count for the new Table.</param>
    public override Table InsertTable(int rowCount, int columnCount) => this.SetMainPart(base.InsertTable(rowCount, columnCount));

    /// <summary>Inserts the provided Table at a specific location in this
    /// Footer.</summary>
    /// <param name="index">The index of the Paragraph where the Table is to be inserted.</param>
    /// <param name="t">The Table to insert.</param>
    public override Table InsertTable(int index, Table t) => this.SetMainPart(base.InsertTable(index, t));

    /// <summary>Inserts the provided Table to this Footer.</summary>
    /// <param name="t">The Table to insert.</param>
    public override Table InsertTable(Table t) => this.SetMainPart(base.InsertTable(t));

    /// <summary>Inserts a Table of a specific size and at a specific
    /// location, to this Footer.</summary>
    /// <param name="index">The index of the Paragraph where the Table is to be inserted.</param>
    /// <param name="rowCount">The row count for the new Table.</param>
    /// <param name="columnCount">The column count for the new Table.</param>
    public override Table InsertTable(int index, int rowCount, int columnCount) => this.SetMainPart(base.InsertTable(index, rowCount, columnCount));

    private Table SetMainPart(Table table)
    {
      if (table != null)
        table.PackagePart = this.PackagePart;
      return table;
    }
  }
}
