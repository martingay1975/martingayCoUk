﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.HelperFunctions
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.IO.Packaging;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  internal static class HelperFunctions
  {
    public const string DOCUMENT_DOCUMENTTYPE = "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml";
    public const string TEMPLATE_DOCUMENTTYPE = "application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml";
    public const string SETTING_DOCUMENTTYPE = "application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml";
    public const string MACRO_DOCUMENTTYPE = "application/vnd.ms-word.document.macroEnabled.main+xml";
    internal static readonly char[] RestrictedXmlCharacters = new char[59]
    {
      '\x0001',
      '\x0002',
      '\x0003',
      '\x0004',
      '\x0005',
      '\x0006',
      '\a',
      '\b',
      '\v',
      '\f',
      '\x000E',
      '\x000F',
      '\x0010',
      '\x0011',
      '\x0012',
      '\x0013',
      '\x0014',
      '\x0015',
      '\x0016',
      '\x0017',
      '\x0018',
      '\x0019',
      '\x001A',
      '\x001B',
      '\x001C',
      '\x001E',
      '\x001F',
      '\x007F',
      '\x0080',
      '\x0081',
      '\x0082',
      '\x0083',
      '\x0084',
      '\x0086',
      '\x0087',
      '\x0088',
      '\x0089',
      '\x008A',
      '\x008B',
      '\x008C',
      '\x008D',
      '\x008E',
      '\x008F',
      '\x0090',
      '\x0091',
      '\x0092',
      '\x0093',
      '\x0094',
      '\x0095',
      '\x0096',
      '\x0097',
      '\x0098',
      '\x0099',
      '\x009A',
      '\x009B',
      '\x009C',
      '\x009D',
      '\x009E',
      '\x009F'
    };

    internal static void CreateRelsPackagePart(Xceed.Document.NET.Document Document, Uri uri)
    {
      using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(Document._package.CreatePart(uri, "application/vnd.openxmlformats-package.relationships+xml", (CompressionOption) 1).GetStream())))
      {
        XDocument xdocument = new XDocument(new XDeclaration("1.0", "UTF-8", "yes"), new object[1]
        {
          (object) new XElement(XName.Get("Relationships", Xceed.Document.NET.Document.rel.NamespaceName))
        });
        XElement root = xdocument.Root;
        xdocument.Save(textWriter);
      }
    }

    internal static int GetSize(XElement Xml)
    {
      switch (Xml.Name.LocalName)
      {
        case "br":
        case "tc":
        case "tr":
          return !HelperFunctions.IsLineBreak(Xml) ? 0 : 1;
        case "delText":
        case "t":
          return Xml.Value.Length;
        case "ptab":
          return 1;
        case "tab":
          return !(Xml.Parent.Name.LocalName != "tabs") ? 0 : 1;
        default:
          return 0;
      }
    }

    internal static string GetText(XElement e)
    {
      StringBuilder sb = new StringBuilder();
      HelperFunctions.GetTextRecursive(e, ref sb);
      return sb.ToString();
    }

    internal static void GetTextRecursive(XElement Xml, ref StringBuilder sb)
    {
      sb.Append(HelperFunctions.ToText(Xml));
      bool flag1 = Xml.Name.Equals((object) XName.Get("Fallback", Xceed.Document.NET.Document.mc.NamespaceName));
      bool flag2 = Xml.Name.Equals((object) XName.Get("drawing", Xceed.Document.NET.Document.w.NamespaceName));
      if (!Xml.HasElements || flag1 || flag2)
        return;
      foreach (XElement element in Xml.Elements())
        HelperFunctions.GetTextRecursive(element, ref sb);
    }

    internal static List<FormattedText> GetFormattedText(XElement e)
    {
      List<FormattedText> alist = new List<FormattedText>();
      HelperFunctions.GetFormattedTextRecursive(e, ref alist);
      return alist;
    }

    internal static void GetFormattedTextRecursive(XElement Xml, ref List<FormattedText> alist)
    {
      FormattedText formattedText1 = HelperFunctions.ToFormattedText(Xml);
      FormattedText formattedText2 = (FormattedText) null;
      if (formattedText1 != null)
      {
        if (alist.Count<FormattedText>() > 0)
          formattedText2 = alist.Last<FormattedText>();
        if (formattedText2 != null && formattedText2.CompareTo((object) formattedText1) == 0)
        {
          formattedText2.text += formattedText1.text;
        }
        else
        {
          if (formattedText2 != null)
            formattedText1.index = formattedText2.index + formattedText2.text.Length;
          alist.Add(formattedText1);
        }
      }
      if (!Xml.HasElements)
        return;
      foreach (XElement element in Xml.Elements())
        HelperFunctions.GetFormattedTextRecursive(element, ref alist);
    }

    internal static FormattedText ToFormattedText(XElement e)
    {
      string text = HelperFunctions.ToText(e);
      if (text == string.Empty)
        return (FormattedText) null;
      if (e.AncestorsAndSelf().FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Name.Equals((object) XName.Get("Fallback", Xceed.Document.NET.Document.mc.NamespaceName)))) != null)
        return (FormattedText) null;
      while (e != null && !e.Name.Equals((object) XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName)) && !e.Name.Equals((object) XName.Get("tabs", Xceed.Document.NET.Document.w.NamespaceName)))
        e = e.Parent;
      FormattedText formattedText = new FormattedText();
      formattedText.text = text;
      formattedText.index = 0;
      formattedText.formatting = (Formatting) null;
      if (e != null)
      {
        XElement rPr = e.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (rPr != null)
          formattedText.formatting = Formatting.Parse(rPr);
      }
      return formattedText;
    }

    internal static bool IsLineBreak(XElement xml)
    {
      if (xml == null || xml.Name.LocalName != "br")
        return false;
      string str = !xml.HasAttributes || xml.Attribute(Xceed.Document.NET.Document.w + "type") == null ? (string) null : xml.Attribute(Xceed.Document.NET.Document.w + "type").Value;
      return str == null || str == "textWrapping";
    }

    internal static string ToText(XElement e)
    {
      switch (e.Name.LocalName)
      {
        case "br":
          return HelperFunctions.IsLineBreak(e) ? "\n" : "";
        case "delText":
        case "t":
          return e.Value;
        case "ptab":
          return "\v";
        case "tab":
        case "tc":
          return e.Parent == null || !e.Parent.Name.Equals((object) XName.Get("tabs", Xceed.Document.NET.Document.w.NamespaceName)) ? "\t" : "";
        case "tr":
          return "\n";
        default:
          return "";
      }
    }

    internal static XElement CloneElement(XElement element) => new XElement(element.Name, new object[2]
    {
      (object) element.Attributes(),
      (object) element.Nodes().Select<XNode, XNode>((Func<XNode, XNode>) (n => n is XElement element1 ? (XNode) HelperFunctions.CloneElement(element1) : n))
    });

    internal static PackagePart GetMainDocumentPart(Package package) => ((IEnumerable<PackagePart>) package.GetParts()).Single<PackagePart>((Func<PackagePart, bool>) (p => p.get_ContentType().Equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml", StringComparison.CurrentCultureIgnoreCase) || p.get_ContentType().Equals("application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml", StringComparison.CurrentCultureIgnoreCase) || p.get_ContentType().Equals("application/vnd.ms-word.document.macroEnabled.main+xml", StringComparison.CurrentCultureIgnoreCase)));

    internal static PackagePart CreateOrGetSettingsPart(Package package)
    {
      Uri uri = new Uri("/word/settings.xml", UriKind.Relative);
      PackagePart part;
      if (!package.PartExists(uri))
      {
        part = package.CreatePart(uri, "application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml", (CompressionOption) 1);
        HelperFunctions.GetMainDocumentPart(package).CreateRelationship(uri, (TargetMode) 0, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings");
        XDocument xdocument = XDocument.Parse("<?xml version='1.0' encoding='utf-8' standalone='yes'?>\r\n                <w:settings xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:r='http://schemas.openxmlformats.org/officeDocument/2006/relationships' xmlns:m='http://schemas.openxmlformats.org/officeDocument/2006/math' xmlns:v='urn:schemas-microsoft-com:vml' xmlns:w10='urn:schemas-microsoft-com:office:word' xmlns:w='http://schemas.openxmlformats.org/wordprocessingml/2006/main' xmlns:sl='http://schemas.openxmlformats.org/schemaLibrary/2006/main'>\r\n                  <w:zoom w:percent='100' />\r\n                  <w:defaultTabStop w:val='720' />\r\n                  <w:characterSpacingControl w:val='doNotCompress' />\r\n                  <w:compat />\r\n                  <w:rsids>\r\n                    <w:rsidRoot w:val='00217F62' />\r\n                    <w:rsid w:val='001915A3' />\r\n                    <w:rsid w:val='00217F62' />\r\n                    <w:rsid w:val='00A906D8' />\r\n                    <w:rsid w:val='00AB5A74' />\r\n                    <w:rsid w:val='00F071AE' />\r\n                  </w:rsids>\r\n                  <m:mathPr>\r\n                    <m:mathFont m:val='Cambria Math' />\r\n                    <m:brkBin m:val='before' />\r\n                    <m:brkBinSub m:val='--' />\r\n                    <m:smallFrac m:val='off' />\r\n                    <m:dispDef />\r\n                    <m:lMargin m:val='0' />\r\n                    <m:rMargin m:val='0' />\r\n                    <m:defJc m:val='centerGroup' />\r\n                    <m:wrapIndent m:val='1440' />\r\n                    <m:intLim m:val='subSup' />\r\n                    <m:naryLim m:val='undOvr' />\r\n                  </m:mathPr>\r\n                  <w:displayBackgroundShape w:val='true' />\r\n                  <w:themeFontLang w:val='en-IE' w:bidi='ar-SA' />\r\n                  <w:clrSchemeMapping w:bg1='light1' w:t1='dark1' w:bg2='light2' w:t2='dark2' w:accent1='accent1' w:accent2='accent2' w:accent3='accent3' w:accent4='accent4' w:accent5='accent5' w:accent6='accent6' w:hyperlink='hyperlink' w:followedHyperlink='followedHyperlink' />\r\n                  <w:shapeDefaults>\r\n                    <o:shapedefaults v:ext='edit' spidmax='2050' />\r\n                    <o:shapelayout v:ext='edit'>\r\n                      <o:idmap v:ext='edit' data='1' />\r\n                    </o:shapelayout>\r\n                  </w:shapeDefaults>\r\n                  <w:decimalSymbol w:val='.' />\r\n                  <w:listSeparator w:val=',' />\r\n                </w:settings>");
        xdocument.Root.Element(XName.Get("themeFontLang", Xceed.Document.NET.Document.w.NamespaceName)).SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) CultureInfo.CurrentCulture);
        using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(part.GetStream())))
          xdocument.Save(textWriter);
      }
      else
        part = package.GetPart(uri);
      return part;
    }

    internal static void CreateCorePropertiesPart(Xceed.Document.NET.Document document)
    {
      PackagePart part = document._package.CreatePart(new Uri("/docProps/core.xml", UriKind.Relative), "application/vnd.openxmlformats-package.core-properties+xml", (CompressionOption) 1);
      using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(part.GetStream(FileMode.Create, FileAccess.Write))))
        XDocument.Parse("<?xml version='1.0' encoding='UTF-8' standalone='yes'?>\r\n      <cp:coreProperties xmlns:cp='http://schemas.openxmlformats.org/package/2006/metadata/core-properties' xmlns:dc='http://purl.org/dc/elements/1.1/' xmlns:dcterms='http://purl.org/dc/terms/' xmlns:dcmitype='http://purl.org/dc/dcmitype/' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'> \r\n         <dc:title></dc:title>\r\n         <dc:subject></dc:subject>\r\n         <dc:creator></dc:creator>\r\n         <cp:keywords></cp:keywords>\r\n         <dc:description></dc:description>\r\n         <cp:lastModifiedBy></cp:lastModifiedBy>\r\n         <cp:revision>1</cp:revision>\r\n         <dcterms:created xsi:type='dcterms:W3CDTF'>" + DateTime.UtcNow.ToString("s") + "Z</dcterms:created>\r\n         <dcterms:modified xsi:type='dcterms:W3CDTF'>" + DateTime.UtcNow.ToString("s") + "Z</dcterms:modified>\r\n      </cp:coreProperties>").Save(textWriter, SaveOptions.None);
      document._package.CreateRelationship(part.get_Uri(), (TargetMode) 0, "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties");
    }

    internal static void CreateCustomPropertiesPart(Xceed.Document.NET.Document document)
    {
      PackagePart part = document._package.CreatePart(new Uri("/docProps/custom.xml", UriKind.Relative), "application/vnd.openxmlformats-officedocument.custom-properties+xml", (CompressionOption) 1);
      using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(part.GetStream(FileMode.Create, FileAccess.Write))))
        new XDocument(new XDeclaration("1.0", "UTF-8", "yes"), new object[1]
        {
          (object) new XElement(XName.Get("Properties", Xceed.Document.NET.Document.customPropertiesSchema.NamespaceName), (object) new XAttribute(XNamespace.Xmlns + "vt", (object) Xceed.Document.NET.Document.customVTypesSchema))
        }).Save(textWriter, SaveOptions.None);
      document._package.CreateRelationship(part.get_Uri(), (TargetMode) 0, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/custom-properties");
    }

    internal static XDocument DecompressXMLResource(string manifest_resource_name)
    {
      using (GZipStream gzipStream = new GZipStream(Assembly.GetExecutingAssembly().GetManifestResourceStream(manifest_resource_name), CompressionMode.Decompress))
      {
        using (TextReader textReader = (TextReader) new StreamReader((Stream) gzipStream))
          return XDocument.Load(textReader);
      }
    }

    internal static string GetResources(ResourceType resType)
    {
      switch (resType)
      {
        case ResourceType.DefaultStyle:
          return "Xceed.Document.NETStandard.Resources.default_styles.xml.gz";
        case ResourceType.NumberingBullet:
          return "Xceed.Document.NETStandard.Resources.numbering.default_bullet_abstract.xml.gz";
        case ResourceType.NumberingDecimal:
          return "Xceed.Document.NETStandard.Resources.numbering.default_decimal_abstract.xml.gz";
        case ResourceType.Numbering:
          return "Xceed.Document.NETStandard.Resources.numbering.xml.gz";
        case ResourceType.Styles:
          return "Xceed.Document.NETStandard.Resources.styles.xml.gz";
        case ResourceType.Theme:
          return "Xceed.Document.NETStandard.Resources.theme.xml.gz";
        default:
          return (string) null;
      }
    }

    internal static XDocument AddDefaultStylesXml(Package package)
    {
      PackagePart part = package.CreatePart(new Uri("/word/styles.xml", UriKind.Relative), "application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml", (CompressionOption) 1);
      XDocument xdocument = HelperFunctions.DecompressXMLResource(HelperFunctions.GetResources(ResourceType.DefaultStyle));
      xdocument.Root.Element(XName.Get("docDefaults", Xceed.Document.NET.Document.w.NamespaceName)).Element(XName.Get("rPrDefault", Xceed.Document.NET.Document.w.NamespaceName)).Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)).Element(XName.Get("lang", Xceed.Document.NET.Document.w.NamespaceName)).SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) CultureInfo.CurrentCulture);
      using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(part.GetStream(FileMode.Create, FileAccess.Write))))
        xdocument.Save(textWriter, SaveOptions.None);
      HelperFunctions.GetMainDocumentPart(package).CreateRelationship(part.get_Uri(), (TargetMode) 0, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles");
      return xdocument;
    }

    internal static XElement CreateEdit(EditType t, DateTime edit_time, object content)
    {
      if (t == EditType.del)
      {
        foreach (object obj in (IEnumerable<XElement>) content)
        {
          if (obj is XElement)
          {
            IEnumerable<XElement> source = (obj as XElement).DescendantsAndSelf(XName.Get(nameof (t), Xceed.Document.NET.Document.w.NamespaceName));
            for (int index = 0; index < source.Count<XElement>(); ++index)
            {
              XElement xelement = source.ElementAt<XElement>(index);
              xelement.ReplaceWith((object) new XElement(Xceed.Document.NET.Document.w + "delText", new object[2]
              {
                (object) xelement.Attributes(),
                (object) xelement.Value
              }));
            }
          }
        }
      }
      return new XElement(Xceed.Document.NET.Document.w + t.ToString(), new object[4]
      {
        (object) new XAttribute(Xceed.Document.NET.Document.w + "id", (object) 0),
        (object) new XAttribute(Xceed.Document.NET.Document.w + "author", (object) (Environment.UserDomainName + "\\" + Environment.UserName)),
        (object) new XAttribute(Xceed.Document.NET.Document.w + "date", (object) edit_time),
        content
      });
    }

    internal static XElement CreateTable(int rowCount, int columnCount)
    {
      int[] columnWidths = rowCount > 0 && columnCount > 0 ? new int[columnCount] : throw new ArgumentOutOfRangeException("Row and Column count must be greater than 0.");
      for (int index = 0; index < columnCount; ++index)
        columnWidths[index] = 2310;
      return HelperFunctions.CreateTable(rowCount, columnWidths);
    }

    internal static XElement CreateTable(int rowCount, int[] columnWidths)
    {
      XElement xelement1 = new XElement(XName.Get("tbl", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName), new object[3]
      {
        (object) new XElement(XName.Get("tblStyle", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) "TableGrid")),
        (object) new XElement(XName.Get("tblW", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
        {
          (object) new XAttribute(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName), (object) "5000"),
          (object) new XAttribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName), (object) "auto")
        }),
        (object) new XElement(XName.Get("tblLook", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) "04A0"))
      }));
      for (int index1 = 0; index1 < rowCount; ++index1)
      {
        XElement xelement2 = new XElement(XName.Get("tr", Xceed.Document.NET.Document.w.NamespaceName));
        for (int index2 = 0; index2 < columnWidths.Length; ++index2)
        {
          XElement tableCell = HelperFunctions.CreateTableCell();
          xelement2.Add((object) tableCell);
        }
        xelement1.Add((object) xelement2);
      }
      return xelement1;
    }

    internal static XElement CreateTableCell(double w = 2310.0) => new XElement(XName.Get("tc", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
    {
      (object) new XElement(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("tcW", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
      {
        (object) new XAttribute(XName.Get(nameof (w), Xceed.Document.NET.Document.w.NamespaceName), (object) w),
        (object) new XAttribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName), (object) "dxa")
      })),
      (object) new XElement(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName)))
    });

    internal static XElement CreateShape(
      long newDocPrId,
      float width,
      float height,
      Color? fillColor = null,
      Color? outlineColor = null,
      float outlineWidth = 1f,
      DashStyle? outlineDash = null)
    {
      float num1 = width * 12700f;
      float num2 = height * 12700f;
      XElement xelement1 = new XElement(XName.Get("solidFill", Xceed.Document.NET.Document.a.NamespaceName), (object) new XElement(XName.Get("srgbClr", Xceed.Document.NET.Document.a.NamespaceName), (object) new XAttribute((XName) "val", fillColor.HasValue ? (object) fillColor.Value.ToHex() : (object) "4472C4")));
      float num3 = outlineWidth * 12700f;
      string str1 = outlineColor.HasValue ? outlineColor.Value.ToHex() : "2F528F";
      string str2 = outlineDash.HasValue ? Shape.GetDashTypeString(outlineDash) : "solid";
      XElement xelement2 = new XElement(XName.Get("ln", Xceed.Document.NET.Document.a.NamespaceName), new object[3]
      {
        (object) new XAttribute(XName.Get("w"), (object) num3),
        (object) new XElement(XName.Get("solidFill", Xceed.Document.NET.Document.a.NamespaceName), (object) new XElement(XName.Get("srgbClr", Xceed.Document.NET.Document.a.NamespaceName), (object) new XAttribute((XName) "val", (object) str1))),
        (object) new XElement(XName.Get("prstDash", Xceed.Document.NET.Document.a.NamespaceName), (object) new XAttribute((XName) "val", (object) str2))
      });
      return XElement.Parse(string.Format("\r\n      <w:r xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">\r\n          <w:drawing xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">\r\n              <wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\" simplePos=\"0\" relativeHeight=\"0\" behindDoc=\"0\" locked=\"0\" layoutInCell=\"1\" allowOverlap=\"1\" xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\">\r\n                  <wp:simplePos x=\"0\" y=\"0\"/>\r\n                  <wp:positionH relativeFrom=\"margin\">\r\n                    <wp:align>left</wp:align>\r\n                  </wp:positionH>\r\n                  <wp:positionV relativeFrom=\"margin\">\r\n                    <wp:align>top</wp:align>\r\n                  </wp:positionV>\r\n                  <wp:extent cx=\"{0}\" cy=\"{1}\"/>\r\n                  <wp:effectExtent l=\"0\" t=\"0\" r=\"0\" b=\"0\"/>\r\n                  <wp:wrapNone/>\r\n                  <wp:docPr id=\"{2}\" name=\"\"/>\r\n                  <wp:cNvGraphicFramePr />\r\n                  <a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">\r\n                      <a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\">\r\n                          <wps:wsp xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\">\r\n                             <wps:cNvSpPr/>\r\n                             <wps:spPr>\r\n                                <a:xfrm>\r\n                                   <a:off x=\"0\" y=\"0\"/>\r\n                                   <a:ext cx=\"{0}\" cy=\"{1}\"/>\r\n                                </a:xfrm >\r\n                                <a:prstGeom prst=\"rect\">\r\n                                  <a:avLst/>\r\n                                </a:prstGeom>\r\n                                {3}\r\n                                {4}\r\n                             </wps:spPr>\r\n                             <wps:bodyPr rot=\"0\" spcFirstLastPara=\"0\" vertOverflow=\"overflow\" horzOverflow=\"overflow\" vert=\"horz\" wrap=\"square\" lIns=\"91440\" tIns=\"45720\" rIns=\"91440\" bIns=\"45720\" numCol=\"1\" spcCol=\"0\" rtlCol=\"0\" fromWordArt=\"0\" anchor=\"ctr\" anchorCtr=\"0\" forceAA=\"0\" compatLnSpc=\"1\">\r\n                               <a:prstTxWarp prst=\"textNoShape\">\r\n                                  <a:avLst/>\r\n                               </a:prstTxWarp>\r\n                               <a:noAutofit/>\r\n                             </wps:bodyPr>\r\n                          </wps:wsp>\r\n                      </a:graphicData>\r\n                  </a:graphic>\r\n              </wp:inline>\r\n          </w:drawing>\r\n      </w:r>\r\n      ", (object) num1, (object) num2, (object) newDocPrId.ToString(), (object) xelement1, (object) xelement2));
    }

    internal static XElement CreateTextBox(
      long newDocPrId,
      float width,
      float height,
      Paragraph paragraph,
      Color? fillColor = null,
      Color? outlineColor = null,
      float outlineWidth = 1f,
      DashStyle? outlineDash = null)
    {
      float num1 = width * 12700f;
      float num2 = height * 12700f;
      XElement xelement1 = new XElement(XName.Get("solidFill", Xceed.Document.NET.Document.a.NamespaceName), (object) new XElement(XName.Get("srgbClr", Xceed.Document.NET.Document.a.NamespaceName), (object) new XAttribute((XName) "val", fillColor.HasValue ? (object) fillColor.Value.ToHex() : (object) "FFFFFF")));
      float num3 = outlineWidth * 12700f;
      string str1 = outlineColor.HasValue ? outlineColor.Value.ToHex() : "000000";
      string str2 = outlineDash.HasValue ? Shape.GetDashTypeString(outlineDash) : "solid";
      XElement xelement2 = new XElement(XName.Get("ln", Xceed.Document.NET.Document.a.NamespaceName), new object[3]
      {
        (object) new XAttribute(XName.Get("w"), (object) num3),
        (object) new XElement(XName.Get("solidFill", Xceed.Document.NET.Document.a.NamespaceName), (object) new XElement(XName.Get("srgbClr", Xceed.Document.NET.Document.a.NamespaceName), (object) new XAttribute((XName) "val", (object) str1))),
        (object) new XElement(XName.Get("prstDash", Xceed.Document.NET.Document.a.NamespaceName), (object) new XAttribute((XName) "val", (object) str2))
      });
      return XElement.Parse(string.Format("\r\n      <w:r xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">\r\n          <w:drawing xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">\r\n              <wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\" simplePos=\"0\" relativeHeight=\"0\" behindDoc=\"0\" locked=\"0\" layoutInCell=\"1\" allowOverlap=\"1\" xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\">\r\n                  <wp:simplePos x=\"0\" y=\"0\"/>\r\n                  <wp:positionH relativeFrom=\"margin\">\r\n                    <wp:align>left</wp:align>\r\n                  </wp:positionH>\r\n                  <wp:positionV relativeFrom=\"margin\">\r\n                    <wp:align>top</wp:align>\r\n                  </wp:positionV>\r\n                  <wp:extent cx=\"{0}\" cy=\"{1}\"/>\r\n                  <wp:effectExtent l=\"0\" t=\"0\" r=\"0\" b=\"0\"/>\r\n                  <wp:wrapNone/>\r\n                  <wp:docPr id=\"{2}\" name=\"\"/>\r\n                  <wp:cNvGraphicFramePr />\r\n                  <a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">\r\n                      <a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\">\r\n                          <wps:wsp xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\">\r\n                             <wps:cNvSpPr txBox=\"1\"/>\r\n                             <wps:spPr>\r\n                                <a:xfrm>\r\n                                   <a:off x=\"0\" y=\"0\"/>\r\n                                   <a:ext cx=\"{0}\" cy=\"{1}\"/>\r\n                                </a:xfrm >\r\n                                <a:prstGeom prst=\"rect\">\r\n                                  <a:avLst/>\r\n                                </a:prstGeom>\r\n                                {3}\r\n                                {4}\r\n                             </wps:spPr>\r\n                             <wps:txbx>\r\n                                <w:txbxContent>\r\n                                  {5}\r\n                                </w:txbxContent>\r\n                             </wps:txbx>\r\n                             <wps:bodyPr rot=\"0\" vert=\"horz\" anchor=\"t\" anchorCtr=\"0\" wrap=\"square\" lIns=\"91440\" tIns=\"45720\" rIns=\"91440\" bIns=\"45720\">\r\n                               <a:noAutofit/>\r\n                             </wps:bodyPr>\r\n                          </wps:wsp>\r\n                      </a:graphicData>\r\n                  </a:graphic>\r\n              </wp:inline>\r\n          </w:drawing>\r\n      </w:r>\r\n      ", (object) num1, (object) num2, (object) newDocPrId.ToString(), (object) xelement1, (object) xelement2, (object) paragraph.Xml));
    }

    internal static void RenumberIDs(Xceed.Document.NET.Document document)
    {
      IEnumerable<XAttribute> source = document._mainDoc.Descendants().Where<XElement>((Func<XElement, bool>) (d => d.Name.LocalName == "ins" || d.Name.LocalName == "del")).Select<XElement, XAttribute>((Func<XElement, XAttribute>) (d => d.Attribute(XName.Get("id", "http://schemas.openxmlformats.org/wordprocessingml/2006/main"))));
      for (int index = 0; index < source.Count<XAttribute>(); ++index)
        source.ElementAt<XAttribute>(index).Value = index.ToString();
    }

    internal static Paragraph GetFirstParagraphEffectedByInsert(
      Xceed.Document.NET.Document document,
      int index)
    {
      ReadOnlyCollection<Paragraph> paragraphs = document.Paragraphs;
      if (paragraphs.Count<Paragraph>() == 0 && index == 0)
        return (Paragraph) null;
      foreach (Paragraph paragraph in paragraphs)
      {
        if (paragraph._endIndex >= index)
          return paragraph;
      }
      throw new ArgumentOutOfRangeException();
    }

    internal static List<XElement> FormatInput(string text, XElement rPr)
    {
      List<XElement> xelementList = new List<XElement>();
      XElement xelement1 = new XElement(Xceed.Document.NET.Document.w + "tab");
      XElement xelement2 = new XElement(Xceed.Document.NET.Document.w + "br");
      StringBuilder stringBuilder = new StringBuilder();
      if (string.IsNullOrEmpty(text))
        return xelementList;
      char ch1 = char.MinValue;
      foreach (char ch2 in text)
      {
        switch (ch2)
        {
          case '\t':
            if (stringBuilder.Length > 0)
            {
              XElement e = new XElement(Xceed.Document.NET.Document.w + "t", (object) stringBuilder.ToString());
              Xceed.Document.NET.Text.PreserveSpace(e);
              xelementList.Add(new XElement(Xceed.Document.NET.Document.w + "r", new object[2]
              {
                (object) rPr,
                (object) e
              }));
              stringBuilder = new StringBuilder();
            }
            xelementList.Add(new XElement(Xceed.Document.NET.Document.w + "r", new object[2]
            {
              (object) rPr,
              (object) xelement1
            }));
            break;
          case '\n':
            if (ch1 != '\r')
            {
              if (stringBuilder.Length > 0)
              {
                XElement e = new XElement(Xceed.Document.NET.Document.w + "t", (object) stringBuilder.ToString());
                Xceed.Document.NET.Text.PreserveSpace(e);
                xelementList.Add(new XElement(Xceed.Document.NET.Document.w + "r", new object[2]
                {
                  (object) rPr,
                  (object) e
                }));
                stringBuilder = new StringBuilder();
              }
              xelementList.Add(new XElement(Xceed.Document.NET.Document.w + "r", new object[2]
              {
                (object) rPr,
                (object) xelement2
              }));
              break;
            }
            break;
          case '\r':
            if (stringBuilder.Length > 0)
            {
              XElement e = new XElement(Xceed.Document.NET.Document.w + "t", (object) stringBuilder.ToString());
              Xceed.Document.NET.Text.PreserveSpace(e);
              xelementList.Add(new XElement(Xceed.Document.NET.Document.w + "r", new object[2]
              {
                (object) rPr,
                (object) e
              }));
              stringBuilder = new StringBuilder();
            }
            xelementList.Add(new XElement(Xceed.Document.NET.Document.w + "r", new object[2]
            {
              (object) rPr,
              (object) xelement2
            }));
            break;
          default:
            if (!((IEnumerable<char>) HelperFunctions.RestrictedXmlCharacters).Contains<char>(ch2))
            {
              stringBuilder.Append(ch2);
              break;
            }
            break;
        }
        ch1 = ch2;
      }
      if (stringBuilder.Length > 0)
      {
        XElement e = new XElement(Xceed.Document.NET.Document.w + "t", (object) stringBuilder.ToString());
        Xceed.Document.NET.Text.PreserveSpace(e);
        xelementList.Add(new XElement(Xceed.Document.NET.Document.w + "r", new object[2]
        {
          (object) rPr,
          (object) e
        }));
      }
      return xelementList;
    }

    internal static XElement[] SplitParagraph(Paragraph p, int index)
    {
      Run runEffectedByEdit = p.GetFirstRunEffectedByEdit(index);
      XElement xelement1;
      XElement xelement2;
      if (runEffectedByEdit.Xml.Parent.Name.LocalName == "ins")
      {
        XElement[] xelementArray = p.SplitEdit(runEffectedByEdit.Xml.Parent, index, EditType.ins);
        xelement1 = new XElement(p.Xml.Name, new object[3]
        {
          (object) p.Xml.Attributes(),
          (object) runEffectedByEdit.Xml.Parent.ElementsBeforeSelf(),
          (object) xelementArray[0]
        });
        xelement2 = new XElement(p.Xml.Name, new object[3]
        {
          (object) p.Xml.Attributes(),
          (object) runEffectedByEdit.Xml.Parent.ElementsAfterSelf(),
          (object) xelementArray[1]
        });
      }
      else if (runEffectedByEdit.Xml.Parent.Name.LocalName == "del")
      {
        XElement[] xelementArray = p.SplitEdit(runEffectedByEdit.Xml.Parent, index, EditType.del);
        xelement1 = new XElement(p.Xml.Name, new object[3]
        {
          (object) p.Xml.Attributes(),
          (object) runEffectedByEdit.Xml.Parent.ElementsBeforeSelf(),
          (object) xelementArray[0]
        });
        xelement2 = new XElement(p.Xml.Name, new object[3]
        {
          (object) p.Xml.Attributes(),
          (object) runEffectedByEdit.Xml.Parent.ElementsAfterSelf(),
          (object) xelementArray[1]
        });
      }
      else
      {
        XElement[] xelementArray = Run.SplitRun(runEffectedByEdit, index);
        xelement1 = new XElement(p.Xml.Name, new object[3]
        {
          (object) p.Xml.Attributes(),
          (object) runEffectedByEdit.Xml.ElementsBeforeSelf(),
          (object) xelementArray[0]
        });
        xelement2 = new XElement(p.Xml.Name, new object[3]
        {
          (object) p.Xml.Attributes(),
          (object) xelementArray[1],
          (object) runEffectedByEdit.Xml.ElementsAfterSelf()
        });
      }
      if (xelement1.Elements().Count<XElement>() == 0)
        xelement1 = (XElement) null;
      if (xelement2.Elements().Count<XElement>() == 0)
        xelement2 = (XElement) null;
      return new XElement[2]{ xelement1, xelement2 };
    }

    internal static bool IsSameFile(Stream streamOne, Stream streamTwo)
    {
      if (streamOne.Length != streamTwo.Length)
        return false;
      int num1;
      int num2;
      do
      {
        num1 = streamOne.ReadByte();
        num2 = streamTwo.ReadByte();
      }
      while (num1 == num2 && num1 != -1);
      streamOne.Position = 0L;
      streamTwo.Position = 0L;
      return num1 - num2 == 0;
    }

    internal static XDocument AddDefaultNumberingXml(Package package)
    {
      PackagePart part = package.CreatePart(new Uri("/word/numbering.xml", UriKind.Relative), "application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml", (CompressionOption) 1);
      XDocument xdocument = HelperFunctions.DecompressXMLResource(HelperFunctions.GetResources(ResourceType.Numbering));
      using (TextWriter textWriter = (TextWriter) new StreamWriter((Stream) new PackagePartStream(part.GetStream(FileMode.Create, FileAccess.Write))))
        xdocument.Save(textWriter, SaveOptions.None);
      HelperFunctions.GetMainDocumentPart(package).CreateRelationship(part.get_Uri(), (TargetMode) 0, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering");
      return xdocument;
    }

    internal static List CreateItemInList(
      List list,
      string listText,
      int level = 0,
      ListItemType listType = ListItemType.Numbered,
      int? startNumber = null,
      bool trackChanges = false,
      bool continueNumbering = false,
      Formatting formatting = null)
    {
      if (list.NumId == 0)
        list.CreateNewNumberingNumId(level, listType, startNumber, continueNumbering);
      if (listText != null)
      {
        XElement xml = new XElement(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName));
        XElement other = list.Items == null || list.Items.Count <= 0 ? (XElement) null : list.Items.Last<Paragraph>().GetOrCreate_pPr();
        if (other == null)
        {
          xml.Add((object) new XElement(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("numPr", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
          {
            (object) new XElement(XName.Get("ilvl", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) level)),
            (object) new XElement(XName.Get("numId", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(Xceed.Document.NET.Document.w + "val", (object) list.NumId))
          })));
        }
        else
        {
          xml.Add((object) new XElement(other));
          xml.Descendants(XName.Get("ilvl", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>()?.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) level);
        }
        if (formatting == null)
          xml.Add((object) new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName), (object) listText)));
        else
          xml.Add((object) HelperFunctions.FormatInput(listText, formatting.Xml));
        if (trackChanges)
          xml = HelperFunctions.CreateEdit(EditType.ins, DateTime.Now, (object) xml);
        if (!startNumber.HasValue)
          list.AddItem(new Paragraph(list.Document, xml, 0, ContainerType.Paragraph));
        else
          list.AddItemWithStartValue(new Paragraph(list.Document, xml, 0, ContainerType.Paragraph), startNumber.Value);
      }
      return list;
    }

    internal static List CreateItemInList(
      List list,
      Paragraph p,
      ListItemType listType = ListItemType.Numbered,
      int? startNumber = null,
      bool trackChanges = false,
      bool continueNumbering = false)
    {
      if (p != null)
      {
        if (list.NumId == 0)
        {
          int level = 0;
          int baseNumId = 0;
          XElement el1 = p.Xml.Descendants(XName.Get("ilvl", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
          if (el1 != null)
          {
            string attribute = el1.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
            if (!string.IsNullOrEmpty(attribute))
              level = int.Parse(attribute);
          }
          XElement el2 = p.Xml.Descendants(XName.Get("numId", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
          if (el2 != null)
          {
            string attribute = el2.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
            if (!string.IsNullOrEmpty(attribute))
              baseNumId = int.Parse(attribute);
          }
          list.CreateNewNumberingNumIdFromNumId(baseNumId, level, listType, startNumber, continueNumbering);
        }
        XElement xml = new XElement(p.Xml);
        xml.Descendants(XName.Get("numId", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>()?.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) list.NumId);
        if (trackChanges)
          xml = HelperFunctions.CreateEdit(EditType.ins, DateTime.Now, (object) xml);
        list.AddItem(new Paragraph(list.Document, xml, 0, ContainerType.Paragraph));
      }
      return list;
    }

    internal static UnderlineStyle GetUnderlineStyle(string underlineStyle)
    {
      switch (underlineStyle)
      {
        case "dash":
          return UnderlineStyle.dash;
        case "dashDotDotHeavy":
          return UnderlineStyle.dashDotDotHeavy;
        case "dashDotHeavy":
          return UnderlineStyle.dashDotHeavy;
        case "dashLong":
          return UnderlineStyle.dashLong;
        case "dashLongHeavy":
          return UnderlineStyle.dashLongHeavy;
        case "dashedHeavy":
          return UnderlineStyle.dashedHeavy;
        case "dotDash":
          return UnderlineStyle.dotDash;
        case "dotDotDash":
          return UnderlineStyle.dotDotDash;
        case "dotted":
          return UnderlineStyle.dotted;
        case "dottedHeavy":
          return UnderlineStyle.dottedHeavy;
        case "double":
          return UnderlineStyle.doubleLine;
        case "single":
          return UnderlineStyle.singleLine;
        case "thick":
          return UnderlineStyle.thick;
        case "wave":
          return UnderlineStyle.wave;
        case "wavyDouble":
          return UnderlineStyle.wavyDouble;
        case "wavyHeavy":
          return UnderlineStyle.wavyHeavy;
        case "words":
          return UnderlineStyle.words;
        default:
          return UnderlineStyle.none;
      }
    }

    internal static bool ContainsEveryChildOf(
      XElement elementWanted,
      XElement elementToValidate,
      MatchFormattingOptions formattingOptions)
    {
      foreach (XElement element in elementWanted.Elements())
      {
        XElement subElement = element;
        if (!elementToValidate.Elements(subElement.Name).Where<XElement>((Func<XElement, bool>) (bElement => bElement.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)) == subElement.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)))).Any<XElement>())
          return false;
      }
      return formattingOptions != MatchFormattingOptions.ExactMatch || elementWanted.Elements().Count<XElement>() == elementToValidate.Elements().Count<XElement>();
    }

    internal static Color GetColorFromHtml(string stringColor, string autoColor = "FFFFFF")
    {
      if (stringColor == "auto")
        stringColor = autoColor;
      return Color.FromArgb(Convert.ToInt32(stringColor.Substring(0, 2), 16), Convert.ToInt32(stringColor.Substring(2, 2), 16), Convert.ToInt32(stringColor.Substring(4, 2), 16));
    }

    internal static string GetListItemType(Paragraph p, Xceed.Document.NET.Document document)
    {
      IEnumerable<XElement> source1 = p.ParagraphNumberProperties.Descendants();
      string str = source1.FirstOrDefault<XElement>((Func<XElement, bool>) (el => el.Name.LocalName == "ilvl"))?.Attribute(Xceed.Document.NET.Document.w + "val").Value;
      string numId = source1.FirstOrDefault<XElement>((Func<XElement, bool>) (el => el.Name.LocalName == "numId"))?.Attribute(Xceed.Document.NET.Document.w + "val").Value;
      XElement abstractNum1 = HelperFunctions.GetAbstractNum(document, numId);
      if (abstractNum1 != null)
      {
        IEnumerable<XElement> source2 = abstractNum1.Descendants().Where<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "lvl"));
        if (source2.Count<XElement>() == 0)
        {
          int linkedStyleNumId = HelperFunctions.GetLinkedStyleNumId(document, numId);
          if (linkedStyleNumId != -1)
          {
            XElement abstractNum2 = HelperFunctions.GetAbstractNum(document, linkedStyleNumId.ToString());
            if (abstractNum2 != null)
              source2 = abstractNum2.Descendants().Where<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "lvl"));
          }
        }
        XElement xelement1 = (XElement) null;
        foreach (XElement xelement2 in source2)
        {
          if (xelement2.Attribute(Xceed.Document.NET.Document.w + "ilvl").Value.Equals(str))
          {
            xelement1 = xelement2;
            break;
          }
          if (str == null)
          {
            XElement el = xelement2.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "pStyle"));
            if (el != null && el.GetAttribute(Xceed.Document.NET.Document.w + "val").Equals(p.StyleId))
            {
              xelement1 = xelement2;
              break;
            }
          }
        }
        if (xelement1 != null)
        {
          XElement xelement2 = xelement1.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "numFmt"));
          if (xelement2 != null)
            return xelement2.Attribute(Xceed.Document.NET.Document.w + "val").Value;
        }
      }
      return (string) null;
    }

    internal static XElement GetAbstractNum(Xceed.Document.NET.Document document, string numId)
    {
      if (document == null)
        return (XElement) null;
      if (numId == null)
        return (XElement) null;
      string abstractNumNodeValue = HelperFunctions.GetAbstractNumIdValue(document, numId);
      return string.IsNullOrEmpty(abstractNumNodeValue) ? (XElement) null : document._numbering.Descendants().Where<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "abstractNum")).FirstOrDefault<XElement>((Func<XElement, bool>) (node => node.Attribute(Xceed.Document.NET.Document.w + "abstractNumId").Value.Equals(abstractNumNodeValue)));
    }

    internal static string GetAbstractNumIdValue(Xceed.Document.NET.Document document, string numId)
    {
      if (document == null)
        return (string) null;
      if (numId == null)
        return (string) null;
      XElement xelement1 = document._numbering.Descendants().Where<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "num")).FirstOrDefault<XElement>((Func<XElement, bool>) (node => node.Attribute(Xceed.Document.NET.Document.w + nameof (numId)).Value.Equals(numId)));
      if (xelement1 == null)
        return (string) null;
      XElement xelement2 = xelement1.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "abstractNumId"));
      if (xelement2 == null)
        return (string) null;
      string str = xelement2.Attribute(Xceed.Document.NET.Document.w + "val").Value;
      return string.IsNullOrEmpty(str) ? (string) null : str;
    }

    internal static string GetListItemStartValue(List list, int level)
    {
      XElement abstractNum1 = list.GetAbstractNum(list.NumId);
      if (abstractNum1 == null)
        return "1";
      XElement xelement = abstractNum1.Descendants().Where<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "lvl")).FirstOrDefault<XElement>((Func<XElement, bool>) (n => n.GetAttribute(Xceed.Document.NET.Document.w + "ilvl").Equals(level.ToString())));
      if (xelement == null)
      {
        int linkedStyleNumId = HelperFunctions.GetLinkedStyleNumId(list.Document, list.NumId.ToString());
        if (linkedStyleNumId != -1)
        {
          XElement abstractNum2 = list.GetAbstractNum(linkedStyleNumId);
          if (abstractNum2 == null)
            return "1";
          xelement = abstractNum2.Descendants().Where<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "lvl")).FirstOrDefault<XElement>((Func<XElement, bool>) (n => n.GetAttribute(Xceed.Document.NET.Document.w + "ilvl").Equals(level.ToString())));
        }
        if (xelement == null)
          return "1";
      }
      XElement el = xelement.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "start"));
      return el == null ? "1" : el.GetAttribute(Xceed.Document.NET.Document.w + "val");
    }

    internal static string GetListItemTextFormat(List list, int level, out Formatting formatting)
    {
      formatting = (Formatting) null;
      XElement abstractNum1 = list.GetAbstractNum(list.NumId);
      if (abstractNum1 == null)
        return "%1.";
      XElement xelement = abstractNum1.Descendants().Where<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "lvl")).FirstOrDefault<XElement>((Func<XElement, bool>) (n => n.GetAttribute(Xceed.Document.NET.Document.w + "ilvl").Equals(level.ToString())));
      if (xelement == null)
      {
        int linkedStyleNumId = HelperFunctions.GetLinkedStyleNumId(list.Document, list.NumId.ToString());
        if (linkedStyleNumId != -1)
        {
          XElement abstractNum2 = list.GetAbstractNum(linkedStyleNumId);
          if (abstractNum2 == null)
            return "%1.";
          xelement = abstractNum2.Descendants().Where<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "lvl")).FirstOrDefault<XElement>((Func<XElement, bool>) (n => n.GetAttribute(Xceed.Document.NET.Document.w + "ilvl").Equals(level.ToString())));
        }
        if (xelement == null)
          return "%1.";
      }
      formatting = Formatting.Parse(xelement.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "rPr")));
      XElement el = xelement.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "lvlText"));
      return el == null ? "%1." : el.GetAttribute(Xceed.Document.NET.Document.w + "val");
    }

    internal static XElement GetListItemAlignment(List list, int level)
    {
      XElement abstractNum1 = list.GetAbstractNum(list.NumId);
      if (abstractNum1 == null)
        return (XElement) null;
      XElement xelement1 = abstractNum1.Descendants().Where<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "lvl")).FirstOrDefault<XElement>((Func<XElement, bool>) (n => n.GetAttribute(Xceed.Document.NET.Document.w + "ilvl").Equals(level.ToString())));
      if (xelement1 == null)
      {
        int linkedStyleNumId = HelperFunctions.GetLinkedStyleNumId(list.Document, list.NumId.ToString());
        if (linkedStyleNumId != -1)
        {
          XElement abstractNum2 = list.GetAbstractNum(linkedStyleNumId);
          if (abstractNum2 == null)
            return (XElement) null;
          xelement1 = abstractNum2.Descendants().Where<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "lvl")).FirstOrDefault<XElement>((Func<XElement, bool>) (n => n.GetAttribute(Xceed.Document.NET.Document.w + "ilvl").Equals(level.ToString())));
        }
        if (xelement1 == null)
          return (XElement) null;
      }
      XElement xelement2 = xelement1.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "pPr"));
      if (xelement2 != null)
      {
        XElement xelement3 = xelement2.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (n => n.Name.LocalName == "ind"));
        if (xelement3 != null)
          return xelement3;
      }
      return (XElement) null;
    }

    internal static Border GetBorderFromXml(XElement xml)
    {
      if (xml == null)
        return (Border) null;
      BorderSize size = BorderSize.one;
      Color color = Color.Black;
      float space = 0.0f;
      BorderStyle tcbs = BorderStyle.Tcbs_single;
      XAttribute xattribute1 = xml.Attribute(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute1 != null && xattribute1.Value != "auto")
        color = HelperFunctions.GetColorFromHtml(xattribute1.Value);
      XAttribute xattribute2 = xml.Attribute(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute2 != null)
      {
        float single = Convert.ToSingle(xattribute2.Value);
        size = (double) single != 2.0 ? ((double) single != 4.0 ? ((double) single != 6.0 ? ((double) single != 8.0 ? ((double) single != 12.0 ? ((double) single != 18.0 ? ((double) single != 24.0 ? ((double) single != 36.0 ? ((double) single != 48.0 ? BorderSize.one : BorderSize.nine) : BorderSize.eight) : BorderSize.seven) : BorderSize.six) : BorderSize.five) : BorderSize.four) : BorderSize.three) : BorderSize.two) : BorderSize.one;
      }
      XAttribute xattribute3 = xml.Attribute(XName.Get("space", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute3 != null)
        space = Convert.ToSingle(xattribute3.Value);
      XAttribute xattribute4 = xml.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute4 != null)
        tcbs = (BorderStyle) Enum.Parse(typeof (BorderStyle), "Tcbs_" + xattribute4.Value);
      return new Border(tcbs, size, space, color);
    }

    internal static void UpdateParagraphFromStyledParagraph(Paragraph p, Paragraph styledParagraph)
    {
      if (p == null || styledParagraph == null)
        return;
      XElement pPr = p.GetOrCreate_pPr();
      foreach (XElement element1 in styledParagraph.GetOrCreate_pPr().Elements())
      {
        XElement xelement = pPr.Element(element1.Name);
        if (xelement == null)
        {
          pPr.Add((object) element1);
        }
        else
        {
          if (xelement.Name.LocalName == "tabs")
          {
            foreach (XElement element2 in element1.Elements())
            {
              XElement styledTab = element2;
              if (xelement.Elements(XName.Get("tab", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.GetAttribute(XName.Get("pos", Xceed.Document.NET.Document.w.NamespaceName)) == styledTab.GetAttribute(XName.Get("pos", Xceed.Document.NET.Document.w.NamespaceName)))) == null)
                xelement.Add((object) styledTab);
            }
          }
          foreach (XAttribute attribute in element1.Attributes())
          {
            if (xelement.Attribute(attribute.Name) == null && p.CanAddAttribute(attribute))
              xelement.Add((object) attribute);
          }
        }
      }
      XElement rPr = p.GetOrCreate_rPr();
      foreach (XElement element in styledParagraph.GetOrCreate_rPr().Elements())
      {
        XElement xelement = rPr.Element(element.Name);
        if (xelement == null)
        {
          rPr.Add((object) element);
        }
        else
        {
          foreach (XAttribute attribute in element.Attributes())
          {
            if (xelement.Attribute(attribute.Name) == null)
              xelement.Add((object) attribute);
          }
        }
      }
      p.ResetBackers();
    }

    internal static XElement GetParagraphStyleFromStyleId(
      Xceed.Document.NET.Document document,
      string styleIdToFind)
    {
      return document == null || string.IsNullOrEmpty(styleIdToFind) ? (XElement) null : document._styles.Element(Xceed.Document.NET.Document.w + "styles").Elements(Xceed.Document.NET.Document.w + "style").Select(s => new
      {
        s = s,
        type = s.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName))
      }).Where(_param1 => _param1.type != null && _param1.type.Value == "paragraph").Select(_param1 => _param1.s).Select(s => new
      {
        s = s,
        styleId = s.Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName))
      }).Where(_param1 => _param1.styleId != null && _param1.styleId.Value == styleIdToFind).Select(_param1 => _param1.s).FirstOrDefault<XElement>();
    }

    internal static XElement GetParagraphStyleFromStyleName(
      Xceed.Document.NET.Document document,
      string styleNameToFind)
    {
      return document == null || string.IsNullOrEmpty(styleNameToFind) ? (XElement) null : document._styles.Element(Xceed.Document.NET.Document.w + "styles").Elements(Xceed.Document.NET.Document.w + "style").Select(s => new
      {
        s = s,
        type = s.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName))
      }).Where(_param1 => _param1.type != null && _param1.type.Value == "paragraph").Select(_param1 => _param1.s).FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Element(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName)) != null && x.Element(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName)).Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)) != null && x.Element(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName)).Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)).Value.ToLower().Equals(styleNameToFind.ToLower())));
    }

    internal static void CopyStream(Stream input, Stream output, int bufferSize = 32768)
    {
      byte[] buffer = new byte[bufferSize];
      int count;
      while ((count = input.Read(buffer, 0, buffer.Length)) > 0)
        output.Write(buffer, 0, count);
    }

    internal static XElement GetStyle(Xceed.Document.NET.Document fileToConvert, string styleId)
    {
      if (fileToConvert == null)
        throw new ArgumentNullException(nameof (fileToConvert));
      if (string.IsNullOrEmpty(styleId))
        throw new ArgumentNullException(nameof (styleId));
      return fileToConvert._styles.Element(XName.Get("styles", Xceed.Document.NET.Document.w.NamespaceName)).Elements(XName.Get("style", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Attribute(XName.Get(nameof (styleId), Xceed.Document.NET.Document.w.NamespaceName)) != null && x.Attribute(XName.Get(nameof (styleId), Xceed.Document.NET.Document.w.NamespaceName)).Value == styleId));
    }

    internal static bool TryParseFloat(string s, out float result) => float.TryParse(s, NumberStyles.Any, (IFormatProvider) CultureInfo.InvariantCulture, out result);

    internal static bool TryParseDouble(string s, out double result) => double.TryParse(s, NumberStyles.Any, (IFormatProvider) CultureInfo.InvariantCulture, out result);

    internal static bool TryParseInt(string s, out int result) => int.TryParse(s, NumberStyles.Any, (IFormatProvider) CultureInfo.InvariantCulture, out result);

    private static int GetLinkedStyleNumId(Xceed.Document.NET.Document document, string numId)
    {
      XElement abstractNum = HelperFunctions.GetAbstractNum(document, numId);
      if (abstractNum != null)
      {
        XElement xelement1 = abstractNum.Element(XName.Get("numStyleLink", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 != null)
        {
          XAttribute xattribute1 = xelement1.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
          if (!string.IsNullOrEmpty(xattribute1.Value))
          {
            XElement style = HelperFunctions.GetStyle(document, xattribute1.Value);
            if (style != null)
            {
              XElement xelement2 = style.Descendants(XName.Get(nameof (numId), Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
              if (xelement2 != null)
              {
                XAttribute xattribute2 = xelement2.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
                if (!string.IsNullOrEmpty(xattribute2.Value))
                  return int.Parse(xattribute2.Value);
              }
            }
          }
        }
      }
      return -1;
    }
  }
}
