﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PackagePartStream
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System.IO;

namespace Xceed.Document.NET
{
  /// <summary>Represents a PackagePartStream.</summary>
  public class PackagePartStream : Stream
  {
    private static readonly object lockObject = new object();
    private readonly Stream _stream;

    /// <summary>Initializes a new instance of the <strong>PackagePartStream</strong> class.</summary>
    public PackagePartStream(Stream stream) => this._stream = stream;

    /// <summary>Gets if the Read method can be used on this PackagePartStream.</summary>
    public override bool CanRead => this._stream.CanRead;

    /// <summary>Gets if the Seek method can be used on this PackagePartStream.</summary>
    public override bool CanSeek => this._stream.CanSeek;

    /// <summary>Gets if the Write method can be used on this PackagePartStream.</summary>
    public override bool CanWrite => this._stream.CanWrite;

    /// <summary>Gets the Length of this PackagePartStream.</summary>
    public override long Length => this._stream.Length;

    /// <summary>Gets or sets the Position of this PackagePartStream.</summary>
    public override long Position
    {
      get => this._stream.Position;
      set => this._stream.Position = value;
    }

    /// <summary>Sets the position within this PackagePartStream.</summary>
    /// <returns>The new position within the PackagePartStream.</returns>
    /// <param name="offset">The byte offset relative to the <strong>origin</strong> parameter.</param>
    /// <param name="origin">The reference point used to obtain the new position.</param>
    public override long Seek(long offset, SeekOrigin origin) => this._stream.Seek(offset, origin);

    /// <summary>Sets the Length of this PackagePartStream.</summary>
    /// <param name="value">The new length of the PackagePartStream.</param>
    public override void SetLength(long value) => this._stream.SetLength(value);

    /// <summary>Reads data in this PackagePartStream.</summary>
    /// <param name="buffer">The buffer to store the received data in.</param>
    /// <param name="offset">The position at which to start reading the data.</param>
    /// <param name="count">The maximum number of bytes to read.</param>
    public override int Read(byte[] buffer, int offset, int count) => this._stream.Read(buffer, offset, count);

    /// <summary>Writes data to this PackagePartStream.</summary>
    /// <param name="buffer">The array from which data will be copied to the PackagePartStream.</param>
    /// <param name="offset">The offset in the buffer at which to begin copying data.</param>
    /// <param name="count">The number of bytes to write.</param>
    public override void Write(byte[] buffer, int offset, int count)
    {
      lock (PackagePartStream.lockObject)
        this._stream.Write(buffer, offset, count);
    }

    /// <summary>Flushes this PackagePartStream.</summary>
    public override void Flush()
    {
      lock (PackagePartStream.lockObject)
        this._stream.Flush();
    }

    /// <summary>Closes this PackagePartStream.</summary>
    public override void Close() => this._stream.Close();

    /// <summary>Releases the unmanaged resources used by the PackagePartStream and optionally releases the managed resources.</summary>
    /// <param name="disposing">
    /// <strong>true</strong> to release both managed and unmanaged resources; <strong>false</strong> to release only unmanaged resources.</param>
    protected override void Dispose(bool disposing) => this._stream.Dispose();
  }
}
