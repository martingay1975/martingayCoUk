﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.UnderlineStyle
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

namespace Xceed.Document.NET
{
  /// <summary>Value indicating the style to apply to an underline.</summary>
  public enum UnderlineStyle
  {
    none = 0,
    singleLine = 1,
    words = 2,
    doubleLine = 3,
    dotted = 4,
    thick = 6,
    dash = 7,
    dotDash = 9,
    dotDotDash = 10, // 0x0000000A
    wave = 11, // 0x0000000B
    dottedHeavy = 20, // 0x00000014
    dashedHeavy = 23, // 0x00000017
    dashDotHeavy = 25, // 0x00000019
    dashDotDotHeavy = 26, // 0x0000001A
    dashLongHeavy = 27, // 0x0000001B
    dashLong = 39, // 0x00000027
    wavyDouble = 43, // 0x0000002B
    wavyHeavy = 55, // 0x00000037
  }
}
