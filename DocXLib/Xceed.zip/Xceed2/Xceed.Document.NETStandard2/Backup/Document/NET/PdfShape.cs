﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfShape
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Xml.Linq;
using Xceed.Pdf;
using Xceed.Pdf.Layout;
using Xceed.Pdf.Layout.Shape;

namespace Xceed.Document.NET
{
  internal class PdfShape : PdfParagraphPart
  {
    private Graphics _graphics;
    private Xceed.Document.NET.Shape _shape;
    private Xceed.Document.NET.Document _fileToConvert;
    private float _actualHeight = -1f;
    private float _actualWidth = -1f;
    private int _pageNumber;

    internal Xceed.Pdf.Layout.Shape.Shape Shape { get; private set; }

    private float ActualHeight
    {
      get
      {
        if ((double) this._actualHeight < 0.0)
          this._actualHeight = PdfShape.GetActualHeight(this._shape, this._fileToConvert, this._graphics, this._pdfParagraph.GetCurrentSection(), this._pageNumber);
        return this._actualHeight;
      }
    }

    private float ActualWidth
    {
      get
      {
        if ((double) this._actualWidth < 0.0)
          this._actualWidth = PdfShape.GetActualWidth(this._shape, this._fileToConvert, this._graphics, this._pdfParagraph.GetCurrentSection(), this._pageNumber);
        return this._actualWidth;
      }
    }

    internal PdfShape(PdfParagraph p, Xceed.Document.NET.Shape shape, Graphics graphics, int pageNumber)
      : base(p)
    {
      this._shape = shape != null ? shape : throw new ArgumentNullException(nameof (shape));
      this._graphics = graphics;
      this._fileToConvert = this._pdfParagraph.GetFileToConvert();
      this._pageNumber = pageNumber;
    }

    internal static RectangleF GetDimensions(
      Section currentSection,
      PdfPageInfo currentPdfPageInfo,
      Xceed.Document.NET.Shape shape)
    {
      if (currentSection == null)
        throw new ArgumentNullException(nameof (currentSection));
      if (currentPdfPageInfo == null)
        throw new ArgumentNullException(nameof (currentPdfPageInfo));
      if (shape == null)
        throw new ArgumentNullException(nameof (shape));
      float actualWidth = PdfShape.GetActualWidth(shape, shape.Document, currentPdfPageInfo.Page.Graphics, currentSection, currentPdfPageInfo.PageNumber);
      float actualHeight = PdfShape.GetActualHeight(shape, shape.Document, currentPdfPageInfo.Page.Graphics, currentSection, currentPdfPageInfo.PageNumber);
      float positionX = PdfUtils.GetPositionX(currentSection, currentPdfPageInfo, (DocumentElement) shape);
      double num1 = (double) actualWidth > (double) shape.OutlineWidth ? (double) positionX : (double) positionX - (double) shape.OutlineWidth / 2.0;
      float positionY = PdfUtils.GetPositionY(currentSection, currentPdfPageInfo, (DocumentElement) shape);
      float num2 = (double) actualHeight > (double) shape.OutlineWidth ? positionY : positionY - shape.OutlineWidth / 2f;
      float num3 = (double) actualWidth > (double) shape.OutlineWidth ? actualWidth : shape.OutlineWidth;
      float num4 = (double) actualHeight > (double) shape.OutlineWidth ? actualHeight : shape.OutlineWidth;
      double num5 = (double) num2;
      double num6 = (double) num3;
      double num7 = (double) num4;
      return new RectangleF((float) num1, (float) num5, (float) num6, (float) num7);
    }

    internal static XElement GetShapeFromXElement(XElement xElement)
    {
      if (xElement == null)
        throw new NullReferenceException(nameof (xElement));
      XElement xelement = xElement.Descendants(XName.Get("drawing", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
      return xelement != null && xelement.Descendants(XName.Get("wsp", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>() != null ? xelement : (XElement) null;
    }

    internal static PdfParagraph CreateShapePdfParagraph(
      Xceed.Document.NET.Document fileToConvert,
      Section currentSection,
      PdfPageInfo currentPdfPageInfo,
      Xceed.Document.NET.Shape shape)
    {
      if (fileToConvert == null)
        throw new ArgumentNullException(nameof (fileToConvert));
      if (currentSection == null)
        throw new ArgumentNullException(nameof (currentSection));
      if (currentPdfPageInfo == null)
        throw new ArgumentNullException(nameof (currentPdfPageInfo));
      return new PdfParagraph(new Paragraph(fileToConvert, new XElement(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName)), 0), (Paragraph) null, (Paragraph) null, 0, currentPdfPageInfo.PageNumber, currentPdfPageInfo.Page.Graphics, fileToConvert, currentSection);
    }

    internal static float GetActualWidth(
      Xceed.Document.NET.Shape shape,
      Xceed.Document.NET.Document fileToConvert,
      Graphics graphics,
      Section currentSection,
      int pageNumber)
    {
      if (shape == null)
        return 0.0f;
      if (shape.IsTextWrap)
        return shape.Width;
      float pdfShapeTextsWidth = PdfShape.GetPdfShapeTextsWidth(shape, fileToConvert, graphics, currentSection, pageNumber);
      return (double) pdfShapeTextsWidth == 0.0 ? shape.Width : pdfShapeTextsWidth + PdfShape.GetTextLeftMargin(shape) + PdfShape.GetTextRightMargin(shape);
    }

    internal static float GetActualHeight(
      Xceed.Document.NET.Shape shape,
      Xceed.Document.NET.Document fileToConvert,
      Graphics graphics,
      Section currentSection,
      int pageNumber)
    {
      if (shape == null)
        return 0.0f;
      if (!shape.IsTextAutoFit)
        return shape.Height;
      float shapeTextsHeight = PdfShape.GetPdfShapeTextsHeight(shape, fileToConvert, graphics, currentSection, pageNumber, shape.IsTextWrap);
      return (double) shapeTextsHeight == 0.0 ? shape.Height : shapeTextsHeight + PdfShape.GetTextBottomMargin(shape) + PdfShape.GetTextTopMargin(shape);
    }

    internal override void UpdateText(Xceed.Pdf.Layout.Text.Text text, bool isMeasuring = false)
    {
      this.Shape = this.CreatePdfShape();
      text?.AddContent(this.Shape, this.ActualWidth, this.ActualHeight);
    }

    private static float GetPdfShapeTextsWidth(
      Xceed.Document.NET.Shape shape,
      Xceed.Document.NET.Document fileToConvert,
      Graphics graphics,
      Section currentSection,
      int pageNumber)
    {
      if (shape == null)
        return 0.0f;
      float val1 = 0.0f;
      List<Paragraph> list = shape.Paragraphs.ToList<Paragraph>();
      for (int i = 0; i < list.Count; ++i)
      {
        Xceed.Pdf.Layout.Text.Text shapeText = new Xceed.Pdf.Layout.Text.Text();
        PdfShape.CreatePdfShapeParagraph(list, i, shapeText, shape, fileToConvert, graphics, currentSection, pageNumber, false, false);
        float width = currentSection.PageWidth - currentSection.MarginLeft - currentSection.MarginRight - (PdfShape.GetTextLeftMargin(shape) + PdfShape.GetTextRightMargin(shape));
        graphics.MeasureBlock(0.0f, 0.0f, width, 0.0f, (Xceed.Pdf.Layout.Block) shapeText);
        shapeText.WidthIsFixed = false;
        if (shapeText.Lines != null && shapeText.Lines.Buffer != null)
          val1 = Math.Max(val1, ((IEnumerable<Xceed.Pdf.Layout.Text.Blocks.Line>) shapeText.Lines.Buffer).Where<Xceed.Pdf.Layout.Text.Blocks.Line>((Func<Xceed.Pdf.Layout.Text.Blocks.Line, bool>) (l => l != null)).Max<Xceed.Pdf.Layout.Text.Blocks.Line>((Func<Xceed.Pdf.Layout.Text.Blocks.Line, float>) (l => l.Width)));
      }
      return val1;
    }

    private static float GetPdfShapeTextsHeight(
      Xceed.Document.NET.Shape shape,
      Xceed.Document.NET.Document fileToConvert,
      Graphics graphics,
      Section currentSection,
      int pageNumber,
      bool isTextWrapping)
    {
      if (shape == null)
        return 0.0f;
      float num = 0.0f;
      List<Paragraph> list = shape.Paragraphs.ToList<Paragraph>();
      for (int i = 0; i < list.Count; ++i)
      {
        Xceed.Pdf.Layout.Text.Text shapeText = new Xceed.Pdf.Layout.Text.Text();
        PdfParagraph pdfShapeParagraph = PdfShape.CreatePdfShapeParagraph(list, i, shapeText, shape, fileToConvert, graphics, currentSection, pageNumber, isTextWrapping, true);
        float width = (isTextWrapping ? PdfShape.GetActualWidth(shape, fileToConvert, graphics, currentSection, pageNumber) : currentSection.PageWidth - currentSection.MarginLeft - currentSection.MarginRight) - (PdfShape.GetTextLeftMargin(shape) + PdfShape.GetTextRightMargin(shape));
        graphics.MeasureBlock(0.0f, 0.0f, width, 0.0f, (Xceed.Pdf.Layout.Block) shapeText);
        shapeText.WidthIsFixed = false;
        num += pdfShapeParagraph.GetLineSpacingBefore() + shapeText.Height + pdfShapeParagraph.GetLineSpacingAfter();
      }
      return num;
    }

    private static PdfParagraph CreatePdfShapeParagraph(
      List<Paragraph> shapeParagraphs,
      int i,
      Xceed.Pdf.Layout.Text.Text shapeText,
      Xceed.Document.NET.Shape shape,
      Xceed.Document.NET.Document fileToConvert,
      Graphics graphics,
      Section currentSection,
      int pageNumber,
      bool isTextWrapping,
      bool isWidthFixed)
    {
      PdfParagraph pdfParagraph = new PdfParagraph(shapeParagraphs[i], i == 0 ? (Paragraph) null : shapeParagraphs[i - 1], i == shapeParagraphs.Count - 1 ? (Paragraph) null : shapeParagraphs[i + 1], i, pageNumber, graphics, fileToConvert, currentSection);
      pdfParagraph.UpdateParagraphPageNumber();
      pdfParagraph.FillContent(shapeText);
      return pdfParagraph;
    }

    private static float GetTextLeftMargin(Xceed.Document.NET.Shape shape) => PdfShape.GetTextMargin(shape, XName.Get("lIns"));

    private static float GetTextRightMargin(Xceed.Document.NET.Shape shape) => PdfShape.GetTextMargin(shape, XName.Get("rIns"));

    private static float GetTextTopMargin(Xceed.Document.NET.Shape shape) => PdfShape.GetTextMargin(shape, XName.Get("tIns"));

    private static float GetTextBottomMargin(Xceed.Document.NET.Shape shape) => PdfShape.GetTextMargin(shape, XName.Get("bIns"));

    private static float GetTextMargin(Xceed.Document.NET.Shape shape, XName marginType)
    {
      if (shape == null || marginType == (XName) null)
        return 0.0f;
      XElement xelement = shape.Xml.Descendants(XName.Get("bodyPr", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>();
      if (xelement != null)
      {
        XAttribute xattribute = xelement.Attribute(marginType);
        if (xattribute != null)
          return Convert.ToSingle(xattribute.Value) / Convert.ToSingle(12700);
      }
      return 0.0f;
    }

    private Xceed.Pdf.Layout.Shape.Shape CreatePdfShape()
    {
      Xceed.Pdf.Layout.Shape.Shape layoutShape = new Xceed.Pdf.Layout.Shape.Shape();
      float shapeTextsHeight = PdfShape.GetPdfShapeTextsHeight(this._shape, this._fileToConvert, this._graphics, this._pdfParagraph.GetCurrentSection(), this._pageNumber, this._shape.IsTextWrap);
      this.AddShapeForm(layoutShape);
      if ((double) shapeTextsHeight != 0.0)
        this.SetTextPosition(this.CreatePdfShapeTexts(layoutShape), shapeTextsHeight);
      return layoutShape;
    }

    private List<PdfShape.PdfShapeText> CreatePdfShapeTexts(Xceed.Pdf.Layout.Shape.Shape layoutShape)
    {
      List<PdfShape.PdfShapeText> pdfShapeTextList = new List<PdfShape.PdfShapeText>();
      List<Paragraph> list = this._shape.Paragraphs.ToList<Paragraph>();
      if (list.Count > 0)
      {
        for (int i = 0; i < list.Count; ++i)
        {
          Xceed.Pdf.Layout.Text.Text shapeText = layoutShape.AddText();
          Color? fontColor = this._shape.FontColor;
          if (fontColor.HasValue && fontColor.HasValue)
            shapeText.Style = new Style()
            {
              Brush = (Brush) new SolidBrush(fontColor.Value)
            };
          PdfParagraph pdfShapeParagraph = PdfShape.CreatePdfShapeParagraph(list, i, shapeText, this._shape, this._fileToConvert, this._graphics, this._pdfParagraph.GetCurrentSection(), this._pageNumber, this._shape.IsTextWrap, true);
          this._graphics.MeasureBlock(0.0f, 0.0f, this.ActualWidth - PdfShape.GetTextLeftMargin(this._shape) - PdfShape.GetTextRightMargin(this._shape), 0.0f, (Xceed.Pdf.Layout.Block) shapeText);
          pdfShapeTextList.Add(new PdfShape.PdfShapeText()
          {
            Text = shapeText,
            SpacingBefore = pdfShapeParagraph.GetLineSpacingBefore(),
            SpacingAfter = pdfShapeParagraph.GetLineSpacingAfter()
          });
        }
      }
      return pdfShapeTextList;
    }

    private void AddShapeForm(Xceed.Pdf.Layout.Shape.Shape layoutShape)
    {
      Element form = (Element) null;
      switch (this._shape.PresetShape)
      {
        case "line":
          Xceed.Pdf.Layout.Shape.Line line1 = layoutShape.AddLine();
          line1.X1 = this._shape.FlipH ? this.ActualWidth : 0.0f;
          line1.Y1 = this._shape.FlipV ? this.ActualHeight : 0.0f;
          line1.X2 = this._shape.FlipH ? 0.0f : this.ActualWidth;
          line1.Y2 = this._shape.FlipV ? 0.0f : this.ActualHeight;
          form = (Element) line1;
          break;
        case "rect":
        case "round1Rect":
        case "round2DiagRect":
        case "round2SameRect":
        case "roundRect":
        case "snip1Rect":
        case "snip2DiagRect":
        case "snip2SameRect":
        case "snipRoundRect":
          Xceed.Pdf.Layout.Shape.Rectangle rectangle = layoutShape.AddRectangle();
          rectangle.X = 0.0f;
          rectangle.Y = 0.0f;
          rectangle.Width = this.ActualWidth;
          rectangle.Height = this.ActualHeight;
          form = (Element) rectangle;
          break;
        case "straightConnector1":
          Xceed.Pdf.Layout.Shape.Line line2 = layoutShape.AddLine();
          line2.X1 = this._shape.FlipH ? this.ActualWidth : 0.0f;
          line2.Y1 = this._shape.FlipV ? this.ActualHeight : 0.0f;
          line2.X2 = this._shape.FlipH ? 0.0f : this.ActualWidth;
          line2.Y2 = this._shape.FlipV ? 0.0f : this.ActualHeight;
          form = (Element) line2;
          break;
        case "triangle":
          Polyline polyline = layoutShape.AddPolyline();
          if (this._shape.FlipV)
          {
            polyline.Points.Add((object) new PointF(0.0f, 0.0f));
            polyline.Points.Add((object) new PointF(this.ActualWidth, 0.0f));
            polyline.Points.Add((object) new PointF(this.ActualWidth / 2f, this.ActualHeight));
          }
          else
          {
            polyline.Points.Add((object) new PointF(0.0f, this.ActualHeight));
            polyline.Points.Add((object) new PointF(this.ActualWidth, this.ActualHeight));
            polyline.Points.Add((object) new PointF(this.ActualWidth / 2f, 0.0f));
          }
          polyline.Close = true;
          form = (Element) polyline;
          break;
      }
      this.FillForm(form);
      this.OutlineForm(form);
    }

    private void FillForm(Element form)
    {
      if (form == null)
        return;
      Color? fillColor = this._shape.FillColor;
      if (!fillColor.HasValue || !fillColor.HasValue)
        return;
      form.Fill = true;
      if (form.Style == null)
        form.Style = new Style();
      form.Style.Brush = (Brush) new SolidBrush(fillColor.Value);
    }

    private void OutlineForm(Element form)
    {
      if (form == null)
        return;
      if (form.Style == null)
        form.Style = new Style();
      form.Stroke = true;
      if (form.Style.Pen == null)
        form.Style.Pen = new Pen(Color.Transparent, this._shape.OutlineWidth);
      if (this._shape.OutlineColor.HasValue)
        form.Style.Pen.set_Color(this._shape.OutlineColor.Value);
      if (!this._shape.OutlineDash.HasValue)
        return;
      form.Style.Pen.set_DashStyle(this._shape.OutlineDash.Value);
      if (form.Style.Pen.get_DashStyle() != 5)
        return;
      form.Style.Pen.set_DashPattern(this._shape.OutlineDashPattern);
    }

    private void SetTextPosition(List<PdfShape.PdfShapeText> shapeTexts, float totalTextsHeight)
    {
      float textLeftMargin = PdfShape.GetTextLeftMargin(this._shape);
      float num1 = PdfShape.GetTextTopMargin(this._shape);
      switch (this.GetTextAnchorType())
      {
        case "b":
          num1 = this.ActualHeight - PdfShape.GetTextBottomMargin(this._shape) - totalTextsHeight;
          break;
        case "ctr":
          num1 = (float) ((double) this.ActualHeight / 2.0 - (double) totalTextsHeight / 2.0);
          break;
      }
      foreach (PdfShape.PdfShapeText shapeText in shapeTexts)
      {
        shapeText.Text.Left = textLeftMargin;
        float num2 = num1 + shapeText.SpacingBefore;
        shapeText.Text.Top = num2;
        num1 = num2 + shapeText.Text.Height + shapeText.SpacingAfter;
      }
    }

    private string GetTextAnchorType()
    {
      XElement xelement = this._shape.Xml.Descendants(XName.Get("bodyPr", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>();
      if (xelement != null)
      {
        XAttribute xattribute = xelement.Attribute(XName.Get("anchor"));
        if (xattribute != null)
          return xattribute.Value;
      }
      return (string) null;
    }

    private struct PdfShapeText
    {
      public float SpacingBefore;
      public float SpacingAfter;
      public Xceed.Pdf.Layout.Text.Text Text;
    }
  }
}
