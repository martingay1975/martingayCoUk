﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.ExtensionsHeadings
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.ComponentModel;

namespace Xceed.Document.NET
{
  public static class ExtensionsHeadings
  {
    public static Paragraph Heading(this Paragraph paragraph, HeadingType headingType)
    {
      string str = headingType.EnumDescription();
      paragraph.StyleId = str;
      return paragraph;
    }

    public static string EnumDescription(this Enum enumValue)
    {
      if (enumValue == null || enumValue.ToString() == "0")
        return string.Empty;
      DescriptionAttribute[] customAttributes = (DescriptionAttribute[]) enumValue.GetType().GetField(enumValue.ToString()).GetCustomAttributes(typeof (DescriptionAttribute), false);
      return customAttributes.Length != 0 ? customAttributes[0].Description : enumValue.ToString();
    }

    public static bool HasFlag(this Enum variable, Enum value)
    {
      if (variable == null)
        return false;
      if (value == null)
        throw new ArgumentNullException(nameof (value));
      ulong num = Enum.IsDefined(variable.GetType(), (object) value) ? Convert.ToUInt64((object) value) : throw new ArgumentException(string.Format("Enumeration type mismatch.  The flag is of type '{0}', was expecting '{1}'.", (object) value.GetType(), (object) variable.GetType()));
      return ((long) Convert.ToUInt64((object) variable) & (long) num) == (long) num;
    }
  }
}
