﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Row
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a Row in a Table.</summary>
  public class Row : Container
  {
    internal Table _table;

    /// <summary>Gets the Column Count of this Row, taking spanned Cells into account.</summary>
    public int ColumnCount
    {
      get
      {
        int gridAfter = this.GridAfter;
        foreach (Cell cell in this.Cells)
        {
          if (cell.GridSpan != 0)
            gridAfter += cell.GridSpan - 1;
        }
        return this.Cells.Count + gridAfter;
      }
    }

    public int GridAfter
    {
      get
      {
        XElement xelement = this.Xml.Element(XName.Get("trPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement != null)
        {
          XAttribute xattribute = xelement.Element(XName.Get("gridAfter", Xceed.Document.NET.Document.w.NamespaceName))?.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
          if (xattribute != null)
            return int.Parse(xattribute.Value);
        }
        return 0;
      }
    }

    /// <summary>Gets the collection of Cells in this Row.</summary>
    public List<Cell> Cells => this.Xml.Elements(XName.Get("tc", Xceed.Document.NET.Document.w.NamespaceName)).Select<XElement, Cell>((Func<XElement, Cell>) (c => new Cell(this, this.Document, c))).ToList<Cell>();

    /// <summary>Gets the collection of Paragraphs in this Row.</summary>
    public override ReadOnlyCollection<Paragraph> Paragraphs
    {
      get
      {
        List<Paragraph> list = this.Xml.Descendants(Xceed.Document.NET.Document.w + "p").Select<XElement, Paragraph>((Func<XElement, Paragraph>) (p => new Paragraph(this.Document, p, 0))).ToList<Paragraph>();
        foreach (DocumentElement documentElement in list)
          documentElement.PackagePart = this._table.PackagePart;
        return list.AsReadOnly();
      }
    }

    /// <summary>Gets or sets the Height of this Row (in points).</summary>
    public double Height
    {
      get
      {
        XAttribute xattribute = this.Xml.Element(XName.Get("trPr", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("trHeight", Xceed.Document.NET.Document.w.NamespaceName))?.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute == null)
          return double.NaN;
        double result;
        if (HelperFunctions.TryParseDouble(xattribute.Value, out result))
          return result / 20.0;
        xattribute.Remove();
        return double.NaN;
      }
      set => this.SetHeight(value, true);
    }

    /// <summary>Gets or sets the Minimum Height of this Row (in points).</summary>
    public double MinHeight
    {
      get => this.Height;
      set => this.SetHeight(value, false);
    }

    /// <summary>Gets or sets if a Table Header is present in this Row.</summary>
    public bool TableHeader
    {
      get => this.Xml.Element(XName.Get("trPr", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("tblHeader", Xceed.Document.NET.Document.w.NamespaceName)) != null;
      set
      {
        XElement xelement1 = this.Xml.Element(XName.Get("trPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 == null)
        {
          this.Xml.SetElementValue(XName.Get("trPr", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement1 = this.Xml.Element(XName.Get("trPr", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement2 = xelement1.Element(XName.Get("tblHeader", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 == null & value)
          xelement1.SetElementValue(XName.Get("tblHeader", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
        if (xelement2 == null || value)
          return;
        xelement2.Remove();
      }
    }

    /// <summary>Gets or sets if the Row is allowed to Break Across Pages.</summary>
    public bool BreakAcrossPages
    {
      get => this.Xml.Element(XName.Get("trPr", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("cantSplit", Xceed.Document.NET.Document.w.NamespaceName)) == null;
      set
      {
        XName name1 = XName.Get("trPr", Xceed.Document.NET.Document.w.NamespaceName);
        XName name2 = XName.Get("cantSplit", Xceed.Document.NET.Document.w.NamespaceName);
        if (value)
        {
          this.Xml.Element(name1)?.Element(name2)?.Remove();
        }
        else
        {
          XElement xelement = this.Xml.Element(name1);
          if (xelement == null)
          {
            this.Xml.SetElementValue(name1, (object) string.Empty);
            xelement = this.Xml.Element(name1);
          }
          if (xelement.Element(name2) != null)
            return;
          xelement.SetElementValue(name2, (object) string.Empty);
        }
      }
    }

    internal Row(Table table, Xceed.Document.NET.Document document, XElement xml)
      : base(document, xml)
    {
      this._table = table;
      this.PackagePart = table.PackagePart;
    }

    private void SetHeight(double height, bool isHeightExact)
    {
      XElement xelement1 = this.Xml.Element(XName.Get("trPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 == null)
      {
        this.Xml.SetElementValue(XName.Get("trPr", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
        xelement1 = this.Xml.Element(XName.Get("trPr", Xceed.Document.NET.Document.w.NamespaceName));
      }
      XElement xelement2 = this.Xml.Element(XName.Get("tc", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 != null)
      {
        xelement1.Remove();
        xelement2.AddBeforeSelf((object) xelement1);
      }
      XElement xelement3 = xelement1.Element(XName.Get("trHeight", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement3 == null)
      {
        xelement1.SetElementValue(XName.Get("trHeight", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
        xelement3 = xelement1.Element(XName.Get("trHeight", Xceed.Document.NET.Document.w.NamespaceName));
      }
      xelement3.SetAttributeValue(XName.Get("hRule", Xceed.Document.NET.Document.w.NamespaceName), isHeightExact ? (object) "exact" : (object) "atLeast");
      xelement3.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) ((int) Math.Round(height * 20.0, 0)).ToString((IFormatProvider) CultureInfo.InvariantCulture));
    }

    /// <summary>Removes this Row.</summary>
    public void Remove()
    {
      XElement parent = this.Xml.Parent;
      this.Xml.Remove();
      if (parent.Elements(XName.Get("tr", Xceed.Document.NET.Document.w.NamespaceName)).Any<XElement>())
        return;
      parent.Remove();
    }

    /// <summary>Merges Cells in this Row.</summary>
    /// <param name="startIndex">The index of the Cell where the merging starts.</param>
    /// <param name="endIndex">The index of the Cell where the merging ends.</param>
    public void MergeCells(int startIndex, int endIndex)
    {
      if (startIndex < 0 || endIndex <= startIndex || endIndex > this.Cells.Count + 1)
        throw new IndexOutOfRangeException();
      int num = 0;
      foreach (Cell cell in this.Cells.Where<Cell>((Func<Cell, int, bool>) ((z, i) => i > startIndex && i <= endIndex)))
      {
        XElement xelement = cell.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("gridSpan", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement != null)
        {
          XAttribute xattribute = xelement.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
          int result;
          if (xattribute != null && HelperFunctions.TryParseInt(xattribute.Value, out result))
            num += result - 1;
        }
        this.Cells[startIndex].Xml.Add((object) cell.Xml.Elements(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName)));
        cell.Xml.Remove();
      }
      while (true)
      {
        ReadOnlyCollection<Paragraph> paragraphs = this.Cells[startIndex].Paragraphs;
        if (paragraphs.Count >= 2)
        {
          int index = paragraphs.Count - 1;
          if (paragraphs[index].Text.Trim() == "")
            paragraphs[index].Remove(false);
          else
            break;
        }
        else
          break;
      }
      XElement xelement1 = this.Cells[startIndex].Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 == null)
      {
        this.Cells[startIndex].Xml.SetElementValue(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
        xelement1 = this.Cells[startIndex].Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
      }
      XElement xelement2 = xelement1.Element(XName.Get("gridSpan", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 == null)
      {
        xelement1.SetElementValue(XName.Get("gridSpan", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
        xelement2 = xelement1.Element(XName.Get("gridSpan", Xceed.Document.NET.Document.w.NamespaceName));
      }
      XAttribute xattribute1 = xelement2.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
      int result1 = 0;
      if (xattribute1 != null && HelperFunctions.TryParseInt(xattribute1.Value, out result1))
        num += result1 - 1;
      xelement2.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) (num + (endIndex - startIndex + 1)).ToString());
    }
  }
}
