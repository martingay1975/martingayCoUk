﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.ValueAxis
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a Value Axis</summary>
  public class ValueAxis : Axis
  {
    internal ValueAxis(XElement xml)
      : base(xml)
    {
    }

    /// <summary>Initializes a new instance of the <strong>ValueAxis</strong> class.</summary>
    /// <param name="id">The Id of the Axis.</param>
    public ValueAxis(string id)
      : base(id)
      => this.Xml = XElement.Parse(string.Format("<c:valAx xmlns:c=\"http://schemas.openxmlformats.org/drawingml/2006/chart\">\r\n                <c:axId val=\"{0}\"/>\r\n                <c:scaling>\r\n                  <c:orientation val=\"minMax\"/>\r\n                </c:scaling>\r\n                <c:delete val=\"0\"/>\r\n                <c:axPos val=\"l\"/>\r\n                <c:numFmt sourceLinked=\"0\" formatCode=\"General\"/>\r\n                <c:majorGridlines/>\r\n                <c:majorTickMark val=\"out\"/>\r\n                <c:minorTickMark val=\"none\"/>\r\n                <c:tickLblPos val=\"nextTo\"/>\r\n                <c:crossAx val=\"148921728\"/>\r\n                <c:crosses val=\"autoZero\"/>\r\n                <c:crossBetween val=\"between\"/>\r\n              </c:valAx>", (object) id));
  }
}
