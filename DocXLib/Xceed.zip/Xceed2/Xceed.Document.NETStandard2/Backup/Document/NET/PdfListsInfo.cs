﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.PdfListsInfo
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Xceed.Document.NET
{
  internal class PdfListsInfo
  {
    private Dictionary<int, Dictionary<int, string>> _listNumberDictionary = new Dictionary<int, Dictionary<int, string>>();

    internal PdfListsInfo(List list, int itemLevel) => this.AddDictionaryEntry(list, itemLevel);

    internal static IDictionary CloneDictionary(IDictionary dict)
    {
      if (!(dict is Dictionary<int, Dictionary<int, string>> dictionary))
        return (IDictionary) null;
      Dictionary<int, Dictionary<int, string>> dictionary1 = new Dictionary<int, Dictionary<int, string>>();
      foreach (KeyValuePair<int, Dictionary<int, string>> keyValuePair1 in dictionary)
      {
        Dictionary<int, string> dictionary2 = new Dictionary<int, string>();
        foreach (KeyValuePair<int, string> keyValuePair2 in keyValuePair1.Value)
          dictionary2.Add(keyValuePair2.Key, keyValuePair2.Value);
        dictionary1.Add(keyValuePair1.Key, dictionary2);
      }
      return (IDictionary) dictionary1;
    }

    internal IDictionary CloneListNumberDictionary() => PdfListsInfo.CloneDictionary((IDictionary) this._listNumberDictionary);

    internal void SetListNumberDictionary(IDictionary dict) => this._listNumberDictionary = PdfListsInfo.CloneDictionary(dict) as Dictionary<int, Dictionary<int, string>>;

    internal void IncrementValue(List list, int itemLevel)
    {
      Formatting formatting = (Formatting) null;
      string listItemTextFormat = HelperFunctions.GetListItemTextFormat(list, itemLevel, out formatting);
      if (!listItemTextFormat.Contains("%"))
        return;
      string[] strArray1 = listItemTextFormat.Split('.');
      int index1 = ((IEnumerable<string>) strArray1).ToList<string>().LastIndexOf(((IEnumerable<string>) strArray1).Last<string>((Func<string, bool>) (x => !string.IsNullOrEmpty(x) && x.Contains("%"))));
      string[] strArray2 = this._listNumberDictionary[list.AbstractNumId][itemLevel].Split('.');
      string source = strArray2[index1];
      string str1 = new string(source.Where<char>((Func<char, bool>) (c => char.IsDigit(c))).ToArray<char>());
      int num = int.Parse(str1) + 1;
      string str2 = source.Replace(str1, num.ToString());
      strArray2[index1] = str2;
      this._listNumberDictionary[list.AbstractNumId][itemLevel] = string.Join(".", strArray2);
      for (int index2 = 0; index2 < this._listNumberDictionary[list.AbstractNumId].Count; ++index2)
      {
        KeyValuePair<int, string> keyValuePair = this._listNumberDictionary[list.AbstractNumId].ElementAt<KeyValuePair<int, string>>(index2);
        if (keyValuePair.Key > itemLevel)
        {
          List<string> list1 = ((IEnumerable<string>) keyValuePair.Value.Split('.')).Where<string>((Func<string, bool>) (p => !string.IsNullOrEmpty(p))).ToList<string>();
          bool flag1 = list1.Count<string>() > 1;
          bool flag2 = false;
          for (int index3 = 0; index3 < list1.Count<string>(); ++index3)
          {
            if (flag1)
            {
              if (flag2)
                list1[index3] = "1";
              if (index3 == index1)
              {
                list1[index3] = (num - 1).ToString();
                flag2 = true;
              }
            }
            else
              list1[index3] = "1";
          }
          this._listNumberDictionary[list.AbstractNumId][keyValuePair.Key] = string.Join(".", (IEnumerable<string>) list1);
        }
      }
    }

    internal void AddListData(List list, int itemLevel) => this.AddDictionaryEntry(list, itemLevel);

    internal bool IsListAndLevelDefined(int abstractNumId, int level) => this._listNumberDictionary.ContainsKey(abstractNumId) && this._listNumberDictionary[abstractNumId].ContainsKey(level);

    internal string GetValue(int abstractNumId, int level)
    {
      if (!this.IsListAndLevelDefined(abstractNumId, level))
        throw new Exception("List or list's level not defined in dictionary");
      return this._listNumberDictionary[abstractNumId][level];
    }

    private void AddDictionaryEntry(List list, int itemLevel)
    {
      string str1 = list != null && itemLevel >= 0 ? HelperFunctions.GetListItemStartValue(list, itemLevel) : throw new InvalidOperationException("Can't add the entry in the dictionary.");
      Formatting formatting = (Formatting) null;
      string listItemTextFormat = HelperFunctions.GetListItemTextFormat(list, itemLevel, out formatting);
      if (listItemTextFormat.Contains("%"))
      {
        int lastIndex = listItemTextFormat.ToList<char>().FindLastIndex((Predicate<char>) (x => x == '%'));
        string source = listItemTextFormat.Remove(lastIndex, 2).Insert(lastIndex, str1);
        string[] strArray1 = source.Split('.');
        if (itemLevel > 0 && source.Contains("%"))
        {
          int num = source.Count<char>((Func<char, bool>) (x => x == '%'));
          if (!this._listNumberDictionary.ContainsKey(list.AbstractNumId))
          {
            Dictionary<int, string> dictionary = new Dictionary<int, string>();
            string str2 = (Convert.ToInt32(HelperFunctions.GetListItemStartValue(list, itemLevel - 1)) + 1).ToString();
            dictionary.Add(itemLevel - 1, str2);
            this._listNumberDictionary.Add(list.AbstractNumId, dictionary);
          }
          string[] strArray2 = this._listNumberDictionary[list.AbstractNumId][itemLevel - 1].Split('.');
          for (int index1 = 0; index1 < strArray1.Length; ++index1)
          {
            int index2 = strArray1[index1].ToList<char>().FindIndex((Predicate<char>) (x => x == '%'));
            int result;
            if (index2 > -1 && HelperFunctions.TryParseInt(new string(strArray2[index1].Where<char>(new Func<char, bool>(char.IsDigit)).ToArray<char>()), out result))
            {
              if (index1 == num - 1)
                --result;
              strArray1[index1] = strArray1[index1].Remove(index2, 2).Insert(index2, result.ToString());
            }
          }
        }
        str1 = string.Join(".", strArray1);
      }
      if (this._listNumberDictionary.ContainsKey(list.AbstractNumId))
      {
        if (this._listNumberDictionary[list.AbstractNumId].ContainsKey(itemLevel))
          this._listNumberDictionary[list.AbstractNumId][itemLevel] = str1;
        else
          this._listNumberDictionary[list.AbstractNumId].Add(itemLevel, str1);
      }
      else
        this._listNumberDictionary.Add(list.AbstractNumId, new Dictionary<int, string>()
        {
          {
            itemLevel,
            str1
          }
        });
    }
  }
}
