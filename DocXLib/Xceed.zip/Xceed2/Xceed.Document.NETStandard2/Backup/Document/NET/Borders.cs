﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Borders
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

namespace Xceed.Document.NET
{
  /// <summary>Represents the Borders (left, top, right, bottom).</summary>
  public class Borders
  {
    private Border _left;
    private Border _top;
    private Border _right;
    private Border _bottom;

    /// <summary>Initializes a new instance of the <strong>Borders</strong> class.</summary>
    public Borders()
    {
    }

    /// <summary>Initializes a new instance of the <strong>Borders</strong> class, using the provided Border.</summary>
    public Borders(Border border)
    {
      this._left = border;
      this._top = border;
      this._right = border;
      this._bottom = border;
    }

    /// <summary>Initializes a new instance of the <strong>Borders</strong> class, using the provided values for each Border (left, top, right, bottom).</summary>
    public Borders(Border leftBorder, Border topBorder, Border rightBorder, Border bottomBorder)
    {
      this._left = leftBorder;
      this._top = topBorder;
      this._right = rightBorder;
      this._bottom = bottomBorder;
    }

    /// <summary>Gets or set the left border.</summary>
    public Border Left
    {
      get => this._left;
      set => this._left = value;
    }

    /// <summary>Gets or set the top border.</summary>
    public Border Top
    {
      get => this._top;
      set => this._top = value;
    }

    /// <summary>Gets or set the right border.</summary>
    public Border Right
    {
      get => this._right;
      set => this._right = value;
    }

    /// <summary>Gets or set the bottom border.</summary>
    public Border Bottom
    {
      get => this._bottom;
      set => this._bottom = value;
    }
  }
}
