﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Paragraph
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a Paragraph.</summary>
  public class Paragraph : InsertBeforeOrAfter
  {
    internal List<XElement> _runs;
    internal int _startIndex;
    internal int _endIndex;
    internal List<XElement> _styles = new List<XElement>();
    internal const float DefaultSingleLineSpacing = 12f;
    private static float DefaultLineSpacing = 12f;
    private static float DefaultLineSpacingAfter = 0.0f;
    private static float DefaultLineSpacingBefore = 0.0f;
    private static bool DefaultLineRuleAuto = false;
    private static float DefaultIndentationFirstLine = 0.0f;
    private static float DefaultIndentationHanging = 0.0f;
    private static float DefaultIndentationBefore = 0.0f;
    private static float DefaultIndentationAfter = 0.0f;
    private Alignment alignment;
    private List<DocProperty> docProperties;
    private Direction direction;
    private float indentationFirstLine;
    private float indentationHanging;
    private float indentationBefore;
    private float indentationAfter;
    private List<Table> followingTables;
    private List<FormattedText> _magicText;
    private static int bookmarkIdCounter = 0;

    private XElement ParagraphNumberPropertiesBacker { get; set; }

    private int? IndentLevelBacker { get; set; }

    internal bool? IsListItemBacker { get; set; }

    /// <summary>Gets the list of Charts associated to this Paragraph.</summary>
    public List<Chart> Charts => this.Xml == null ? new List<Chart>() : this.GetCharts();

    /// <summary>Gets the collection of Shapes associated with this Paragraph.</summary>
    public List<Shape> Shapes => this.Xml == null ? new List<Shape>() : this.GetShapes();

    /// <summary>Gets the collection of TextBoxes associated with this Paragraph.</summary>
    public List<Shape> TextBoxes => this.Xml == null ? new List<Shape>() : this.GetShapes(true);

    /// <summary>Gets the collection of CheckBoxes associated with this Paragraph.</summary>
    public List<CheckBox> CheckBoxes => this.Xml == null ? new List<CheckBox>() : this.GetCheckBoxes();

    /// <summary>Gets or sets the Parent Container of this Paragraph.</summary>
    public ContainerType ParentContainer { get; set; }

    /// <summary>Gets the List Item Type of this Paragraph.</summary>
    public ListItemType ListItemType { get; set; }

    /// <summary>Gets the collection of Pictures of this Paragraph.</summary>
    public List<Picture> Pictures
    {
      get
      {
        if (this.Xml == null)
          return new List<Picture>();
        List<Picture> pictures = this.GetPictures("drawing", "blip", "embed");
        foreach (Picture picture in this.GetPictures("pict", "imagedata", "id"))
          pictures.Add(picture);
        return pictures;
      }
    }

    /// <summary>Gets the collection of Hyperlinks of this Paragraph.</summary>
    public List<Hyperlink> Hyperlinks
    {
      get
      {
        List<Hyperlink> hyperlinkList = new List<Hyperlink>();
        foreach (XElement xelement1 in this.Xml.Descendants().Where<XElement>((Func<XElement, bool>) (h => h.Name.LocalName == "hyperlink" || h.Name.LocalName == "instrText")).ToList<XElement>())
        {
          if (xelement1.Name.LocalName == "hyperlink")
          {
            try
            {
              Hyperlink hyperlink = new Hyperlink(this.Document, this.PackagePart, xelement1);
              hyperlink.PackagePart = this.PackagePart;
              hyperlinkList.Add(hyperlink);
            }
            catch (Exception ex)
            {
            }
          }
          else
          {
            XElement xelement2 = xelement1;
            while (xelement2.Name.LocalName != "r")
              xelement2 = xelement2.Parent;
            List<XElement> runs = new List<XElement>();
            foreach (XElement xelement3 in xelement2.ElementsAfterSelf(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName)))
            {
              runs.Add(xelement3);
              XElement xelement4 = xelement3.Descendants(XName.Get("fldChar", Xceed.Document.NET.Document.w.NamespaceName)).SingleOrDefault<XElement>();
              if (xelement4 != null)
              {
                XAttribute xattribute = xelement4.Attribute(XName.Get("fldCharType", Xceed.Document.NET.Document.w.NamespaceName));
                if (xattribute != null)
                {
                  if (xattribute.Value.Equals("end", StringComparison.CurrentCultureIgnoreCase))
                  {
                    try
                    {
                      Hyperlink hyperlink = new Hyperlink(this.Document, xelement1, runs);
                      hyperlink.PackagePart = this.PackagePart;
                      hyperlinkList.Add(hyperlink);
                      break;
                    }
                    catch (Exception ex)
                    {
                      break;
                    }
                  }
                }
              }
            }
          }
        }
        return hyperlinkList;
      }
    }

    [Obsolete("This property is obsolete and should no longer be used. Use StyleId instead.")]
    public string StyleName
    {
      get => this.StyleId;
      set => this.StyleId = value;
    }

    /// <summary>
    ///   <span id="BugEvents">Gets or sets the id of the style of this Paragraph.</span>
    /// </summary>
    public string StyleId
    {
      get
      {
        XAttribute xattribute = this.GetOrCreate_pPr().Element(XName.Get("pStyle", Xceed.Document.NET.Document.w.NamespaceName))?.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        return !string.IsNullOrEmpty(xattribute?.Value) ? xattribute.Value : this.Document.GetNormalStyleId();
      }
      set
      {
        if (string.IsNullOrEmpty(value))
          value = this.Document.GetNormalStyleId();
        XElement pPr = this.GetOrCreate_pPr();
        XElement xelement = pPr.Element(XName.Get("pStyle", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement == null)
        {
          pPr.Add((object) new XElement(XName.Get("pStyle", Xceed.Document.NET.Document.w.NamespaceName)));
          xelement = pPr.Element(XName.Get("pStyle", Xceed.Document.NET.Document.w.NamespaceName));
        }
        xelement.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) value);
        this.AddParagraphStyleIfNotPresent(this.StyleId);
      }
    }

    /// <summary>Gets the collection of Document Properties of this Paragraph.</summary>
    public List<DocProperty> DocumentProperties => this.docProperties;

    /// <summary>Gets or sets the Direction of this Paragraph.</summary>
    public Direction Direction
    {
      get => this.GetOrCreate_pPr().Element(XName.Get("bidi", Xceed.Document.NET.Document.w.NamespaceName)) != null ? Direction.RightToLeft : Direction.LeftToRight;
      set
      {
        this.direction = value;
        XElement pPr = this.GetOrCreate_pPr();
        XElement xelement = pPr.Element(XName.Get("bidi", Xceed.Document.NET.Document.w.NamespaceName));
        if (this.direction == Direction.RightToLeft)
        {
          if (xelement != null)
            return;
          pPr.Add((object) new XElement(XName.Get("bidi", Xceed.Document.NET.Document.w.NamespaceName)));
        }
        else
          xelement?.Remove();
      }
    }

    /// <summary>Gets or sets the Indentation (in points) of the first line of this Paragraph.</summary>
    public float IndentationFirstLine
    {
      get
      {
        this.GetOrCreate_pPr();
        XAttribute xattribute = this.GetOrCreate_pPr_ind().Attribute(XName.Get("firstLine", Xceed.Document.NET.Document.w.NamespaceName));
        return xattribute != null ? float.Parse(xattribute.Value) / 20f : Paragraph.DefaultIndentationFirstLine;
      }
      set
      {
        if ((double) this.IndentationFirstLine == (double) value)
          return;
        this.indentationFirstLine = value;
        this.GetOrCreate_pPr();
        XElement pPrInd = this.GetOrCreate_pPr_ind();
        pPrInd.Attribute(XName.Get("hanging", Xceed.Document.NET.Document.w.NamespaceName))?.Remove();
        string str = (this.indentationFirstLine * 20f).ToString((IFormatProvider) CultureInfo.InvariantCulture);
        XAttribute xattribute = pPrInd.Attribute(XName.Get("firstLine", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null)
          xattribute.Value = str;
        else
          pPrInd.Add((object) new XAttribute(XName.Get("firstLine", Xceed.Document.NET.Document.w.NamespaceName), (object) str));
      }
    }

    /// <summary>Gets or sets the Indentation (in points) of all but the first line of this Paragraph.</summary>
    public float IndentationHanging
    {
      get
      {
        this.GetOrCreate_pPr();
        XAttribute xattribute = this.GetOrCreate_pPr_ind().Attribute(XName.Get("hanging", Xceed.Document.NET.Document.w.NamespaceName));
        return xattribute != null ? float.Parse(xattribute.Value) / 20f : Paragraph.DefaultIndentationHanging;
      }
      set
      {
        if ((double) this.IndentationHanging == (double) value)
          return;
        this.indentationHanging = value;
        this.GetOrCreate_pPr();
        XElement pPrInd = this.GetOrCreate_pPr_ind();
        pPrInd.Attribute(XName.Get("firstLine", Xceed.Document.NET.Document.w.NamespaceName))?.Remove();
        string str = (this.indentationHanging * 20f).ToString((IFormatProvider) CultureInfo.InvariantCulture);
        XAttribute xattribute = pPrInd.Attribute(XName.Get("hanging", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null)
          xattribute.Value = str;
        else
          pPrInd.Add((object) new XAttribute(XName.Get("hanging", Xceed.Document.NET.Document.w.NamespaceName), (object) str));
        this.IndentationBefore = this.indentationHanging;
      }
    }

    /// <summary>Gets or sets the Indentation (in points) before this Paragraph.</summary>
    public float IndentationBefore
    {
      get
      {
        this.GetOrCreate_pPr();
        XAttribute xattribute = this.GetOrCreate_pPr_ind().Attribute(XName.Get("left", Xceed.Document.NET.Document.w.NamespaceName));
        return xattribute != null ? float.Parse(xattribute.Value) / 20f : Paragraph.DefaultIndentationBefore;
      }
      set
      {
        if ((double) this.IndentationBefore == (double) value)
          return;
        this.indentationBefore = value;
        this.GetOrCreate_pPr();
        XElement pPrInd = this.GetOrCreate_pPr_ind();
        string str = (this.indentationBefore * 20f).ToString((IFormatProvider) CultureInfo.InvariantCulture);
        XAttribute xattribute = pPrInd.Attribute(XName.Get("left", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null)
          xattribute.Value = str;
        else
          pPrInd.Add((object) new XAttribute(XName.Get("left", Xceed.Document.NET.Document.w.NamespaceName), (object) str));
      }
    }

    /// <summary>Gets or sets the Indentation (in points) after this Paragraph.</summary>
    public float IndentationAfter
    {
      get
      {
        this.GetOrCreate_pPr();
        XAttribute xattribute = this.GetOrCreate_pPr_ind().Attribute(XName.Get("right", Xceed.Document.NET.Document.w.NamespaceName));
        return xattribute != null ? float.Parse(xattribute.Value) / 20f : Paragraph.DefaultIndentationAfter;
      }
      set
      {
        if ((double) this.IndentationAfter == (double) value)
          return;
        this.indentationAfter = value;
        this.GetOrCreate_pPr();
        XElement pPrInd = this.GetOrCreate_pPr_ind();
        string str = (this.indentationAfter * 20f).ToString((IFormatProvider) CultureInfo.InvariantCulture);
        XAttribute xattribute = pPrInd.Attribute(XName.Get("right", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null)
          xattribute.Value = str;
        else
          pPrInd.Add((object) new XAttribute(XName.Get("right", Xceed.Document.NET.Document.w.NamespaceName), (object) str));
      }
    }

    /// <summary>Gets or sets the Alignment of this Paragraph.</summary>
    public Alignment Alignment
    {
      get
      {
        XElement xelement = this.GetOrCreate_pPr().Element(XName.Get("jc", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement != null)
        {
          switch (xelement.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)).Value.ToLower())
          {
            case "left":
              return Alignment.left;
            case "right":
              return Alignment.right;
            case "center":
              return Alignment.center;
            case "both":
              return Alignment.both;
          }
        }
        return Alignment.left;
      }
      set
      {
        this.alignment = value;
        XElement pPr = this.GetOrCreate_pPr();
        XElement xelement = pPr.Element(XName.Get("jc", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement == null)
          pPr.Add((object) new XElement(XName.Get("jc", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) this.alignment.ToString())));
        else
          xelement.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)).Value = this.alignment.ToString();
      }
    }

    /// <summary>Gets the Text of this Paragraph.</summary>
    public string Text
    {
      get
      {
        try
        {
          return HelperFunctions.GetText(this.Xml);
        }
        catch (Exception ex)
        {
          return (string) null;
        }
      }
    }

    /// <summary>Gets the formatted text value of this Paragraph.</summary>
    public List<FormattedText> MagicText
    {
      get
      {
        if (this._magicText == null)
          this._magicText = HelperFunctions.GetFormattedText(this.Xml);
        return this._magicText;
      }
    }

    /// <summary>
    ///         <span style="FONT-SIZE: 13px; FONT-FAMILY: &amp;quot;Segoe UI&amp;quot;, Verdana, Arial; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; FLOAT: none; FONT-WEIGHT: 400; COLOR: rgb(0,0,0); FONT-STYLE: normal; ORPHANS: 2; WIDOWS: 2; DISPLAY: inline !important; LETTER-SPACING: normal; TEXT-INDENT: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
    /// Applies the current culture to the last appended text.</span>
    ///       </summary>
    /// <returns>
    ///         <span style="FONT-SIZE: 13px; FONT-FAMILY: &amp;quot;Segoe UI&amp;quot;, Verdana, Arial; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; FLOAT: none; FONT-WEIGHT: 400; COLOR: rgb(0,0,0); FONT-STYLE: normal; ORPHANS: 2; WIDOWS: 2; DISPLAY: inline !important; LETTER-SPACING: normal; TEXT-INDENT: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
    /// This Paragraph with the last appended text's culture changed.</span>
    ///       </returns>
    public Paragraph CurrentCulture()
    {
      this.ApplyTextFormattingProperty(XName.Get("lang", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) CultureInfo.CurrentCulture.Name));
      return this;
    }

    /// <summary>Gets the list of Tables following the current paragraph.</summary>
    public List<Table> FollowingTables
    {
      get => this.followingTables;
      internal set => this.followingTables = value;
    }

    /// <summary>Gets or sets the LineSpacing (in points) of this Paragraph.</summary>
    public float LineSpacing
    {
      get
      {
        XElement xelement = this.GetOrCreate_pPr().Element(XName.Get("spacing", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement != null)
        {
          XAttribute xattribute = xelement.Attribute(XName.Get("line", Xceed.Document.NET.Document.w.NamespaceName));
          float result;
          if (xattribute != null && HelperFunctions.TryParseFloat(xattribute.Value, out result))
            return result / 20f;
        }
        return Paragraph.DefaultLineSpacing;
      }
      set => this.SpacingLine((double) value);
    }

    /// <summary>Gets or sets the Line Spacing (in points) before this Paragraph.</summary>
    public float LineSpacingBefore
    {
      get
      {
        XElement xelement = this.GetOrCreate_pPr().Element(XName.Get("spacing", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement != null)
        {
          if (this.IsBeforeAutoSpacing())
            return 0.0f;
          XAttribute xattribute = xelement.Attribute(XName.Get("before", Xceed.Document.NET.Document.w.NamespaceName));
          float result;
          if (xattribute != null && HelperFunctions.TryParseFloat(xattribute.Value, out result))
            return result / 20f;
        }
        return Paragraph.DefaultLineSpacingBefore;
      }
      set => this.SpacingBefore((double) value);
    }

    /// <summary>Gets or sets the Line Spacing (in points) after this Paragraph.</summary>
    public float LineSpacingAfter
    {
      get
      {
        XElement xelement = this.GetOrCreate_pPr().Element(XName.Get("spacing", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement != null)
        {
          if (this.IsAfterAutoSpacing())
            return 0.0f;
          XAttribute xattribute = xelement.Attribute(XName.Get("after", Xceed.Document.NET.Document.w.NamespaceName));
          float result;
          if (xattribute != null && HelperFunctions.TryParseFloat(xattribute.Value, out result))
            return result / 20f;
        }
        return Paragraph.DefaultLineSpacingAfter;
      }
      set => this.SpacingAfter((double) value);
    }

    internal bool IsAfterAutoSpacing()
    {
      XElement xelement = this.GetOrCreate_pPr().Element(XName.Get("spacing", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement != null)
      {
        XAttribute xattribute = xelement.Attribute(XName.Get("afterAutospacing", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null && xattribute.Value == "1")
          return true;
      }
      return false;
    }

    internal bool IsBeforeAutoSpacing()
    {
      XElement xelement = this.GetOrCreate_pPr().Element(XName.Get("spacing", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement != null)
      {
        XAttribute xattribute = xelement.Attribute(XName.Get("beforeAutospacing", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null && xattribute.Value == "1")
          return true;
      }
      return false;
    }

    /// <summary>Gets the Number Properties of this Paragraph.</summary>
    public XElement ParagraphNumberProperties => this.ParagraphNumberPropertiesBacker ?? (this.ParagraphNumberPropertiesBacker = this.GetParagraphNumberProperties());

    /// <summary>Gets if this Paragraph is a list element.</summary>
    public bool IsListItem
    {
      get
      {
        bool? isListItemBacker = this.IsListItemBacker;
        this.IsListItemBacker = new bool?(isListItemBacker.HasValue ? isListItemBacker.GetValueOrDefault() : this.ParagraphNumberProperties != null);
        isListItemBacker = this.IsListItemBacker;
        return isListItemBacker.Value;
      }
    }

    /// <summary>Gets the Indentation level of this Paragraph.</summary>
    public int? IndentLevel
    {
      get
      {
        if (!this.IsListItem)
          return new int?();
        int? nullable = this.IndentLevelBacker;
        if (nullable.HasValue)
          return this.IndentLevelBacker;
        XElement el1 = this.ParagraphNumberProperties.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (el => el.Name.LocalName == "ilvl"));
        nullable = new int?(el1 != null ? int.Parse(el1.GetAttribute(Xceed.Document.NET.Document.w + "val")) : 0);
        this.IndentLevelBacker = nullable;
        return nullable;
      }
    }

    /// <summary>Gets if this Paragraph must stay with the next Paragraph (stay on the same page).</summary>
    public bool IsKeepWithNext => this.GetOrCreate_pPr().Element(XName.Get("keepNext", Xceed.Document.NET.Document.w.NamespaceName)) != null;

    internal Paragraph(
      Xceed.Document.NET.Document document,
      XElement xml,
      int startIndex,
      ContainerType parentContainerType = ContainerType.None)
      : base(document, xml)
    {
      this._startIndex = startIndex;
      this._endIndex = startIndex + Paragraph.GetElementTextLength(xml);
      this.ParentContainer = parentContainerType;
      this.RebuildDocProperties();
      this._runs = this.Xml.Elements(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName)).ToList<XElement>();
    }

    /// <summary>Inserts the provided Table before this Paragraph.</summary>
    /// <returns>The new Table that was inserted.</returns>
    /// <param name="t">The Table to insert.</param>
    public override Table InsertTableBeforeSelf(Table t)
    {
      t = base.InsertTableBeforeSelf(t);
      t.PackagePart = this.PackagePart;
      return t;
    }

    /// <summary>Inserts a Table of a specific size before this Paragraph.</summary>
    /// <returns>The new Table that was inserted.</returns>
    /// <param name="rowCount">The row count for the new Table.</param>
    /// <param name="columnCount">The column count for the new Table.</param>
    public override Table InsertTableBeforeSelf(int rowCount, int columnCount) => base.InsertTableBeforeSelf(rowCount, columnCount);

    /// <summary>Inserts the provided Table after this Paragraph.</summary>
    /// <returns>The new Table that was inserted.</returns>
    /// <param name="t">The Table to insert.</param>
    public override Table InsertTableAfterSelf(Table t)
    {
      t = base.InsertTableAfterSelf(t);
      t.PackagePart = this.PackagePart;
      if (this.ParentContainer == ContainerType.Cell)
        t.InsertParagraphAfterSelf("");
      return t;
    }

    /// <summary>Inserts a Table of a specific size after this Paragraph.</summary>
    /// <returns>The new Table that was inserted.</returns>
    /// <param name="rowCount">The row count for the new Table.</param>
    /// <param name="columnCount">The column count for the new Table.</param>
    public override Table InsertTableAfterSelf(int rowCount, int columnCount)
    {
      Table table = base.InsertTableAfterSelf(rowCount, columnCount);
      if (this.ParentContainer == ContainerType.Cell)
        table.InsertParagraphAfterSelf("");
      return table;
    }

    /// <summary>Replaces a Picture in this Paragraph with another Picture.</summary>
    /// <returns>The Picture that was inserted.</returns>
    /// <param name="toBeReplaced">The Picture to remove.</param>
    /// <param name="replaceWith">The Picture to insert.</param>
    public Picture ReplacePicture(Picture toBeReplaced, Picture replaceWith)
    {
      Xceed.Document.NET.Document document = this.Document;
      long nextFreeDocPrId = document.GetNextFreeDocPrId();
      XElement i = XElement.Parse(toBeReplaced.Xml.ToString());
      foreach (XElement descendant in i.Descendants(XName.Get("docPr", Xceed.Document.NET.Document.wp.NamespaceName)))
        descendant.SetAttributeValue(XName.Get("id"), (object) nextFreeDocPrId);
      foreach (XElement descendant in i.Descendants(XName.Get("blip", Xceed.Document.NET.Document.a.NamespaceName)))
        descendant.SetAttributeValue(XName.Get("embed", Xceed.Document.NET.Document.r.NamespaceName), (object) replaceWith.Id);
      Picture p = new Picture(this.Document, i, new Image(document, this.PackagePart.GetRelationship(replaceWith.Id)));
      this.AppendPicture(p);
      toBeReplaced.Remove();
      return p;
    }

    /// <summary>Inserts the provided Paragraph before this Paragraph.</summary>
    /// <param name="p">The Paragraph to insert.</param>
    public override Paragraph InsertParagraphBeforeSelf(Paragraph p)
    {
      Paragraph paragraph = base.InsertParagraphBeforeSelf(p);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    /// <summary>Inserts a Paragraph before this Paragraph, using the provided text.</summary>
    /// <param name="text">The text for the new Paragraph.</param>
    public override Paragraph InsertParagraphBeforeSelf(string text)
    {
      Paragraph paragraph = base.InsertParagraphBeforeSelf(text);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    /// <summary>Inserts a Paragraph before this Paragraph, using the provided text, and optionally track this change.</summary>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public override Paragraph InsertParagraphBeforeSelf(string text, bool trackChanges)
    {
      Paragraph paragraph = base.InsertParagraphBeforeSelf(text, trackChanges);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    /// <summary>Inserts a Paragraph before this Paragraph, using the provided text and formatting, and optionally track this change.</summary>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="formatting">The format to apply to the new Paragraph.</param>
    public override Paragraph InsertParagraphBeforeSelf(
      string text,
      bool trackChanges,
      Formatting formatting)
    {
      Paragraph paragraph = base.InsertParagraphBeforeSelf(text, trackChanges, formatting);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    /// <summary>Inserts a page break before this Paragraph.</summary>
    public override void InsertPageBreakBeforeSelf() => base.InsertPageBreakBeforeSelf();

    /// <summary>Inserts a page break after this Paragraph.</summary>
    public override void InsertPageBreakAfterSelf() => base.InsertPageBreakAfterSelf();

    [Obsolete("Instead use: InsertHyperlink(Hyperlink h, int index)")]
    public Paragraph InsertHyperlink(int index, Hyperlink h) => this.InsertHyperlink(h, index);

    /// <summary>Inserts a Hyperlink at a specific index in this Paragraph.</summary>
    /// <returns>This Paragraph with the Hyperlink inserted.</returns>
    /// <param name="h">The Hyperlink to insert.</param>
    /// <param name="index">The index at which to insert the Hyperlink.</param>
    public Paragraph InsertHyperlink(Hyperlink h, int index = 0)
    {
      Uri uri = new Uri(string.Format("/word/_rels/{0}.rels", (object) this.PackagePart.get_Uri().OriginalString.Replace("/word/", "")), UriKind.Relative);
      if (!this.Document._package.PartExists(uri))
        HelperFunctions.CreateRelsPackagePart(this.Document, uri);
      string orGenerateRel = Paragraph.GetOrGenerateRel(h, this.PackagePart);
      XElement xelement;
      if (index == 0)
      {
        this.Xml.AddFirst((object) h.Xml);
        xelement = (XElement) this.Xml.FirstNode;
      }
      else
      {
        Run runEffectedByEdit = this.GetFirstRunEffectedByEdit(index);
        if (runEffectedByEdit == null)
        {
          this.Xml.Add((object) h.Xml);
          xelement = (XElement) this.Xml.LastNode;
        }
        else
        {
          XElement[] xelementArray = Run.SplitRun(runEffectedByEdit, index);
          runEffectedByEdit.Xml.ReplaceWith((object) xelementArray[0], (object) h.Xml, (object) xelementArray[1]);
          xelement = (XElement) this.GetFirstRunEffectedByEdit(index).Xml.NextNode;
        }
      }
      xelement.SetAttributeValue(Xceed.Document.NET.Document.r + "id", (object) orGenerateRel);
      this._runs = this.Xml.Elements().Last<XElement>().Elements(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName)).ToList<XElement>();
      return this;
    }

    /// <summary>Removes the specified Hyperlink from this Paragraph.</summary>
    /// <param name="index">The index of the Hyperlink to remove.</param>
    public void RemoveHyperlink(int index)
    {
      if (index < 0)
        throw new ArgumentOutOfRangeException();
      int count = 0;
      bool found = false;
      this.RemoveHyperlinkRecursive(this.Xml, index, ref count, ref found);
      if (!found)
        throw new ArgumentOutOfRangeException();
    }

    /// <summary>Inserts the provided Paragraph after this Paragraph.</summary>
    /// <param name="p">The Paragraph to insert.</param>
    public override Paragraph InsertParagraphAfterSelf(Paragraph p)
    {
      Paragraph paragraph = base.InsertParagraphAfterSelf(p);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    /// <summary>Inserts a Paragraph after this Paragraph, using the provided text and formatting, and optionally track this change.</summary>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="formatting">The format to apply to the new Paragraph.</param>
    public override Paragraph InsertParagraphAfterSelf(
      string text,
      bool trackChanges,
      Formatting formatting)
    {
      Paragraph paragraph = base.InsertParagraphAfterSelf(text, trackChanges, formatting);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    /// <summary>Inserts a Paragraph after this Paragraph, using the provided text, and optionally track this change.</summary>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public override Paragraph InsertParagraphAfterSelf(string text, bool trackChanges)
    {
      Paragraph paragraph = base.InsertParagraphAfterSelf(text, trackChanges);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    /// <summary>Inserts a Paragraph after this Paragraph, using the provided text.</summary>
    /// <param name="text">The text for the new Paragraph.</param>
    public override Paragraph InsertParagraphAfterSelf(string text)
    {
      Paragraph paragraph = base.InsertParagraphAfterSelf(text);
      paragraph.PackagePart = this.PackagePart;
      return paragraph;
    }

    /// <summary>Removes this Paragraph from the Document.</summary>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public void Remove(bool trackChanges)
    {
      if (trackChanges)
      {
        DateTime universalTime = DateTime.Now.ToUniversalTime();
        List<XElement> list = this.Xml.Elements().ToList<XElement>();
        List<XElement> source = new List<XElement>();
        for (int index = 0; index < list.Count<XElement>(); ++index)
        {
          XElement xelement = list[index];
          if (xelement.Name.LocalName != "del")
          {
            source.Add(xelement);
            xelement.Remove();
          }
          else if (source.Count<XElement>() > 0)
          {
            xelement.AddBeforeSelf((object) Paragraph.CreateEdit(EditType.del, universalTime, (object) source.Elements<XElement>()));
            source.Clear();
          }
        }
        if (source.Count<XElement>() <= 0)
          return;
        this.Xml.Add((object) Paragraph.CreateEdit(EditType.del, universalTime, (object) source));
      }
      else if (this.Xml.Parent.Name.LocalName == "tc" && this.Xml.Parent.Elements(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName)).Count<XElement>() == 1)
      {
        this.Xml.Value = string.Empty;
      }
      else
      {
        this.Xml.Remove();
        this.Xml = (XElement) null;
      }
    }

    /// <summary>Inserts the provided text in this Paragraph, using the provided formatting, and optionally track this change.</summary>
    /// <param name="value">The text to insert.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="formatting">The formatting to use.</param>
    public void InsertText(string value, bool trackChanges = false, Formatting formatting = null) => this.InsertText(this.Text.Length, value, trackChanges, formatting);

    /// <summary>Inserts the provided text at a specific location in this Paragraph, using the provided formatting, and optionally track this change.</summary>
    /// <param name="index">The index at which to insert the text.</param>
    /// <param name="value">The text to insert.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="formatting">The formatting to use.</param>
    public void InsertText(int index, string value, bool trackChanges = false, Formatting formatting = null)
    {
      DateTime now = DateTime.Now;
      DateTime edit_time = new DateTime(now.Year, now.Month, now.Day, now.Hour, now.Minute, 0, DateTimeKind.Utc);
      Run runEffectedByEdit = this.GetFirstRunEffectedByEdit(index);
      if (runEffectedByEdit == null)
      {
        object content = formatting != null ? (object) HelperFunctions.FormatInput(value, formatting.Xml) : (object) HelperFunctions.FormatInput(value, (XElement) null);
        if (trackChanges)
          content = (object) Paragraph.CreateEdit(EditType.ins, edit_time, content);
        this.Xml.Add(content);
      }
      else
      {
        XElement rPr = runEffectedByEdit.Xml.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
        object content;
        if (formatting != null)
        {
          Formatting newFormatting;
          if (rPr != null)
          {
            Formatting formatting1 = Formatting.Parse(rPr);
            if (formatting1 != null)
            {
              newFormatting = formatting1.Clone();
              this.ApplyFormattingFrom(ref newFormatting, formatting);
            }
            else
              newFormatting = formatting;
          }
          else
            newFormatting = formatting;
          content = (object) HelperFunctions.FormatInput(value, newFormatting.Xml);
        }
        else
          content = (object) HelperFunctions.FormatInput(value, rPr);
        XElement parent = runEffectedByEdit.Xml.Parent;
        switch (parent.Name.LocalName)
        {
          case "ins":
            DateTime dateTime = DateTime.Parse(parent.Attribute(XName.Get("date", Xceed.Document.NET.Document.w.NamespaceName)).Value);
            if (!trackChanges || dateTime.CompareTo(edit_time) != 0)
              goto case "del";
            else
              break;
          case "del":
            object obj1 = content;
            if (trackChanges)
              obj1 = (object) Paragraph.CreateEdit(EditType.ins, edit_time, content);
            XElement[] xelementArray1 = this.SplitEdit(parent, index, EditType.ins);
            parent.ReplaceWith((object) xelementArray1[0], obj1, (object) xelementArray1[1]);
            goto label_20;
        }
        object obj2 = content;
        if (trackChanges && !parent.Name.LocalName.Equals("ins"))
          obj2 = (object) Paragraph.CreateEdit(EditType.ins, edit_time, content);
        XElement[] xelementArray2 = Run.SplitRun(runEffectedByEdit, index);
        runEffectedByEdit.Xml.ReplaceWith((object) xelementArray2[0], obj2, (object) xelementArray2[1]);
      }
label_20:
      this._runs = this.Xml.Elements(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName)).ToList<XElement>();
      HelperFunctions.RenumberIDs(this.Document);
    }

    /// <summary>Applies the provided culture to the last appended text.</summary>
    /// <returns>This Paragraph with the last appended text's culture changed.</returns>
    /// <param name="culture">The culture to apply.</param>
    public Paragraph Culture(CultureInfo culture)
    {
      this.ApplyTextFormattingProperty(XName.Get("lang", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) culture.Name));
      return this;
    }

    /// <summary>Appends text to this Paragraph.</summary>
    /// <returns>This Paragraph with the new text appended.</returns>
    /// <param name="text">The text to append.</param>
    public Paragraph Append(string text)
    {
      List<XElement> source = HelperFunctions.FormatInput(text, (XElement) null);
      this.Xml.Add((object) source);
      this._runs = this.Xml.Elements(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName)).Reverse<XElement>().Take<XElement>(source.Count<XElement>()).ToList<XElement>();
      return this;
    }

    /// <summary>Appends text to this Paragraph, and apply the provided format.</summary>
    /// <returns>This Paragraph with the new text appended.</returns>
    /// <param name="text">The text to append.</param>
    /// <param name="format">The format to use.</param>
    public Paragraph Append(string text, Formatting format)
    {
      this.Append(text);
      bool? nullable1;
      if (format.Bold.HasValue)
      {
        nullable1 = format.Bold;
        if (nullable1.Value)
          this.Bold();
      }
      Xceed.Document.NET.CapsStyle? capsStyle = format.CapsStyle;
      if (capsStyle.HasValue)
      {
        capsStyle = format.CapsStyle;
        this.CapsStyle(capsStyle.Value);
      }
      System.Drawing.Color? nullable2 = format.FontColor;
      if (nullable2.HasValue)
      {
        nullable2 = format.FontColor;
        this.Color(nullable2.Value);
      }
      if (format.FontFamily != null)
        this.Font(format.FontFamily);
      nullable1 = format.Hidden;
      if (nullable1.HasValue)
      {
        nullable1 = format.Hidden;
        if (nullable1.Value)
          this.Hide();
      }
      Xceed.Document.NET.Highlight? highlight = format.Highlight;
      if (highlight.HasValue)
      {
        highlight = format.Highlight;
        this.Highlight(highlight.Value);
      }
      nullable2 = format.Shading;
      if (nullable2.HasValue)
      {
        nullable2 = format.Shading;
        this.Shading(nullable2.Value);
      }
      if (format.Border != null)
        this.Border(format.Border);
      nullable1 = format.Italic;
      if (nullable1.HasValue)
      {
        nullable1 = format.Italic;
        if (nullable1.Value)
          this.Italic();
      }
      float? nullable3 = format.Kerning;
      if (nullable3.HasValue)
      {
        nullable3 = format.Kerning;
        this.Kerning(nullable3.Value);
      }
      if (format.Language != null)
        this.Culture(format.Language);
      Xceed.Document.NET.Misc? misc = format.Misc;
      if (misc.HasValue)
      {
        misc = format.Misc;
        this.Misc(misc.Value);
      }
      nullable3 = format.PercentageScale;
      if (nullable3.HasValue)
      {
        nullable3 = format.PercentageScale;
        this.PercentageScale(nullable3.Value);
      }
      nullable3 = format.Position;
      if (nullable3.HasValue)
      {
        nullable3 = format.Position;
        this.Position((double) nullable3.Value);
      }
      Xceed.Document.NET.Script? script = format.Script;
      if (script.HasValue)
      {
        script = format.Script;
        this.Script(script.Value);
      }
      double? nullable4 = format.Size;
      if (nullable4.HasValue)
      {
        nullable4 = format.Size;
        this.FontSize(nullable4.Value);
      }
      nullable4 = format.Spacing;
      if (nullable4.HasValue)
      {
        nullable4 = format.Spacing;
        this.Spacing(nullable4.Value);
      }
      Xceed.Document.NET.StrikeThrough? strikeThrough = format.StrikeThrough;
      if (strikeThrough.HasValue)
      {
        strikeThrough = format.StrikeThrough;
        this.StrikeThrough(strikeThrough.Value);
      }
      nullable2 = format.UnderlineColor;
      if (nullable2.HasValue)
      {
        nullable2 = format.UnderlineColor;
        this.UnderlineColor(nullable2.Value);
      }
      Xceed.Document.NET.UnderlineStyle? underlineStyle = format.UnderlineStyle;
      if (underlineStyle.HasValue)
      {
        underlineStyle = format.UnderlineStyle;
        this.UnderlineStyle(underlineStyle.Value);
      }
      return this;
    }

    /// <summary>Appends a Hyperlink to this Paragraph.</summary>
    /// <returns>This Paragraph with the new Hyperlink appended.</returns>
    /// <param name="h">The Hyperlink to append.</param>
    public Paragraph AppendHyperlink(Hyperlink h)
    {
      Uri uri = new Uri("/word/_rels/" + this.PackagePart.get_Uri().OriginalString.Replace("/word/", "") + ".rels", UriKind.Relative);
      if (!this.Document._package.PartExists(uri))
        HelperFunctions.CreateRelsPackagePart(this.Document, uri);
      string orGenerateRel = Paragraph.GetOrGenerateRel(h, this.PackagePart);
      this.Xml.Add((object) h.Xml);
      this.Xml.Elements().Last<XElement>().SetAttributeValue(Xceed.Document.NET.Document.r + "id", (object) orGenerateRel);
      this._runs = this.Xml.Elements().Last<XElement>().Elements(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName)).ToList<XElement>();
      return this;
    }

    /// <summary>Appends a Picture to this Paragraph.</summary>
    /// <returns>This Paragraph with the new Picture appended.</returns>
    /// <param name="p">The Picture to append.</param>
    public Paragraph AppendPicture(Picture p)
    {
      Uri uri = new Uri("/word/_rels/" + this.PackagePart.get_Uri().OriginalString.Replace("/word/", "") + ".rels", UriKind.Relative);
      if (!this.Document._package.PartExists(uri))
        HelperFunctions.CreateRelsPackagePart(this.Document, uri);
      string orGenerateRel = this.GetOrGenerateRel(p);
      this.Xml.Add((object) p.Xml);
      this.Xml.Elements().Last<XElement>().Descendants().Where<XElement>((Func<XElement, bool>) (e => e.Name.LocalName.Equals("blip"))).Select<XElement, XAttribute>((Func<XElement, XAttribute>) (e => e.Attribute(XName.Get("embed", "http://schemas.openxmlformats.org/officeDocument/2006/relationships")))).Single<XAttribute>().SetValue((object) orGenerateRel);
      this._runs = this.Xml.Elements(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName)).ToList<XElement>();
      return this;
    }

    /// <summary>Appends a Shape to this Paragraph.</summary>
    /// <returns>This Paragraph with the new Shape appended.</returns>
    /// <param name="shape">The Shape to append.</param>
    public Paragraph AppendShape(Shape shape)
    {
      this.Xml.Add((object) shape.Xml);
      this._runs = this.Xml.Elements(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName)).ToList<XElement>();
      return this;
    }

    /// <summary>Inserts a Shape at a specific location in this Paragraph.</summary>
    /// <returns>This Paragraph with the Shape inserted.</returns>
    /// <param name="s">The Shape to insert.</param>
    /// <param name="index">The index at which to insert the shape. By default, 0.</param>
    public Paragraph InsertShape(Shape s, int index = 0)
    {
      if (index == 0)
      {
        XElement xelement = this.Xml.Descendants(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
        if (xelement != null)
          xelement.AddBeforeSelf((object) s.Xml);
        else
          this.Xml.AddFirst((object) s.Xml);
      }
      else
      {
        Run runEffectedByEdit = this.GetFirstRunEffectedByEdit(index);
        if (runEffectedByEdit == null)
        {
          this.Xml.Add((object) s.Xml);
        }
        else
        {
          XElement[] xelementArray = Run.SplitRun(runEffectedByEdit, index);
          runEffectedByEdit.Xml.ReplaceWith((object) xelementArray[0], (object) s.Xml, (object) xelementArray[1]);
          this.GetFirstRunEffectedByEdit(index);
        }
      }
      return this;
    }

    /// <summary>Returns the ListItem number value that this Paragraph represents.</summary>
    /// <returns>A string representing the ListItem number value.</returns>
    public string GetListItemNumber() => this.GetListItemNumber((string) null);

    /// <summary>Appends a CheckBox to this Paragraph.</summary>
    /// <returns>This Paragraph with the new CheckBox appended.</returns>
    /// <param name="c">The CheckBox to append.</param>
    public Paragraph AppendCheckBox(CheckBox c)
    {
      if (!c.Size.HasValue && this.MagicText != null)
        c.Size = this.MagicText.Last<FormattedText>().formatting.Size;
      this.Xml.Add((object) c.Xml);
      this._runs = this.Xml.Elements().Last<XElement>().Elements(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName)).ToList<XElement>();
      return this;
    }

    /// <summary>Appends an equation to this Paragraph.</summary>
    /// <returns>This Paragraph with the new equation appended.</returns>
    /// <param name="equation">The equation to append.</param>
    /// <param name="align">The Alignment to apply.</param>
    public Paragraph AppendEquation(string equation, Alignment align = Alignment.center)
    {
      string empty = string.Empty;
      string str;
      switch (align)
      {
        case Alignment.left:
          str = "left";
          break;
        case Alignment.right:
          str = "right";
          break;
        default:
          str = "center";
          break;
      }
      this.Xml.Add((object) new XElement(XName.Get("oMathPara", Xceed.Document.NET.Document.m.NamespaceName), (object[]) new XElement[2]
      {
        new XElement(XName.Get("oMathParaPr", Xceed.Document.NET.Document.m.NamespaceName), (object) new XElement(XName.Get("jc", Xceed.Document.NET.Document.m.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.m.NamespaceName), (object) str))),
        new XElement(XName.Get("oMath", Xceed.Document.NET.Document.m.NamespaceName), (object) new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
        {
          (object) new Formatting()
          {
            FontFamily = new Xceed.Document.NET.Font("Cambria Math")
          }.Xml,
          (object) new XElement(XName.Get("t", Xceed.Document.NET.Document.m.NamespaceName), (object) equation)
        }))
      }));
      this._runs = this.Xml.Elements(XName.Get("oMathPara", Xceed.Document.NET.Document.m.NamespaceName)).ToList<XElement>();
      return this;
    }

    /// <summary>Inserts a Picture at a specific location in this Paragraph.</summary>
    /// <returns>This Paragraph with the Picture inserted.</returns>
    /// <param name="p">The Picture to insert.</param>
    /// <param name="index">The index at which to insert the picture. By default, 0.</param>
    public Paragraph InsertPicture(Picture p, int index = 0)
    {
      Uri uri = new Uri("/word/_rels/" + this.PackagePart.get_Uri().OriginalString.Replace("/word/", "") + ".rels", UriKind.Relative);
      if (!this.Document._package.PartExists(uri))
        HelperFunctions.CreateRelsPackagePart(this.Document, uri);
      string orGenerateRel = this.GetOrGenerateRel(p);
      XElement xelement1;
      if (index == 0)
      {
        XElement xelement2 = this.Xml.Descendants(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
        if (xelement2 != null)
        {
          xelement2.AddBeforeSelf((object) p.Xml);
          xelement1 = (XElement) xelement2.PreviousNode;
        }
        else
        {
          this.Xml.AddFirst((object) p.Xml);
          xelement1 = (XElement) this.Xml.FirstNode;
        }
      }
      else
      {
        Run runEffectedByEdit = this.GetFirstRunEffectedByEdit(index);
        if (runEffectedByEdit == null)
        {
          this.Xml.Add((object) p.Xml);
          xelement1 = (XElement) this.Xml.LastNode;
        }
        else
        {
          XElement[] xelementArray = Run.SplitRun(runEffectedByEdit, index);
          runEffectedByEdit.Xml.ReplaceWith((object) xelementArray[0], (object) p.Xml, (object) xelementArray[1]);
          xelement1 = (XElement) this.GetFirstRunEffectedByEdit(index).Xml.NextNode;
        }
      }
      xelement1.Descendants().Where<XElement>((Func<XElement, bool>) (e => e.Name.LocalName.Equals("blip"))).Select<XElement, XAttribute>((Func<XElement, XAttribute>) (e => e.Attribute(XName.Get("embed", "http://schemas.openxmlformats.org/officeDocument/2006/relationships")))).Single<XAttribute>().SetValue((object) orGenerateRel);
      return this;
    }

    /// <summary>Inserts a tab stop in this paragraph.</summary>
    /// <param name="alignment">The alignment of the tab stop.</param>
    /// <param name="position">The horizontal position of the tab stop.</param>
    /// <param name="leader">A TabStopPositionLeader value indicating the character used to fill in the space
    /// created by a tab.</param>
    public Paragraph InsertTabStopPosition(
      Alignment alignment,
      float position,
      TabStopPositionLeader leader = TabStopPositionLeader.none)
    {
      XElement pPr = this.GetOrCreate_pPr();
      XElement xelement1 = pPr.Element(XName.Get("tabs", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 == null)
      {
        xelement1 = new XElement(XName.Get("tabs", Xceed.Document.NET.Document.w.NamespaceName));
        pPr.Add((object) xelement1);
      }
      XElement xelement2 = new XElement(XName.Get("tab", Xceed.Document.NET.Document.w.NamespaceName));
      string empty1 = string.Empty;
      string str1;
      switch (alignment)
      {
        case Alignment.left:
          str1 = "left";
          break;
        case Alignment.center:
          str1 = "center";
          break;
        case Alignment.right:
          str1 = "right";
          break;
        default:
          throw new ArgumentException(nameof (alignment), "Value must be left, right or center.");
      }
      xelement2.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) str1);
      float num = position * 20f;
      xelement2.SetAttributeValue(XName.Get("pos", Xceed.Document.NET.Document.w.NamespaceName), (object) num.ToString((IFormatProvider) CultureInfo.InvariantCulture));
      string empty2 = string.Empty;
      string str2;
      switch (leader)
      {
        case TabStopPositionLeader.none:
          str2 = "none";
          break;
        case TabStopPositionLeader.dot:
          str2 = "dot";
          break;
        case TabStopPositionLeader.underscore:
          str2 = "underscore";
          break;
        case TabStopPositionLeader.hyphen:
          str2 = "hyphen";
          break;
        default:
          throw new ArgumentException(nameof (leader), "Unknown leader character.");
      }
      xelement2.SetAttributeValue(XName.Get(nameof (leader), Xceed.Document.NET.Document.w.NamespaceName), (object) str2);
      xelement1.Add((object) xelement2);
      return this;
    }

    public Paragraph AppendLine(string text) => this.Append("\n" + text);

    /// <summary>Appends a line to this Paragraph.</summary>
    public Paragraph AppendLine() => this.Append("\n");

    /// <summary>Applies or removes the Bold format to the last appended text.</summary>
    /// <returns>This Paragraph with the last appended text's Bold formatting changed.</returns>
    /// <param name="isBold">
    /// <strong>false</strong> to remove the bold formatting from the text. By default, <strong>true</strong>.</param>
    public Paragraph Bold(bool isBold = true)
    {
      this.ApplyTextFormattingProperty(XName.Get("b", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, isBold ? (object) (XAttribute) null : (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) "0"));
      return this;
    }

    /// <summary>Applies or removes the Italic format to the last appended text.</summary>
    /// <returns>This Paragraph with the last appended text's Italic formatting changed.</returns>
    /// <param name="isItalic">
    /// <strong>false</strong> to remove the italic formatting from the text. By default, <strong>true</strong>.</param>
    public Paragraph Italic(bool isItalic = true)
    {
      this.ApplyTextFormattingProperty(XName.Get("i", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, isItalic ? (object) (XAttribute) null : (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) "0"));
      return this;
    }

    /// <summary>Applies the provided color to the last appended text.</summary>
    /// <returns>This Paragraph with the last appended text's color changed.</returns>
    /// <param name="c">The Color to apply.</param>
    public Paragraph Color(System.Drawing.Color c)
    {
      this.ApplyTextFormattingProperty(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) c.ToHex()));
      return this;
    }

    /// <summary>Applies the provided UnderlineStyle to the last appended text.</summary>
    /// <returns>This Paragraph with the last appended text's underline style changed.</returns>
    /// <param name="underlineStyle">The UnderlineStyle to apply.</param>
    public Paragraph UnderlineStyle(Xceed.Document.NET.UnderlineStyle underlineStyle)
    {
      string str;
      switch (underlineStyle)
      {
        case Xceed.Document.NET.UnderlineStyle.none:
          str = string.Empty;
          break;
        case Xceed.Document.NET.UnderlineStyle.singleLine:
          str = "single";
          break;
        case Xceed.Document.NET.UnderlineStyle.doubleLine:
          str = "double";
          break;
        default:
          str = underlineStyle.ToString();
          break;
      }
      this.ApplyTextFormattingProperty(XName.Get("u", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) str));
      return this;
    }

    /// <summary>Applies the provided font size to the last appended text.</summary>
    /// <returns>This Paragraph with the last appended text's font size changed.</returns>
    /// <param name="fontSize">The font size to apply.</param>
    public Paragraph FontSize(double fontSize)
    {
      double num;
      if ((num = (double) ((int) fontSize * 2)) - num != 0.0)
        throw new ArgumentException("Size", "Value must be either a whole or half number, examples: 32, 32.5");
      if (fontSize <= 0.0 || fontSize >= 1639.0)
        throw new ArgumentException("Size", "Value must be in the range 0 - 1638");
      this.ApplyTextFormattingProperty(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) (fontSize * 2.0)));
      this.ApplyTextFormattingProperty(XName.Get("szCs", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) (fontSize * 2.0)));
      return this;
    }

    /// <summary>Applies the provided font name to the last appended text.</summary>
    /// <returns>This Paragraph with the last appended text's font changed.</returns>
    /// <param name="fontName">The font name to apply.</param>
    public Paragraph Font(string fontName) => this.Font(new Xceed.Document.NET.Font(fontName));

    /// <summary>Applies the provided Font to the last appended text.</summary>
    /// <returns>This Paragraph with the last appended text's font changed.</returns>
    /// <param name="fontFamily">The Font to apply.</param>
    public Paragraph Font(Xceed.Document.NET.Font fontFamily)
    {
      this.ApplyTextFormattingProperty(XName.Get("rFonts", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) new XAttribute[4]
      {
        new XAttribute(XName.Get("ascii", Xceed.Document.NET.Document.w.NamespaceName), (object) fontFamily.Name),
        new XAttribute(XName.Get("hAnsi", Xceed.Document.NET.Document.w.NamespaceName), (object) fontFamily.Name),
        new XAttribute(XName.Get("cs", Xceed.Document.NET.Document.w.NamespaceName), (object) fontFamily.Name),
        new XAttribute(XName.Get("eastAsia", Xceed.Document.NET.Document.w.NamespaceName), (object) fontFamily.Name)
      });
      return this;
    }

    /// <summary>Applies a CapsStyle format to the last appended text.</summary>
    /// <returns>This Paragraph with the last appended text's CapsStyle changed.</returns>
    /// <param name="capsStyle">The CapsStyle to apply.</param>
    public Paragraph CapsStyle(Xceed.Document.NET.CapsStyle capsStyle)
    {
      if (capsStyle != Xceed.Document.NET.CapsStyle.none)
        this.ApplyTextFormattingProperty(XName.Get(capsStyle.ToString(), Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) null);
      return this;
    }

    /// <summary>Applies the provided Script style to the last appended text.</summary>
    /// <returns>This Paragraph with the last appended text's script style changed.</returns>
    /// <param name="script">The Script style to apply.</param>
    public Paragraph Script(Xceed.Document.NET.Script script)
    {
      if (script != Xceed.Document.NET.Script.none)
        this.ApplyTextFormattingProperty(XName.Get("vertAlign", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) script.ToString()));
      return this;
    }

    /// <summary>Applies a Highlight color to the last appended text.</summary>
    /// <returns>This Paragraph with the last appended text highlighted.</returns>
    /// <param name="highlight">The Highlight color to apply.</param>
    public Paragraph Highlight(Xceed.Document.NET.Highlight highlight)
    {
      this.ApplyTextFormattingProperty(XName.Get(nameof (highlight), Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) highlight.ToString()));
      return this;
    }

    /// <summary>Adds a shading to this text or paragraph.</summary>
    /// <returns>The Paragraph with the requested shading applied.</returns>
    /// <param name="shading">The <strong>Color</strong> to use for the shading.</param>
    /// <param name="shadingType">The type of shading. By default, <strong>Text</strong>.</param>
    public Paragraph Shading(System.Drawing.Color shading, ShadingType shadingType = ShadingType.Text)
    {
      if (shadingType == ShadingType.Text)
      {
        this.ApplyTextFormattingProperty(XName.Get("shd", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) new XAttribute(XName.Get("fill", Xceed.Document.NET.Document.w.NamespaceName), (object) shading.ToHex()));
      }
      else
      {
        XElement pPr = this.GetOrCreate_pPr();
        XElement xelement = pPr.Element(XName.Get("shd", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement == null)
        {
          xelement = new XElement(XName.Get("shd", Xceed.Document.NET.Document.w.NamespaceName));
          pPr.Add((object) xelement);
        }
        XAttribute xattribute = xelement.Attribute(XName.Get("fill", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute == null)
          xelement.SetAttributeValue(XName.Get("fill", Xceed.Document.NET.Document.w.NamespaceName), (object) shading.ToHex());
        else
          xattribute.SetValue((object) shading.ToHex());
      }
      return this;
    }

    /// <summary>Applies a Border to this Paragraph's text.</summary>
    /// <returns>The modified Paragraph.</returns>
    /// <param name="border">The Border to apply.</param>
    public Paragraph Border(Xceed.Document.NET.Border border)
    {
      string numericSize = Xceed.Document.NET.Border.GetNumericSize(border.Size);
      string str = border.Tcbs.ToString().Remove(0, 5);
      this.ApplyTextFormattingProperty(XName.Get("bdr", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) new List<XAttribute>()
      {
        new XAttribute(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName), (object) border.Color.ToHex()),
        new XAttribute(XName.Get("space", Xceed.Document.NET.Document.w.NamespaceName), (object) border.Space),
        new XAttribute(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName), (object) numericSize),
        new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) str)
      });
      return this;
    }

    /// <summary>Applies the provided Misc property to the last appended text.</summary>
    /// <returns>This Paragraph with the last appended text updated by a Misc property.</returns>
    /// <param name="misc">The Misc property to apply.</param>
    public Paragraph Misc(Xceed.Document.NET.Misc misc)
    {
      switch (misc)
      {
        case Xceed.Document.NET.Misc.none:
          return this;
        case Xceed.Document.NET.Misc.outlineShadow:
          this.ApplyTextFormattingProperty(XName.Get("outline", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) null);
          this.ApplyTextFormattingProperty(XName.Get("shadow", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) null);
          goto case Xceed.Document.NET.Misc.none;
        case Xceed.Document.NET.Misc.engrave:
          this.ApplyTextFormattingProperty(XName.Get("imprint", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) null);
          goto case Xceed.Document.NET.Misc.none;
        default:
          this.ApplyTextFormattingProperty(XName.Get(misc.ToString(), Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) null);
          goto case Xceed.Document.NET.Misc.none;
      }
    }

    /// <summary>Applies the provided StrikeThrough style to the last appended text.</summary>
    /// <returns>This Paragraph with the last appended text's strikethrough style changed.</returns>
    /// <param name="strikeThrough">The StrikeThrough style to apply.</param>
    public Paragraph StrikeThrough(Xceed.Document.NET.StrikeThrough strikeThrough)
    {
      string localName;
      switch (strikeThrough)
      {
        case Xceed.Document.NET.StrikeThrough.strike:
          localName = "strike";
          break;
        case Xceed.Document.NET.StrikeThrough.doubleStrike:
          localName = "dstrike";
          break;
        default:
          return this;
      }
      this.ApplyTextFormattingProperty(XName.Get(localName, Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) null);
      return this;
    }

    /// <summary>Applies the provided underline color to the last appended text.</summary>
    /// <returns>This Paragraph with the last appended text's underline color changed.</returns>
    /// <param name="underlineColor">The underline Color to apply. If no UnderlineStyle is set, a single line will be used.</param>
    public Paragraph UnderlineColor(System.Drawing.Color underlineColor)
    {
      foreach (XElement run in this._runs)
      {
        XElement xelement1 = run.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 == null)
        {
          run.AddFirst((object) new XElement(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)));
          xelement1 = run.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement2 = xelement1.Element(XName.Get("u", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.SetElementValue(XName.Get("u", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement2 = xelement1.Element(XName.Get("u", Xceed.Document.NET.Document.w.NamespaceName));
          xelement2.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) "single");
        }
        xelement2.SetAttributeValue(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName), (object) underlineColor.ToHex());
      }
      return this;
    }

    /// <summary>Hides the last appended text.</summary>
    /// <returns>This Paragraph with the last appended text hidden.</returns>
    public Paragraph Hide()
    {
      this.ApplyTextFormattingProperty(XName.Get("vanish", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) null);
      return this;
    }

    /// <summary>Applies the provided spacing value to this Paragraph (in points).</summary>
    /// <returns>The modified Paragraph.</returns>
    /// <param name="spacing">The spacing value to apply (in points).</param>
    public Paragraph Spacing(double spacing)
    {
      spacing *= 20.0;
      if (spacing - (double) (int) spacing != 0.0)
        throw new ArgumentException(nameof (Spacing), "Value must be either a whole or acurate to one decimal, examples: 32, 32.1, 32.2, 32.9");
      if (spacing <= -1585.0 || spacing >= 1585.0)
        throw new ArgumentException(nameof (Spacing), "Value must be in the range: -1584 - 1584");
      this.ApplyTextFormattingProperty(XName.Get(nameof (spacing), Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) spacing));
      return this;
    }

    /// <summary>Applies the provided spacing value before this Paragraph (in points).</summary>
    /// <returns>The modified Paragraph.</returns>
    /// <param name="spacingBefore">The spacing value to apply (in points).</param>
    public Paragraph SpacingBefore(double spacingBefore)
    {
      spacingBefore *= 20.0;
      XElement pPr = this.GetOrCreate_pPr();
      XElement xelement = pPr.Element(XName.Get("spacing", Xceed.Document.NET.Document.w.NamespaceName));
      if (spacingBefore > 0.0)
      {
        if (xelement == null)
        {
          xelement = new XElement(XName.Get("spacing", Xceed.Document.NET.Document.w.NamespaceName));
          pPr.Add((object) xelement);
        }
        XAttribute xattribute = xelement.Attribute(XName.Get("before", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute == null)
          xelement.SetAttributeValue(XName.Get("before", Xceed.Document.NET.Document.w.NamespaceName), (object) spacingBefore);
        else
          xattribute.SetValue((object) spacingBefore);
      }
      if (Math.Abs(spacingBefore) < 0.100000001490116 && xelement != null)
      {
        xelement.Attribute(XName.Get("before", Xceed.Document.NET.Document.w.NamespaceName)).Remove();
        if (!xelement.HasAttributes)
          xelement.Remove();
      }
      return this;
    }

    /// <summary>Applies the provided spacing value after this Paragraph (in points).</summary>
    /// <returns>The modified Paragraph.</returns>
    /// <param name="spacingAfter">The spacing value to apply (in points).</param>
    public Paragraph SpacingAfter(double spacingAfter)
    {
      spacingAfter *= 20.0;
      XElement pPr = this.GetOrCreate_pPr();
      XElement xelement = pPr.Element(XName.Get("spacing", Xceed.Document.NET.Document.w.NamespaceName));
      if (spacingAfter > 0.0)
      {
        if (xelement == null)
        {
          xelement = new XElement(XName.Get("spacing", Xceed.Document.NET.Document.w.NamespaceName));
          pPr.Add((object) xelement);
        }
        XAttribute xattribute = xelement.Attribute(XName.Get("after", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute == null)
          xelement.SetAttributeValue(XName.Get("after", Xceed.Document.NET.Document.w.NamespaceName), (object) spacingAfter);
        else
          xattribute.SetValue((object) spacingAfter);
      }
      if (Math.Abs(spacingAfter) < 0.100000001490116 && xelement != null)
      {
        xelement.Attribute(XName.Get("after", Xceed.Document.NET.Document.w.NamespaceName)).Remove();
        if (!xelement.HasAttributes)
          xelement.Remove();
      }
      return this;
    }

    /// <summary>Modifies the spacing between the lines of this paragraph (in points).</summary>
    /// <returns>The Paragraph with the new line spacing applied.</returns>
    /// <param name="lineSpacing">The spacing between the lines of the paragraph (in points).</param>
    public Paragraph SpacingLine(double lineSpacing)
    {
      lineSpacing *= 20.0;
      XElement pPr = this.GetOrCreate_pPr();
      XElement xelement = pPr.Element(XName.Get("spacing", Xceed.Document.NET.Document.w.NamespaceName));
      if (lineSpacing > 0.0)
      {
        if (xelement == null)
        {
          xelement = new XElement(XName.Get("spacing", Xceed.Document.NET.Document.w.NamespaceName));
          pPr.Add((object) xelement);
        }
        XAttribute xattribute = xelement.Attribute(XName.Get("line", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute == null)
          xelement.SetAttributeValue(XName.Get("line", Xceed.Document.NET.Document.w.NamespaceName), (object) lineSpacing);
        else
          xattribute.SetValue((object) lineSpacing);
      }
      if (Math.Abs(lineSpacing) < 0.100000001490116 && xelement != null)
      {
        xelement.Attribute(XName.Get("line", Xceed.Document.NET.Document.w.NamespaceName)).Remove();
        if (!xelement.HasAttributes)
          xelement.Remove();
      }
      return this;
    }

    /// <summary>Applies the provided kerning value to this Paragraph (in points).</summary>
    /// <returns>The modified Paragraph.</returns>
    /// <param name="kerning">The kerning value to apply (in points).</param>
    public Paragraph Kerning(float kerning)
    {
      this.ApplyTextFormattingProperty(XName.Get("kern", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) (float) ((double) kerning * 2.0)));
      return this;
    }

    /// <summary>Applies the provided position to this Paragraph (in points).</summary>
    /// <returns>The modified Paragraph.</returns>
    /// <param name="position">The position value to apply (in points).</param>
    public Paragraph Position(double position)
    {
      if (position <= -1585.0 || position >= 1585.0)
        throw new ArgumentOutOfRangeException(nameof (Position), "Value must be in the range -1585 - 1585");
      this.ApplyTextFormattingProperty(XName.Get(nameof (position), Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) (position * 2.0)));
      return this;
    }

    /// <summary>Applies the provided percentage scale to this Paragraph.</summary>
    /// <returns>The modified Paragraph.</returns>
    /// <param name="percentageScale">The percentage scale to apply.</param>
    public Paragraph PercentageScale(float percentageScale)
    {
      if ((double) percentageScale < 1.0 || (double) percentageScale > 600.0)
        throw new ArgumentException(nameof (PercentageScale), "Value must be in the range: 1 - 600");
      this.ApplyTextFormattingProperty(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName), string.Empty, (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) percentageScale));
      return this;
    }

    /// <summary>Appends a document property field at the end of this Paragraph.</summary>
    /// <returns>This Paragraph with the document property field appended.</returns>
    /// <param name="cp">The custom property to display.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="f">The formatting to use.</param>
    public Paragraph AppendDocProperty(CustomProperty cp, bool trackChanges = false, Formatting f = null)
    {
      this.InsertDocProperty(cp, trackChanges, f);
      return this;
    }

    /// <summary>Inserts a document property field at the end of this Paragraph.</summary>
    /// <returns>The DocProperty that was inserted.</returns>
    /// <param name="cp">The custom property to display.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="f">The formatting to use.</param>
    public DocProperty InsertDocProperty(
      CustomProperty cp,
      bool trackChanges = false,
      Formatting f = null)
    {
      XElement xelement1 = (XElement) null;
      if (f != null)
        xelement1 = f.Xml;
      XElement xelement2 = new XElement(XName.Get("fldSimple", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
      {
        (object) new XAttribute(XName.Get("instr", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Format("DOCPROPERTY {0} \\* MERGEFORMAT", (object) cp.Name)),
        (object) new XElement(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName), (object) new XElement(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
        {
          (object) xelement1,
          cp.Value
        }))
      });
      XElement xml = xelement2;
      if (trackChanges)
      {
        DateTime now = DateTime.Now;
        xelement2 = Paragraph.CreateEdit(EditType.ins, new DateTime(now.Year, now.Month, now.Day, now.Hour, now.Minute, 0, DateTimeKind.Utc), (object) xelement2);
      }
      this.Xml.Add((object) xelement2);
      return new DocProperty(this.Document, xml);
    }

    /// <summary>Removes characters from this Paragraph.</summary>
    /// <param name="index">The index at which to begin deleting characters.</param>
    /// <param name="count">The amount of characters to delete.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="removeEmptyParagraph">
    /// <strong>true</strong> if the paragraph should be removed if it is empty, otherwise <strong>false</strong>.</param>
    public void RemoveText(int index, int count, bool trackChanges = false, bool removeEmptyParagraph = true)
    {
      DateTime now = DateTime.Now;
      DateTime edit_time = new DateTime(now.Year, now.Month, now.Day, now.Hour, now.Minute, 0, DateTimeKind.Utc);
      int num1 = 0;
      do
      {
        Run runEffectedByEdit = this.GetFirstRunEffectedByEdit(index, EditType.del);
        XElement parent = runEffectedByEdit.Xml.Parent;
        switch (parent.Name.LocalName)
        {
          case "ins":
            XElement[] xelementArray1 = this.SplitEdit(parent, index, EditType.del);
            int num2 = Math.Min(count - num1, runEffectedByEdit.Xml.ElementsAfterSelf().Sum<XElement>((Func<XElement, int>) (e => Paragraph.GetElementTextLength(e))));
            XElement[] xelementArray2 = this.SplitEdit(parent, index + num2, EditType.del);
            XElement xelement = this.SplitEdit(xelementArray1[1], index + num2, EditType.del)[1];
            XElement run1 = Paragraph.CreateEdit(EditType.del, edit_time, (object) xelement.Elements());
            int num3 = num1 + Paragraph.GetElementTextLength(run1);
            if (!trackChanges)
              run1 = (XElement) null;
            parent.ReplaceWith((object) xelementArray1[0], (object) run1, (object) xelementArray2[0]);
            num1 = num3 + Paragraph.GetElementTextLength(run1);
            break;
          case "del":
            if (trackChanges)
            {
              num1 += Paragraph.GetElementTextLength(parent);
              break;
            }
            goto case "ins";
          default:
            if (Paragraph.GetElementTextLength(runEffectedByEdit.Xml) > 0)
            {
              XElement[] xelementArray3 = Run.SplitRun(runEffectedByEdit, index, EditType.del);
              int index1 = Math.Min(index + (count - num1), runEffectedByEdit.EndIndex);
              XElement[] xelementArray4 = Run.SplitRun(runEffectedByEdit, index1, EditType.del);
              XElement run2 = Paragraph.CreateEdit(EditType.del, edit_time, (object) new List<XElement>()
              {
                Run.SplitRun(new Run(this.Document, xelementArray3[1], runEffectedByEdit.StartIndex + Paragraph.GetElementTextLength(xelementArray3[0])), index1, EditType.del)[0]
              });
              num1 += Paragraph.GetElementTextLength(run2);
              if (!trackChanges)
                run2 = (XElement) null;
              runEffectedByEdit.Xml.ReplaceWith((object) xelementArray3[0], (object) run2, (object) xelementArray4[1]);
              break;
            }
            num1 = count;
            break;
        }
        bool flag = removeEmptyParagraph && Paragraph.GetElementTextLength(parent) == 0;
        if (parent.Parent != null && ((flag ? 1 : 0) & (!(parent.Parent.Name.LocalName == "tc") ? 0 : (parent.Parent.Elements(XName.Get("p", Xceed.Document.NET.Document.w.NamespaceName)).Count<XElement>() > 1 ? 1 : 0))) != 0 & parent.Descendants(XName.Get("drawing", Xceed.Document.NET.Document.w.NamespaceName)).Count<XElement>() == 0)
          parent.Remove();
      }
      while (num1 < count);
      this._runs = this.Xml.Elements(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName)).ToList<XElement>();
      HelperFunctions.RenumberIDs(this.Document);
    }

    /// <summary>Removes characters from the end of this Paragraph.</summary>
    /// <param name="index">The index at which to begin deleting characters.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public void RemoveText(int index, bool trackChanges = false) => this.RemoveText(index, this.Text.Length - index, trackChanges);

    /// <summary>Replaces all instances of a string with another string.</summary>
    /// <param name="searchValue">The value to be replaced.</param>
    /// <param name="newValue">The new value to replace with.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="options">The regular expression options to use.</param>
    /// <param name="newFormatting">The formatting to apply to the new text.</param>
    /// <param name="matchFormatting">The formatting that the text must match in order to be replaced.</param>
    /// <param name="fo">A MatchFormattingOptions value indicating
    /// how the formatting should be matched.</param>
    /// <param name="escapeRegEx">
    ///         <strong>true</strong> if if the searchValue needs to be escaped, otherwise <strong>false</strong>. If it represents a valid RegEx pattern, this should be
    /// false.</param>
    /// <param name="useRegExSubstitutions">
    ///         <strong>true</strong> if a RegEx-like replace should be performed (i.e. if the newValue contains RegEx substitutions), otherwise <strong>false</strong>. Does
    /// not perform named-group substitutions (only numbered groups).</param>
    /// <param name="removeEmptyParagraph">
    /// <strong>true</strong> if the paragraph should be removed if it's empty, otherwise <strong>false</strong>.</param>
    public void ReplaceText(
      string searchValue,
      string newValue,
      bool trackChanges = false,
      RegexOptions options = RegexOptions.None,
      Formatting newFormatting = null,
      Formatting matchFormatting = null,
      MatchFormattingOptions fo = MatchFormattingOptions.SubsetMatch,
      bool escapeRegEx = true,
      bool useRegExSubstitutions = false,
      bool removeEmptyParagraph = true)
    {
      foreach (Match match in Regex.Matches(this.Text, escapeRegEx ? Regex.Escape(searchValue) : searchValue, options).Cast<Match>().Reverse<Match>())
      {
        bool flag = true;
        if (matchFormatting != null)
        {
          int num = 0;
          do
          {
            Run runEffectedByEdit = this.GetFirstRunEffectedByEdit(match.Index + num);
            XElement elementToValidate = runEffectedByEdit.Xml.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)) ?? new Formatting().Xml;
            if (!HelperFunctions.ContainsEveryChildOf(matchFormatting.Xml, elementToValidate, fo))
            {
              flag = false;
              break;
            }
            num += runEffectedByEdit.Value.Length;
          }
          while (num < match.Length);
        }
        if (flag)
        {
          if (useRegExSubstitutions && !string.IsNullOrEmpty(newValue))
          {
            newValue = newValue.Replace("$&", match.Value);
            if (match.Groups.Count > 0)
            {
              int groupnum1 = 0;
              for (int groupnum2 = 0; groupnum2 < match.Groups.Count; ++groupnum2)
              {
                Group group = match.Groups[groupnum2];
                if (group != null && !(group.Value == ""))
                {
                  newValue = newValue.Replace("$" + groupnum2.ToString(), group.Value);
                  groupnum1 = groupnum2;
                }
              }
              newValue = newValue.Replace("$+", match.Groups[groupnum1].Value);
            }
            if (match.Index > 0)
              newValue = newValue.Replace("$`", this.Text.Substring(0, match.Index));
            if (match.Index + match.Length < this.Text.Length)
              newValue = newValue.Replace("$'", this.Text.Substring(match.Index + match.Length));
            newValue = newValue.Replace("$_", this.Text);
            newValue = newValue.Replace("$$", "$");
          }
          if (!string.IsNullOrEmpty(newValue))
            this.InsertText(match.Index + match.Length, newValue, trackChanges, newFormatting);
          if (match.Length > 0)
            this.RemoveText(match.Index, match.Length, trackChanges, removeEmptyParagraph);
        }
      }
    }

    /// <summary>Replaces all instances of a string with another string, using the provided Func to match a regex search group value to its corresponding replacement string.</summary>
    /// <param name="findPattern">The pattern to search for to determine which values to replace.</param>
    /// <param name="regexMatchHandler">A Func that accepts the matching regex search group value and passes it to this to return the replacement string.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="options">The regular expression options to use.</param>
    /// <param name="newFormatting">The formatting to apply to the new text.</param>
    /// <param name="matchFormatting">The formatting that the text must match in order to be replaced.</param>
    /// <param name="fo">A MatchFormattingOptions value indicating
    /// how the formatting should be matched.</param>
    /// <param name="removeEmptyParagraph">
    /// <strong>true</strong> if the paragraph should be removed if it's empty, otherwise <strong>false</strong>.</param>
    public void ReplaceText(
      string findPattern,
      Func<string, string> regexMatchHandler,
      bool trackChanges = false,
      RegexOptions options = RegexOptions.None,
      Formatting newFormatting = null,
      Formatting matchFormatting = null,
      MatchFormattingOptions fo = MatchFormattingOptions.SubsetMatch,
      bool removeEmptyParagraph = true)
    {
      foreach (Match match in Regex.Matches(this.Text, findPattern, options).Cast<Match>().Reverse<Match>())
      {
        bool flag = true;
        Run runEffectedByEdit;
        if (matchFormatting != null)
        {
          for (int index = 0; index < match.Length; index += runEffectedByEdit.Value.Length)
          {
            runEffectedByEdit = this.GetFirstRunEffectedByEdit(match.Index + index);
            XElement elementToValidate = runEffectedByEdit.Xml.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)) ?? new Formatting().Xml;
            if (!HelperFunctions.ContainsEveryChildOf(matchFormatting.Xml, elementToValidate, fo))
            {
              flag = false;
              break;
            }
          }
        }
        if (flag)
        {
          string str = regexMatchHandler(match.Groups[1].Value);
          this.InsertText(match.Index + match.Value.Length, str, trackChanges, newFormatting);
          this.RemoveText(match.Index, match.Value.Length, trackChanges, removeEmptyParagraph);
        }
      }
    }

    /// <summary>Replaces all instances of a string with a DocumentElement.</summary>
    /// <param name="searchValue">The value to be replaced.</param>
    /// <param name="objectToAdd">A DocumentElement representing the object to add,
    /// it can be a Picture, a Hyperlink or a Table.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="options">The regular expression options to use.</param>
    /// <param name="matchFormatting">The formatting that the text must match in order to be replaced.</param>
    /// <param name="fo">A MatchFormattingOptions value indicating
    /// how the formatting should be matched.</param>
    /// <param name="escapeRegEx">
    ///         <strong>true</strong> if if the searchValue needs to be escaped, otherwise <strong>false</strong>. If it represents a valid RegEx pattern, this should be
    /// false.</param>
    /// <param name="removeEmptyParagraph">
    /// <strong>true</strong> if the paragraph should be removed if it's empty, otherwise <strong>false</strong>.</param>
    public void ReplaceTextWithObject(
      string searchValue,
      DocumentElement objectToAdd,
      bool trackChanges = false,
      RegexOptions options = RegexOptions.None,
      Formatting matchFormatting = null,
      MatchFormattingOptions fo = MatchFormattingOptions.SubsetMatch,
      bool escapeRegEx = true,
      bool removeEmptyParagraph = true)
    {
      foreach (Match match in Regex.Matches(this.Text, escapeRegEx ? Regex.Escape(searchValue) : searchValue, options).Cast<Match>().Reverse<Match>())
      {
        bool flag = true;
        if (matchFormatting != null)
        {
          int num = 0;
          do
          {
            Run runEffectedByEdit = this.GetFirstRunEffectedByEdit(match.Index + num);
            XElement elementToValidate = runEffectedByEdit.Xml.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)) ?? new Formatting().Xml;
            if (!HelperFunctions.ContainsEveryChildOf(matchFormatting.Xml, elementToValidate, fo))
            {
              flag = false;
              break;
            }
            num += runEffectedByEdit.Value.Length;
          }
          while (num < match.Length);
        }
        if (flag)
        {
          switch (objectToAdd)
          {
            case null:
              if (match.Length > 0)
              {
                this.RemoveText(match.Index, match.Length, trackChanges, removeEmptyParagraph);
                continue;
              }
              continue;
            case Picture _:
              this.InsertPicture((Picture) objectToAdd, match.Index + match.Length);
              goto case null;
            case Hyperlink _:
              this.InsertHyperlink((Hyperlink) objectToAdd, match.Index + match.Length);
              goto case null;
            case Table _:
              this.InsertTableAfterSelf((Table) objectToAdd);
              goto case null;
            default:
              throw new ArgumentException("Unknown object received. Valid objects are Picture, Hyperlink or Table.");
          }
        }
      }
    }

    /// <summary>Retrieves all the indexes where the provided search value is found.</summary>
    /// <returns>A list of indexes that match the search conditions.</returns>
    /// <param name="str">The value to search for.</param>
    public List<int> FindAll(string str) => this.FindAll(str, RegexOptions.None);

    /// <summary>Retrieves all the indexes in this Container where the provided search value is found, using the provided RegexOptions.</summary>
    /// <returns>A list of indexes that match the search conditions.</returns>
    /// <param name="str">The value to search for.</param>
    /// <param name="options">A value representing the regular expression options to use.</param>
    public List<int> FindAll(string str, RegexOptions options) => Regex.Matches(this.Text, Regex.Escape(str), options).Cast<Match>().Select<Match, int>((Func<Match, int>) (m => m.Index)).ToList<int>();

    /// <summary>Finds all unique instances of the provided Regex pattern.</summary>
    /// <returns>A list of all the unique string values that were found.</returns>
    /// <param name="str">The pattern to search for.</param>
    /// <param name="options">The regular expression options to use.</param>
    public List<string> FindAllByPattern(string str, RegexOptions options) => Regex.Matches(this.Text, str, options).Cast<Match>().Select<Match, string>((Func<Match, string>) (m => m.Value)).ToList<string>();

    /// <summary>Inserts a PageNumber placeholder at a specific location in this Paragraph.</summary>
    /// <param name="pnf">The PageNumberFormat to use.</param>
    /// <param name="index">The index at which to insert the PageNumber placeholder.</param>
    public void InsertPageNumber(PageNumberFormat pnf, int index = 0)
    {
      XElement xelement = new XElement(XName.Get("fldSimple", Xceed.Document.NET.Document.w.NamespaceName));
      if (pnf == PageNumberFormat.normal)
        xelement.Add((object) new XAttribute(XName.Get("instr", Xceed.Document.NET.Document.w.NamespaceName), (object) " PAGE   \\* MERGEFORMAT "));
      else
        xelement.Add((object) new XAttribute(XName.Get("instr", Xceed.Document.NET.Document.w.NamespaceName), (object) " PAGE  \\* ROMAN  \\* MERGEFORMAT "));
      XElement contentBasedOnLastRPr = this.GetNumberContentBasedOnLast_rPr();
      xelement.Add((object) contentBasedOnLastRPr);
      if (index == 0)
      {
        this.Xml.AddFirst((object) xelement);
      }
      else
      {
        Run runEffectedByEdit = this.GetFirstRunEffectedByEdit(index);
        XElement[] xelementArray = this.SplitEdit(runEffectedByEdit.Xml, index, EditType.ins);
        runEffectedByEdit.Xml.ReplaceWith((object) xelementArray[0], (object) xelement, (object) xelementArray[1]);
      }
    }

    /// <summary>Appends a page number placeholder at the end of this Paragraph.</summary>
    /// <returns>This Paragraph with the page number placeholder appended.</returns>
    /// <param name="pnf">A PageNumberFormat value indicating the format to
    /// use for the page number.</param>
    public Paragraph AppendPageNumber(PageNumberFormat pnf)
    {
      XElement xelement = new XElement(XName.Get("fldSimple", Xceed.Document.NET.Document.w.NamespaceName));
      if (pnf == PageNumberFormat.normal)
        xelement.Add((object) new XAttribute(XName.Get("instr", Xceed.Document.NET.Document.w.NamespaceName), (object) " PAGE   \\* MERGEFORMAT "));
      else
        xelement.Add((object) new XAttribute(XName.Get("instr", Xceed.Document.NET.Document.w.NamespaceName), (object) " PAGE  \\* ROMAN  \\* MERGEFORMAT "));
      XElement contentBasedOnLastRPr = this.GetNumberContentBasedOnLast_rPr();
      xelement.Add((object) contentBasedOnLastRPr);
      this.Xml.Add((object) xelement);
      return this;
    }

    /// <summary>Inserts a PageCount placeholder at a specific location in this Paragraph.</summary>
    /// <param name="pnf">The PageNumberFormat to use.</param>
    /// <param name="index">The index at which to insert the PageCount placeholder.</param>
    public void InsertPageCount(PageNumberFormat pnf, int index = 0)
    {
      XElement xelement = new XElement(XName.Get("fldSimple", Xceed.Document.NET.Document.w.NamespaceName));
      if (pnf == PageNumberFormat.normal)
        xelement.Add((object) new XAttribute(XName.Get("instr", Xceed.Document.NET.Document.w.NamespaceName), (object) " NUMPAGES   \\* MERGEFORMAT "));
      else
        xelement.Add((object) new XAttribute(XName.Get("instr", Xceed.Document.NET.Document.w.NamespaceName), (object) " NUMPAGES  \\* ROMAN  \\* MERGEFORMAT "));
      XElement contentBasedOnLastRPr = this.GetNumberContentBasedOnLast_rPr();
      xelement.Add((object) contentBasedOnLastRPr);
      if (index == 0)
      {
        this.Xml.AddFirst((object) xelement);
      }
      else
      {
        Run runEffectedByEdit = this.GetFirstRunEffectedByEdit(index);
        XElement[] xelementArray = this.SplitEdit(runEffectedByEdit.Xml, index, EditType.ins);
        runEffectedByEdit.Xml.ReplaceWith((object) xelementArray[0], (object) xelement, (object) xelementArray[1]);
      }
    }

    /// <summary>Appends a page count placeholder at the end of this Paragraph.</summary>
    /// <returns>This Paragraph with the page count placeholder appended.</returns>
    /// <param name="pnf">A PageNumberFormat value indicating the format to use for the page count.</param>
    public Paragraph AppendPageCount(PageNumberFormat pnf)
    {
      XElement xelement = new XElement(XName.Get("fldSimple", Xceed.Document.NET.Document.w.NamespaceName));
      if (pnf == PageNumberFormat.normal)
        xelement.Add((object) new XAttribute(XName.Get("instr", Xceed.Document.NET.Document.w.NamespaceName), (object) " NUMPAGES   \\* MERGEFORMAT "));
      else
        xelement.Add((object) new XAttribute(XName.Get("instr", Xceed.Document.NET.Document.w.NamespaceName), (object) " NUMPAGES  \\* ROMAN  \\* MERGEFORMAT "));
      XElement contentBasedOnLastRPr = this.GetNumberContentBasedOnLast_rPr();
      xelement.Add((object) contentBasedOnLastRPr);
      this.Xml.Add((object) xelement);
      return this;
    }

    /// <summary>Sets the line spacing for this Paragraph (in points), manually.</summary>
    /// <param name="spacingType">The LineSpacingType to use.</param>
    /// <param name="spacingFloat">The spacing value to use (in points).</param>
    public void SetLineSpacing(LineSpacingType spacingType, float spacingFloat)
    {
      XElement pPr = this.GetOrCreate_pPr();
      XName name = XName.Get("spacing", Xceed.Document.NET.Document.w.NamespaceName);
      XElement xelement = pPr.Element(name);
      if (xelement == null)
      {
        pPr.Add((object) new XElement(name));
        xelement = pPr.Element(name);
      }
      string str;
      switch (spacingType)
      {
        case LineSpacingType.Before:
          str = "before";
          break;
        case LineSpacingType.After:
          str = "after";
          break;
        default:
          str = "line";
          break;
      }
      string localName = str;
      xelement.SetAttributeValue(XName.Get(localName, Xceed.Document.NET.Document.w.NamespaceName), (object) (int) ((double) spacingFloat * 20.0));
    }

    /// <summary>Sets the line spacing for this Paragraph (in points), automatically.</summary>
    /// <param name="spacingTypeAuto">The LineSpacingTypeAuto to use.</param>
    public void SetLineSpacing(LineSpacingTypeAuto spacingTypeAuto)
    {
      XElement pPr = this.GetOrCreate_pPr();
      XName name = XName.Get("spacing", Xceed.Document.NET.Document.w.NamespaceName);
      XElement xelement = pPr.Element(name);
      if (spacingTypeAuto == LineSpacingTypeAuto.None)
      {
        xelement?.Remove();
      }
      else
      {
        if (xelement == null)
        {
          pPr.Add((object) new XElement(name));
          xelement = pPr.Element(name);
        }
        int num = 500;
        string localName1 = spacingTypeAuto == LineSpacingTypeAuto.AutoAfter ? "after" : "before";
        string localName2 = spacingTypeAuto == LineSpacingTypeAuto.AutoAfter ? "afterAutospacing" : "beforeAutospacing";
        xelement.SetAttributeValue(XName.Get(localName1, Xceed.Document.NET.Document.w.NamespaceName), (object) num);
        xelement.SetAttributeValue(XName.Get(localName2, Xceed.Document.NET.Document.w.NamespaceName), (object) 1);
        if (spacingTypeAuto != LineSpacingTypeAuto.Auto)
          return;
        xelement.SetAttributeValue(XName.Get("after", Xceed.Document.NET.Document.w.NamespaceName), (object) num);
        xelement.SetAttributeValue(XName.Get("afterAutospacing", Xceed.Document.NET.Document.w.NamespaceName), (object) 1);
      }
    }

    /// <summary>Appends a Bookmark to this Paragraph.</summary>
    /// <returns>This Paragraph with the new Bookmark appended.</returns>
    /// <param name="bookmarkName">The name of the Bookmark to append.</param>
    public Paragraph AppendBookmark(string bookmarkName)
    {
      this.Xml.Add((object) new XElement(XName.Get("bookmarkStart", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
      {
        (object) new XAttribute(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName), (object) Paragraph.bookmarkIdCounter),
        (object) new XAttribute(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName), (object) bookmarkName)
      }));
      this.Xml.Add((object) new XElement(XName.Get("bookmarkEnd", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
      {
        (object) new XAttribute(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName), (object) Paragraph.bookmarkIdCounter),
        (object) new XAttribute(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName), (object) bookmarkName)
      }));
      ++Paragraph.bookmarkIdCounter;
      return this;
    }

    /// <summary>Removes all the Bookmarks from this Paragraph.</summary>
    public void ClearBookmarks()
    {
      IEnumerable<XElement> source1 = this.Xml.Descendants(XName.Get("bookmarkStart", Xceed.Document.NET.Document.w.NamespaceName));
      if (source1.Count<XElement>() > 0)
        source1.Remove<XElement>();
      IEnumerable<XElement> source2 = this.Xml.Descendants(XName.Get("bookmarkEnd", Xceed.Document.NET.Document.w.NamespaceName));
      if (source2.Count<XElement>() <= 0)
        return;
      source2.Remove<XElement>();
    }

    public bool ValidateBookmark(string bookmarkName) => this.GetBookmarks().Any<Bookmark>((Func<Bookmark, bool>) (b => b.Name.Equals(bookmarkName)));

    /// <summary>Retrieves the list of Bookmarks found in this Paragraph.</summary>
    /// <returns>The list of bookmarks found in the Paragraph.</returns>
    public IEnumerable<Bookmark> GetBookmarks() => this.Xml.Descendants(XName.Get("bookmarkStart", Xceed.Document.NET.Document.w.NamespaceName)).Select<XElement, XAttribute>((Func<XElement, XAttribute>) (x => x.Attribute(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName)))).Select<XAttribute, Bookmark>((Func<XAttribute, Bookmark>) (x => new Bookmark()
    {
      Name = x.Value,
      Paragraph = this
    }));

    /// <summary>Inserts the provided text at a bookmark location in this Paragraph, using the specified formatting.</summary>
    /// <param name="toInsert">The text to insert.</param>
    /// <param name="bookmarkName">The name of the Bookmark where the text will be inserted.</param>
    /// <param name="formatting">The Formatting to apply to the inserted text.</param>
    public void InsertAtBookmark(string toInsert, string bookmarkName, Formatting formatting = null)
    {
      XElement xelement = this.Xml.Descendants(XName.Get("bookmarkStart", Xceed.Document.NET.Document.w.NamespaceName)).Where<XElement>((Func<XElement, bool>) (x => x.Attribute(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName)).Value == bookmarkName)).SingleOrDefault<XElement>();
      if (xelement == null)
        return;
      List<XElement> xelementList = HelperFunctions.FormatInput(toInsert, formatting?.Xml);
      xelement.AddBeforeSelf((object) xelementList);
      this._runs = this.Xml.Elements(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName)).ToList<XElement>();
      HelperFunctions.RenumberIDs(this.Document);
    }

    /// <summary>Indicates if this Paragraph must stay on the same page as the next Paragraph.</summary>
    /// <returns>The modified Paragraph.</returns>
    /// <param name="keepWithNextParagraph">
    /// <strong>true</strong> if this Paragraph must stay on the same page as the next Paragraph, otherwise <strong>false</strong>.</param>
    public Paragraph KeepWithNextParagraph(bool keepWithNextParagraph = true)
    {
      XElement pPr = this.GetOrCreate_pPr();
      XElement xelement = pPr.Element(XName.Get("keepNext", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement == null & keepWithNextParagraph)
        pPr.Add((object) new XElement(XName.Get("keepNext", Xceed.Document.NET.Document.w.NamespaceName)));
      if (!keepWithNextParagraph && xelement != null)
        xelement.Remove();
      return this;
    }

    /// <summary>Indicates if this Paragraph's lines must stay together on the same page or if they can be split over more than one page.</summary>
    /// <returns>The modified Paragraph.</returns>
    /// <param name="keepLinesTogether">
    /// <strong>true</strong> if this Paragraph's lines must stay together on the same page, otherwise <strong>false</strong>.</param>
    public Paragraph KeepLinesTogether(bool keepLinesTogether = true)
    {
      XElement pPr = this.GetOrCreate_pPr();
      XElement xelement = pPr.Element(XName.Get("keepLines", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement == null & keepLinesTogether)
        pPr.Add((object) new XElement(XName.Get("keepLines", Xceed.Document.NET.Document.w.NamespaceName)));
      if (!keepLinesTogether && xelement != null)
        xelement.Remove();
      return this;
    }

    /// <summary>Replaces the text at the specified Bookmark in this Paragraph.</summary>
    /// <param name="text">The text to insert.</param>
    /// <param name="bookmarkName">The name of the Bookmark where the text is to be inserted.</param>
    /// <param name="formatting">
    ///   <span id="BugEvents">The format to apply to the bookmark text.</span>
    /// </param>
    public void ReplaceAtBookmark(string text, string bookmarkName, Formatting formatting = null)
    {
      List<XElement> xelementList = new List<XElement>();
      XElement bookmark1 = this.Xml.Descendants(XName.Get("bookmarkStart", Xceed.Document.NET.Document.w.NamespaceName)).Where<XElement>((Func<XElement, bool>) (x => x.Attribute(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName)).Value == bookmarkName)).FirstOrDefault<XElement>();
      if (bookmark1 == null)
        return;
      string str = bookmark1.Attribute(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName)).Value;
      XNode nextNode = bookmark1.NextNode;
      xelement = (XElement) null;
      for (; nextNode != null; nextNode = nextNode.NextNode)
      {
        if (nextNode is XElement xelement && xelement.Name.NamespaceName == Xceed.Document.NET.Document.w.NamespaceName)
        {
          if (xelement.Name.LocalName == "r")
            xelementList.Add(xelement);
          else if (xelement.Name.LocalName == "bookmarkEnd" && xelement.Attribute(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName))?.Value == str)
            break;
        }
      }
      if (xelement == null)
        return;
      if (xelementList.Count == 0)
      {
        this.ReplaceAtBookmark_Core(text, bookmark1, formatting);
      }
      else
      {
        bool flag = false;
        foreach (XElement xelement in xelementList)
        {
          XElement bookmark2 = xelement.Elements(XName.Get("t", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
          if (bookmark2 == null)
          {
            if (!flag)
            {
              this.ReplaceAtBookmark_Core(text, bookmark1, formatting);
              flag = true;
            }
          }
          else
          {
            if (!flag)
            {
              this.ReplaceAtBookmark_Core(text, bookmark2, formatting);
              if (formatting != null)
                xelement.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName))?.Remove();
              flag = true;
            }
            bookmark2.Remove();
          }
        }
      }
    }

    /// <summary>Removes the specified Bookmark from the this Paragraph.</summary>
    /// <param name="bookmarkName">The name of the Bookmark to remove.</param>
    public void RemoveBookmark(string bookmarkName)
    {
      XElement xelement1 = this.Xml.Descendants(XName.Get("bookmarkStart", Xceed.Document.NET.Document.w.NamespaceName)).Where<XElement>((Func<XElement, bool>) (x => x.Attribute(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName)).Value == bookmarkName)).FirstOrDefault<XElement>();
      if (xelement1 == null)
        return;
      string bookmarkStartId = xelement1.Attribute(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName)).Value;
      XElement xelement2 = this.Xml.Descendants(XName.Get("bookmarkEnd", Xceed.Document.NET.Document.w.NamespaceName)).Where<XElement>((Func<XElement, bool>) (x => x.Attribute(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName))?.Value == bookmarkStartId)).FirstOrDefault<XElement>();
      xelement1.Remove();
      xelement2.Remove();
    }

    [Obsolete("Instead use : InsertHorizontalLine( HorizontalBorderPosition position, BorderStyle borderStyle, int size, int space, Color? color )")]
    public void InsertHorizontalLine(
      HorizontalBorderPosition position = HorizontalBorderPosition.bottom,
      string lineType = "single",
      int size = 6,
      int space = 1,
      string color = "auto")
    {
      XName name1 = XName.Get("pBdr", Xceed.Document.NET.Document.w.NamespaceName);
      XName name2 = position == HorizontalBorderPosition.bottom ? XName.Get("bottom", Xceed.Document.NET.Document.w.NamespaceName) : XName.Get("top", Xceed.Document.NET.Document.w.NamespaceName);
      XElement pPr = this.GetOrCreate_pPr();
      if (pPr.Element(name1) != null)
        return;
      pPr.Add((object) new XElement(name1));
      XElement xelement1 = pPr.Element(name1);
      xelement1.Add((object) new XElement(name2));
      XElement xelement2 = xelement1.Element(name2);
      xelement2.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) lineType);
      xelement2.SetAttributeValue(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName), (object) size.ToString());
      xelement2.SetAttributeValue(XName.Get(nameof (space), Xceed.Document.NET.Document.w.NamespaceName), (object) space.ToString());
      xelement2.SetAttributeValue(XName.Get(nameof (color), Xceed.Document.NET.Document.w.NamespaceName), (object) color.Replace("#", ""));
    }

    /// <summary>
    ///         <span style="FONT-SIZE: 13px; FONT-FAMILY: &amp;quot;Segoe UI&amp;quot;, Verdana, Arial; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; FLOAT: none; FONT-WEIGHT: 400; COLOR: rgb(0,0,0); FONT-STYLE: normal; ORPHANS: 2; WIDOWS: 2; DISPLAY: inline !important; LETTER-SPACING: normal; TEXT-INDENT: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
    /// Inserts a horizontal line to this Paragraph.</span>
    ///       </summary>
    /// <param name="position">
    ///         <span style="FONT-SIZE: 13px; FONT-FAMILY: &amp;quot;Segoe UI&amp;quot;, Verdana, Arial; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; FLOAT: none; FONT-WEIGHT: 400; COLOR: rgb(0,0,0); FONT-STYLE: normal; ORPHANS: 2; WIDOWS: 2; DISPLAY: inline !important; LETTER-SPACING: normal; TEXT-INDENT: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
    /// The position of the horizontal line within the Paragraph. By default,</span>
    ///         <strong style="FONT-SIZE: 13px; FONT-FAMILY: &amp;quot;Segoe UI&amp;quot;, Verdana, Arial; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; COLOR: rgb(0,0,0); FONT-STYLE: normal; ORPHANS: 2; WIDOWS: 2; LETTER-SPACING: normal; TEXT-INDENT: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">Bottom</strong>
    ///         <span style="FONT-SIZE: 13px; FONT-FAMILY: &amp;quot;Segoe UI&amp;quot;, Verdana, Arial; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; FLOAT: none; FONT-WEIGHT: 400; COLOR: rgb(0,0,0); FONT-STYLE: normal; ORPHANS: 2; WIDOWS: 2; DISPLAY: inline !important; LETTER-SPACING: normal; TEXT-INDENT: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">.</span>
    ///       </param>
    /// <param name="lineType">
    ///         <span style="FONT-SIZE: 13px; FONT-FAMILY: &amp;quot;Segoe UI&amp;quot;, Verdana, Arial; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; FLOAT: none; FONT-WEIGHT: 400; COLOR: rgb(0,0,0); FONT-STYLE: normal; ORPHANS: 2; WIDOWS: 2; DISPLAY: inline !important; LETTER-SPACING: normal; TEXT-INDENT: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
    /// The type of line. By default,</span>
    ///         <strong style="FONT-SIZE: 13px; FONT-FAMILY: &amp;quot;Segoe UI&amp;quot;, Verdana, Arial; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; COLOR: rgb(0,0,0); FONT-STYLE: normal; ORPHANS: 2; WIDOWS: 2; LETTER-SPACING: normal; TEXT-INDENT: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">Tcbs_single</strong>
    ///         <span style="FONT-SIZE: 13px; FONT-FAMILY: &amp;quot;Segoe UI&amp;quot;, Verdana, Arial; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; FLOAT: none; FONT-WEIGHT: 400; COLOR: rgb(0,0,0); FONT-STYLE: normal; ORPHANS: 2; WIDOWS: 2; DISPLAY: inline !important; LETTER-SPACING: normal; TEXT-INDENT: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">.</span>
    ///       </param>
    /// <param name="size">
    ///         <span style="FONT-SIZE: 13px; FONT-FAMILY: &amp;quot;Segoe UI&amp;quot;, Verdana, Arial; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; FLOAT: none; FONT-WEIGHT: 400; COLOR: rgb(0,0,0); FONT-STYLE: normal; ORPHANS: 2; WIDOWS: 2; DISPLAY: inline !important; LETTER-SPACING: normal; TEXT-INDENT: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
    /// The size of the line. By default,</span>
    ///         <strong>6 points</strong>.</param>
    /// <param name="space">
    ///         <span style="FONT-SIZE: 13px; FONT-FAMILY: &amp;quot;Segoe UI&amp;quot;, Verdana, Arial; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; FLOAT: none; FONT-WEIGHT: 400; COLOR: rgb(0,0,0); FONT-STYLE: normal; ORPHANS: 2; WIDOWS: 2; DISPLAY: inline !important; LETTER-SPACING: normal; TEXT-INDENT: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
    /// The space of the line. By default,</span>
    ///         <strong>1 point</strong>.</param>
    /// <param name="color">
    ///         <span style="FONT-SIZE: 13px; FONT-FAMILY: &amp;quot;Segoe UI&amp;quot;, Verdana, Arial; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; FLOAT: none; FONT-WEIGHT: 400; COLOR: rgb(0,0,0); FONT-STYLE: normal; ORPHANS: 2; WIDOWS: 2; DISPLAY: inline !important; LETTER-SPACING: normal; TEXT-INDENT: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
    /// The color of the line. By default,</span>
    ///         <strong style="FONT-SIZE: 13px; FONT-FAMILY: &amp;quot;Segoe UI&amp;quot;, Verdana, Arial; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; COLOR: rgb(0,0,0); FONT-STYLE: normal; ORPHANS: 2; WIDOWS: 2; LETTER-SPACING: normal; TEXT-INDENT: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">"auto"</strong>
    ///         <span style="FONT-SIZE: 13px; FONT-FAMILY: &amp;quot;Segoe UI&amp;quot;, Verdana, Arial; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; FLOAT: none; FONT-WEIGHT: 400; COLOR: rgb(0,0,0); FONT-STYLE: normal; ORPHANS: 2; WIDOWS: 2; DISPLAY: inline !important; LETTER-SPACING: normal; TEXT-INDENT: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">.</span>
    ///       </param>
    public void InsertHorizontalLine(
      HorizontalBorderPosition position = HorizontalBorderPosition.bottom,
      BorderStyle lineType = BorderStyle.Tcbs_single,
      int size = 6,
      int space = 1,
      System.Drawing.Color? color = null)
    {
      XName name1 = XName.Get("pBdr", Xceed.Document.NET.Document.w.NamespaceName);
      XName name2 = position == HorizontalBorderPosition.bottom ? XName.Get("bottom", Xceed.Document.NET.Document.w.NamespaceName) : XName.Get("top", Xceed.Document.NET.Document.w.NamespaceName);
      XElement pPr = this.GetOrCreate_pPr();
      if (pPr.Element(name1) != null)
        return;
      pPr.Add((object) new XElement(name1));
      XElement xelement1 = pPr.Element(name1);
      xelement1.Add((object) new XElement(name2));
      XElement xelement2 = xelement1.Element(name2);
      xelement2.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) lineType.ToString().Substring(5));
      xelement2.SetAttributeValue(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName), (object) size);
      xelement2.SetAttributeValue(XName.Get(nameof (space), Xceed.Document.NET.Document.w.NamespaceName), (object) space);
      xelement2.SetAttributeValue(XName.Get(nameof (color), Xceed.Document.NET.Document.w.NamespaceName), color.HasValue ? (object) color.Value.ToHex() : (object) "auto");
    }

    internal static void ResetDefaultValues()
    {
      Paragraph.DefaultLineSpacing = 12f;
      Paragraph.DefaultLineSpacingAfter = 0.0f;
      Paragraph.DefaultLineSpacingBefore = 0.0f;
      Paragraph.DefaultIndentationFirstLine = 0.0f;
      Paragraph.DefaultIndentationHanging = 0.0f;
      Paragraph.DefaultIndentationBefore = 0.0f;
      Paragraph.DefaultIndentationAfter = 0.0f;
    }

    internal static void SetDefaultValues(XElement pPr)
    {
      if (pPr == null)
        return;
      XElement xelement1 = pPr.Element(XName.Get("spacing", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 != null)
      {
        XAttribute xattribute1 = xelement1.Attribute(XName.Get("line", Xceed.Document.NET.Document.w.NamespaceName));
        float result1;
        if (xattribute1 != null && HelperFunctions.TryParseFloat(xattribute1.Value, out result1))
          Paragraph.DefaultLineSpacing = result1 / 20f;
        XAttribute xattribute2 = xelement1.Attribute(XName.Get("after", Xceed.Document.NET.Document.w.NamespaceName));
        float result2;
        if (xattribute2 != null && HelperFunctions.TryParseFloat(xattribute2.Value, out result2))
          Paragraph.DefaultLineSpacingAfter = result2 / 20f;
        XAttribute xattribute3 = xelement1.Attribute(XName.Get("before", Xceed.Document.NET.Document.w.NamespaceName));
        float result3;
        if (xattribute3 != null && HelperFunctions.TryParseFloat(xattribute3.Value, out result3))
          Paragraph.DefaultLineSpacingBefore = result3 / 20f;
        XAttribute xattribute4 = xelement1.Attribute(XName.Get("lineRule", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute4 != null)
          Paragraph.DefaultLineRuleAuto = xattribute4.Value == "auto";
      }
      XElement xelement2 = pPr.Element(XName.Get("ind", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 == null)
        return;
      XAttribute xattribute5 = xelement2.Attribute(XName.Get("firstLine", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute5 != null)
        Paragraph.DefaultIndentationFirstLine = float.Parse(xattribute5.Value) / 20f;
      XAttribute xattribute6 = xelement2.Attribute(XName.Get("hanging", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute6 != null)
        Paragraph.DefaultIndentationHanging = float.Parse(xattribute6.Value) / 20f;
      XAttribute xattribute7 = xelement2.Attribute(XName.Get("left", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute7 != null)
        Paragraph.DefaultIndentationBefore = float.Parse(xattribute7.Value) / 20f;
      XAttribute xattribute8 = xelement2.Attribute(XName.Get("right", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute8 == null)
        return;
      Paragraph.DefaultIndentationAfter = float.Parse(xattribute8.Value) / 20f;
    }

    internal XElement GetOrCreate_pPr()
    {
      XElement xelement = this.Xml.Element(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement == null)
      {
        this.Xml.AddFirst((object) new XElement(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName)));
        xelement = this.Xml.Element(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName));
      }
      return xelement;
    }

    internal XElement GetOrCreate_rPr()
    {
      XElement xelement = this.Xml.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement == null)
      {
        this.Xml.AddFirst((object) new XElement(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)));
        xelement = this.Xml.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
      }
      return xelement;
    }

    internal XElement GetOrCreate_pPr_ind()
    {
      XElement pPr = this.GetOrCreate_pPr();
      XElement xelement = pPr.Element(XName.Get("ind", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement == null)
      {
        pPr.Add((object) new XElement(XName.Get("ind", Xceed.Document.NET.Document.w.NamespaceName)));
        xelement = pPr.Element(XName.Get("ind", Xceed.Document.NET.Document.w.NamespaceName));
      }
      return xelement;
    }

    internal void RemoveHyperlinkRecursive(XElement xml, int index, ref int count, ref bool found)
    {
      if (xml.Name.LocalName.Equals("hyperlink", StringComparison.CurrentCultureIgnoreCase))
      {
        if (count == index)
        {
          found = true;
          xml.Remove();
        }
        else
          ++count;
      }
      if (!xml.HasElements)
        return;
      foreach (XElement element in xml.Elements())
      {
        if (!found)
          this.RemoveHyperlinkRecursive(element, index, ref count, ref found);
      }
    }

    internal void ResetBackers()
    {
      this.ParagraphNumberPropertiesBacker = (XElement) null;
      this.IsListItemBacker = new bool?();
      this.IndentLevelBacker = new int?();
    }

    internal static Picture CreatePicture(
      Xceed.Document.NET.Document document,
      string id,
      string name,
      string descr,
      float width,
      float height)
    {
      PackagePart part = document._package.GetPart(document.PackagePart.GetRelationship(id).get_TargetUri());
      long nextFreeDocPrId = document.GetNextFreeDocPrId();
      long int64_1;
      long int64_2;
      using (PackagePartStream packagePartStream = new PackagePartStream(part.GetStream()))
      {
        using (Image image = Image.FromStream((Stream) packagePartStream, false, false))
        {
          int64_1 = Convert.ToInt64((float) ((double) image.get_Width() * (72.0 / (double) image.get_HorizontalResolution()) * 12700.0));
          int64_2 = Convert.ToInt64((float) ((double) image.get_Height() * (72.0 / (double) image.get_VerticalResolution()) * 12700.0));
        }
      }
      XElement i = XElement.Parse(string.Format("\r\n        <w:r xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">\r\n            <w:drawing xmlns = \"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">\r\n                <wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\" simplePos=\"0\" relativeHeight=\"0\" behindDoc=\"0\" locked=\"0\" layoutInCell=\"1\" allowOverlap=\"1\" xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\">\r\n                    <wp:simplePos x=\"0\" y=\"0\" />\r\n                    <wp:positionH relativeFrom=\"margin\" >\r\n                      <wp:align>left</wp:align>\r\n                    </wp:positionH>\r\n                    <wp:positionV relativeFrom=\"margin\" >\r\n                      <wp:align>top</wp:align>\r\n                    </wp:positionV>\r\n                    <wp:extent cx=\"{0}\" cy=\"{1}\" />\r\n                    <wp:effectExtent l=\"0\" t=\"0\" r=\"0\" b=\"0\" />\r\n                    <wp:wrapNone />\r\n                    <wp:docPr id=\"{5}\" name=\"{3}\" descr=\"{4}\" />\r\n                    <wp:cNvGraphicFramePr>\r\n                        <a:graphicFrameLocks xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" noChangeAspect=\"1\" />\r\n                    </wp:cNvGraphicFramePr>\r\n                    <a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">\r\n                        <a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">\r\n                            <pic:pic xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">\r\n                                <pic:nvPicPr>\r\n                                  <pic:cNvPr id=\"0\" name=\"{3}\" />\r\n                                <pic:cNvPicPr />\r\n                                </pic:nvPicPr>\r\n                                <pic:blipFill>\r\n                                    <a:blip r:embed=\"{2}\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"/>\r\n                                    <a:stretch>\r\n                                        <a:fillRect />\r\n                                    </a:stretch>\r\n                                </pic:blipFill>\r\n                                <pic:spPr>\r\n                                    <a:xfrm>\r\n                                        <a:off x=\"0\" y=\"0\" />\r\n                                        <a:ext cx=\"{0}\" cy=\"{1}\" />\r\n                                    </a:xfrm>\r\n                                    <a:prstGeom prst=\"rect\">\r\n                                        <a:avLst />\r\n                                    </a:prstGeom>\r\n                                </pic:spPr>\r\n                            </pic:pic>\r\n                        </a:graphicData>\r\n                    </a:graphic>\r\n                </wp:inline>\r\n            </w:drawing>\r\n        </w:r>\r\n        ", (object) int64_1, (object) int64_2, (object) id, (object) name, (object) descr, (object) nextFreeDocPrId.ToString()));
      Picture picture = new Picture(document, i, new Image(document, document.PackagePart.GetRelationship(id)));
      if ((double) width > -1.0)
        picture.Width = width;
      if ((double) height > -1.0)
        picture.Height = height;
      return picture;
    }

    internal static XElement CreateEdit(EditType t, DateTime edit_time, object content)
    {
      if (t == EditType.del)
      {
        foreach (object obj in (IEnumerable<XElement>) content)
        {
          if (obj is XElement)
          {
            IEnumerable<XElement> source = (obj as XElement).DescendantsAndSelf(XName.Get(nameof (t), Xceed.Document.NET.Document.w.NamespaceName));
            for (int index = 0; index < source.Count<XElement>(); ++index)
            {
              XElement xelement = source.ElementAt<XElement>(index);
              xelement.ReplaceWith((object) new XElement(Xceed.Document.NET.Document.w + "delText", new object[2]
              {
                (object) xelement.Attributes(),
                (object) xelement.Value
              }));
            }
          }
        }
      }
      string str = "";
      try
      {
        str = Environment.UserDomainName + "\\" + Environment.UserName;
      }
      catch (Exception ex)
      {
      }
      return str.Trim() == "" ? new XElement(Xceed.Document.NET.Document.w + t.ToString(), new object[3]
      {
        (object) new XAttribute(Xceed.Document.NET.Document.w + "id", (object) 0),
        (object) new XAttribute(Xceed.Document.NET.Document.w + "date", (object) edit_time),
        content
      }) : new XElement(Xceed.Document.NET.Document.w + t.ToString(), new object[4]
      {
        (object) new XAttribute(Xceed.Document.NET.Document.w + "id", (object) 0),
        (object) new XAttribute(Xceed.Document.NET.Document.w + "author", (object) str),
        (object) new XAttribute(Xceed.Document.NET.Document.w + "date", (object) edit_time),
        content
      });
    }

    internal Run GetFirstRunEffectedByEdit(int index, EditType type = EditType.ins)
    {
      int length = HelperFunctions.GetText(this.Xml).Length;
      if (index < 0 || type == EditType.ins && index > length || type == EditType.del && index >= length)
        throw new ArgumentOutOfRangeException();
      int count = 0;
      Run theOne = (Run) null;
      this.GetFirstRunEffectedByEditRecursive(this.Xml, index, ref count, ref theOne, type);
      return theOne;
    }

    internal void GetFirstRunEffectedByEditRecursive(
      XElement Xml,
      int index,
      ref int count,
      ref Run theOne,
      EditType type)
    {
      count += HelperFunctions.GetSize(Xml);
      if (count > 0 && (type == EditType.del && count > index || type == EditType.ins && count >= index))
      {
        foreach (XElement Xml1 in Xml.ElementsBeforeSelf())
          count -= HelperFunctions.GetSize(Xml1);
        count -= HelperFunctions.GetSize(Xml);
        count = Math.Max(0, count);
        while (Xml.Name.LocalName != "r")
        {
          Xml = Xml.Parent;
          if (Xml == null)
            return;
        }
        theOne = new Run(this.Document, Xml, count);
      }
      else
      {
        if (!Xml.HasElements)
          return;
        foreach (XElement element in Xml.Elements())
        {
          if (theOne == null)
            this.GetFirstRunEffectedByEditRecursive(element, index, ref count, ref theOne, type);
        }
      }
    }

    internal static int GetElementTextLength(XElement run)
    {
      int num = 0;
      if (run == null)
        return num;
      foreach (XElement descendant in run.Descendants())
      {
        switch (descendant.Name.LocalName)
        {
          case "tab":
            if (descendant.Parent.Name.LocalName != "tabs")
            {
              ++num;
              continue;
            }
            continue;
          case "br":
            if (HelperFunctions.IsLineBreak(descendant))
            {
              ++num;
              continue;
            }
            continue;
          case "t":
          case "delText":
            num += descendant.Value.Length;
            continue;
          default:
            continue;
        }
      }
      return num;
    }

    internal XElement[] SplitEdit(XElement edit, int index, EditType type)
    {
      Run runEffectedByEdit = this.GetFirstRunEffectedByEdit(index, type);
      XElement[] xelementArray = Run.SplitRun(runEffectedByEdit, index, type);
      XElement run1 = new XElement(edit.Name, new object[3]
      {
        (object) edit.Attributes(),
        (object) runEffectedByEdit.Xml.ElementsBeforeSelf(),
        (object) xelementArray[0]
      });
      if (Paragraph.GetElementTextLength(run1) == 0)
        run1 = (XElement) null;
      XElement run2 = new XElement(edit.Name, new object[3]
      {
        (object) edit.Attributes(),
        (object) xelementArray[1],
        (object) runEffectedByEdit.Xml.ElementsAfterSelf()
      });
      if (Paragraph.GetElementTextLength(run2) == 0)
        run2 = (XElement) null;
      return new XElement[2]{ run1, run2 };
    }

    internal string GetOrGenerateRel(Picture p)
    {
      string originalString = p._img._pr.get_TargetUri().OriginalString;
      string str = (string) null;
      using (IEnumerator<PackageRelationship> enumerator = this.PackagePart.GetRelationshipsByType("http://schemas.openxmlformats.org/officeDocument/2006/relationships/image").GetEnumerator())
      {
        while (((IEnumerator) enumerator).MoveNext())
        {
          PackageRelationship current = enumerator.Current;
          if (string.Equals(current.get_TargetUri().OriginalString, originalString, StringComparison.Ordinal))
          {
            str = current.get_Id();
            break;
          }
        }
      }
      if (str == null)
        str = this.PackagePart.CreateRelationship(p._img._pr.get_TargetUri(), (TargetMode) 0, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image").get_Id();
      return str;
    }

    internal static string GetOrGenerateRel(Hyperlink h, PackagePart packagePart)
    {
      string image_uri_string = h.Uri != (Uri) null ? h.Uri.OriginalString : (string) null;
      string str = ((IEnumerable<PackageRelationship>) packagePart.GetRelationshipsByType("http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink")).Where<PackageRelationship>((Func<PackageRelationship, bool>) (r => r.get_TargetUri().OriginalString == image_uri_string)).Select<PackageRelationship, string>((Func<PackageRelationship, string>) (r => r.get_Id())).SingleOrDefault<string>();
      if (str == null && h.Uri != (Uri) null)
        str = packagePart.CreateRelationship(h.Uri, (TargetMode) 1, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink").get_Id();
      return str;
    }

    internal void ApplyTextFormattingProperty(
      XName textFormatPropName,
      string value,
      object content)
    {
      if (this._runs.Count == 0)
      {
        XElement xelement1 = this.Xml.Element(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 == null)
        {
          this.Xml.AddFirst((object) new XElement(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName)));
          xelement1 = this.Xml.Element(XName.Get("pPr", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XElement xelement2 = xelement1.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.AddFirst((object) new XElement(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)));
          xelement2 = xelement1.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
        }
        xelement2.SetElementValue(textFormatPropName, (object) value);
        XElement xelement3 = xelement2.Elements(textFormatPropName).Last<XElement>();
        if (!(content is XAttribute))
          return;
        if (xelement3.Attribute(((XAttribute) content).Name) == null)
          xelement3.Add(content);
        else
          xelement3.Attribute(((XAttribute) content).Name).Value = ((XAttribute) content).Value;
      }
      else
      {
        bool flag = false;
        if (content is IEnumerable enumerable)
        {
          foreach (object obj in enumerable)
            flag = obj is XAttribute;
        }
        foreach (XElement run in this._runs)
        {
          XElement xelement1 = run.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
          if (xelement1 == null)
          {
            run.AddFirst((object) new XElement(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)));
            xelement1 = run.Element(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName));
          }
          xelement1.SetElementValue(textFormatPropName, (object) value);
          XElement xelement2 = xelement1.Elements(textFormatPropName).Last<XElement>();
          if (flag)
          {
            foreach (object content1 in enumerable)
            {
              if (xelement2.Attribute(((XAttribute) content1).Name) == null)
                xelement2.Add(content1);
              else
                xelement2.Attribute(((XAttribute) content1).Name).Value = ((XAttribute) content1).Value;
            }
          }
          if (content is XAttribute)
          {
            if (xelement2.Attribute(((XAttribute) content).Name) == null)
              xelement2.Add(content);
            else
              xelement2.Attribute(((XAttribute) content).Name).Value = ((XAttribute) content).Value;
          }
        }
      }
    }

    internal bool IsLineSpacingRuleAuto()
    {
      XElement xelement = this.GetOrCreate_pPr().Element(XName.Get("spacing", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement != null)
      {
        XAttribute xattribute = xelement.Attribute(XName.Get("lineRule", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null)
          return xattribute.Value == "auto";
      }
      return Paragraph.DefaultLineRuleAuto;
    }

    internal void ClearMagicTextCache() => this._magicText = (List<FormattedText>) null;

    internal bool CanAddAttribute(XAttribute att) => !(att.Name.LocalName == "hanging") || (double) this.IndentationFirstLine == (double) Paragraph.DefaultIndentationFirstLine;

    internal int GetNumId()
    {
      XElement xelement = this.Xml.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (s => s.Name.LocalName == "numId"));
      return xelement == null ? -1 : int.Parse(xelement.Attribute(Xceed.Document.NET.Document.w + "val").Value);
    }

    internal int GetListItemLevel()
    {
      if (this.ParagraphNumberProperties != null)
      {
        XElement xelement = this.ParagraphNumberProperties.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (el => el.Name.LocalName == "ilvl"));
        if (xelement != null)
          return int.Parse(xelement.Attribute(Xceed.Document.NET.Document.w + "val").Value);
      }
      return -1;
    }

    internal void SetAsBookmark(string bookmarkName)
    {
      this.Xml.AddFirst((object) new XElement(XName.Get("bookmarkStart", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
      {
        (object) new XAttribute(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName), (object) Paragraph.bookmarkIdCounter),
        (object) new XAttribute(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName), (object) bookmarkName)
      }));
      this.Xml.Add((object) new XElement(XName.Get("bookmarkEnd", Xceed.Document.NET.Document.w.NamespaceName), new object[2]
      {
        (object) new XAttribute(XName.Get("id", Xceed.Document.NET.Document.w.NamespaceName), (object) Paragraph.bookmarkIdCounter),
        (object) new XAttribute(XName.Get("name", Xceed.Document.NET.Document.w.NamespaceName), (object) bookmarkName)
      }));
      ++Paragraph.bookmarkIdCounter;
    }

    internal bool IsInTOC()
    {
      XElement parent1 = this.Xml.Parent;
      if (parent1 != null && parent1.Name == XName.Get("sdtContent", Xceed.Document.NET.Document.w.NamespaceName))
      {
        XElement parent2 = parent1.Parent;
        if (parent2 != null && parent2.Name == XName.Get("sdt", Xceed.Document.NET.Document.w.NamespaceName))
          return parent2.Descendants(XName.Get("docPartGallery", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>((Func<XElement, bool>) (x => x.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)).Value == "Table of Contents")) != null;
      }
      return false;
    }

    internal List<XElement> GetSdtContentRuns()
    {
      List<XElement> xelementList = (List<XElement>) null;
      IEnumerable<XElement> xelements1 = this.Xml.Descendants(XName.Get("sdtContent", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelements1 != null)
      {
        foreach (XContainer xcontainer in xelements1)
        {
          IEnumerable<XElement> xelements2 = xcontainer.Elements(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName));
          if (xelements2 != null && xelements2.Count<XElement>() > 0)
          {
            if (xelementList == null)
              xelementList = xelements2.ToList<XElement>();
            else
              xelementList.AddRange(xelements2);
          }
        }
      }
      return xelementList;
    }

    internal bool IsInSdt() => this.GetParentSdt() != null;

    internal XElement GetParentSdt() => this.Xml.Ancestors(XName.Get("sdt", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();

    private void ApplyFormattingFrom(ref Formatting newFormatting, Formatting sourceFormatting)
    {
      newFormatting.FontFamily = sourceFormatting.FontFamily;
      newFormatting.Language = sourceFormatting.Language;
      if (sourceFormatting.Bold.HasValue)
        newFormatting.Bold = sourceFormatting.Bold;
      if (sourceFormatting.CapsStyle.HasValue)
        newFormatting.CapsStyle = sourceFormatting.CapsStyle;
      if (sourceFormatting.FontColor.HasValue)
        newFormatting.FontColor = sourceFormatting.FontColor;
      if (sourceFormatting.Hidden.HasValue)
        newFormatting.Hidden = sourceFormatting.Hidden;
      if (sourceFormatting.Highlight.HasValue)
        newFormatting.Highlight = sourceFormatting.Highlight;
      if (sourceFormatting.Italic.HasValue)
        newFormatting.Italic = sourceFormatting.Italic;
      if (sourceFormatting.Kerning.HasValue)
        newFormatting.Kerning = sourceFormatting.Kerning;
      if (sourceFormatting.Misc.HasValue)
        newFormatting.Misc = sourceFormatting.Misc;
      if (sourceFormatting.PercentageScale.HasValue)
        newFormatting.PercentageScale = sourceFormatting.PercentageScale;
      if (sourceFormatting.Position.HasValue)
        newFormatting.Position = sourceFormatting.Position;
      if (sourceFormatting.Script.HasValue)
        newFormatting.Script = sourceFormatting.Script;
      if (sourceFormatting.Size.HasValue)
        newFormatting.Size = sourceFormatting.Size;
      if (sourceFormatting.Spacing.HasValue)
        newFormatting.Spacing = sourceFormatting.Spacing;
      if (sourceFormatting.StrikeThrough.HasValue)
        newFormatting.StrikeThrough = sourceFormatting.StrikeThrough;
      if (sourceFormatting.UnderlineColor.HasValue)
        newFormatting.UnderlineColor = sourceFormatting.UnderlineColor;
      if (!sourceFormatting.UnderlineStyle.HasValue)
        return;
      newFormatting.UnderlineStyle = sourceFormatting.UnderlineStyle;
    }

    private void RebuildDocProperties() => this.docProperties = this.Xml.Descendants(XName.Get("fldSimple", Xceed.Document.NET.Document.w.NamespaceName)).Select<XElement, DocProperty>((Func<XElement, DocProperty>) (xml => new DocProperty(this.Document, xml))).ToList<DocProperty>();

    private XElement GetParagraphNumberProperties()
    {
      XElement xelement = this.Xml.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (el => el.Name.LocalName == "numPr"));
      if (xelement != null)
      {
        if (this.GetNumId() == 0)
          return (XElement) null;
      }
      else
        xelement = this.GetParagraphNumberPropertiesFromStyle(HelperFunctions.GetParagraphStyleFromStyleId(this.Document, this.StyleId));
      return xelement;
    }

    private XElement GetParagraphNumberPropertiesFromStyle(XElement style)
    {
      if (style == null)
        return (XElement) null;
      XElement xelement1 = style.Descendants().FirstOrDefault<XElement>((Func<XElement, bool>) (el => el.Name.LocalName == "numPr"));
      if (xelement1 != null)
        return xelement1;
      XElement xelement2 = style.Element(XName.Get("basedOn", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 != null)
      {
        XAttribute xattribute = xelement2.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null)
          return this.GetParagraphNumberPropertiesFromStyle(HelperFunctions.GetParagraphStyleFromStyleId(this.Document, xattribute.Value));
      }
      return (XElement) null;
    }

    private List<Picture> GetPictures(
      string localName,
      string localNameEquals,
      string attributeName)
    {
      return this.Xml.Descendants().Where<XElement>((Func<XElement, bool>) (p => p.Name.LocalName == localName)).Select(p => new
      {
        p = p,
        id = p.Descendants().Where<XElement>((Func<XElement, bool>) (e => e.Name.LocalName.Equals(localNameEquals))).Select<XElement, string>((Func<XElement, string>) (e => e.Attribute(XName.Get(attributeName, "http://schemas.openxmlformats.org/officeDocument/2006/relationships")).Value)).SingleOrDefault<string>()
      }).Where(_param1 => _param1.id != null).Select(_param1 => new
      {
        \u003C\u003Eh__TransparentIdentifier0 = _param1,
        img = new Image(this.Document, this.PackagePart.GetRelationship(_param1.id))
      }).Select(_param1 =>
      {
        return new Picture(this.Document, _param1.\u003C\u003Eh__TransparentIdentifier0.p, _param1.img)
        {
          PackagePart = this.PackagePart
        };
      }).ToList<Picture>();
    }

    private List<Shape> GetShapes(bool onlyTextBoxes = false)
    {
      List<Shape> shapeList1 = new List<Shape>();
      IEnumerable<XElement> xelements = this.Xml.Descendants(XName.Get("drawing", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelements != null)
      {
        using (IEnumerator<XElement> enumerator = xelements.GetEnumerator())
        {
label_15:
          while (enumerator.MoveNext())
          {
            XElement current = enumerator.Current;
            IEnumerable<XElement> source = current.Descendants(XName.Get("wsp", Xceed.Document.NET.Document.wps.NamespaceName));
            if (source != null && source.Count<XElement>() > 0)
            {
              if (onlyTextBoxes)
              {
                foreach (XContainer xcontainer in source)
                {
                  XElement el = xcontainer.Element(XName.Get("cNvSpPr", Xceed.Document.NET.Document.wps.NamespaceName));
                  if (el != null)
                  {
                    switch (el.GetAttribute(XName.Get("txBox")))
                    {
                      case "1":
                        List<Shape> shapeList2 = shapeList1;
                        Shape shape = new Shape(this.Document, current);
                        shape.PackagePart = this.PackagePart;
                        shapeList2.Add(shape);
                        goto label_15;
                      default:
                        continue;
                    }
                  }
                }
              }
              else
              {
                List<Shape> shapeList2 = shapeList1;
                Shape shape = new Shape(this.Document, current);
                shape.PackagePart = this.PackagePart;
                shapeList2.Add(shape);
              }
            }
          }
        }
      }
      return shapeList1;
    }

    private List<Chart> GetCharts()
    {
      List<Chart> chartList = new List<Chart>();
      IEnumerable<XElement> xelements1 = this.Xml.Descendants(XName.Get("drawing", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelements1 != null)
      {
        foreach (XContainer xcontainer in xelements1)
        {
          IEnumerable<XElement> xelements2 = xcontainer.Descendants(XName.Get("chart", Xceed.Document.NET.Document.c.NamespaceName));
          if (xelements2 != null)
          {
            foreach (XElement xelement1 in xelements2)
            {
              string str = xelement1.Attribute(XName.Get("id", "http://schemas.openxmlformats.org/officeDocument/2006/relationships")).Value;
              if (str != null)
              {
                Uri uri = this.PackagePart.GetRelationship(str).get_TargetUri();
                if (uri != (Uri) null)
                {
                  if (!uri.OriginalString.StartsWith("/"))
                    uri = new Uri("/" + uri.OriginalString, UriKind.Relative);
                  if (!uri.OriginalString.StartsWith("/word"))
                    uri = new Uri("/word" + uri.OriginalString, UriKind.Relative);
                }
                PackagePart part = this.Document._package.GetPart(uri);
                if (part != null)
                {
                  using (TextReader textReader = (TextReader) new StreamReader(part.GetStream()))
                  {
                    XDocument chartDocument = XDocument.Load(textReader);
                    if (chartDocument != null)
                    {
                      XElement xelement2 = chartDocument.Element(XName.Get("chartSpace", Xceed.Document.NET.Document.c.NamespaceName));
                      if (xelement2 != null)
                      {
                        XElement chartRootXml = xelement2.Element(XName.Get("chart", Xceed.Document.NET.Document.c.NamespaceName));
                        if (chartRootXml != null)
                        {
                          XElement xml = chartRootXml.Element(XName.Get("plotArea", Xceed.Document.NET.Document.c.NamespaceName));
                          if (xml != null)
                          {
                            XElement chartXml = Chart.GetChartXml(xml);
                            if (chartXml != null)
                            {
                              Chart chart = (Chart) null;
                              switch (chartXml.Name.LocalName)
                              {
                                case "barChart":
                                case "bar3DChart":
                                  chart = (Chart) new BarChart(part, chartDocument);
                                  break;
                                case "lineChart":
                                case "line3DChart":
                                  chart = (Chart) new LineChart(part, chartDocument);
                                  break;
                                case "pieChart":
                                case "pie3DChart":
                                  chart = (Chart) new PieChart(part, chartDocument);
                                  break;
                              }
                              if (chart != null)
                              {
                                chart.SetXml(chartRootXml, chartXml);
                                XElement Xml = chartRootXml.Element(XName.Get("legend", Xceed.Document.NET.Document.c.NamespaceName));
                                if (Xml != null)
                                  chart.Legend = new ChartLegend(Xml);
                                chartList.Add(chart);
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      return chartList;
    }

    private string GetListItemNumber(string textFormat)
    {
      if (this.IsListItem)
      {
        List list = this.Document.Lists.FirstOrDefault<List>((Func<List, bool>) (l => l.NumId == this.GetNumId()));
        if (list != null)
        {
          int listItemLevel = this.GetListItemLevel();
          if (listItemLevel != -1)
          {
            string listItemType = HelperFunctions.GetListItemType(this, this.Document);
            string listItemStartValue = HelperFunctions.GetListItemStartValue(list, listItemLevel);
            if (textFormat == null)
            {
              Formatting formatting = (Formatting) null;
              textFormat = HelperFunctions.GetListItemTextFormat(list, listItemLevel, out formatting);
            }
            IEnumerable<Paragraph> source = list.Items.Where<Paragraph>((Func<Paragraph, bool>) (p => p.GetListItemLevel() == listItemLevel));
            if (source.Count<Paragraph>() > 0)
            {
              int index1 = source.ToList<Paragraph>().FindIndex((Predicate<Paragraph>) (p => p.Text == this.Text));
              if (index1 != -1)
              {
                int number = int.Parse(listItemStartValue) + index1;
                if (listItemType != null)
                {
                  string roman;
                  if (!(listItemType == "decimal"))
                  {
                    if (!(listItemType == "lowerLetter"))
                    {
                      if (!(listItemType == "upperLetter"))
                      {
                        if (!(listItemType == "lowerRoman"))
                        {
                          if (listItemType == "upperRoman")
                            roman = PdfParagraphPart.ConvertIntToRoman(number, true);
                          else
                            goto label_18;
                        }
                        else
                          roman = PdfParagraphPart.ConvertIntToRoman(number, false);
                      }
                      else
                        roman = ((char) ((number - 1) % 26 + 65)).ToString();
                    }
                    else
                      roman = ((char) ((number - 1) % 26 + 97)).ToString();
                  }
                  else
                    roman = number.ToString();
                  if (textFormat != null)
                  {
                    int startIndex = textFormat.LastIndexOf("%");
                    if (startIndex >= 0)
                      textFormat = textFormat.Remove(startIndex, 2).Insert(startIndex, roman);
                    if (textFormat.Contains("%"))
                    {
                      Paragraph currentLevelFirstItem = source.FirstOrDefault<Paragraph>();
                      if (currentLevelFirstItem != null)
                      {
                        int index2 = list.Items.FindIndex((Predicate<Paragraph>) (i => i.Text == currentLevelFirstItem.Text));
                        if (index2 > 0)
                          return list.Items[index2 - 1].GetListItemNumber(textFormat);
                      }
                    }
                  }
                  return textFormat;
                }
label_18:
                return (string) null;
              }
            }
          }
        }
      }
      return (string) null;
    }

    private List<CheckBox> GetCheckBoxes()
    {
      List<CheckBox> checkBoxList = new List<CheckBox>();
      IEnumerable<XElement> xelements = this.Xml.Descendants(XName.Get("sdt", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelements != null)
      {
        foreach (XElement xml in xelements)
        {
          IEnumerable<XElement> source = xml.Descendants(XName.Get("checkbox", Xceed.Document.NET.Document.w14.NamespaceName));
          if (source != null && source.Count<XElement>() > 0)
            checkBoxList.Add(new CheckBox(this.Document, xml));
        }
      }
      return checkBoxList;
    }

    private void ReplaceAtBookmark_Core(string text, XElement bookmark, Formatting formatting = null)
    {
      List<XElement> xelementList = HelperFunctions.FormatInput(text, formatting?.Xml);
      bookmark.AddAfterSelf((object) xelementList);
      this._runs = this.Xml.Elements(XName.Get("r", Xceed.Document.NET.Document.w.NamespaceName)).ToList<XElement>();
      HelperFunctions.RenumberIDs(this.Document);
    }

    private void AddParagraphStyleIfNotPresent(string wantedParagraphStyleId)
    {
      if (string.IsNullOrEmpty(wantedParagraphStyleId))
        return;
      if (this.Document._styles == null)
      {
        using (TextReader textReader = (TextReader) new StreamReader(this.Document._package.GetPart(new Uri("/word/styles.xml", UriKind.Relative)).GetStream()))
          this.Document._styles = XDocument.Load(textReader);
      }
      if (HelperFunctions.GetParagraphStyleFromStyleId(this.Document, wantedParagraphStyleId) != null)
        return;
      IEnumerable<XElement> source = HelperFunctions.DecompressXMLResource(HelperFunctions.GetResources(ResourceType.DefaultStyle)).Element(Xceed.Document.NET.Document.w + "styles").Elements(Xceed.Document.NET.Document.w + "style").Select(s => new
      {
        s = s,
        type = s.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName))
      }).Where(_param1 => _param1.type != null && _param1.type.Value == "paragraph").Select(_param1 => _param1.s).Select(s => new
      {
        s = s,
        styleId = s.Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName))
      }).Where(_param1 => _param1.styleId != null && _param1.styleId.Value == wantedParagraphStyleId).Select(_param1 => _param1.s);
      if (source == null || source.Count<XElement>() <= 0)
        return;
      this.Document._styles.Element(Xceed.Document.NET.Document.w + "styles").Add((object) source);
    }

    private XElement GetNumberContentBasedOnLast_rPr()
    {
      XElement xelement = this.Xml.Descendants(XName.Get("rPr", Xceed.Document.NET.Document.w.NamespaceName)).LastOrDefault<XElement>();
      return XElement.Parse(string.Format("\r\n              <w:r w:rsidR='001D0226' xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">\r\n                   {0}\r\n                   <w:t>1</w:t> \r\n               </w:r>", xelement != null ? (object) xelement.ToString() : (object) "<w:rPr><w:noProof/></w:rPr>"));
    }
  }
}
