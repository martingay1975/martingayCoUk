﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.CustomProperty
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Globalization;

namespace Xceed.Document.NET
{
  /// <summary>Represents a Custom Property.</summary>
  public class CustomProperty
  {
    /// <summary>Gets the Name of this CustomProperty.</summary>
    public string Name { get; private set; }

    /// <summary>Gets the Value of this CustomProperty.</summary>
    public object Value { get; private set; }

    internal string Type { get; private set; }

    internal Formatting Formatting { get; set; }

    /// <summary>Initializes a new instance of the <strong>CustomProperty</strong> class for a string value.</summary>
    /// <returns>The newly created custom property.</returns>
    /// <param name="name">The name of the custom property.</param>
    /// <param name="value">The value of the custom property.</param>
    /// <param name="formatting">The formatting of the custom property value. By default, <strong>Null</strong>.</param>
    public CustomProperty(string name, string value, Formatting formatting = null)
      : this(name, "lpwstr", value, formatting)
    {
    }

    /// <summary>Initializes a new instance of the <strong>CustomProperty</strong> class for an integer value.</summary>
    /// <returns>The newly created custom property.</returns>
    /// <param name="name">The name of the custom property.</param>
    /// <param name="value">The value of the custom property.</param>
    /// <param name="formatting">The formatting of the custom property value. By default, <strong>Null</strong>.</param>
    public CustomProperty(string name, int value, Formatting formatting = null)
      : this(name, "i4", (object) value, formatting)
    {
    }

    /// <summary>Initializes a new instance of the <strong>CustomProperty</strong> class for a double value.</summary>
    /// <returns>The newly created custom property.</returns>
    /// <param name="name">The name of the custom property.</param>
    /// <param name="value">The value of the custom property.</param>
    /// <param name="formatting">The formatting of the custom property value. By default, <strong>Null</strong>.</param>
    public CustomProperty(string name, double value, Formatting formatting = null)
      : this(name, "r8", (object) value, formatting)
    {
    }

    /// <summary>Initializes a new instance of the <strong>CustomProperty</strong> class for a date time value.</summary>
    /// <returns>The newly created custom property.</returns>
    /// <param name="name">The name of the custom property.</param>
    /// <param name="value">The value of the custom property.</param>
    /// <param name="formatting">The formatting of the custom property value. By default, <strong>Null</strong>.</param>
    public CustomProperty(string name, DateTime value, Formatting formatting = null)
      : this(name, "filetime", (object) value.ToUniversalTime(), formatting)
    {
    }

    /// <summary>Initializes a new instance of the <strong>CustomProperty</strong> class for a boolean value.</summary>
    /// <returns>The newly created custom property.</returns>
    /// <param name="name">The name of the custom property.</param>
    /// <param name="value">The value of the custom property.</param>
    /// <param name="formatting">The formatting of the custom property value. By default, <strong>Null</strong>.</param>
    public CustomProperty(string name, bool value, Formatting formatting = null)
      : this(name, "bool", (object) value, formatting)
    {
    }

    internal CustomProperty(string name, string type, string value, Formatting formatting = null)
    {
      Licenser.VerifyLicense();
      object obj;
      switch (type)
      {
        case "lpwstr":
          obj = (object) value;
          break;
        case "i4":
          obj = (object) int.Parse(value, (IFormatProvider) CultureInfo.InvariantCulture);
          break;
        case "r8":
          obj = (object) double.Parse(value, (IFormatProvider) CultureInfo.InvariantCulture);
          break;
        case "filetime":
          obj = (object) DateTime.Parse(value, (IFormatProvider) CultureInfo.InvariantCulture);
          break;
        case "bool":
          obj = (object) bool.Parse(value);
          break;
        default:
          throw new Exception();
      }
      this.Name = name;
      this.Type = type;
      this.Value = obj;
      this.Formatting = formatting;
    }

    private CustomProperty(string name, string type, object value, Formatting formatting = null)
    {
      Licenser.VerifyLicense();
      this.Name = name;
      this.Type = type;
      this.Value = value;
      this.Formatting = formatting;
    }
  }
}
