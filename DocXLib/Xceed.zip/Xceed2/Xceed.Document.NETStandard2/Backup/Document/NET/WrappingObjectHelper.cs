﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.WrappingObjectHelper
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System.Xml.Linq;

namespace Xceed.Document.NET
{
  internal abstract class WrappingObjectHelper : IWrappingObject
  {
    private XElement _xml;
    private WrappingHorizontalAlignment _horizontalAlignment;
    private WrappingHorizontalOffsetAlignmentFrom _horizontalOffsetAlignmentFrom;
    private double _horizontalOffset;
    private WrappingVerticalAlignment _verticalAlignment;
    private double _verticalOffset;
    private WrappingVerticalOffsetAlignmentFrom _verticalOffsetAlignmentFrom;
    private double _distanceFromTextLeft;
    private double _distanceFromTextRight;
    private double _distanceFromTextTop;
    private double _distanceFromTextBottom;

    public WrappingHorizontalAlignment HorizontalAlignment
    {
      get => this._horizontalAlignment;
      set
      {
        this._horizontalAlignment = value;
        this.UpdateHorizontalAlignment();
      }
    }

    public double HorizontalOffset
    {
      get => this._horizontalOffset / 12700.0;
      set
      {
        this._horizontalOffset = value * 12700.0;
        this.UpdateHorizontalAlignment();
      }
    }

    public WrappingHorizontalOffsetAlignmentFrom HorizontalOffsetAlignmentFrom
    {
      get => this._horizontalOffsetAlignmentFrom;
      set
      {
        this._horizontalOffsetAlignmentFrom = value;
        this.UpdateHorizontalAlignment();
      }
    }

    public WrappingVerticalAlignment VerticalAlignment
    {
      get => this._verticalAlignment;
      set
      {
        this._verticalAlignment = value;
        this.UpdateVerticalAlignment();
      }
    }

    public double VerticalOffset
    {
      get => this._verticalOffset / 12700.0;
      set
      {
        this._verticalOffset = value * 12700.0;
        this.UpdateVerticalAlignment();
      }
    }

    public WrappingVerticalOffsetAlignmentFrom VerticalOffsetAlignmentFrom
    {
      get => this._verticalOffsetAlignmentFrom;
      set
      {
        this._verticalOffsetAlignmentFrom = value;
        this.UpdateVerticalAlignment();
      }
    }

    public double DistanceFromTextLeft
    {
      get => this._distanceFromTextLeft / 12700.0;
      set
      {
        this._distanceFromTextLeft = value * 12700.0;
        this.UpdateDistanceFromText();
      }
    }

    public double DistanceFromTextRight
    {
      get => this._distanceFromTextRight / 12700.0;
      set
      {
        this._distanceFromTextRight = value * 12700.0;
        this.UpdateDistanceFromText();
      }
    }

    public double DistanceFromTextTop
    {
      get => this._distanceFromTextTop / 12700.0;
      set
      {
        this._distanceFromTextTop = value * 12700.0;
        this.UpdateDistanceFromText();
      }
    }

    public double DistanceFromTextBottom
    {
      get => this._distanceFromTextBottom / 12700.0;
      set
      {
        this._distanceFromTextBottom = value * 12700.0;
        this.UpdateDistanceFromText();
      }
    }

    internal WrappingObjectHelper(XElement xml) => this._xml = xml;

    internal virtual void UpdateHorizontalAlignment()
    {
    }

    internal virtual void UpdateVerticalAlignment()
    {
    }

    internal virtual void UpdateDistanceFromText()
    {
    }

    internal XElement GetXml() => this._xml;

    internal virtual string GetHorizontalRelativeFrom() => (string) null;

    internal virtual string GetVerticalRelativeFrom() => (string) null;

    internal string GetHorizontalAlignment()
    {
      switch (this.HorizontalAlignment)
      {
        case WrappingHorizontalAlignment.LeftRelativeToMargin:
        case WrappingHorizontalAlignment.LeftRelativeToPage:
        case WrappingHorizontalAlignment.LeftRelativeToColumn:
        case WrappingHorizontalAlignment.LeftRelativeToCharacter:
        case WrappingHorizontalAlignment.LeftRelativeToLeftMargin:
        case WrappingHorizontalAlignment.LeftRelativeToRightMargin:
        case WrappingHorizontalAlignment.LeftRelativeToInsideMargin:
        case WrappingHorizontalAlignment.LeftRelativeToOutsideMargin:
          return "left";
        case WrappingHorizontalAlignment.CenteredRelativeToMargin:
        case WrappingHorizontalAlignment.CenteredRelativeToPage:
        case WrappingHorizontalAlignment.CenteredRelativeToColumn:
        case WrappingHorizontalAlignment.CenteredRelativeToCharacter:
        case WrappingHorizontalAlignment.CenteredRelativeToLeftMargin:
        case WrappingHorizontalAlignment.CenteredRelativeToRightMargin:
        case WrappingHorizontalAlignment.CenteredRelativeToInsideMargin:
        case WrappingHorizontalAlignment.CenteredRelativeToOutsideMargin:
          return "center";
        case WrappingHorizontalAlignment.RightRelativeToMargin:
        case WrappingHorizontalAlignment.RightRelativeToPage:
        case WrappingHorizontalAlignment.RightRelativeToColumn:
        case WrappingHorizontalAlignment.RightRelativeToCharacter:
        case WrappingHorizontalAlignment.RightRelativeToLeftMargin:
        case WrappingHorizontalAlignment.RightRelativeToRightMargin:
        case WrappingHorizontalAlignment.RightRelativeToInsideMargin:
        case WrappingHorizontalAlignment.RightRelativeToOutsideMargin:
          return "right";
        case WrappingHorizontalAlignment.InsideOfMargin:
        case WrappingHorizontalAlignment.InsideOfPage:
          return "inside";
        case WrappingHorizontalAlignment.OutsideOfMargin:
        case WrappingHorizontalAlignment.OutsideOfPage:
          return "outside";
        default:
          return "left";
      }
    }

    internal string GetVerticalAlignment()
    {
      switch (this.VerticalAlignment)
      {
        case WrappingVerticalAlignment.TopRelativeToMargin:
        case WrappingVerticalAlignment.TopRelativeToPage:
        case WrappingVerticalAlignment.TopRelativeToLine:
        case WrappingVerticalAlignment.TopRelativeToTopMargin:
        case WrappingVerticalAlignment.TopRelativeToBottomMargin:
        case WrappingVerticalAlignment.TopRelativeToInsideMargin:
        case WrappingVerticalAlignment.TopRelativeToOutsideMargin:
          return "top";
        case WrappingVerticalAlignment.CenteredRelativeToMargin:
        case WrappingVerticalAlignment.CenteredRelativeToPage:
        case WrappingVerticalAlignment.CenteredRelativeToLine:
        case WrappingVerticalAlignment.CenteredRelativeToTopMargin:
        case WrappingVerticalAlignment.CenteredRelativeToBottomMargin:
        case WrappingVerticalAlignment.CenteredRelativeToInsideMargin:
        case WrappingVerticalAlignment.CenteredRelativeToOutsideMargin:
          return "center";
        case WrappingVerticalAlignment.BottomRelativeToMargin:
        case WrappingVerticalAlignment.BottomRelativeToPage:
        case WrappingVerticalAlignment.BottomRelativeToLine:
        case WrappingVerticalAlignment.BottomRelativeToTopMargin:
        case WrappingVerticalAlignment.BottomRelativeToBottomMargin:
        case WrappingVerticalAlignment.BottomRelativeToInsideMargin:
        case WrappingVerticalAlignment.BottomRelativeToOutsideMargin:
          return "bottom";
        case WrappingVerticalAlignment.InsideRelativeToMargin:
        case WrappingVerticalAlignment.InsideRelativeToPage:
        case WrappingVerticalAlignment.InsideRelativeToLine:
        case WrappingVerticalAlignment.InsideRelativeToTopMargin:
        case WrappingVerticalAlignment.InsideRelativeToBottomMargin:
        case WrappingVerticalAlignment.InsideRelativeToInsideMargin:
        case WrappingVerticalAlignment.InsideRelativeToOutsideMargin:
          return "inside";
        case WrappingVerticalAlignment.OutsideRelativeToMargin:
        case WrappingVerticalAlignment.OutsideRelativeToPage:
        case WrappingVerticalAlignment.OutsideRelativeToLine:
        case WrappingVerticalAlignment.OutsideRelativeToTopMargin:
        case WrappingVerticalAlignment.OutsideRelativeToBottomMargin:
        case WrappingVerticalAlignment.OutsideRelativeToInsideMargin:
        case WrappingVerticalAlignment.OutsideRelativeToOutsideMargin:
          return "outside";
        default:
          return "top";
      }
    }
  }
}
