﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Shape
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a Shape.</summary>
  public class Shape : Container, IPictureWrappingObject, IWrappingObject
  {
    private float _cx;
    private float _cy;
    private float _outlineWidth;
    private float[] _outlineDashPattern;
    private bool _flipH;
    private bool _flipV;
    private bool _isTextAutoFit;
    private bool _isTextWrap;
    private string _prst;
    private string _id;
    private double _textMarginBottom;
    private double _textMarginTop;
    private double _textMarginLeft;
    private double _textMarginRight;
    private Color? _fillColor;
    private Color? _fontColor;
    private Color? _outlineColor;
    private DashStyle? _outlineDash;
    private Xceed.Document.NET.VerticalAlignment _textVerticalAlignment;
    private XDocument _theme_document;
    private XElement _clrSchemeMapping;
    private IPictureWrappingObject _wrappingObjectHelper;
    internal const string DefaultFillColor = "4472C4";
    internal const string DefaultOutlineColor = "2F528F";
    internal const string DefaultDash = "solid";

    /// <summary>Gets or sets the color used to fill this Shape.</summary>
    public Color? FillColor
    {
      get => this._fillColor;
      set
      {
        this._fillColor = value;
        XElement xelement1 = this.Xml.Descendants(XName.Get("spPr", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>();
        if (xelement1 == null)
          return;
        xelement1.Element(XName.Get("noFill", Xceed.Document.NET.Document.a.NamespaceName))?.Remove();
        XElement xelement2 = xelement1.Element(XName.Get("solidFill", Xceed.Document.NET.Document.a.NamespaceName));
        if (xelement2 == null)
        {
          XElement xelement3 = xelement1.Element(XName.Get("prstGeom", Xceed.Document.NET.Document.a.NamespaceName));
          if (xelement3 != null)
            xelement3.AddAfterSelf((object) new XElement(XName.Get("solidFill", Xceed.Document.NET.Document.a.NamespaceName)));
          else
            xelement1.AddFirst((object) new XElement(XName.Get("solidFill", Xceed.Document.NET.Document.a.NamespaceName)));
          xelement2 = xelement1.Element(XName.Get("solidFill", Xceed.Document.NET.Document.a.NamespaceName));
        }
        xelement2.Elements().Remove<XElement>();
        XElement xelement4 = new XElement(XName.Get("srgbClr", Xceed.Document.NET.Document.a.NamespaceName));
        xelement4.SetAttributeValue(XName.Get("val"), (object) this._fillColor.Value.ToHex());
        xelement2.Add((object) xelement4);
      }
    }

    /// <summary>Gets or sets if this Shape is horizontally flipped.</summary>
    public bool FlipH
    {
      get => this._flipH;
      set
      {
        this._flipH = value;
        foreach (XAttribute attribute in this.Xml.Descendants().Attributes(XName.Get("flipH")))
          attribute.Value = this._flipH ? "1" : "0";
      }
    }

    /// <summary>Gets or sets if this Shape is vertically flipped.</summary>
    public bool FlipV
    {
      get => this._flipV;
      set
      {
        this._flipV = value;
        foreach (XAttribute attribute in this.Xml.Descendants().Attributes(XName.Get("flipV")))
          attribute.Value = this._flipV ? "1" : "0";
      }
    }

    /// <summary>Gets or sets the height of this Shape (in points).</summary>
    public float Height
    {
      get => this._cy / 12700f;
      set
      {
        this._cy = value * 12700f;
        foreach (XAttribute attribute in this.Xml.Descendants().Attributes(XName.Get("cy")))
          attribute.Value = this._cy.ToString();
      }
    }

    /// <summary>Gets or sets if this Shape auto adjusts its size to fit the contained text.</summary>
    public bool IsTextAutoFit
    {
      get => this._isTextAutoFit;
      set
      {
        this._isTextAutoFit = value;
        XElement xelement = this.Xml.Descendants(XName.Get("bodyPr", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>();
        if (xelement == null)
          return;
        if (this._isTextAutoFit)
        {
          if (xelement.Element(XName.Get("spAutoFit", Xceed.Document.NET.Document.a.NamespaceName)) == null)
            xelement.Add((object) new XElement(XName.Get("spAutoFit", Xceed.Document.NET.Document.a.NamespaceName)));
          xelement.Element(XName.Get("noAutofit", Xceed.Document.NET.Document.a.NamespaceName))?.Remove();
        }
        else
        {
          if (xelement.Element(XName.Get("noAutofit", Xceed.Document.NET.Document.a.NamespaceName)) == null)
            xelement.Add((object) new XElement(XName.Get("noAutofit", Xceed.Document.NET.Document.a.NamespaceName)));
          xelement.Element(XName.Get("spAutoFit", Xceed.Document.NET.Document.a.NamespaceName))?.Remove();
        }
      }
    }

    /// <summary>Gets or sets if the text inside this Shape will wrap.</summary>
    public bool IsTextWrap
    {
      get => this._isTextWrap;
      set
      {
        this._isTextWrap = value;
        this.Xml.Descendants(XName.Get("bodyPr", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>()?.SetAttributeValue(XName.Get("wrap"), this._isTextWrap ? (object) "square" : (object) "none");
      }
    }

    /// <summary>Gets or sets the outline color of this Shape.</summary>
    public Color? OutlineColor
    {
      get => this._outlineColor;
      set
      {
        this._outlineColor = value;
        XElement xelement1 = this.Xml.Descendants(XName.Get("spPr", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>();
        if (xelement1 == null)
          return;
        XElement xelement2 = xelement1.Element(XName.Get("ln", Xceed.Document.NET.Document.a.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.Add((object) new XElement(XName.Get("ln", Xceed.Document.NET.Document.a.NamespaceName)));
          xelement2 = xelement1.Element(XName.Get("ln", Xceed.Document.NET.Document.a.NamespaceName));
        }
        xelement2.Element(XName.Get("noFill", Xceed.Document.NET.Document.a.NamespaceName))?.Remove();
        xelement2.Element(XName.Get("solidFill", Xceed.Document.NET.Document.a.NamespaceName))?.Remove();
        xelement2.Element(XName.Get("gradFill", Xceed.Document.NET.Document.a.NamespaceName))?.Remove();
        xelement2.Element(XName.Get("pattFill", Xceed.Document.NET.Document.a.NamespaceName))?.Remove();
        if (this._outlineColor.HasValue)
        {
          XElement xelement3 = new XElement(XName.Get("solidFill", Xceed.Document.NET.Document.a.NamespaceName));
          XElement xelement4 = new XElement(XName.Get("srgbClr", Xceed.Document.NET.Document.a.NamespaceName), (object) new XAttribute((XName) "val", (object) this._outlineColor.Value.ToHex()));
          xelement3.Add((object) xelement4);
          xelement2.AddFirst((object) xelement3);
        }
        else
          xelement2.AddFirst((object) new XElement(XName.Get("noFill", Xceed.Document.NET.Document.a.NamespaceName)));
      }
    }

    /// <summary>Gets or sets the style of this Shape's outline dash.</summary>
    public DashStyle? OutlineDash
    {
      get => this._outlineDash;
      set
      {
        this._outlineDash = value;
        XElement xelement1 = this.Xml.Descendants(XName.Get("spPr", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>();
        if (xelement1 == null)
          return;
        XElement xelement2 = xelement1.Element(XName.Get("ln", Xceed.Document.NET.Document.a.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.Add((object) new XElement(XName.Get("ln", Xceed.Document.NET.Document.a.NamespaceName)));
          xelement2 = xelement1.Element(XName.Get("ln", Xceed.Document.NET.Document.a.NamespaceName));
        }
        xelement2.Element(XName.Get("prstDash", Xceed.Document.NET.Document.a.NamespaceName))?.Remove();
        xelement2.Element(XName.Get("custDash", Xceed.Document.NET.Document.a.NamespaceName))?.Remove();
        XElement xelement3 = new XElement(XName.Get("prstDash", Xceed.Document.NET.Document.a.NamespaceName), (object) new XAttribute((XName) "val", (object) Shape.GetDashTypeString(this._outlineDash)));
        xelement2.Add((object) xelement3);
      }
    }

    /// <summary>Gets or sets the width of this Shape's outline (in points).</summary>
    public float OutlineWidth
    {
      get => this._outlineWidth;
      set
      {
        this._outlineWidth = value;
        XElement xelement1 = this.Xml.Descendants(XName.Get("spPr", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>();
        if (xelement1 == null)
          return;
        XElement xelement2 = xelement1.Element(XName.Get("ln", Xceed.Document.NET.Document.a.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.Add((object) new XElement(XName.Get("ln", Xceed.Document.NET.Document.a.NamespaceName)));
          xelement2 = xelement1.Element(XName.Get("ln", Xceed.Document.NET.Document.a.NamespaceName));
        }
        if ((double) this._outlineWidth <= 0.0)
          return;
        xelement2.SetAttributeValue(XName.Get("w"), (object) (float) ((double) this._outlineWidth * 12700.0));
      }
    }

    /// <summary>Gets or sets the type of this Shape.</summary>
    public string PresetShape
    {
      get => this._prst;
      set => throw new NotImplementedException("Only rect PresetShape is currently available.");
    }

    /// <summary>Gets or sets the margin between the text and the bottom side of this shape (in points).</summary>
    public double TextMarginBottom
    {
      get => this._textMarginBottom / 12700.0;
      set
      {
        this._textMarginBottom = value * 12700.0;
        this.Xml.Descendants(XName.Get("bodyPr", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>()?.SetAttributeValue(XName.Get("bIns"), (object) this._textMarginBottom);
      }
    }

    /// <summary>Gets or sets the margin between the text and the left side of this Shape (in points).</summary>
    public double TextMarginLeft
    {
      get => this._textMarginLeft / 12700.0;
      set
      {
        this._textMarginLeft = value * 12700.0;
        this.Xml.Descendants(XName.Get("bodyPr", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>()?.SetAttributeValue(XName.Get("lIns"), (object) this._textMarginLeft);
      }
    }

    /// <summary>Gets or sets the margin between the text and the right side of this Shape (in points).</summary>
    public double TextMarginRight
    {
      get => this._textMarginRight / 12700.0;
      set
      {
        this._textMarginRight = value * 12700.0;
        this.Xml.Descendants(XName.Get("bodyPr", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>()?.SetAttributeValue(XName.Get("rIns"), (object) this._textMarginRight);
      }
    }

    /// <summary>Gets or sets the margin between the text and the top side of this Shape (in points).</summary>
    public double TextMarginTop
    {
      get => this._textMarginTop / 12700.0;
      set
      {
        this._textMarginTop = value * 12700.0;
        this.Xml.Descendants(XName.Get("bodyPr", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>()?.SetAttributeValue(XName.Get("tIns"), (object) this._textMarginTop);
      }
    }

    /// <summary>Gets or sets the vertical alignment of the text inside this Shape.</summary>
    public Xceed.Document.NET.VerticalAlignment TextVerticalAlignment
    {
      get => this._textVerticalAlignment;
      set
      {
        this._textVerticalAlignment = value;
        XElement xelement = this.Xml.Descendants(XName.Get("bodyPr", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>();
        if (xelement == null)
          return;
        string str;
        switch (this._textVerticalAlignment)
        {
          case Xceed.Document.NET.VerticalAlignment.Center:
            str = "ctr";
            break;
          case Xceed.Document.NET.VerticalAlignment.Bottom:
            str = "b";
            break;
          default:
            str = "t";
            break;
        }
        xelement.SetAttributeValue(XName.Get("anchor"), (object) str);
      }
    }

    /// <summary>Gets or sets the width of this Shape (in points).</summary>
    public float Width
    {
      get => this._cx / 12700f;
      set
      {
        this._cx = value * 12700f;
        foreach (XAttribute attribute in this.Xml.Descendants().Attributes(XName.Get("cx")))
          attribute.Value = this._cx.ToString();
      }
    }

    internal string Id => this._id;

    internal Color? FontColor => this._fontColor;

    internal float[] OutlineDashPattern
    {
      get => this._outlineDashPattern;
      set => this._outlineDashPattern = value;
    }

    internal Shape(Xceed.Document.NET.Document document, XElement xml)
      : base(document, xml)
    {
      this._cx = this.Xml.Descendants().Select(e => new
      {
        e = e,
        a = e.Attribute(XName.Get("cx"))
      }).Where(_param1 => _param1.a != null).Select(_param1 => float.Parse(_param1.a.Value)).FirstOrDefault<float>();
      this._cy = this.Xml.Descendants().Select(e => new
      {
        e = e,
        a = e.Attribute(XName.Get("cy"))
      }).Where(_param1 => _param1.a != null).Select(_param1 => float.Parse(_param1.a.Value)).FirstOrDefault<float>();
      this._flipH = this.Xml.Descendants().Select(e => new
      {
        e = e,
        a = e.Attribute(XName.Get("flipH"))
      }).Where(_param1 => _param1.a != null).Select(_param1 => _param1.a.Value == "1").FirstOrDefault<bool>();
      this._flipV = this.Xml.Descendants().Select(e => new
      {
        e = e,
        a = e.Attribute(XName.Get("flipV"))
      }).Where(_param1 => _param1.a != null).Select(_param1 => _param1.a.Value == "1").FirstOrDefault<bool>();
      this._prst = this.Xml.Descendants().Select(e => new
      {
        e = e,
        a = e.Attribute(XName.Get("prst"))
      }).Where(_param1 => _param1.a != null && _param1.a.Parent.Name.LocalName == "prstGeom").Select(_param1 => _param1.a.Value).FirstOrDefault<string>();
      this.SetInitialShapeTextProperties();
      this._id = this._cx.ToString() + this._cy.ToString() + this._outlineWidth.ToString() + this._outlineDashPattern?.ToString() + this._flipH.ToString() + this._flipV.ToString() + this._isTextAutoFit.ToString() + this._isTextWrap.ToString() + this._prst + this._textMarginBottom.ToString() + this._textMarginTop.ToString() + this._textMarginLeft.ToString() + this._textMarginRight.ToString() + this._fillColor.ToString() + this._fontColor.ToString() + this._outlineColor.ToString() + this._outlineDash.ToString() + this._textVerticalAlignment.ToString();
      Uri uri = new Uri("/word/theme/theme1.xml", UriKind.Relative);
      if (this.Document._package.PartExists(uri))
      {
        PackagePart part = this.Document._package.GetPart(uri);
        if (part != null)
        {
          using (TextReader textReader = (TextReader) new StreamReader(part.GetStream()))
            this._theme_document = XDocument.Load(textReader);
        }
      }
      this._clrSchemeMapping = this.Document._settings.Descendants(XName.Get("clrSchemeMapping", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>();
      XElement xelement1 = this.Xml.Descendants(XName.Get("style", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>();
      if (xelement1 != null)
      {
        XElement element1 = xelement1.Element(XName.Get("fillRef", Xceed.Document.NET.Document.a.NamespaceName));
        if (element1 != null)
          this._fillColor = this.GetFillColorFromXmlReference(element1);
        XElement element2 = xelement1.Element(XName.Get("lnRef", Xceed.Document.NET.Document.a.NamespaceName));
        if (element2 != null)
          this.SetOutlinePropertiesFromXmlReference(element2);
        XElement element3 = xelement1.Element(XName.Get("fontRef", Xceed.Document.NET.Document.a.NamespaceName));
        if (element3 != null)
          this._fontColor = this.GetFontColorFromXmlReference(element3);
      }
      XElement xelement2 = this.Xml.Descendants(XName.Get("spPr", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>();
      if (xelement2 != null)
      {
        XElement element1 = xelement2.Element(XName.Get("solidFill", Xceed.Document.NET.Document.a.NamespaceName)) ?? xelement2.Element(XName.Get("gradFill", Xceed.Document.NET.Document.a.NamespaceName));
        if (element1 == null && xelement2.Element(XName.Get("noFill", Xceed.Document.NET.Document.a.NamespaceName)) != null)
          this._fillColor = new Color?();
        if (element1 != null)
        {
          Color? nullable = this.GetFillColorFromRGB(element1);
          if (!nullable.HasValue)
            nullable = this.GetFillColorFromScheme(element1);
          if (!nullable.HasValue)
            nullable = this.GetFillColorFromSystem(element1);
          if (nullable.HasValue)
            this._fillColor = nullable;
        }
        XElement element2 = xelement2.Element(XName.Get("ln", Xceed.Document.NET.Document.a.NamespaceName));
        if (element2 != null && (element2.HasAttributes || element2.HasElements))
          this.SetOutlinePropertiesFromXml(element2);
      }
      this._wrappingObjectHelper = (IPictureWrappingObject) new PictureWrappingObjectHelper(this.Xml);
    }

    protected internal override void AddElementInXml(object element)
    {
      XElement xelement1 = this.Xml.Descendants(XName.Get("wsp", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>();
      if (xelement1 == null)
        return;
      XElement xelement2 = xelement1.Element(XName.Get("txbx", Xceed.Document.NET.Document.wps.NamespaceName));
      if (xelement2 == null)
      {
        XElement xelement3 = xelement1.Element(XName.Get("spPr", Xceed.Document.NET.Document.wps.NamespaceName));
        if (xelement3 != null)
          xelement3.AddAfterSelf((object) new XElement(XName.Get("txbx", Xceed.Document.NET.Document.wps.NamespaceName)));
        else
          xelement1.Add((object) new XElement(XName.Get("txbx", Xceed.Document.NET.Document.wps.NamespaceName)));
        xelement2 = xelement1.Element(XName.Get("txbx", Xceed.Document.NET.Document.wps.NamespaceName));
      }
      XElement xelement4 = xelement2.Element(XName.Get("txbxContent", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement4 == null)
      {
        xelement2.Add((object) new XElement(XName.Get("txbxContent", Xceed.Document.NET.Document.w.NamespaceName)));
        xelement4 = xelement2.Element(XName.Get("txbxContent", Xceed.Document.NET.Document.w.NamespaceName));
      }
      xelement4.Add(element);
    }

    internal static string GetDashTypeString(DashStyle? dashStyle)
    {
      if (!dashStyle.HasValue || !dashStyle.HasValue)
        return "solid";
      switch (dashStyle.GetValueOrDefault() - 1)
      {
        case 0:
          return "dash";
        case 1:
          return "sysDot";
        case 2:
          return "dashDot";
        case 3:
          return "lgDashDotDot";
        default:
          return "solid";
      }
    }

    private Color? GetFillColorFromRGB(XElement element)
    {
      if (element == null)
        return new Color?();
      XElement xelement = element.Name.LocalName == "gradFill" ? element.Descendants(XName.Get("srgbClr", Xceed.Document.NET.Document.a.NamespaceName)).FirstOrDefault<XElement>() : element.Element(XName.Get("srgbClr", Xceed.Document.NET.Document.a.NamespaceName));
      if (xelement != null)
      {
        XAttribute xattribute = xelement.Attribute(XName.Get("val"));
        if (!string.IsNullOrEmpty(xattribute.Value))
          return new Color?(Color.FromArgb((int) byte.MaxValue, Color.FromArgb(int.Parse(xattribute.Value, NumberStyles.HexNumber))));
      }
      return new Color?();
    }

    private Color? GetFillColorFromSystem(XElement element)
    {
      if (element == null)
        return new Color?();
      XElement xelement = element.Element(XName.Get("sysClr", Xceed.Document.NET.Document.a.NamespaceName));
      if (xelement != null)
      {
        XAttribute xattribute = xelement.Attribute(XName.Get("val"));
        if (!string.IsNullOrEmpty(xattribute.Value))
        {
          switch (xattribute.Value)
          {
            case "3dDkShadow":
              return new Color?(SystemColors.get_ButtonShadow());
            case "3dLight":
              return new Color?(SystemColors.get_ControlLight());
            case "activeBorder":
              return new Color?(SystemColors.get_ActiveBorder());
            case "activeCaption":
              return new Color?(SystemColors.get_ActiveCaption());
            case "appWorkspace":
              return new Color?(SystemColors.get_AppWorkspace());
            case "background":
              return new Color?(SystemColors.get_Desktop());
            case "btnFace":
              return new Color?(SystemColors.get_ButtonFace());
            case "btnHighlight":
              return new Color?(SystemColors.get_ButtonHighlight());
            case "btnShadow":
              return new Color?(SystemColors.get_ButtonShadow());
            case "btnText":
              return new Color?(SystemColors.get_ControlText());
            case "captionText":
              return new Color?(SystemColors.get_ActiveCaptionText());
            case "gradientActiveCaption":
              return new Color?(SystemColors.get_GradientActiveCaption());
            case "gradientInactiveCaption":
              return new Color?(SystemColors.get_GradientInactiveCaption());
            case "grayText":
              return new Color?(SystemColors.get_GrayText());
            case "highlight":
              return new Color?(SystemColors.get_Highlight());
            case "highlightText":
              return new Color?(SystemColors.get_HighlightText());
            case "hotLight":
              return new Color?(SystemColors.get_HotTrack());
            case "inactiveBorder":
              return new Color?(SystemColors.get_InactiveBorder());
            case "inactiveCaption":
              return new Color?(SystemColors.get_InactiveCaption());
            case "inactiveCaptionText":
              return new Color?(SystemColors.get_InactiveCaptionText());
            case "infoBk":
              return new Color?(SystemColors.get_Info());
            case "infoText":
              return new Color?(SystemColors.get_InfoText());
            case "menu":
              return new Color?(SystemColors.get_Menu());
            case "menuBar":
              return new Color?(SystemColors.get_MenuBar());
            case "menuHighlight":
              return new Color?(SystemColors.get_MenuHighlight());
            case "menuText":
              return new Color?(SystemColors.get_MenuText());
            case "scrollBar":
              return new Color?(SystemColors.get_ScrollBar());
            case "window":
              return new Color?(SystemColors.get_Window());
            case "windowFrame":
              return new Color?(SystemColors.get_WindowFrame());
            case "windowText":
              return new Color?(SystemColors.get_WindowText());
          }
        }
      }
      return new Color?();
    }

    private Color? GetFillColorFromScheme(XElement element)
    {
      if (element == null)
        return new Color?();
      Color? nullable = new Color?();
      int alpha = (int) byte.MaxValue;
      XElement xelement1 = element.Name.LocalName == "gradFill" ? element.Descendants(XName.Get("schemeClr", Xceed.Document.NET.Document.a.NamespaceName)).FirstOrDefault<XElement>() : element.Element(XName.Get("schemeClr", Xceed.Document.NET.Document.a.NamespaceName));
      if (xelement1 != null)
      {
        XAttribute xattribute1 = xelement1.Attribute(XName.Get("val"));
        if (!string.IsNullOrEmpty(xattribute1.Value) && this._theme_document != null)
        {
          XElement xelement2 = this._theme_document.Descendants(XName.Get("clrScheme", Xceed.Document.NET.Document.a.NamespaceName)).FirstOrDefault<XElement>();
          if (xelement2 != null)
          {
            XElement element1 = xelement2.Element(XName.Get(xattribute1.Value, Xceed.Document.NET.Document.a.NamespaceName));
            if (element1 == null)
            {
              string mappedSchemeColor = this.GetMappedSchemeColor(xattribute1.Value);
              element1 = xelement2.Element(XName.Get(mappedSchemeColor, Xceed.Document.NET.Document.a.NamespaceName));
            }
            if (element1 != null)
            {
              nullable = this.GetFillColorFromRGB(element1);
              if (!nullable.HasValue)
                nullable = this.GetFillColorFromSystem(element1);
            }
          }
        }
        XElement xelement3 = xelement1.Element(XName.Get("alpha", Xceed.Document.NET.Document.a.NamespaceName));
        if (xelement3 != null)
        {
          XAttribute xattribute2 = xelement3.Attribute(XName.Get("val"));
          if (!string.IsNullOrEmpty(xattribute2.Value))
            alpha = Convert.ToInt32(xattribute2.Value) / 1000 * (int) byte.MaxValue / 100;
        }
      }
      return !nullable.HasValue ? new Color?() : new Color?(Color.FromArgb(alpha, nullable.Value));
    }

    private string GetMappedSchemeColor(string val)
    {
      if (string.IsNullOrEmpty(val))
        return val;
      string str = val;
      if (this._clrSchemeMapping != null)
      {
        switch (val)
        {
          case "t1":
          case "tx1":
            str = this.GetMappedSchemeColorCore(this._clrSchemeMapping.Attribute(XName.Get("t1", Xceed.Document.NET.Document.w.NamespaceName)).Value);
            break;
          case "t2":
          case "tx2":
            str = this.GetMappedSchemeColorCore(this._clrSchemeMapping.Attribute(XName.Get("t2", Xceed.Document.NET.Document.w.NamespaceName)).Value);
            break;
          default:
            str = this.GetMappedSchemeColorCore(this._clrSchemeMapping.Attribute(XName.Get(val, Xceed.Document.NET.Document.w.NamespaceName)).Value);
            break;
        }
      }
      return str;
    }

    private string GetMappedSchemeColorCore(string map)
    {
      switch (map)
      {
        case "dark1":
          return "dk1";
        case "dark2":
          return "dk2";
        case "light1":
          return "lt1";
        case "light2":
          return "lt2";
        case "hyperlink":
          return "hlink";
        case "followedHyperlink":
          return "folHlink";
        default:
          return map;
      }
    }

    private void SetOutlinePropertiesFromXml(XElement element)
    {
      if (element == null)
        return;
      XAttribute xattribute1 = element.Attribute(XName.Get("w"));
      if (xattribute1 != null)
        this._outlineWidth = Convert.ToSingle(xattribute1.Value) / 12700f;
      XElement element1 = element.Element(XName.Get("solidFill", Xceed.Document.NET.Document.a.NamespaceName)) ?? element.Element(XName.Get("gradFill", Xceed.Document.NET.Document.a.NamespaceName));
      if (element1 == null && element.Element(XName.Get("noFill", Xceed.Document.NET.Document.a.NamespaceName)) != null)
      {
        this._outlineColor = new Color?();
      }
      else
      {
        if (element1 != null)
        {
          this._outlineColor = this.GetFillColorFromRGB(element1);
          if (!this._outlineColor.HasValue)
            this._outlineColor = this.GetFillColorFromScheme(element1);
          if (!this._outlineColor.HasValue)
            this._outlineColor = this.GetFillColorFromSystem(element1);
        }
        XElement xelement = element.Element(XName.Get("prstDash", Xceed.Document.NET.Document.a.NamespaceName));
        if (xelement == null)
          return;
        XAttribute xattribute2 = xelement.Attribute(XName.Get("val"));
        if (string.IsNullOrEmpty(xattribute2.Value))
          return;
        switch (xattribute2.Value)
        {
          case "dash":
          case "sysDash":
            this._outlineDash = new DashStyle?((DashStyle) 1);
            break;
          case "dashDot":
            this._outlineDash = new DashStyle?((DashStyle) 3);
            break;
          case "lgDash":
            this._outlineDash = new DashStyle?((DashStyle) 5);
            this._outlineDashPattern = new float[2]
            {
              15f,
              3f
            };
            break;
          case "lgDashDot":
            this._outlineDash = new DashStyle?((DashStyle) 5);
            this._outlineDashPattern = new float[4]
            {
              15f,
              4f,
              2f,
              4f
            };
            break;
          case "lgDashDotDot":
            this._outlineDash = new DashStyle?((DashStyle) 4);
            break;
          case "sysDot":
            this._outlineDash = new DashStyle?((DashStyle) 2);
            break;
          default:
            this._outlineDash = new DashStyle?((DashStyle) 0);
            break;
        }
      }
    }

    private void SetInitialShapeTextProperties()
    {
      XElement xelement = this.Xml.Descendants(XName.Get("bodyPr", Xceed.Document.NET.Document.wps.NamespaceName)).FirstOrDefault<XElement>();
      if (xelement == null)
        return;
      XAttribute xattribute1 = xelement.Attribute(XName.Get("anchor"));
      if (xattribute1 != null)
      {
        Xceed.Document.NET.VerticalAlignment verticalAlignment;
        switch (xattribute1.Value)
        {
          case "b":
            verticalAlignment = Xceed.Document.NET.VerticalAlignment.Bottom;
            break;
          case "ctr":
            verticalAlignment = Xceed.Document.NET.VerticalAlignment.Center;
            break;
          default:
            verticalAlignment = Xceed.Document.NET.VerticalAlignment.Top;
            break;
        }
        this._textVerticalAlignment = verticalAlignment;
      }
      this._isTextAutoFit = xelement.Element(XName.Get("spAutoFit", Xceed.Document.NET.Document.a.NamespaceName)) != null;
      XAttribute xattribute2 = xelement.Attribute(XName.Get("wrap"));
      if (xattribute2 != null)
        this._isTextWrap = xattribute2.Value != "none";
      XAttribute xattribute3 = xelement.Attribute(XName.Get("bIns"));
      if (xattribute3 != null)
        this._textMarginBottom = double.Parse(xattribute3.Value);
      XAttribute xattribute4 = xelement.Attribute(XName.Get("tIns"));
      if (xattribute4 != null)
        this._textMarginTop = double.Parse(xattribute4.Value);
      XAttribute xattribute5 = xelement.Attribute(XName.Get("lIns"));
      if (xattribute5 != null)
        this._textMarginLeft = double.Parse(xattribute5.Value);
      XAttribute xattribute6 = xelement.Attribute(XName.Get("rIns"));
      if (xattribute6 == null)
        return;
      this._textMarginRight = double.Parse(xattribute6.Value);
    }

    private Color? GetFillColorFromXmlReference(XElement element)
    {
      if (element == null)
        return new Color?();
      XAttribute xattribute = element.Attribute(XName.Get("idx"));
      if (xattribute != null)
      {
        int int32 = Convert.ToInt32(xattribute.Value);
        if (int32 == 0 || int32 == 1000)
          return new Color?();
        XElement element1 = int32 < 1000 ? this.GetStyleFromXmlReference(element, "fillStyleLst", int32) : this.GetStyleFromXmlReference(element, "bgFillStyleLst", int32 - 1000);
        if (element1 != null)
          return this.GetFillColorFromScheme(element1);
      }
      return new Color?();
    }

    private void SetOutlinePropertiesFromXmlReference(XElement element)
    {
      XElement fromXmlReference = this.GetStyleFromXmlReference(element, "lnStyleLst");
      if (fromXmlReference == null)
        return;
      this.SetOutlinePropertiesFromXml(fromXmlReference);
    }

    private Color? GetFontColorFromXmlReference(XElement element)
    {
      if (element == null)
        return new Color?();
      Color? nullable = this.GetFillColorFromRGB(element);
      if (!nullable.HasValue)
        nullable = this.GetFillColorFromScheme(element);
      if (!nullable.HasValue)
        nullable = this.GetFillColorFromSystem(element);
      return nullable;
    }

    private XElement GetStyleFromXmlReference(
      XElement element,
      string listsName,
      int idxValue = -1)
    {
      if (element == null)
        return (XElement) null;
      if (this._theme_document == null)
        return (XElement) null;
      if (idxValue == -1)
      {
        XAttribute xattribute = element.Attribute(XName.Get("idx"));
        if (xattribute != null)
          idxValue = Convert.ToInt32(xattribute.Value);
      }
      if (idxValue <= 0)
        return (XElement) null;
      IEnumerable<XElement> xelements = element.Elements();
      XElement xelement1 = this._theme_document.Descendants(XName.Get(listsName, Xceed.Document.NET.Document.a.NamespaceName)).FirstOrDefault<XElement>();
      if (xelement1 != null)
      {
        List<XElement> list = xelement1.Elements().ToList<XElement>();
        if (list != null && list.Count<XElement>() > 0 && idxValue <= list.Count)
        {
          XElement xelement2 = new XElement(list[idxValue - 1]);
          foreach (XElement xelement3 in xelements)
          {
            IEnumerable<XElement> source = xelement2.Descendants(xelement3.Name).Where<XElement>((Func<XElement, bool>) (x => x.Attribute(XName.Get("val")).Value == "phClr"));
            if (source != null && source.Count<XElement>() > 0)
            {
              foreach (XElement xelement4 in source)
                xelement4.SetAttributeValue(XName.Get("val"), (object) xelement3.Attribute(XName.Get("val")).Value);
            }
          }
          return xelement2;
        }
      }
      return (XElement) null;
    }

    /// <summary>Gets or sets the text wrapping style.</summary>
    public PictureWrappingStyle WrappingStyle
    {
      get => this._wrappingObjectHelper.WrappingStyle;
      set => this._wrappingObjectHelper.WrappingStyle = value;
    }

    /// <summary>Gets or sets the text wrapping position.</summary>
    public PictureWrapText WrapText
    {
      get => this._wrappingObjectHelper.WrapText;
      set => this._wrappingObjectHelper.WrapText = value;
    }

    /// <summary>Gets or sets the text horizontal alignment for this Shape.</summary>
    public WrappingHorizontalAlignment HorizontalAlignment
    {
      get => this._wrappingObjectHelper.HorizontalAlignment;
      set => this._wrappingObjectHelper.HorizontalAlignment = value;
    }

    /// <summary>Gets or sets the text horizontal offset of this Shape relative to the element identified in the HorizontalOffsetAlignmentFrom property.</summary>
    public double HorizontalOffset
    {
      get => this._wrappingObjectHelper.HorizontalOffset;
      set => this._wrappingObjectHelper.HorizontalOffset = value;
    }

    /// <summary>Gets or sets the element from which the HorizontalOffset is calculated.</summary>
    public WrappingHorizontalOffsetAlignmentFrom HorizontalOffsetAlignmentFrom
    {
      get => this._wrappingObjectHelper.HorizontalOffsetAlignmentFrom;
      set => this._wrappingObjectHelper.HorizontalOffsetAlignmentFrom = value;
    }

    /// <summary>Gets or sets the text vertical alignment for this Shape.</summary>
    public WrappingVerticalAlignment VerticalAlignment
    {
      get => this._wrappingObjectHelper.VerticalAlignment;
      set => this._wrappingObjectHelper.VerticalAlignment = value;
    }

    /// <summary>Gets or sets the text vertical offset of this Shape relative to the element identified in the VerticalOffsetAlignmentFrom property.</summary>
    public double VerticalOffset
    {
      get => this._wrappingObjectHelper.VerticalOffset;
      set => this._wrappingObjectHelper.VerticalOffset = value;
    }

    /// <summary>Gets or sets the element from which the VerticalOffset is calculated.</summary>
    public WrappingVerticalOffsetAlignmentFrom VerticalOffsetAlignmentFrom
    {
      get => this._wrappingObjectHelper.VerticalOffsetAlignmentFrom;
      set => this._wrappingObjectHelper.VerticalOffsetAlignmentFrom = value;
    }

    /// <summary>Gets or sets the distance of the text from the left of this Shape.</summary>
    public double DistanceFromTextLeft
    {
      get => this._wrappingObjectHelper.DistanceFromTextLeft;
      set => this._wrappingObjectHelper.DistanceFromTextLeft = value;
    }

    /// <summary>Gets or sets the distance of the text from the right of this Shape.</summary>
    public double DistanceFromTextRight
    {
      get => this._wrappingObjectHelper.DistanceFromTextRight;
      set => this._wrappingObjectHelper.DistanceFromTextRight = value;
    }

    /// <summary>Gets or sets the distance of the text from the top of the shape.</summary>
    public double DistanceFromTextTop
    {
      get => this._wrappingObjectHelper.DistanceFromTextTop;
      set => this._wrappingObjectHelper.DistanceFromTextTop = value;
    }

    /// <summary>Gets or sets the distance of the text from the bottom of the shape.</summary>
    public double DistanceFromTextBottom
    {
      get => this._wrappingObjectHelper.DistanceFromTextBottom;
      set => this._wrappingObjectHelper.DistanceFromTextBottom = value;
    }

    /// <summary>Gets or sets the list of points to use to define the polygon inside this Shape where no text can be drawn.</summary>
    public List<Point> WrapPolygon
    {
      get => this._wrappingObjectHelper.WrapPolygon;
      set => this._wrappingObjectHelper.WrapPolygon = value;
    }
  }
}
