﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Table
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a Table.</summary>
  public class Table : InsertBeforeOrAfter, ITableWrappingObject, IWrappingObject
  {
    private Alignment _alignment;
    private AutoFit _autofit;
    private TableDesign _design;
    private TableLook _tableLook;
    private double _indentFromLeft;
    private ITableWrappingObject _wrappingObjectHelper;
    private string _customTableDesignName;
    private int _cachedColumnCount = -1;

    /// <summary>Gets the collection of Paragraphs in this Table.</summary>
    public virtual List<Paragraph> Paragraphs
    {
      get
      {
        List<Paragraph> paragraphList = new List<Paragraph>();
        foreach (Row row in this.Rows)
          paragraphList.AddRange((IEnumerable<Paragraph>) row.Paragraphs);
        return paragraphList;
      }
    }

    /// <summary>Gets the collection of Pictures in this Table.</summary>
    public List<Picture> Pictures
    {
      get
      {
        List<Picture> pictureList = new List<Picture>();
        foreach (Row row in this.Rows)
          pictureList.AddRange((IEnumerable<Picture>) row.Pictures);
        return pictureList;
      }
    }

    /// <summary>Gets the collection of Shapes associated with this Table.</summary>
    public List<Shape> Shapes
    {
      get
      {
        List<Shape> shapeList = new List<Shape>();
        foreach (Row row in this.Rows)
          shapeList.AddRange((IEnumerable<Shape>) row.Shapes);
        return shapeList;
      }
    }

    /// <summary>Gets the collection of TextBoxes associated with this Table.</summary>
    public List<Shape> TextBoxes
    {
      get
      {
        List<Shape> shapeList = new List<Shape>();
        foreach (Row row in this.Rows)
          shapeList.AddRange((IEnumerable<Shape>) row.TextBoxes);
        return shapeList;
      }
    }

    /// <summary>Gets the collection of Hyperlinks in this Table.</summary>
    public List<Hyperlink> Hyperlinks
    {
      get
      {
        List<Hyperlink> hyperlinkList = new List<Hyperlink>();
        foreach (Row row in this.Rows)
          hyperlinkList.AddRange((IEnumerable<Hyperlink>) row.Hyperlinks);
        return hyperlinkList;
      }
    }

    /// <summary>Gets the Row Count of this Table.</summary>
    public int RowCount => this.Xml.Elements(XName.Get("tr", Xceed.Document.NET.Document.w.NamespaceName)).Count<XElement>();

    /// <summary>Gets the Column Count of this Table.</summary>
    public int ColumnCount
    {
      get
      {
        if (this.RowCount == 0)
          return 0;
        if (this._cachedColumnCount == -1)
        {
          foreach (Row row in this.Rows)
            this._cachedColumnCount = Math.Max(this._cachedColumnCount, row.ColumnCount);
        }
        return this._cachedColumnCount;
      }
    }

    /// <summary>Gets the collection of Rows in this Table.</summary>
    public List<Row> Rows => this.Xml.Elements(XName.Get("tr", Xceed.Document.NET.Document.w.NamespaceName)).Select<XElement, Row>((Func<XElement, Row>) (r => new Row(this, this.Document, r))).ToList<Row>();

    /// <summary>Gets or sets the Alignment of this Table.</summary>
    public Alignment Alignment
    {
      get => this._alignment;
      set
      {
        string str = string.Empty;
        switch (value)
        {
          case Alignment.left:
            str = "left";
            break;
          case Alignment.center:
            str = "center";
            break;
          case Alignment.right:
            str = "right";
            break;
          case Alignment.both:
            str = "both";
            break;
        }
        XElement xelement = this.Xml.Descendants(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName)).First<XElement>();
        xelement.Descendants(XName.Get("jc", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>()?.Remove();
        xelement.Add((object) new XElement(XName.Get("jc", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) str)));
        this._alignment = value;
      }
    }

    /// <summary>
    ///   <span id="BugEvents">Gets or sets the indentation of this Table, from the left margin of the document.</span>
    /// </summary>
    public double IndentFromLeft
    {
      get => this._indentFromLeft / 20.0;
      set
      {
        this._indentFromLeft = value * 20.0;
        XElement xelement1 = this.Xml.Descendants(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName)).First<XElement>();
        XElement xelement2 = xelement1.Element(XName.Get("tblInd", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.Add((object) new XElement(XName.Get("tblInd", Xceed.Document.NET.Document.w.NamespaceName)));
          xelement2 = xelement1.Element(XName.Get("tblInd", Xceed.Document.NET.Document.w.NamespaceName));
        }
        xelement2.SetAttributeValue(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName), (object) this._indentFromLeft);
      }
    }

    /// <summary>Gets or sets the AutoFit of this Table.</summary>
    public AutoFit AutoFit
    {
      get => this._autofit;
      set
      {
        string str1 = string.Empty;
        string str2 = string.Empty;
        switch (value)
        {
          case AutoFit.Contents:
            str1 = str2 = "auto";
            break;
          case AutoFit.Window:
            str1 = str2 = "pct";
            break;
          case AutoFit.ColumnWidth:
            str1 = "auto";
            str2 = "dxa";
            XElement xelement1 = this.Xml.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
            if (xelement1 != null)
            {
              XElement xelement2 = xelement1.Element(XName.Get("tblLayout", Xceed.Document.NET.Document.w.NamespaceName));
              if (xelement2 == null)
              {
                xelement1.Add((object) new XElement(XName.Get("tblLayout", Xceed.Document.NET.Document.w.NamespaceName)));
                xelement2 = xelement1.Element(XName.Get("tblLayout", Xceed.Document.NET.Document.w.NamespaceName));
              }
              XAttribute xattribute = xelement2.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName));
              if (xattribute == null)
              {
                xelement2.Add((object) new XAttribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty));
                xattribute = xelement2.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName));
              }
              xattribute.Value = "fixed";
              break;
            }
            break;
          case AutoFit.Fixed:
            str1 = str2 = "dxa";
            XElement xelement3 = this.Xml.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
            if (xelement3.Element(XName.Get("tblLayout", Xceed.Document.NET.Document.w.NamespaceName)) == null)
            {
              (xelement3.Element(XName.Get("tblInd", Xceed.Document.NET.Document.w.NamespaceName)) ?? xelement3.Element(XName.Get("tblW", Xceed.Document.NET.Document.w.NamespaceName))).AddAfterSelf((object) new XElement(XName.Get("tblLayout", Xceed.Document.NET.Document.w.NamespaceName)));
              xelement3.Element(XName.Get("tblLayout", Xceed.Document.NET.Document.w.NamespaceName)).SetAttributeValue(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName), (object) "fixed");
              XElement xelement2 = xelement3.Element(XName.Get("tblW", Xceed.Document.NET.Document.w.NamespaceName));
              double num = 0.0;
              if (this.ColumnWidths != null)
              {
                foreach (double columnWidth in this.ColumnWidths)
                  num += columnWidth;
              }
              xelement2.SetAttributeValue(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName), (object) (num * 20.0).ToString((IFormatProvider) CultureInfo.InvariantCulture));
              break;
            }
            foreach (XAttribute xattribute in this.Xml.Descendants().Select(d => new
            {
              d = d,
              type = d.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName))
            }).Where(_param1 => _param1.d.Name.LocalName == "tblLayout" && _param1.type != null).Select(_param1 => _param1.type))
              xattribute.Value = "fixed";
            XElement xelement4 = xelement3.Element(XName.Get("tblW", Xceed.Document.NET.Document.w.NamespaceName));
            double num1 = 0.0;
            if (this.ColumnWidths != null)
            {
              foreach (double columnWidth in this.ColumnWidths)
                num1 += columnWidth;
            }
            xelement4.SetAttributeValue(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName), (object) (num1 * 20.0).ToString((IFormatProvider) CultureInfo.InvariantCulture));
            break;
        }
        foreach (XAttribute xattribute in this.Xml.Descendants().Select(d => new
        {
          d = d,
          type = d.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName))
        }).Where(_param1 => _param1.d.Name.LocalName == "tblW" && _param1.type != null).Select(_param1 => _param1.type))
          xattribute.Value = str1;
        foreach (XAttribute xattribute in this.Xml.Descendants().Select(d => new
        {
          d = d,
          type = d.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName))
        }).Where(_param1 => _param1.d.Name.LocalName == "tcW" && _param1.type != null).Select(_param1 => _param1.type))
          xattribute.Value = str2;
        this._autofit = value;
      }
    }

    /// <summary>Gets or sets the Design of this Table.</summary>
    public TableDesign Design
    {
      get => this._design;
      set
      {
        if (this._design == value)
          return;
        XElement xelement1 = this.Xml.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
        XElement xelement2 = xelement1.Element(XName.Get("tblStyle", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 == null)
        {
          xelement1.Add((object) new XElement(XName.Get("tblStyle", Xceed.Document.NET.Document.w.NamespaceName)));
          xelement2 = xelement1.Element(XName.Get("tblStyle", Xceed.Document.NET.Document.w.NamespaceName));
        }
        XAttribute val = xelement2.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        if (val == null)
        {
          xelement2.Add((object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) ""));
          val = xelement2.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        }
        this._design = value;
        if (this._design == TableDesign.None && xelement2 != null)
          xelement2.Remove();
        if (this._design == TableDesign.Custom)
        {
          if (string.IsNullOrEmpty(this._customTableDesignName))
          {
            this._design = TableDesign.None;
            xelement2?.Remove();
          }
          else
            val.Value = this._customTableDesignName;
        }
        else
        {
          switch (this._design)
          {
            case TableDesign.TableNormal:
              val.Value = "TableNormal";
              break;
            case TableDesign.TableGrid:
              val.Value = "TableGrid";
              break;
            case TableDesign.LightShading:
              val.Value = "LightShading";
              break;
            case TableDesign.LightShadingAccent1:
              val.Value = "LightShading-Accent1";
              break;
            case TableDesign.LightShadingAccent2:
              val.Value = "LightShading-Accent2";
              break;
            case TableDesign.LightShadingAccent3:
              val.Value = "LightShading-Accent3";
              break;
            case TableDesign.LightShadingAccent4:
              val.Value = "LightShading-Accent4";
              break;
            case TableDesign.LightShadingAccent5:
              val.Value = "LightShading-Accent5";
              break;
            case TableDesign.LightShadingAccent6:
              val.Value = "LightShading-Accent6";
              break;
            case TableDesign.LightList:
              val.Value = "LightList";
              break;
            case TableDesign.LightListAccent1:
              val.Value = "LightList-Accent1";
              break;
            case TableDesign.LightListAccent2:
              val.Value = "LightList-Accent2";
              break;
            case TableDesign.LightListAccent3:
              val.Value = "LightList-Accent3";
              break;
            case TableDesign.LightListAccent4:
              val.Value = "LightList-Accent4";
              break;
            case TableDesign.LightListAccent5:
              val.Value = "LightList-Accent5";
              break;
            case TableDesign.LightListAccent6:
              val.Value = "LightList-Accent6";
              break;
            case TableDesign.LightGrid:
              val.Value = "LightGrid";
              break;
            case TableDesign.LightGridAccent1:
              val.Value = "LightGrid-Accent1";
              break;
            case TableDesign.LightGridAccent2:
              val.Value = "LightGrid-Accent2";
              break;
            case TableDesign.LightGridAccent3:
              val.Value = "LightGrid-Accent3";
              break;
            case TableDesign.LightGridAccent4:
              val.Value = "LightGrid-Accent4";
              break;
            case TableDesign.LightGridAccent5:
              val.Value = "LightGrid-Accent5";
              break;
            case TableDesign.LightGridAccent6:
              val.Value = "LightGrid-Accent6";
              break;
            case TableDesign.MediumShading1:
              val.Value = "MediumShading1";
              break;
            case TableDesign.MediumShading1Accent1:
              val.Value = "MediumShading1-Accent1";
              break;
            case TableDesign.MediumShading1Accent2:
              val.Value = "MediumShading1-Accent2";
              break;
            case TableDesign.MediumShading1Accent3:
              val.Value = "MediumShading1-Accent3";
              break;
            case TableDesign.MediumShading1Accent4:
              val.Value = "MediumShading1-Accent4";
              break;
            case TableDesign.MediumShading1Accent5:
              val.Value = "MediumShading1-Accent5";
              break;
            case TableDesign.MediumShading1Accent6:
              val.Value = "MediumShading1-Accent6";
              break;
            case TableDesign.MediumShading2:
              val.Value = "MediumShading2";
              break;
            case TableDesign.MediumShading2Accent1:
              val.Value = "MediumShading2-Accent1";
              break;
            case TableDesign.MediumShading2Accent2:
              val.Value = "MediumShading2-Accent2";
              break;
            case TableDesign.MediumShading2Accent3:
              val.Value = "MediumShading2-Accent3";
              break;
            case TableDesign.MediumShading2Accent4:
              val.Value = "MediumShading2-Accent4";
              break;
            case TableDesign.MediumShading2Accent5:
              val.Value = "MediumShading2-Accent5";
              break;
            case TableDesign.MediumShading2Accent6:
              val.Value = "MediumShading2-Accent6";
              break;
            case TableDesign.MediumList1:
              val.Value = "MediumList1";
              break;
            case TableDesign.MediumList1Accent1:
              val.Value = "MediumList1-Accent1";
              break;
            case TableDesign.MediumList1Accent2:
              val.Value = "MediumList1-Accent2";
              break;
            case TableDesign.MediumList1Accent3:
              val.Value = "MediumList1-Accent3";
              break;
            case TableDesign.MediumList1Accent4:
              val.Value = "MediumList1-Accent4";
              break;
            case TableDesign.MediumList1Accent5:
              val.Value = "MediumList1-Accent5";
              break;
            case TableDesign.MediumList1Accent6:
              val.Value = "MediumList1-Accent6";
              break;
            case TableDesign.MediumList2:
              val.Value = "MediumList2";
              break;
            case TableDesign.MediumList2Accent1:
              val.Value = "MediumList2-Accent1";
              break;
            case TableDesign.MediumList2Accent2:
              val.Value = "MediumList2-Accent2";
              break;
            case TableDesign.MediumList2Accent3:
              val.Value = "MediumList2-Accent3";
              break;
            case TableDesign.MediumList2Accent4:
              val.Value = "MediumList2-Accent4";
              break;
            case TableDesign.MediumList2Accent5:
              val.Value = "MediumList2-Accent5";
              break;
            case TableDesign.MediumList2Accent6:
              val.Value = "MediumList2-Accent6";
              break;
            case TableDesign.MediumGrid1:
              val.Value = "MediumGrid1";
              break;
            case TableDesign.MediumGrid1Accent1:
              val.Value = "MediumGrid1-Accent1";
              break;
            case TableDesign.MediumGrid1Accent2:
              val.Value = "MediumGrid1-Accent2";
              break;
            case TableDesign.MediumGrid1Accent3:
              val.Value = "MediumGrid1-Accent3";
              break;
            case TableDesign.MediumGrid1Accent4:
              val.Value = "MediumGrid1-Accent4";
              break;
            case TableDesign.MediumGrid1Accent5:
              val.Value = "MediumGrid1-Accent5";
              break;
            case TableDesign.MediumGrid1Accent6:
              val.Value = "MediumGrid1-Accent6";
              break;
            case TableDesign.MediumGrid2:
              val.Value = "MediumGrid2";
              break;
            case TableDesign.MediumGrid2Accent1:
              val.Value = "MediumGrid2-Accent1";
              break;
            case TableDesign.MediumGrid2Accent2:
              val.Value = "MediumGrid2-Accent2";
              break;
            case TableDesign.MediumGrid2Accent3:
              val.Value = "MediumGrid2-Accent3";
              break;
            case TableDesign.MediumGrid2Accent4:
              val.Value = "MediumGrid2-Accent4";
              break;
            case TableDesign.MediumGrid2Accent5:
              val.Value = "MediumGrid2-Accent5";
              break;
            case TableDesign.MediumGrid2Accent6:
              val.Value = "MediumGrid2-Accent6";
              break;
            case TableDesign.MediumGrid3:
              val.Value = "MediumGrid3";
              break;
            case TableDesign.MediumGrid3Accent1:
              val.Value = "MediumGrid3-Accent1";
              break;
            case TableDesign.MediumGrid3Accent2:
              val.Value = "MediumGrid3-Accent2";
              break;
            case TableDesign.MediumGrid3Accent3:
              val.Value = "MediumGrid3-Accent3";
              break;
            case TableDesign.MediumGrid3Accent4:
              val.Value = "MediumGrid3-Accent4";
              break;
            case TableDesign.MediumGrid3Accent5:
              val.Value = "MediumGrid3-Accent5";
              break;
            case TableDesign.MediumGrid3Accent6:
              val.Value = "MediumGrid3-Accent6";
              break;
            case TableDesign.DarkList:
              val.Value = "DarkList";
              break;
            case TableDesign.DarkListAccent1:
              val.Value = "DarkList-Accent1";
              break;
            case TableDesign.DarkListAccent2:
              val.Value = "DarkList-Accent2";
              break;
            case TableDesign.DarkListAccent3:
              val.Value = "DarkList-Accent3";
              break;
            case TableDesign.DarkListAccent4:
              val.Value = "DarkList-Accent4";
              break;
            case TableDesign.DarkListAccent5:
              val.Value = "DarkList-Accent5";
              break;
            case TableDesign.DarkListAccent6:
              val.Value = "DarkList-Accent6";
              break;
            case TableDesign.ColorfulShading:
              val.Value = "ColorfulShading";
              break;
            case TableDesign.ColorfulShadingAccent1:
              val.Value = "ColorfulShading-Accent1";
              break;
            case TableDesign.ColorfulShadingAccent2:
              val.Value = "ColorfulShading-Accent2";
              break;
            case TableDesign.ColorfulShadingAccent3:
              val.Value = "ColorfulShading-Accent3";
              break;
            case TableDesign.ColorfulShadingAccent4:
              val.Value = "ColorfulShading-Accent4";
              break;
            case TableDesign.ColorfulShadingAccent5:
              val.Value = "ColorfulShading-Accent5";
              break;
            case TableDesign.ColorfulShadingAccent6:
              val.Value = "ColorfulShading-Accent6";
              break;
            case TableDesign.ColorfulList:
              val.Value = "ColorfulList";
              break;
            case TableDesign.ColorfulListAccent1:
              val.Value = "ColorfulList-Accent1";
              break;
            case TableDesign.ColorfulListAccent2:
              val.Value = "ColorfulList-Accent2";
              break;
            case TableDesign.ColorfulListAccent3:
              val.Value = "ColorfulList-Accent3";
              break;
            case TableDesign.ColorfulListAccent4:
              val.Value = "ColorfulList-Accent4";
              break;
            case TableDesign.ColorfulListAccent5:
              val.Value = "ColorfulList-Accent5";
              break;
            case TableDesign.ColorfulListAccent6:
              val.Value = "ColorfulList-Accent6";
              break;
            case TableDesign.ColorfulGrid:
              val.Value = "ColorfulGrid";
              break;
            case TableDesign.ColorfulGridAccent1:
              val.Value = "ColorfulGrid-Accent1";
              break;
            case TableDesign.ColorfulGridAccent2:
              val.Value = "ColorfulGrid-Accent2";
              break;
            case TableDesign.ColorfulGridAccent3:
              val.Value = "ColorfulGrid-Accent3";
              break;
            case TableDesign.ColorfulGridAccent4:
              val.Value = "ColorfulGrid-Accent4";
              break;
            case TableDesign.ColorfulGridAccent5:
              val.Value = "ColorfulGrid-Accent5";
              break;
            case TableDesign.ColorfulGridAccent6:
              val.Value = "ColorfulGrid-Accent6";
              break;
          }
        }
        if (this.Document._styles == null)
        {
          using (TextReader textReader = (TextReader) new StreamReader(this.Document._package.GetPart(new Uri("/word/styles.xml", UriKind.Relative)).GetStream()))
            this.Document._styles = XDocument.Load(textReader);
        }
        if (string.IsNullOrEmpty(val.Value) || this.Document._styles.Descendants().Select(e => new
        {
          e = e,
          styleId = e.Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName))
        }).Where(_param1 => _param1.styleId != null && _param1.styleId.Value == val.Value).Select(_param1 => _param1.e).FirstOrDefault<XElement>() != null)
          return;
        XElement xelement3 = HelperFunctions.DecompressXMLResource(HelperFunctions.GetResources(ResourceType.Styles)).Descendants().Select(e => new
        {
          e = e,
          styleId = e.Attribute(XName.Get("styleId", Xceed.Document.NET.Document.w.NamespaceName))
        }).Where(_param1 => _param1.styleId != null && _param1.styleId.Value == val.Value).Select(_param1 => _param1.e).FirstOrDefault<XElement>();
        if (xelement3 == null)
          return;
        this.Document._styles.Element(XName.Get("styles", Xceed.Document.NET.Document.w.NamespaceName)).Add((object) xelement3);
      }
    }

    /// <summary>Gets the Index of this Table.</summary>
    public int Index
    {
      get
      {
        int num = 0;
        foreach (XElement run in this.Xml.ElementsBeforeSelf())
          num += Paragraph.GetElementTextLength(run);
        return num;
      }
    }

    /// <summary>Gets or sets the name of the custom design to apply to this Table.</summary>
    public string CustomTableDesignName
    {
      get => this._customTableDesignName;
      set
      {
        this._customTableDesignName = value;
        this.Design = TableDesign.Custom;
      }
    }

    /// <summary>Gets or sets the Caption of this Table.</summary>
    public string TableCaption
    {
      get
      {
        XElement el = this.Xml.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("tblCaption", Xceed.Document.NET.Document.w.NamespaceName));
        return el != null ? el.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)) : (string) null;
      }
      set
      {
        XElement xelement1 = this.Xml.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 == null)
          return;
        xelement1.Descendants(XName.Get("tblCaption", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>()?.Remove();
        XElement xelement2 = new XElement(XName.Get("tblCaption", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) value));
        xelement1.Add((object) xelement2);
      }
    }

    /// <summary>Gets or sets the Description of this Table.</summary>
    public string TableDescription
    {
      get
      {
        XElement el = this.Xml.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName))?.Element(XName.Get("tblDescription", Xceed.Document.NET.Document.w.NamespaceName));
        return el != null ? el.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName)) : (string) null;
      }
      set
      {
        XElement xelement1 = this.Xml.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement1 == null)
          return;
        xelement1.Descendants(XName.Get("tblDescription", Xceed.Document.NET.Document.w.NamespaceName)).FirstOrDefault<XElement>()?.Remove();
        XElement xelement2 = new XElement(XName.Get("tblDescription", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) value));
        xelement1.Add((object) xelement2);
      }
    }

    /// <summary>Gets or sets the TableLook of this Table.</summary>
    public TableLook TableLook
    {
      get => this._tableLook;
      set
      {
        if (this._tableLook != null)
          this._tableLook.PropertyChanged -= new PropertyChangedEventHandler(this.TableLook_PropertyChanged);
        this._tableLook = value;
        this._tableLook.PropertyChanged += new PropertyChangedEventHandler(this.TableLook_PropertyChanged);
        this.UpdateTableLookXml();
      }
    }

    /// <summary>Gets the collection of Column Widths of this Table (in points).</summary>
    public List<double> ColumnWidths
    {
      get
      {
        List<double> doubleList = new List<double>();
        IEnumerable<XElement> xelements = this.Xml.Element(XName.Get("tblGrid", Xceed.Document.NET.Document.w.NamespaceName))?.Elements(XName.Get("gridCol", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelements == null)
          return (List<double>) null;
        foreach (XElement el in xelements)
        {
          string attribute = el.GetAttribute(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName));
          doubleList.Add(Convert.ToDouble(attribute, (IFormatProvider) new CultureInfo("en-US")) / 20.0);
        }
        return doubleList;
      }
    }

    internal Table(Xceed.Document.NET.Document document, XElement xml, PackagePart packagePart)
      : base(document, xml)
    {
      this._autofit = Table.GetAutoFitFromXml(xml);
      this.Xml = xml;
      this.PackagePart = packagePart;
      XElement xelement1 = xml.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xml.Element(XName.Get("tblGrid", Xceed.Document.NET.Document.w.NamespaceName)) == null)
        this.SetColumnWidth();
      XElement xelement2 = xelement1?.Element(XName.Get("jc", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 != null)
      {
        XAttribute xattribute = xelement2.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null)
          this._alignment = (Alignment) Enum.Parse(typeof (Alignment), xattribute.Value);
      }
      XElement xelement3 = xelement1?.Element(XName.Get("tblStyle", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement3 != null)
      {
        XAttribute xattribute = xelement3.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        if (xattribute != null)
        {
          string str = xattribute.Value.Replace("-", string.Empty);
          if (Enum.IsDefined(typeof (TableDesign), (object) str))
          {
            this.Design = (TableDesign) Enum.Parse(typeof (TableDesign), str);
          }
          else
          {
            this.Design = TableDesign.Custom;
            this.CustomTableDesignName = xattribute.Value;
          }
        }
        else
          this.Design = TableDesign.None;
      }
      else
        this.Design = TableDesign.None;
      XElement el = xelement1?.Element(XName.Get("tblLook", Xceed.Document.NET.Document.w.NamespaceName));
      if (el != null)
      {
        string attribute = el.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
        if (!string.IsNullOrEmpty(attribute))
        {
          int num = int.Parse(attribute, NumberStyles.HexNumber);
          this.TableLook = new TableLook((uint) (num & int.Parse("0020", NumberStyles.HexNumber)) > 0U, (uint) (num & int.Parse("0040", NumberStyles.HexNumber)) > 0U, (uint) (num & int.Parse("0080", NumberStyles.HexNumber)) > 0U, (uint) (num & int.Parse("0100", NumberStyles.HexNumber)) > 0U, (uint) (num & int.Parse("0200", NumberStyles.HexNumber)) > 0U, (uint) (num & int.Parse("0400", NumberStyles.HexNumber)) > 0U);
        }
        else
          this.TableLook = new TableLook(el.GetAttribute(XName.Get("firstRow", Xceed.Document.NET.Document.w.NamespaceName)) == "1", el.GetAttribute(XName.Get("lastRow", Xceed.Document.NET.Document.w.NamespaceName)) == "1", el.GetAttribute(XName.Get("firstColumn", Xceed.Document.NET.Document.w.NamespaceName)) == "1", el.GetAttribute(XName.Get("lastColumn", Xceed.Document.NET.Document.w.NamespaceName)) == "1", el.GetAttribute(XName.Get("noHBand", Xceed.Document.NET.Document.w.NamespaceName)) == "1", el.GetAttribute(XName.Get("noVBand", Xceed.Document.NET.Document.w.NamespaceName)) == "1");
      }
      this._wrappingObjectHelper = (ITableWrappingObject) new TableWrappingObjectHelper(this.Xml);
    }

    /// <summary>Merges cells in a given column, using the provided start and end row indexes.</summary>
    /// <param name="columnIndex">The index of the column where cells are to be merged.</param>
    /// <param name="startRow">The index of the row where the merge begins.</param>
    /// <param name="endRow">The index of the row where the merge ends.</param>
    public void MergeCellsInColumn(int columnIndex, int startRow, int endRow)
    {
      if (columnIndex < 0 || columnIndex >= this.ColumnCount)
        throw new IndexOutOfRangeException();
      if (startRow < 0 || endRow <= startRow || endRow >= this.Rows.Count)
        throw new IndexOutOfRangeException();
      foreach (Row row in this.Rows.Where<Row>((Func<Row, int, bool>) ((z, i) => i > startRow && i <= endRow)))
      {
        Cell cell = row.Cells[columnIndex];
        XElement xelement = cell.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement == null)
        {
          cell.Xml.SetElementValue(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement = cell.Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
        }
        if (xelement.Element(XName.Get("vMerge", Xceed.Document.NET.Document.w.NamespaceName)) == null)
        {
          xelement.SetElementValue(XName.Get("vMerge", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
          xelement.Element(XName.Get("vMerge", Xceed.Document.NET.Document.w.NamespaceName));
        }
      }
      int count = this.Rows[startRow].Cells.Count;
      XElement xelement1 = columnIndex > count ? this.Rows[startRow].Cells[count - 1].Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName)) : this.Rows[startRow].Cells[columnIndex].Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 == null)
      {
        this.Rows[startRow].Cells[columnIndex].Xml.SetElementValue(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
        xelement1 = this.Rows[startRow].Cells[columnIndex].Xml.Element(XName.Get("tcPr", Xceed.Document.NET.Document.w.NamespaceName));
      }
      XElement xelement2 = xelement1.Element(XName.Get("vMerge", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 == null)
      {
        xelement1.SetElementValue(XName.Get("vMerge", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
        xelement2 = xelement1.Element(XName.Get("vMerge", Xceed.Document.NET.Document.w.NamespaceName));
      }
      xelement2.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) "restart");
    }

    /// <summary>Sets the Direction of the content of this Table.</summary>
    /// <param name="direction">The Direction of the content.</param>
    public void SetDirection(Direction direction)
    {
      this.GetOrCreate_tblPr().Add((object) new XElement(Xceed.Document.NET.Document.w + "bidiVisual"));
      foreach (Container row in this.Rows)
        row.SetDirection(direction);
    }

    /// <summary>Removes this Table from this Document.</summary>
    public void Remove() => this.Xml.Remove();

    /// <summary>Inserts a Row in this Table.</summary>
    public Row InsertRow() => this.InsertRow(this.RowCount);

    /// <summary>Inserts a copy of the provided Row at the end of this Table,
    /// and optionally keep the same formatting as the original Row.</summary>
    /// <returns>The new Row that was inserted.</returns>
    /// <param name="row">The Row to copy.</param>
    /// <param name="keepFormatting">
    /// <strong>true</strong> if the format of the original Row is also copied, otherwise <strong>false</strong>.</param>
    public Row InsertRow(Row row, bool keepFormatting = false) => this.InsertRow(row, this.RowCount, keepFormatting);

    /// <summary>Inserts a Column at the right end of this Table.</summary>
    public void InsertColumn() => this.InsertColumn(this.ColumnCount - 1, true);

    /// <summary>Removes a Row from this Table.</summary>
    public void RemoveRow() => this.RemoveRow(this.RowCount - 1);

    /// <summary>Removes a specific column from this Table.</summary>
    /// <param name="index">The index of the row to remove.</param>
    public void RemoveRow(int index)
    {
      if (index < 0 || index > this.RowCount - 1)
        throw new IndexOutOfRangeException();
      this.Rows[index].Xml.Remove();
      if (this.Rows.Count != 0)
        return;
      this.Remove();
    }

    /// <summary>Removes the last column from this Table.</summary>
    public void RemoveColumn() => this.RemoveColumn(this.ColumnCount - 1);

    /// <summary>Removes a specific column from this Table.</summary>
    /// <param name="index">The index of the column to remove.</param>
    public void RemoveColumn(int index)
    {
      if (index < 0 || index > this.ColumnCount - 1)
        throw new IndexOutOfRangeException();
      foreach (Row row in this.Rows)
      {
        if (row.Cells.Count < this.ColumnCount)
        {
          int gridAfter = row.GridAfter;
          int index1 = 0;
          int num1 = 0;
          for (int index2 = 0; index2 < row.Cells.Count; ++index2)
          {
            Cell cell = row.Cells[index2];
            int num2 = cell.GridSpan != 0 ? cell.GridSpan - 1 : 0;
            if (index - gridAfter >= num1 && index - gridAfter <= num1 + num2)
            {
              row.Cells[index1].Xml.Remove();
              break;
            }
            ++index1;
            num1 += num2 + 1;
          }
        }
        else
          row.Cells[index].Xml.Remove();
      }
      this._cachedColumnCount = -1;
    }

    /// <summary>Inserts a Row at a specific location in this Table.</summary>
    /// <returns>The new Row that was inserted.</returns>
    /// <param name="index">The index at which to insert the new Row.</param>
    public Row InsertRow(int index)
    {
      if (index < 0 || index > this.RowCount)
        throw new IndexOutOfRangeException();
      List<XElement> content = new List<XElement>();
      for (int columnIndex = 0; columnIndex < this.ColumnCount; ++columnIndex)
      {
        XElement xelement = this.GetColumnWidth(columnIndex) != double.NaN ? HelperFunctions.CreateTableCell(this.GetColumnWidth(columnIndex) * 20.0) : HelperFunctions.CreateTableCell();
        content.Add(xelement);
      }
      return this.InsertRow(content, index);
    }

    /// <summary>Inserts a copy of the provided Row at a specific location in
    /// this Table, and optionally keep the same formatting as the original Row.</summary>
    /// <returns>The new Row that was inserted.</returns>
    /// <param name="row">The Row to copy.</param>
    /// <param name="index">The index at which to insert the new Row.</param>
    /// <param name="keepFormatting">
    /// <strong>true</strong> if the format of the original Row is also copied, otherwise <strong>false</strong>.</param>
    public Row InsertRow(Row row, int index, bool keepFormatting = false)
    {
      if (row == null)
        throw new ArgumentNullException(nameof (row));
      if (index < 0 || index > this.RowCount)
        throw new IndexOutOfRangeException();
      return this.InsertRow(!keepFormatting ? row.Xml.Elements(XName.Get("tc", Xceed.Document.NET.Document.w.NamespaceName)).Select<XElement, XElement>((Func<XElement, XElement>) (element => HelperFunctions.CloneElement(element))).ToList<XElement>() : row.Xml.Elements().Select<XElement, XElement>((Func<XElement, XElement>) (element => HelperFunctions.CloneElement(element))).ToList<XElement>(), index);
    }

    /// <summary>Inserts a Column at a specific location in this Table.</summary>
    /// <param name="index">The index at which to insert the new Column.</param>
    /// <param name="direction">
    /// <strong>true</strong> to insert the Column on the right side of the indexed Column, <strong>false</strong> to insert on the left side.</param>
    public void InsertColumn(int index, bool direction)
    {
      int columnCount = this.ColumnCount;
      if (index < 0 || index >= columnCount)
        throw new NullReferenceException("index should be greater or equal to 0 and smaller to this.ColumnCount.");
      if (this.RowCount <= 0)
        return;
      this._cachedColumnCount = -1;
      foreach (Row row in this.Rows)
      {
        XElement tableCell = HelperFunctions.CreateTableCell();
        if (row.Cells.Count < columnCount)
        {
          int gridAfter = row.GridAfter;
          int num1 = 0;
          int index1 = 0;
          foreach (Cell cell in row.Cells)
          {
            int num2 = cell.GridSpan != 0 ? cell.GridSpan - 1 : 0;
            if (index - gridAfter >= num1 && index - gridAfter <= num1 + num2)
            {
              bool direction1 = direction && index == num1 + num2;
              this.AddCellToRow(row, tableCell, index1, direction1);
              break;
            }
            ++index1;
            num1 += num2 + 1;
          }
        }
        else
          this.AddCellToRow(row, tableCell, index, direction);
      }
    }

    /// <summary>Inserts a page break before this Table.</summary>
    public override void InsertPageBreakBeforeSelf() => base.InsertPageBreakBeforeSelf();

    /// <summary>Sets the widths of this Table's columns (in points).</summary>
    /// <param name="widths">The array of widths to set (one entry per column, in points).</param>
    public void SetWidths(float[] widths)
    {
      if (widths == null)
        return;
      float totalTableWidth = ((IEnumerable<float>) widths).Sum();
      float num = this.Document.PageWidth - this.Document.MarginLeft - this.Document.MarginRight;
      if (this.AutoFit != AutoFit.Fixed && (double) totalTableWidth > (double) num)
      {
        List<float> newWidths = new List<float>(widths.Length);
        ((IEnumerable<float>) widths).ToList<float>().ForEach((Action<float>) (pWidth => newWidths.Add((float) ((double) pWidth / (double) totalTableWidth * 100.0))));
        this.SetWidthsPercentage(newWidths.ToArray(), new float?(num));
      }
      else
      {
        for (int columnIndex = 0; columnIndex < widths.Length; ++columnIndex)
          this.SetColumnWidth(columnIndex, (double) widths[columnIndex]);
      }
    }

    /// <summary>Sets the widths of this Table's columns, using the provided total width (in points) and a width percentage for each column.</summary>
    /// <param name="widthsPercentage">The array of width percentages to use (in points).</param>
    /// <param name="totalWidth">The total width of the columns. If null, the maximum width available is used.</param>
    public void SetWidthsPercentage(float[] widthsPercentage, float? totalWidth = null)
    {
      if (!totalWidth.HasValue)
        totalWidth = new float?(this.Document.PageWidth - this.Document.MarginLeft - this.Document.MarginRight);
      List<float> widths = new List<float>(widthsPercentage.Length);
      ((IEnumerable<float>) widthsPercentage).ToList<float>().ForEach((Action<float>) (pWidth => widths.Add((float) ((double) pWidth * (double) totalWidth.Value / 100.0 * 1.0))));
      for (int index = 0; index < widths.Count; ++index)
        this.SetColumnWidth(index, (double) widths[index]);
    }

    /// <summary>Inserts a page break after this Table.</summary>
    public override void InsertPageBreakAfterSelf() => base.InsertPageBreakAfterSelf();

    /// <summary>Inserts the provided Table before this Table.</summary>
    /// <returns>The new Table that was inserted.</returns>
    /// <param name="t">The Table to insert.</param>
    public override Table InsertTableBeforeSelf(Table t) => base.InsertTableBeforeSelf(t);

    /// <summary>Inserts a Table of a specific size before this Table.</summary>
    /// <returns>The new Table that was inserted.</returns>
    /// <param name="rowCount">The row count for the new Table.</param>
    /// <param name="columnCount">The column count for the new Table.</param>
    public override Table InsertTableBeforeSelf(int rowCount, int columnCount) => base.InsertTableBeforeSelf(rowCount, columnCount);

    /// <summary>Inserts the provided Table after this Table.</summary>
    /// <returns>The new Table that was inserted.</returns>
    /// <param name="t">The Table to insert.</param>
    public override Table InsertTableAfterSelf(Table t) => base.InsertTableAfterSelf(t);

    /// <summary>Inserts a Table of a specific size after this Table.</summary>
    /// <returns>The new Table that was inserted.</returns>
    /// <param name="rowCount">The row count for the new Table.</param>
    /// <param name="columnCount">The column count for the new Table.</param>
    public override Table InsertTableAfterSelf(int rowCount, int columnCount) => base.InsertTableAfterSelf(rowCount, columnCount);

    /// <summary>Inserts the provided Paragraph before this Table.</summary>
    /// <returns>The new Paragraph that was inserted.</returns>
    /// <param name="p">The Paragraph to insert.</param>
    public override Paragraph InsertParagraphBeforeSelf(Paragraph p) => base.InsertParagraphBeforeSelf(p);

    /// <summary>Inserts a Paragraph before this Table, using the
    /// provided text.</summary>
    /// <returns>The new Paragraph that was inserted.</returns>
    /// <param name="text">The text for the new Paragraph.</param>
    public override Paragraph InsertParagraphBeforeSelf(string text) => base.InsertParagraphBeforeSelf(text);

    /// <summary>Inserts a Paragraph before this Table, using the
    /// provided text, and optionally track this change.</summary>
    /// <returns>The new Paragraph that was inserted.</returns>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public override Paragraph InsertParagraphBeforeSelf(string text, bool trackChanges) => base.InsertParagraphBeforeSelf(text, trackChanges);

    /// <summary>Inserts a Paragraph before this Table, using the
    /// provided text and formatting, and optionally track this change.</summary>
    /// <returns>The new Paragraph that was inserted.</returns>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="formatting">The format to apply to the new Paragraph.</param>
    public override Paragraph InsertParagraphBeforeSelf(
      string text,
      bool trackChanges,
      Formatting formatting)
    {
      return base.InsertParagraphBeforeSelf(text, trackChanges, formatting);
    }

    /// <summary>Inserts the provided Paragraph after this Table.</summary>
    /// <returns>The new Paragraph that was inserted.</returns>
    /// <param name="p">The Paragraph to insert.</param>
    public override Paragraph InsertParagraphAfterSelf(Paragraph p) => base.InsertParagraphAfterSelf(p);

    /// <summary>Inserts a Paragraph after this Table, using the provided
    /// text and formatting, and optionally track this change.</summary>
    /// <returns>The new Paragraph that was inserted.</returns>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    /// <param name="formatting">The format to apply to the new Paragraph.</param>
    public override Paragraph InsertParagraphAfterSelf(
      string text,
      bool trackChanges,
      Formatting formatting)
    {
      return base.InsertParagraphAfterSelf(text, trackChanges, formatting);
    }

    /// <summary>Inserts a Paragraph after this Table, using the provided
    /// text, and optionally track this change.</summary>
    /// <returns>The new Paragraph that was inserted.</returns>
    /// <param name="text">The text for the new Paragraph.</param>
    /// <param name="trackChanges">
    /// <strong>true</strong> if this change should be tracked, otherwise <strong>false</strong>.</param>
    public override Paragraph InsertParagraphAfterSelf(string text, bool trackChanges) => base.InsertParagraphAfterSelf(text, trackChanges);

    /// <summary>Inserts a Paragraph after this Table, using the provided
    /// text.</summary>
    /// <returns>The new Paragraph that was inserted.</returns>
    /// <param name="text">The text for the new Paragraph.</param>
    public override Paragraph InsertParagraphAfterSelf(string text) => base.InsertParagraphAfterSelf(text);

    /// <summary>Sets a border on this Table.</summary>
    /// <param name="borderType">A TableBorderType value indicating which border to set.</param>
    /// <param name="border">The border object to set.</param>
    public void SetBorder(TableBorderType borderType, Border border)
    {
      XElement xelement1 = this.Xml.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 == null)
      {
        this.Xml.SetElementValue(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
        xelement1 = this.Xml.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
      }
      XElement xelement2 = xelement1.Element(XName.Get("tblBorders", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 == null)
      {
        xelement1.SetElementValue(XName.Get("tblBorders", Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
        xelement2 = xelement1.Element(XName.Get("tblBorders", Xceed.Document.NET.Document.w.NamespaceName));
      }
      string str1 = borderType.ToString();
      string localName = str1.Substring(0, 1).ToLower() + str1.Substring(1);
      XElement xelement3 = xelement2.Element(XName.Get(borderType.ToString(), Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement3 == null)
      {
        xelement2.SetElementValue(XName.Get(localName, Xceed.Document.NET.Document.w.NamespaceName), (object) string.Empty);
        xelement3 = xelement2.Element(XName.Get(localName, Xceed.Document.NET.Document.w.NamespaceName));
      }
      string str2 = border.Tcbs.ToString().Substring(5);
      string str3 = str2.Substring(0, 1).ToLower() + str2.Substring(1);
      xelement3.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) str3);
      if (border.Tcbs == BorderStyle.Tcbs_nil)
        return;
      int num;
      switch (border.Size)
      {
        case BorderSize.one:
          num = 2;
          break;
        case BorderSize.two:
          num = 4;
          break;
        case BorderSize.three:
          num = 6;
          break;
        case BorderSize.four:
          num = 8;
          break;
        case BorderSize.five:
          num = 12;
          break;
        case BorderSize.six:
          num = 18;
          break;
        case BorderSize.seven:
          num = 24;
          break;
        case BorderSize.eight:
          num = 36;
          break;
        case BorderSize.nine:
          num = 48;
          break;
        default:
          num = 2;
          break;
      }
      xelement3.SetAttributeValue(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName), (object) num.ToString());
      xelement3.SetAttributeValue(XName.Get("space", Xceed.Document.NET.Document.w.NamespaceName), (object) border.Space.ToString());
      xelement3.SetAttributeValue(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName), (object) border.Color.ToHex());
    }

    /// <summary>Gets a Border from this Table.</summary>
    /// <returns>The Border of the Table.</returns>
    /// <param name="borderType">The type of table border to get.</param>
    public Border GetBorder(TableBorderType borderType)
    {
      Border border = new Border();
      XElement xelement1 = this.Xml.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 == null)
        return border;
      XElement xelement2 = xelement1.Element(XName.Get("tblBorders", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement2 == null)
        return border;
      string str1 = borderType.ToString();
      string localName = str1.Substring(0, 1).ToLower() + str1.Substring(1);
      XElement xelement3 = xelement2.Element(XName.Get(localName, Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement3 == null)
        return border;
      XAttribute xattribute1 = xelement3.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute1 != null)
      {
        try
        {
          string str2 = "Tcbs_" + xattribute1.Value;
          border.Tcbs = (BorderStyle) Enum.Parse(typeof (BorderStyle), str2);
        }
        catch
        {
          xattribute1.Remove();
        }
      }
      XAttribute xattribute2 = xelement3.Attribute(XName.Get("sz", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute2 != null)
      {
        int result;
        if (!HelperFunctions.TryParseInt(xattribute2.Value, out result))
        {
          xattribute2.Remove();
        }
        else
        {
          switch (result)
          {
            case 2:
              border.Size = BorderSize.one;
              break;
            case 4:
              border.Size = BorderSize.two;
              break;
            case 6:
              border.Size = BorderSize.three;
              break;
            case 8:
              border.Size = BorderSize.four;
              break;
            case 12:
              border.Size = BorderSize.five;
              break;
            case 18:
              border.Size = BorderSize.six;
              break;
            case 24:
              border.Size = BorderSize.seven;
              break;
            case 36:
              border.Size = BorderSize.eight;
              break;
            case 48:
              border.Size = BorderSize.nine;
              break;
            default:
              border.Size = BorderSize.one;
              break;
          }
        }
      }
      XAttribute xattribute3 = xelement3.Attribute(XName.Get("space", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute3 != null)
      {
        float result;
        if (!HelperFunctions.TryParseFloat(xattribute3.Value, out result))
          xattribute3.Remove();
        else
          border.Space = result;
      }
      XAttribute xattribute4 = xelement3.Attribute(XName.Get("color", Xceed.Document.NET.Document.w.NamespaceName));
      if (xattribute4 != null)
      {
        try
        {
          border.Color = HelperFunctions.GetColorFromHtml(xattribute4.Value);
        }
        catch
        {
          xattribute4.Remove();
        }
      }
      return border;
    }

    /// <summary>Gets the width of the specified column (in points).</summary>
    /// <returns>The width of the specified column (in points).</returns>
    /// <param name="columnIndex">The index of the column.</param>
    public double GetColumnWidth(int columnIndex)
    {
      List<double> columnWidths = this.ColumnWidths;
      return columnWidths == null || columnIndex > columnWidths.Count - 1 ? double.NaN : columnWidths[columnIndex];
    }

    /// <summary>Sets the width of the specified column (in points).</summary>
    /// <param name="columnIndex">The index of the column.</param>
    /// <param name="width">The width to apply (in points).</param>
    public void SetColumnWidth(int columnIndex = 0, double width = -1.0)
    {
      List<double> source1 = this.ColumnWidths;
      if (source1 == null || columnIndex > source1.Count - 1)
      {
        if (this.Rows.Count == 0)
          throw new Exception("There is at least one row required to detect the existing columns.");
        source1 = new List<double>();
        foreach (Cell cell in this.Rows[this.Rows.Count - 1].Cells)
          source1.Add(cell.Width);
        if (source1.Contains(double.NaN))
        {
          double num1 = (double) this.Document.PageWidth - (double) this.Document.MarginLeft - (double) this.Document.MarginRight;
          IEnumerable<double> source2 = source1.Where<double>((Func<double, bool>) (c => !double.IsNaN(c)));
          double num2 = source2.Sum();
          double num3 = (num1 - num2) / (double) (source1.Count - source2.Count<double>());
          for (int index = 0; index < source1.Count; ++index)
          {
            if (double.IsNaN(source1[index]))
              source1[index] = num3;
          }
        }
      }
      if (columnIndex > source1.Count - 1)
        throw new Exception("The index is greather than the available table columns.");
      XElement xelement1 = this.Xml.Element(XName.Get("tblGrid", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 == null)
      {
        this.GetOrCreate_tblPr().AddAfterSelf((object) new XElement(XName.Get("tblGrid", Xceed.Document.NET.Document.w.NamespaceName)));
        xelement1 = this.Xml.Element(XName.Get("tblGrid", Xceed.Document.NET.Document.w.NamespaceName));
      }
      xelement1?.RemoveAll();
      int num4 = 0;
      foreach (double num1 in source1)
      {
        double num2 = num1;
        if (num4 == columnIndex && width >= 0.0)
          num2 = width;
        XElement xelement2 = new XElement(XName.Get("gridCol", Xceed.Document.NET.Document.w.NamespaceName), (object) new XAttribute(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName), (object) (num2 * 20.0)));
        xelement1?.Add((object) xelement2);
        ++num4;
      }
      if (width < 0.0)
        return;
      foreach (Row row in this.Rows)
      {
        foreach (Cell cell in row.Cells)
          cell.Width = -1.0;
      }
      this.AutoFit = AutoFit.Fixed;
    }

    /// <summary>Sets a cell margin on this Table (in points).</summary>
    /// <param name="type">A TableCellMarginType value indicating which margin to set.</param>
    /// <param name="margin">The margin value to set (in points).</param>
    public void SetTableCellMargin(TableCellMarginType type, double margin)
    {
      XElement tblPr = this.GetOrCreate_tblPr();
      XName name1 = XName.Get("tblCellMar", Xceed.Document.NET.Document.w.NamespaceName);
      XName name2 = XName.Get(type.ToString(), Xceed.Document.NET.Document.w.NamespaceName);
      XElement xelement1 = tblPr.Element(name1);
      if (xelement1 == null)
      {
        tblPr.Add((object) new XElement(name1));
        xelement1 = tblPr.Element(name1);
      }
      XElement xelement2 = xelement1.Element(name2);
      if (xelement2 == null)
      {
        xelement1.AddFirst((object) new XElement(name2));
        xelement2 = xelement1.Element(name2);
      }
      xelement2.RemoveAttributes();
      xelement2.Add((object) new XAttribute(XName.Get("w", Xceed.Document.NET.Document.w.NamespaceName), (object) (margin * 20.0)));
      xelement2.Add((object) new XAttribute(XName.Get(nameof (type), Xceed.Document.NET.Document.w.NamespaceName), (object) "dxa"));
    }

    /// <summary>Deletes a Cell in a <see cref="Xceed.Document.NET~Xceed.Document.NET.Row.html">Row</see>, and shifts
    /// the other Cells to the left.</summary>
    /// <param name="rowIndex">The index of the Row where a Cell will be removed..</param>
    /// <param name="celIndex">The index of the Cell to remove.</param>
    public void DeleteAndShiftCellsLeft(int rowIndex, int celIndex)
    {
      XElement xelement1 = this.Rows[rowIndex].Xml.Element(XName.Get("trPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement1 != null)
      {
        XElement xelement2 = xelement1.Element(XName.Get("gridAfter", Xceed.Document.NET.Document.w.NamespaceName));
        if (xelement2 != null)
        {
          XAttribute xattribute = xelement2.Attribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName));
          xattribute.Value = xattribute != null ? int.Parse(xattribute.Value).ToString() : "1";
        }
        else
          xelement2.SetAttributeValue((XName) "val", (object) 1);
      }
      else
      {
        XElement xelement2 = new XElement(XName.Get("gridAfter", Xceed.Document.NET.Document.w.NamespaceName));
        XAttribute xattribute = new XAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) 1);
        xelement2.Add((object) xattribute);
        XElement xelement3 = new XElement(XName.Get("trPr", Xceed.Document.NET.Document.w.NamespaceName));
        xelement3.Add((object) xelement2);
        this.Rows[rowIndex].Xml.AddFirst((object) xelement3);
      }
      if (celIndex > this.ColumnCount || this.Rows[rowIndex].ColumnCount > this.ColumnCount)
        return;
      this.Rows[rowIndex].Cells[celIndex].Xml.Remove();
    }

    internal static AutoFit GetAutoFitFromXml(XElement xml)
    {
      if (xml == null)
        return AutoFit.ColumnWidth;
      IEnumerable<XAttribute> source1 = xml.Descendants().Select(d => new
      {
        d = d,
        type = d.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName))
      }).Where(_param1 => _param1.d.Name.LocalName == "tblW" && _param1.type != null).Select(_param1 => _param1.type);
      IEnumerable<XAttribute> source2 = xml.Descendants().Select(d => new
      {
        d = d,
        type = d.Attribute(XName.Get("type", Xceed.Document.NET.Document.w.NamespaceName))
      }).Where(_param1 => _param1.d.Name.LocalName == "tcW" && _param1.type != null).Select(_param1 => _param1.type);
      if (source1.All<XAttribute>((Func<XAttribute, bool>) (type => type.Value == "auto")) && source2.All<XAttribute>((Func<XAttribute, bool>) (type => type.Value == "auto")))
        return AutoFit.Contents;
      if (source1.All<XAttribute>((Func<XAttribute, bool>) (type => type.Value == "dxa")) && source2.All<XAttribute>((Func<XAttribute, bool>) (type => type.Value == "dxa")))
        return AutoFit.Fixed;
      return source1.All<XAttribute>((Func<XAttribute, bool>) (type => type.Value == "pct")) && source2.All<XAttribute>((Func<XAttribute, bool>) (type => type.Value == "pct")) ? AutoFit.Window : AutoFit.ColumnWidth;
    }

    internal XElement GetOrCreate_tblPr()
    {
      XElement xelement = this.Xml.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
      if (xelement == null)
      {
        this.Xml.AddFirst((object) new XElement(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName)));
        xelement = this.Xml.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
      }
      return xelement;
    }

    private Row InsertRow(List<XElement> content, int index)
    {
      Row row = new Row(this, this.Document, new XElement(XName.Get("tr", Xceed.Document.NET.Document.w.NamespaceName), (object) content));
      if (index == this.Rows.Count)
        this.Rows.Last<Row>().Xml.AddAfterSelf((object) row.Xml);
      else
        this.Rows[index].Xml.AddBeforeSelf((object) row.Xml);
      return row;
    }

    private void AddCellToRow(Row row, XElement cell, int index, bool direction)
    {
      if (index >= row.Cells.Count)
        throw new IndexOutOfRangeException("index is greater or equals to row.Cells.Count.");
      if (direction)
        row.Cells[index].Xml.AddAfterSelf((object) cell);
      else
        row.Cells[index].Xml.AddBeforeSelf((object) cell);
    }

    private void UpdateTableLookXml()
    {
      XElement xelement = this.Xml.Element(XName.Get("tblPr", Xceed.Document.NET.Document.w.NamespaceName));
      XElement el = xelement.Element(XName.Get("tblLook", Xceed.Document.NET.Document.w.NamespaceName));
      if (el == null)
      {
        xelement.Add((object) new XElement(XName.Get("tblLook", Xceed.Document.NET.Document.w.NamespaceName)));
        el = xelement.Element(XName.Get("tblLook", Xceed.Document.NET.Document.w.NamespaceName));
      }
      if (!string.IsNullOrEmpty(el.GetAttribute(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName))))
      {
        int num = 0;
        if (this._tableLook.FirstRow)
          num += 32;
        if (this._tableLook.LastRow)
          num += 64;
        if (this._tableLook.FirstColumn)
          num += 128;
        if (this._tableLook.LastColumn)
          num += 256;
        if (this._tableLook.NoHorizontalBanding)
          num += 512;
        if (this._tableLook.NoVerticalBanding)
          num += 1024;
        el.SetAttributeValue(XName.Get("val", Xceed.Document.NET.Document.w.NamespaceName), (object) num.ToString("X4"));
      }
      else
      {
        el.SetAttributeValue(XName.Get("firstRow", Xceed.Document.NET.Document.w.NamespaceName), this._tableLook.FirstRow ? (object) "1" : (object) "0");
        el.SetAttributeValue(XName.Get("lastRow", Xceed.Document.NET.Document.w.NamespaceName), this._tableLook.LastRow ? (object) "1" : (object) "0");
        el.SetAttributeValue(XName.Get("firstColumn", Xceed.Document.NET.Document.w.NamespaceName), this._tableLook.FirstColumn ? (object) "1" : (object) "0");
        el.SetAttributeValue(XName.Get("lastColumn", Xceed.Document.NET.Document.w.NamespaceName), this._tableLook.LastColumn ? (object) "1" : (object) "0");
        el.SetAttributeValue(XName.Get("noHBand", Xceed.Document.NET.Document.w.NamespaceName), this._tableLook.NoHorizontalBanding ? (object) "1" : (object) "0");
        el.SetAttributeValue(XName.Get("noVBand", Xceed.Document.NET.Document.w.NamespaceName), this._tableLook.NoVerticalBanding ? (object) "1" : (object) "0");
      }
    }

    private void TableLook_PropertyChanged(object sender, PropertyChangedEventArgs e) => this.UpdateTableLookXml();

    /// <summary>Gets or sets the wrapping style for this Table.</summary>
    public TableWrappingStyle WrappingStyle
    {
      get => this._wrappingObjectHelper.WrappingStyle;
      set => this._wrappingObjectHelper.WrappingStyle = value;
    }

    /// <summary>Gets or sets the horizontal alignment for this Table.</summary>
    public WrappingHorizontalAlignment HorizontalAlignment
    {
      get => this._wrappingObjectHelper.HorizontalAlignment;
      set => this._wrappingObjectHelper.HorizontalAlignment = value;
    }

    /// <summary>Gets or sets the horizontal offset of this Table relative to the element identified in the HorizontalOffsetAlignmentFrom property.</summary>
    public double HorizontalOffset
    {
      get => this._wrappingObjectHelper.HorizontalOffset;
      set => this._wrappingObjectHelper.HorizontalOffset = value;
    }

    /// <summary>Gets or sets the element from which the HorizontalOffset is calculated.</summary>
    public WrappingHorizontalOffsetAlignmentFrom HorizontalOffsetAlignmentFrom
    {
      get => this._wrappingObjectHelper.HorizontalOffsetAlignmentFrom;
      set => this._wrappingObjectHelper.HorizontalOffsetAlignmentFrom = value;
    }

    /// <summary>Gets or sets the vertical alignment for this Table.</summary>
    public WrappingVerticalAlignment VerticalAlignment
    {
      get => this._wrappingObjectHelper.VerticalAlignment;
      set => this._wrappingObjectHelper.VerticalAlignment = value;
    }

    /// <summary>Gets or sets the vertical offset of this Table relative to the element identified in the VerticalOffsetAlignmentFrom property.</summary>
    public double VerticalOffset
    {
      get => this._wrappingObjectHelper.VerticalOffset;
      set => this._wrappingObjectHelper.VerticalOffset = value;
    }

    /// <summary>Gets or sets the element from which the VerticalOffset is calculated.</summary>
    public WrappingVerticalOffsetAlignmentFrom VerticalOffsetAlignmentFrom
    {
      get => this._wrappingObjectHelper.VerticalOffsetAlignmentFrom;
      set => this._wrappingObjectHelper.VerticalOffsetAlignmentFrom = value;
    }

    /// <summary>Gets or sets the distance of the text from the left of this Table.</summary>
    public double DistanceFromTextLeft
    {
      get => this._wrappingObjectHelper.DistanceFromTextLeft;
      set => this._wrappingObjectHelper.DistanceFromTextLeft = value;
    }

    /// <summary>Gets or sets the distance of the text from the right of this Table.</summary>
    public double DistanceFromTextRight
    {
      get => this._wrappingObjectHelper.DistanceFromTextRight;
      set => this._wrappingObjectHelper.DistanceFromTextRight = value;
    }

    /// <summary>Gets or sets the distance of the text from the top of this Table.</summary>
    public double DistanceFromTextTop
    {
      get => this._wrappingObjectHelper.DistanceFromTextTop;
      set => this._wrappingObjectHelper.DistanceFromTextTop = value;
    }

    /// <summary>Gets or sets the distance of the text from the bottom of this Table.</summary>
    public double DistanceFromTextBottom
    {
      get => this._wrappingObjectHelper.DistanceFromTextBottom;
      set => this._wrappingObjectHelper.DistanceFromTextBottom = value;
    }
  }
}
