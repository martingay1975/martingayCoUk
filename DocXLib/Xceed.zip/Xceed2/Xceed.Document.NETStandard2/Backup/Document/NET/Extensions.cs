﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Extensions
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  internal static class Extensions
  {
    internal static string ToHex(this Color source)
    {
      byte r = source.R;
      byte g = source.G;
      byte b = source.B;
      string str1 = r.ToString("X");
      if (str1.Length < 2)
        str1 = "0" + str1;
      string str2 = b.ToString("X");
      if (str2.Length < 2)
        str2 = "0" + str2;
      string str3 = g.ToString("X");
      if (str3.Length < 2)
        str3 = "0" + str3;
      return string.Format("{0}{1}{2}", (object) str1, (object) str3, (object) str2);
    }

    public static void Flatten(this XElement e, XName name, List<XElement> flat)
    {
      XElement xelement = Extensions.CloneElement(e);
      xelement.Elements().Remove<XElement>();
      if (xelement.Name == name)
        flat.Add(xelement);
      if (!e.HasElements)
        return;
      foreach (XElement element in e.Elements(name))
        element.Flatten(name, flat);
    }

    public static string GetAttribute(this XElement el, XName name, string defaultValue = "")
    {
      XAttribute xattribute = el.Attribute(name);
      return xattribute != null ? xattribute.Value : defaultValue;
    }

    public static void SetMargin(
      this Xceed.Document.NET.Document document,
      float top,
      float bottom,
      float right,
      float left)
    {
      Extensions.SetMargin(document.Sections[0], top, bottom, right, left);
    }

    public static void SetMargin(
      Section section,
      float top,
      float bottom,
      float right,
      float left)
    {
      if (section == null)
        return;
      string str = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
      IEnumerable<XElement> xelements = section.PageLayout.Xml.Descendants((XName) (str + "pgMar"));
      int num = 1440;
      foreach (XElement xelement in xelements)
      {
        if ((double) top != -1.0)
          xelement.SetAttributeValue((XName) (str + nameof (top)), (object) (float) ((double) num * (double) top));
        if ((double) bottom != -1.0)
          xelement.SetAttributeValue((XName) (str + nameof (bottom)), (object) (float) ((double) num * (double) bottom));
        if ((double) right != -1.0)
          xelement.SetAttributeValue((XName) (str + nameof (right)), (object) (float) ((double) num * (double) right));
        if ((double) left != -1.0)
          xelement.SetAttributeValue((XName) (str + nameof (left)), (object) (float) ((double) num * (double) left));
      }
    }

    private static XElement CloneElement(XElement element) => new XElement(element.Name, new object[2]
    {
      (object) element.Attributes(),
      (object) element.Nodes().Select<XNode, XNode>((Func<XNode, XNode>) (n => n is XElement element1 ? (XNode) Extensions.CloneElement(element1) : n))
    });
  }
}
