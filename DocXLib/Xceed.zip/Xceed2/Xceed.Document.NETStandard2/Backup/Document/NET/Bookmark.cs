﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.Bookmark
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

namespace Xceed.Document.NET
{
  /// <summary>Represents a Bookmark.</summary>
  public class Bookmark
  {
    /// <summary>Gets or sets the Name of this Bookmark.</summary>
    public string Name { get; set; }

    /// <summary>Gets or sets at which Paragraph this Bookmark is located.</summary>
    public Paragraph Paragraph { get; set; }

    /// <summary>Initializes a new instance of the <strong>Bookmark</strong> class.</summary>
    public Bookmark() => Licenser.VerifyLicense();

    /// <summary>Sets the text of this Bookmark.</summary>
    /// <param name="text">The text of this bookmark.</param>
    public void SetText(string text) => this.Paragraph.ReplaceAtBookmark(text, this.Name);

    /// <summary>Sets the text of this Bookmark using the provided format.</summary>
    /// <param name="text">The text of this bookmark.</param>
    /// <param name="formatting">
    ///   <span id="BugEvents">The format to apply to the bookmark text.</span>
    /// </param>
    public void SetText(string text, Formatting formatting = null) => this.Paragraph.ReplaceAtBookmark(text, this.Name, formatting);

    /// <summary>Removes this Bookmark from the Document. The Paragraph will remain.</summary>
    public void Remove() => this.Paragraph.RemoveBookmark(this.Name);
  }
}
