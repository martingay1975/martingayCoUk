﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.TableLook
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System.ComponentModel;

namespace Xceed.Document.NET
{
  /// <summary>Represents a TableLook.</summary>
  public class TableLook : INotifyPropertyChanged
  {
    private bool _firstRow;
    private bool _lastRow;
    private bool _firstColumn;
    private bool _lastColumn;
    private bool _noHorizontalBanding;
    private bool _noVerticalBanding;

    /// <summary>Gets or sets if the First Row conditional formatting is applied to this Table.</summary>
    public bool FirstRow
    {
      get => this._firstRow;
      set
      {
        this._firstRow = value;
        this.OnPropertyChanged(nameof (FirstRow));
      }
    }

    /// <summary>Gets or sets if the Last Row conditional formatting is applied to this Table.</summary>
    public bool LastRow
    {
      get => this._lastRow;
      set
      {
        this._lastRow = value;
        this.OnPropertyChanged(nameof (LastRow));
      }
    }

    /// <summary>Gets or sets if the First Column conditional formatting is applied to this Table.</summary>
    public bool FirstColumn
    {
      get => this._firstColumn;
      set
      {
        this._firstColumn = value;
        this.OnPropertyChanged(nameof (FirstColumn));
      }
    }

    /// <summary>Gets or sets if the Last Column conditional formatting is applied to this Table.</summary>
    public bool LastColumn
    {
      get => this._lastColumn;
      set
      {
        this._lastColumn = value;
        this.OnPropertyChanged(nameof (LastColumn));
      }
    }

    /// <summary>Gets or sets if the horizontal banding conditional formatting is not applied to this Table.</summary>
    public bool NoHorizontalBanding
    {
      get => this._noHorizontalBanding;
      set
      {
        this._noHorizontalBanding = value;
        this.OnPropertyChanged(nameof (NoHorizontalBanding));
      }
    }

    /// <summary>Gets or sets if the vertical banding conditional formatting is not applied to this Table.</summary>
    public bool NoVerticalBanding
    {
      get => this._noVerticalBanding;
      set
      {
        this._noVerticalBanding = value;
        this.OnPropertyChanged(nameof (NoVerticalBanding));
      }
    }

    /// <summary>Initializes a new instance of the <strong>TableLook</strong> class.</summary>
    public TableLook()
    {
    }

    /// <summary>Initializes a new instance of the <strong>TableLook</strong> class, using the provided values for FirstRow, LastRow, FirstColumn, LastColumn, and specififying
    /// if no Horizontal or Vertical Banding is applied.</summary>
    /// <param name="firstRow">
    /// <strong>true</strong> if the First Row conditional formatting is applied to the Table, otherwise <strong>false</strong>.</param>
    /// <param name="lastRow">
    /// <strong>true</strong> if the Last Row conditional formatting is applied to the Table, otherwise <strong>false</strong>.</param>
    /// <param name="firstColumn">
    /// <strong>true</strong> if the First Column conditional formatting is applied to the Table, otherwise <strong>false</strong>.</param>
    /// <param name="lastColumn">
    /// <strong>true</strong> if the Last Column conditional formatting is applied to the Table, otherwise <strong>false</strong>.</param>
    /// <param name="noHorizontalBanding">
    /// <strong>true</strong> if the Horizontal Banding conditional formatting is <strong>NOT</strong> applied to the Table, otherwise <strong>false</strong>.</param>
    /// <param name="noVerticalBanding">
    /// <strong>true</strong> if the Vertical Banding conditional formatting is <strong>NOT</strong> applied to the Table, otherwise <strong>false</strong>.</param>
    public TableLook(
      bool firstRow,
      bool lastRow,
      bool firstColumn,
      bool lastColumn,
      bool noHorizontalBanding,
      bool noVerticalBanding)
    {
      this.FirstRow = firstRow;
      this.LastRow = lastRow;
      this.FirstColumn = firstColumn;
      this.LastColumn = lastColumn;
      this.NoHorizontalBanding = noHorizontalBanding;
      this.NoVerticalBanding = noVerticalBanding;
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected void OnPropertyChanged(string propertyName)
    {
      if (this.PropertyChanged == null)
        return;
      this.PropertyChanged((object) this, new PropertyChangedEventArgs(propertyName));
    }
  }
}
