﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.BarChart
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Globalization;
using System.IO.Packaging;
using System.Xml.Linq;

namespace Xceed.Document.NET
{
  /// <summary>Represents a Bar Chart.</summary>
  public class BarChart : Chart
  {
    /// <summary>Gets or sets the direction of the bars in this BarChart.</summary>
    public BarDirection BarDirection
    {
      get => XElementHelpers.GetValueToEnum<BarDirection>(this.ChartXml.Element(XName.Get("barDir", Xceed.Document.NET.Document.c.NamespaceName)));
      set => XElementHelpers.SetValueFromEnum<BarDirection>(this.ChartXml.Element(XName.Get("barDir", Xceed.Document.NET.Document.c.NamespaceName)), value);
    }

    /// <summary>Gets or sets the type of grouping used for this BarChart.</summary>
    public BarGrouping BarGrouping
    {
      get => XElementHelpers.GetValueToEnum<BarGrouping>(this.ChartXml.Element(XName.Get("grouping", Xceed.Document.NET.Document.c.NamespaceName)));
      set
      {
        XElementHelpers.SetValueFromEnum<BarGrouping>(this.ChartXml.Element(XName.Get("grouping", Xceed.Document.NET.Document.c.NamespaceName)), value);
        string str = value == BarGrouping.Stacked || value == BarGrouping.PercentStacked ? "100" : "0";
        XElement xelement = this.ChartXml.Element(XName.Get("overlap", Xceed.Document.NET.Document.c.NamespaceName));
        if (xelement == null)
          return;
        xelement.Attribute(XName.Get("val")).Value = str;
      }
    }

    /// <summary>Gets or sets which percentage of the bar is used as a gap (value between 0% and 500%).</summary>
    public int GapWidth
    {
      get => Convert.ToInt32(this.ChartXml.Element(XName.Get("gapWidth", Xceed.Document.NET.Document.c.NamespaceName)).Attribute(XName.Get("val")).Value);
      set => this.ChartXml.Element(XName.Get("gapWidth", Xceed.Document.NET.Document.c.NamespaceName)).Attribute(XName.Get("val")).Value = value >= 1 && value <= 500 ? value.ToString((IFormatProvider) CultureInfo.InvariantCulture) : throw new ArgumentException("GapWidth lay between 0% and 500%!");
    }

    /// <summary>Initializes a new instance of the <strong>BarChart</strong> class.</summary>
    public BarChart()
    {
    }

    internal BarChart(PackagePart packagePart, XDocument chartDocument)
      : base(packagePart, chartDocument)
    {
    }

    /// <summary>Creates the XML for this BarChart.</summary>
    /// <returns>An XElement value representing the XML for the BarChart.</returns>
    protected override XElement CreateChartXml() => XElement.Parse("<c:barChart xmlns:c=\"http://schemas.openxmlformats.org/drawingml/2006/chart\">\r\n                    <c:barDir val=\"col\"/>\r\n                    <c:grouping val=\"clustered\"/>                    \r\n                    <c:gapWidth val=\"150\"/>\r\n                    <c:overlap val=\"0\"/>\r\n                  </c:barChart>");
  }
}
