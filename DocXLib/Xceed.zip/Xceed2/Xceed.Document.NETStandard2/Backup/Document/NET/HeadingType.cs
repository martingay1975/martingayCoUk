﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.HeadingType
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System.ComponentModel;

namespace Xceed.Document.NET
{
  /// <summary>Value indicating the type of heading.</summary>
  public enum HeadingType
  {
    [Description("Heading1")] Heading1,
    [Description("Heading2")] Heading2,
    [Description("Heading3")] Heading3,
    [Description("Heading4")] Heading4,
    [Description("Heading5")] Heading5,
    [Description("Heading6")] Heading6,
    [Description("Heading7")] Heading7,
    [Description("Heading8")] Heading8,
    [Description("Heading9")] Heading9,
  }
}
