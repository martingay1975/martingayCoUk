﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.WrappingHorizontalAlignment
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

namespace Xceed.Document.NET
{
  /// <summary>
  ///         <span style="FONT-SIZE: 13px; FONT-FAMILY: &amp;quot;Segoe UI&amp;quot;, Verdana, Arial; WHITE-SPACE: normal; WORD-SPACING: 0px; TEXT-TRANSFORM: none; FLOAT: none; FONT-WEIGHT: 400; COLOR: rgb(0,0,0); FONT-STYLE: normal; ORPHANS: 2; WIDOWS: 2; DISPLAY: inline !important; LETTER-SPACING: normal; TEXT-INDENT: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
  /// Value indicating the horizontal alignment of an element.</span>
  ///       </summary>
  public enum WrappingHorizontalAlignment
  {
    /// <summary>Not using any horizontal alignment.</summary>
    None,
    /// <summary>Element is horizontally aligned from its Left relative to the margin.</summary>
    LeftRelativeToMargin,
    /// <summary>Element is horizontally aligned from its Left relative to the page left position.</summary>
    LeftRelativeToPage,
    /// <summary>Element is horizontally aligned from its Left relative to the text column.</summary>
    LeftRelativeToColumn,
    /// <summary>Element is horizontally aligned from its Left relative to the associated character.</summary>
    LeftRelativeToCharacter,
    /// <summary>Element is horizontally aligned from its Left relative to the left margin.</summary>
    LeftRelativeToLeftMargin,
    /// <summary>Element is horizontally aligned from its Left relative to the right margin.</summary>
    LeftRelativeToRightMargin,
    /// <summary>Element is horizontally aligned from its Left relative to the inside margin.</summary>
    LeftRelativeToInsideMargin,
    /// <summary>Element is horizontally aligned from its Left relative to the outside margin.</summary>
    LeftRelativeToOutsideMargin,
    /// <summary>Element is horizontally aligned from its Center relative to the left margin.</summary>
    CenteredRelativeToMargin,
    /// <summary>Element is horizontally aligned from its Center relative to the page center position.</summary>
    CenteredRelativeToPage,
    /// <summary>Element is horizontally aligned from its Center relative to the text column.</summary>
    CenteredRelativeToColumn,
    /// <summary>Element is horizontally aligned from its Center relative to the associated character.</summary>
    CenteredRelativeToCharacter,
    /// <summary>Element is horizontally aligned from its Center relative to the left margin.</summary>
    CenteredRelativeToLeftMargin,
    /// <summary>Element is horizontally aligned from its Center relative to the right margin.</summary>
    CenteredRelativeToRightMargin,
    /// <summary>Element is horizontally aligned from its Center relative to the inside margin.</summary>
    CenteredRelativeToInsideMargin,
    /// <summary>Element is horizontally aligned from its Center relative to the outside margin.</summary>
    CenteredRelativeToOutsideMargin,
    /// <summary>Element is horizontally aligned from its Right relative to the margin.</summary>
    RightRelativeToMargin,
    /// <summary>Element is horizontally aligned from its Right relative to the page right position.</summary>
    RightRelativeToPage,
    /// <summary>Element is horizontally aligned from its Right relative to the text column.</summary>
    RightRelativeToColumn,
    /// <summary>Element is horizontally aligned from its Right relative to the associated character.</summary>
    RightRelativeToCharacter,
    /// <summary>Element is horizontally aligned from its Right relative to the left margin.</summary>
    RightRelativeToLeftMargin,
    /// <summary>Element is horizontally aligned from its Right relative to the right margin.</summary>
    RightRelativeToRightMargin,
    /// <summary>Element is horizontally aligned from its Right relative to the inside margin.</summary>
    RightRelativeToInsideMargin,
    /// <summary>Element is horizontally aligned from its Right relative to the outside margin.</summary>
    RightRelativeToOutsideMargin,
    /// <summary>Element is horizontally aligned from its Left inside of the margin.</summary>
    InsideOfMargin,
    /// <summary>Element is horizontally aligned from its Left inside of the page.</summary>
    InsideOfPage,
    /// <summary>Element is horizontally aligned from its Left outside of the margin.</summary>
    OutsideOfMargin,
    /// <summary>Element is horizontally aligned from its Left outside of the page.</summary>
    OutsideOfPage,
  }
}
