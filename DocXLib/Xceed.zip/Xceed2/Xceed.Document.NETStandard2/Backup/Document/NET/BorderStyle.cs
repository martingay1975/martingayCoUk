﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Document.NET.BorderStyle
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

namespace Xceed.Document.NET
{
  /// <summary>Value indicating the style to apply to a border.</summary>
  public enum BorderStyle
  {
    Tcbs_none,
    Tcbs_single,
    Tcbs_thick,
    Tcbs_double,
    Tcbs_dotted,
    Tcbs_dashed,
    Tcbs_dotDash,
    Tcbs_dotDotDash,
    Tcbs_triple,
    Tcbs_thinThickSmallGap,
    Tcbs_thickThinSmallGap,
    Tcbs_thinThickThinSmallGap,
    Tcbs_thinThickMediumGap,
    Tcbs_thickThinMediumGap,
    Tcbs_thinThickThinMediumGap,
    Tcbs_thinThickLargeGap,
    Tcbs_thickThinLargeGap,
    Tcbs_thinThickThinLargeGap,
    Tcbs_wave,
    Tcbs_doubleWave,
    Tcbs_dashSmallGap,
    Tcbs_dashDotStroked,
    Tcbs_threeDEmboss,
    Tcbs_threeDEngrave,
    Tcbs_outset,
    Tcbs_inset,
    Tcbs_nil,
  }
}
