﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Utils.Licensing.XceedLicense
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Collections.Generic;
using Xceed.Utils.Exceptions;

namespace Xceed.Utils.Licensing
{
  internal abstract class XceedLicense
  {
    private string m_licenseKey = "";
    private bool m_trial;
    private LicenseProduct m_product;
    private byte m_versionMajor;
    private byte m_versionMinor;
    private byte m_nbLicenses;
    private bool m_siteLicense;
    private int m_daysLeft;
    private bool m_isFromRegistry;
    private List<LicenseInformationType> m_performedFeratureAnalysis = new List<LicenseInformationType>();
    internal const string LicensesRegistryLocation = "Licenses\\4507C5F2-9077-40DE-A621-64EC59BF6829\\";
    internal const string UserLicensesRegistryLocation = "Software\\Xceed Software\\Licenses\\";

    public void Analyse(ref string licenseKey) => this.Analyse(ref licenseKey, true);

    public void Analyse(ref string licenseKey, bool allowThrow)
    {
      XceedLicenseManager lm = new XceedLicenseManager();
      this.ValidateLicenseKey(ref lm, ref licenseKey, true, allowThrow);
      this.m_licenseKey = licenseKey;
      this.m_nbLicenses = lm.NbLicenses;
      this.m_siteLicense = lm.IsSiteLicense;
      this.m_trial = lm.Originator >= LicenseOrigin.TrialVersion && lm.Originator <= LicenseOrigin.TrialRenew9;
      if (this.m_trial)
      {
        DateTime dateTime = lm.Date;
        long ticks1 = dateTime.Ticks;
        dateTime = DateTime.Today;
        long ticks2 = dateTime.Ticks;
        this.m_daysLeft = new TimeSpan(ticks1 - ticks2).Days;
      }
      this.m_product = lm.Product;
      this.m_versionMajor = lm.VerMajor;
      this.m_versionMinor = lm.VerMinor;
    }

    public void Initialize(string licenseKey, Type licenserType) => this.Initialize(licenseKey, licenserType, true);

    public void Initialize(string licenseKey, Type licenserType, bool allowThrow)
    {
      if (string.IsNullOrEmpty(licenseKey))
      {
        licenseKey = this.GetLicenseKeyFromRegistry();
        if (string.IsNullOrEmpty(licenseKey))
        {
          if (!allowThrow)
            return;
          this.ThrowNoKeyInCodeAndRegistry();
        }
      }
      this.Analyse(ref licenseKey, allowThrow);
      if (string.IsNullOrEmpty(this.m_licenseKey) || this.m_trial || !this.m_isFromRegistry)
        return;
      this.ThrowNoKeyInCodeAndRegistry();
    }

    public bool IsFromRegistry
    {
      get => this.m_isFromRegistry;
      set => this.m_isFromRegistry = value;
    }

    public int DaysLeft => this.m_daysLeft;

    public string LicenseKey => this.m_licenseKey;

    public bool IsTrial => this.m_trial;

    public LicenseProduct Product => this.m_product;

    public byte VersionMajor => this.m_versionMajor;

    public byte VersionMinor => this.m_versionMinor;

    public byte NbLicenses => this.m_nbLicenses;

    public bool IsSiteLicense => this.m_siteLicense;

    protected virtual void ThrowNoKeyInCodeAndRegistry() => ThrowException.ThrowLicenseException(this.LicenseeType, (object) null, this.LicenseeType.FullName + ".LicenseKey must be set to a valid trial or registered license key in the code of your application before using this product. Please refer to the Licensing topic in the documentation for specific instructions on how to avoid this exception.");

    protected virtual void ThrowKeyInvalid() => ThrowException.ThrowLicenseException(this.LicenseeType, (object) null, "The license key used to license this Xceed product is invalid. " + this.LicenseeType.FullName + ".LicenseKey must be set to a valid trial or registered license key before using this product. Please refer to the Licensing topic in the documentation for specific instructions on how to avoid this exception.");

    protected virtual void ThrowKeyInvalidProduct() => ThrowException.ThrowLicenseException(this.LicenseeType, (object) null, "The license key used to license this Xceed product does not match the current product. Please make sure that you are correctly licensing the product as described in the documentation and then recompile in order to avoid this exception.");

    protected virtual void ThrowKeyInvalidProductVersion() => ThrowException.ThrowLicenseException(this.LicenseeType, (object) null, "The license key used to license this Xceed product is not in a valid version range. To unlock this assembly, please make sure that you are using a valid or up-to-date license key.");

    protected virtual void ThrowTrialKeyExpired() => ThrowException.ThrowLicenseException(this.LicenseeType, (object) null, "The trial license key used to license this Xceed product has expired. Please contact Xceed if you need additional time to evaluate the library, or if you wish to purchase a registered license.");

    protected abstract XceedLicense.ProductVersion[] AllowedVersions { get; }

    protected virtual XceedLicense.ProductVersion GetProductVersion(
      LicenseProduct product)
    {
      if (product == LicenseProduct.InvalidProduct)
        return this.AllowedVersions[0];
      foreach (XceedLicense.ProductVersion allowedVersion in this.AllowedVersions)
      {
        if (allowedVersion.Product == product)
          return allowedVersion;
      }
      return this.AllowedVersions[0];
    }

    protected abstract Type LicenseeType { get; }

    private string GetLicenseKeyFromRegistry() => string.Empty;

    private void ValidateLicenseKey(
      ref XceedLicenseManager lm,
      ref string licenseKey,
      bool performNagIfNecessary)
    {
      this.ValidateLicenseKey(ref lm, ref licenseKey, performNagIfNecessary, false);
    }

    private void ValidateLicenseKey(
      ref XceedLicenseManager lm,
      ref string licenseKey,
      bool performNagIfNecessary,
      bool allowThrow)
    {
      try
      {
        lm.AnalyzeLicense(licenseKey, allowThrow);
      }
      catch (XceedLicenseManagerException ex)
      {
        if (!allowThrow)
          return;
        this.ThrowKeyInvalid();
      }
      XceedLicense.ProductVersion[] allowedVersions = this.AllowedVersions;
      if (allowedVersions == null)
        return;
      bool flag1 = false;
      bool flag2 = false;
      XceedLicense.VersionNumber versionNumber = new XceedLicense.VersionNumber(lm.VerMajor, lm.VerMinor);
      foreach (XceedLicense.ProductVersion productVersion in allowedVersions)
      {
        if (productVersion.Product == lm.Product)
        {
          flag2 = true;
          if (versionNumber >= productVersion.MinimumVersion && versionNumber <= productVersion.MaximumVersion)
          {
            flag1 = true;
            break;
          }
        }
      }
      if (allowThrow && !flag2)
        this.ThrowKeyInvalidProduct();
      else if (allowThrow && !flag1)
        this.ThrowKeyInvalidProductVersion();
      if (lm.Originator < LicenseOrigin.TrialVersion || lm.Originator > LicenseOrigin.TrialRenew9)
        return;
      bool flag3 = new TimeSpan(lm.Date.Ticks - DateTime.Today.Ticks).Days <= 0;
      if (!(allowThrow & flag3))
        return;
      this.ThrowTrialKeyExpired();
    }

    internal struct VersionNumber
    {
      private byte Major;
      private byte Minor;

      public VersionNumber(byte[] version)
      {
        this.Major = version[0];
        this.Minor = version[1];
      }

      public VersionNumber(byte major, byte minor)
      {
        this.Major = major;
        this.Minor = minor;
      }

      public VersionNumber(string version)
      {
        string[] strArray = !string.IsNullOrEmpty(version) ? version.Split('.') : throw new ArgumentException("Version cannot be null or empty.");
        this.Major = strArray.Length == 2 ? Convert.ToByte(strArray[0]) : throw new ArgumentException("Version format is invalid.");
        this.Minor = Convert.ToByte(strArray[1]);
      }

      public static bool operator ==(XceedLicense.VersionNumber v1, XceedLicense.VersionNumber v2) => (int) v1.Minor == (int) v2.Minor && (int) v1.Major == (int) v2.Major;

      public static bool operator !=(XceedLicense.VersionNumber v1, XceedLicense.VersionNumber v2) => (int) v1.Minor != (int) v2.Minor || (int) v1.Major != (int) v2.Major;

      public static bool operator >(XceedLicense.VersionNumber v1, XceedLicense.VersionNumber v2) => (int) v1.Major > (int) v2.Major || (int) v1.Major == (int) v2.Major && (int) v1.Minor > (int) v2.Minor;

      public static bool operator >=(XceedLicense.VersionNumber v1, XceedLicense.VersionNumber v2) => v1 > v2 || v1 == v2;

      public static bool operator <=(XceedLicense.VersionNumber v1, XceedLicense.VersionNumber v2) => v1 < v2 || v1 == v2;

      public static bool operator <(XceedLicense.VersionNumber v1, XceedLicense.VersionNumber v2) => (int) v1.Major < (int) v2.Major || (int) v1.Major == (int) v2.Major && (int) v1.Minor < (int) v2.Minor;

      public override bool Equals(object obj) => obj is XceedLicense.VersionNumber versionNumber && this == versionNumber;

      public override int GetHashCode() => Convert.ToInt32((int) this.Major * 10 + (int) this.Minor);

      public override string ToString() => this.Major.ToString() + "." + this.Minor.ToString();
    }

    internal struct ProductVersion
    {
      public LicenseProduct Product;
      public XceedLicense.VersionNumber MinimumVersion;
      public XceedLicense.VersionNumber MaximumVersion;
      public XceedLicense.VersionNumber LatestVersion;
      public bool SearchInRegistry;

      public ProductVersion(
        LicenseProduct product,
        XceedLicense.VersionNumber latestVersion,
        XceedLicense.VersionNumber minimumVersion)
        : this(product, latestVersion, minimumVersion, new XceedLicense.VersionNumber((byte) 9, (byte) 9), true)
      {
      }

      public ProductVersion(
        LicenseProduct product,
        XceedLicense.VersionNumber latestVersion,
        XceedLicense.VersionNumber minimumVersion,
        bool searchInRegistry)
        : this(product, latestVersion, minimumVersion, new XceedLicense.VersionNumber((byte) 9, (byte) 9), searchInRegistry)
      {
      }

      public ProductVersion(
        LicenseProduct product,
        XceedLicense.VersionNumber latestVersion,
        XceedLicense.VersionNumber minimumVersion,
        XceedLicense.VersionNumber maximumVersion,
        bool searchInRegistry)
      {
        this.MinimumVersion = minimumVersion;
        this.MaximumVersion = maximumVersion;
        this.LatestVersion = latestVersion;
        this.Product = product;
        this.SearchInRegistry = searchInRegistry;
      }
    }
  }
}
