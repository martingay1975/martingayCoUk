﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Utils.Licensing.LicenseProduct
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.ComponentModel;

namespace Xceed.Utils.Licensing
{
  internal enum LicenseProduct
  {
    InvalidProduct = 0,
    FirstProduct = 1,
    [Description("Xceed Zip Compression Library")] XceedZip = 1,
    [Description("Xceed Zip Compression Library with SFX")] XceedZipSfx = 2,
    [Description("Xceed Backup Library")] XceedBackup = 3,
    [Description("Xceed Winsock Library")] XceedWinsock = 4,
    [Description("Xceed FTP Library")] XceedFtp = 5,
    [Description("Xceed Data Compression Library")] XceedCompress = 6,
    [Description("Xceed Binary Encoding Library")] XceedEncode = 7,
    [Description("Xceed Encryption Library")] XceedEncrypt = 8,
    [Description("Xceed FTP Library For BizTalk Server")] XceedFtpBiz = 9,
    [Description("Xceed Zip for .NET")] XceedZipNET = 10, // 0x0000000A
    [Description("Abale Zip")] AbaleZip = 11, // 0x0000000B
    [Description("Xceed Grid for WinForms")] XceedGridNET = 12, // 0x0000000C
    [Description("Xceed Streaming Compression for .NET")] XceedCompressNET = 13, // 0x0000000D
    [Description("Xceed Zip for .NET Compact Framework")] XceedZipNETCF = 14, // 0x0000000E
    [Obsolete("This product was merged into Xceed Zip for .NET CF."), Description("Xceed Streaming Compression for .NET Compact Framework")] XceedCompressNETCF = 15, // 0x0000000F
    [Description("Xceed SmartUI")] XceedSmartUI = 16, // 0x00000010
    [Description("Xceed SmartUI for WinForms")] XceedSmartUINET = 17, // 0x00000011
    [Description("Xceed FTP for .NET")] XceedFtpNET = 18, // 0x00000012
    [Description("Xceed FTP for .NET Compact Framework")] XceedFtpNETCF = 19, // 0x00000013
    [Description("Xceed Chart for WinForms")] XceedChartNET = 20, // 0x00000014
    [Description("Xceed Docking Windows for WinForms")] XceedDockingWindowsNET = 21, // 0x00000015
    [Description("Xceed Chart for ASP.NET")] XceedChartASPNET = 22, // 0x00000016
    [Description("Xceed Input Validator for WinForms")] XceedInputValidatorNET = 23, // 0x00000017
    [Description("Xceed DeployReady")] XceedDeployReady = 24, // 0x00000018
    [Description("Xceed Editors for WinForms")] XceedEditorsNET = 25, // 0x00000019
    [Description("Xceed ZipNoAES for .NET")] XceedZipNoAES = 26, // 0x0000001A
    [Description("Xceed Tar for .NET")] XceedTarNET = 27, // 0x0000001B
    [Description("Xceed DataGrid for WPF (Free Edition)")] XceedDataGridFreeWPFNET = 28, // 0x0000001C
    [Description("Xceed DataGrid Pro for WPF")] XceedDataGridProWPFNET = 29, // 0x0000001D
    [Description("Xceed Workflow Activities for .NET")] XceedWorkflowActivitiesNET = 30, // 0x0000001E
    [Description("Xceed Synchronization for .NET")] XceedSynchronizationNET = 31, // 0x0000001F
    [Description("Xceed Zip Compression Library (AMD64/EM64T port)")] XceedZipX64 = 32, // 0x00000020
    [Description("Xceed Zip Compression Library (Itanium port)")] XceedZipIA64 = 33, // 0x00000021
    [Description("Xceed Zip for .NET with Self-Extractor")] XceedZipNETSfx = 34, // 0x00000022
    [Description("Xceed Real-Time Zip for .NET")] XceedRealTimeZipNET = 35, // 0x00000023
    [Description("Xceed Real-Time Zip for .NET CF")] XceedRealTimeZipNETCF = 36, // 0x00000024
    [Description("Xceed Upload for Silverlight")] XceedUploadSilverlight = 37, // 0x00000025
    [Description("Xceed 3D Views for WPF")] Xceed3DViewsWPFNET = 38, // 0x00000026
    [Description("Xceed Real-Time Zip for Silverlight")] XceedRealTimeZipSilverlight = 39, // 0x00000027
    [Description("Xceed Pro Themes for WPF")] XceedProThemesForWPF = 40, // 0x00000028
    [Description("Xceed Office 2007 Themes for WPF")] XceedOffice2007ThemesWPF = 41, // 0x00000029
    [Description("Xceed Glass Theme for WPF")] XceedGlassThemeWPF = 42, // 0x0000002A
    [Description("Xceed Media Theme for WPF")] XceedMediaThemeWPF = 43, // 0x0000002B
    [Description("Xceed Live Explorer Theme for WPF")] XceedLiveExplorerThemeWPF = 44, // 0x0000002C
    [Description("Xceed Windows7 Theme for WPF")] XceedWindows7ThemeWPF = 45, // 0x0000002D
    [Description("Xceed DataGrid for Silverlight")] XceedDataGridSilverlight = 46, // 0x0000002E
    [Description("Xceed Ultimate ListBox for Silverlight")] XceedListBoxSilverlight = 47, // 0x0000002F
    [Description("Xceed Real-Time Zip for Windows Phone")] XceedRealTimeZipPhone = 48, // 0x00000030
    [Description("Xceed Upload for Windows Phone")] XceedUploadPhone = 49, // 0x00000031
    [Description("Xceed Ultimate ListBox for WPF")] XceedListBoxWPF = 50, // 0x00000032
    [Description("Xceed Blendables for WPF")] XceedBlendablesWPF = 51, // 0x00000033
    [Description("Xceed SFtp for .NET")] XceedSFtpNET = 52, // 0x00000034
    [Description("Xceed Toolkit Plus for WPF")] XceedToolkitWPF = 53, // 0x00000035
    [Description("Xceed Real-Time Zip for Xamarin")] XceedRealTimeZipXamarin = 54, // 0x00000036
    [Description("Xceed Zip for Xamarin")] XceedZipXamarin = 55, // 0x00000037
    [Description("Xceed Ftp for Xamarin")] XceedFtpXamarin = 56, // 0x00000038
    [Description("Xceed SFtp for Xamarin")] XceedSFtpXamarin = 57, // 0x00000039
    [Description("Xceed Words for .NET")] XceedWordsNET = 58, // 0x0000003A
    LastProduct = 59, // 0x0000003B
    [Description("Xceed PDF Creator for .NET")] XceedPDFCreatorNET = 59, // 0x0000003B
  }
}
