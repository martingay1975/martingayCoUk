﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Utils.Licensing.LicenseErrorCode
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

namespace Xceed.Utils.Licensing
{
  internal enum LicenseErrorCode : uint
  {
    InvalidProductCode = 2147746560, // 0x80040300
    InvalidOriginCode = 2147746561, // 0x80040301
    InvalidVersion = 2147746562, // 0x80040302
    BufferTooSmall = 2147746563, // 0x80040303
    UnsupportedKey = 2147746564, // 0x80040304
    InvalidKeyLength = 2147746565, // 0x80040305
    ChecksumFailed = 2147746566, // 0x80040306
    ProductMismatch = 2147746567, // 0x80040307
    VersionMismatch = 2147746568, // 0x80040308
    WriteRegistry = 2147746569, // 0x80040309
    ReadRegistry = 2147746570, // 0x8004030A
  }
}
