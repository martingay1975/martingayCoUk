﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Utils.Licensing.XceedLicenseManager
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

using System;
using System.Globalization;

namespace Xceed.Utils.Licensing
{
  internal class XceedLicenseManager
  {
    private LicenseProduct m_Product;
    private byte m_VerMajor;
    private byte m_VerMinor;
    private LicenseOrigin m_Originator;
    private ushort m_UniqueSeed;
    private byte m_NbLicenses;
    private string m_Key;
    private DateTime m_Date;
    private const int RawKeyStringLen = 19;
    private const string LicKeyVersion = "A";
    private const byte SiteLicense = 255;
    private const uint BitCount = 65;
    private const int BaseDateYear = 2001;
    private const int BaseDateMonth = 1;
    private const int BaseDateDay = 1;
    private const int NbLookupChar = 32;
    private const uint AdlerNMax = 5552;
    private const uint AdlerBase = 65521;
    private static readonly string[] ProductIds = new string[61]
    {
      "",
      "ZIP",
      "SFX",
      "BKP",
      "WSL",
      "FTP",
      "SCO",
      "BEN",
      "CRY",
      "FTB",
      "ZIN",
      "ABZ",
      "GRD",
      "SCN",
      "ZIC",
      "SCC",
      "SUI",
      "SUN",
      "FTN",
      "FTC",
      "CHT",
      "DWN",
      "CHW",
      "IVN",
      "RDY",
      "EDN",
      "ZIL",
      "TAN",
      "DGF",
      "DGP",
      "WAN",
      "SYN",
      "ZIX",
      "ZII",
      "SFN",
      "ZRT",
      "ZRC",
      "UPS",
      "TDV",
      "ZRS",
      "XPT",
      "OFT",
      "GLT",
      "MET",
      "LET",
      "WST",
      "DGS",
      "LBS",
      "ZRP",
      "UPP",
      "LBW",
      "BLD",
      "SFT",
      "WTK",
      "ZRX",
      "ZXA",
      "FXA",
      "SXA",
      "WDN",
      "PDF",
      null
    };
    private const string AlphaNumLookup = "ABJCKTDL4UEMW71FNX52YGP98Z63HRS0";
    private static byte[] NbDaysBits = new byte[15]
    {
      (byte) 2,
      (byte) 7,
      (byte) 12,
      (byte) 17,
      (byte) 22,
      (byte) 26,
      (byte) 31,
      (byte) 37,
      (byte) 42,
      (byte) 47,
      (byte) 51,
      (byte) 55,
      (byte) 59,
      (byte) 62,
      byte.MaxValue
    };
    private static byte[] UniqueSeedBits = new byte[17]
    {
      (byte) 64,
      (byte) 60,
      (byte) 56,
      (byte) 52,
      (byte) 48,
      (byte) 44,
      (byte) 39,
      (byte) 35,
      (byte) 32,
      (byte) 28,
      (byte) 23,
      (byte) 19,
      (byte) 14,
      (byte) 10,
      (byte) 5,
      (byte) 1,
      byte.MaxValue
    };
    private static byte[] ProductCodeBits = new byte[7]
    {
      (byte) 3,
      (byte) 16,
      (byte) 29,
      (byte) 41,
      (byte) 53,
      (byte) 61,
      byte.MaxValue
    };
    private static byte[] ProductVersionBits = new byte[8]
    {
      (byte) 4,
      (byte) 15,
      (byte) 25,
      (byte) 34,
      (byte) 43,
      (byte) 50,
      (byte) 58,
      byte.MaxValue
    };
    private static byte[] NbLicensesBits = new byte[9]
    {
      (byte) 6,
      (byte) 13,
      (byte) 20,
      (byte) 30,
      (byte) 38,
      (byte) 40,
      (byte) 46,
      (byte) 57,
      byte.MaxValue
    };
    private static byte[] OriginCodeBits = new byte[7]
    {
      (byte) 8,
      (byte) 11,
      (byte) 21,
      (byte) 24,
      (byte) 33,
      (byte) 49,
      byte.MaxValue
    };
    private static byte[] ChecksumBits = new byte[9]
    {
      (byte) 0,
      (byte) 9,
      (byte) 18,
      (byte) 27,
      (byte) 36,
      (byte) 45,
      (byte) 54,
      (byte) 63,
      byte.MaxValue
    };

    public XceedLicenseManager()
    {
      this.m_Product = LicenseProduct.InvalidProduct;
      this.m_Originator = LicenseOrigin.InvalidOrigin;
      this.Reset();
    }

    public LicenseProduct Product => this.m_Product;

    public string ProductCodeName => XceedLicenseManager.ProductIds[(int) this.m_Product];

    public byte VerMajor => this.m_VerMajor;

    public byte VerMinor => this.m_VerMinor;

    public LicenseOrigin Originator => this.m_Originator;

    public ushort UniqueSeed => this.m_UniqueSeed;

    public byte NbLicenses => this.m_NbLicenses;

    public bool IsSiteLicense => this.m_NbLicenses == byte.MaxValue;

    public DateTime Date => this.m_Date;

    public static string GetProductCodeName(LicenseProduct product) => XceedLicenseManager.ProductIds[(int) product];

    public void AnalyzeLicense(string key) => this.AnalyzeLicense(key, true);

    public void AnalyzeLicense(string key, bool allowThrow)
    {
      this.Reset();
      this.CopyKeyNoDashes(key);
      if (this.m_Key.Length != 19)
      {
        if (allowThrow)
          throw new XceedLicenseManagerException(LicenseErrorCode.InvalidKeyLength);
      }
      else if (!this.m_Key.EndsWith("A", StringComparison.Ordinal))
      {
        if (allowThrow)
          throw new XceedLicenseManagerException(LicenseErrorCode.UnsupportedKey);
      }
      else
      {
        this.DecodeEncodedPart();
        if (this.m_Product < LicenseProduct.XceedZip || this.m_Product > LicenseProduct.XceedPDFCreatorNET)
        {
          if (allowThrow)
            throw new XceedLicenseManagerException(LicenseErrorCode.InvalidProductCode);
        }
        else if (this.m_Originator < LicenseOrigin.TrialVersion || this.m_Originator > LicenseOrigin.CRM)
        {
          if (allowThrow)
            throw new XceedLicenseManagerException(LicenseErrorCode.InvalidOriginCode);
        }
        else if (this.m_VerMajor > (byte) 9 || this.m_VerMinor > (byte) 9)
        {
          if (allowThrow)
            throw new XceedLicenseManagerException(LicenseErrorCode.InvalidVersion);
        }
        else
          this.DecodeReadablePart();
      }
    }

    private void CopyKeyNoDashes(string key)
    {
      this.m_Key = "";
      if (key == null)
        return;
      for (int index = 0; index < key.Length; ++index)
      {
        if (key[index] != '-')
          this.m_Key += key[index].ToString();
      }
    }

    private void DecodeEncodedPart()
    {
      uint bitsLen = (uint) (8 + 1);
      byte[] bits = new byte[(int) bitsLen];
      this.DecodeAlphaNumString(bits, bitsLen);
      int number1 = (int) XceedLicenseManager.MapBitsToNumber(bits, bitsLen, XceedLicenseManager.ChecksumBits);
      XceedLicenseManager.MapNumberToBits(bits, bitsLen, 0U, XceedLicenseManager.ChecksumBits);
      int checksum = (int) this.CalculateChecksum(bits, bitsLen);
      if (number1 != checksum)
        throw new XceedLicenseManagerException(LicenseErrorCode.ChecksumFailed);
      this.m_Date = new DateTime(2001, 1, 1).AddDays((double) XceedLicenseManager.MapBitsToNumber(bits, bitsLen, XceedLicenseManager.NbDaysBits));
      this.m_UniqueSeed = (ushort) XceedLicenseManager.MapBitsToNumber(bits, bitsLen, XceedLicenseManager.UniqueSeedBits);
      this.m_Product = (LicenseProduct) XceedLicenseManager.MapBitsToNumber(bits, bitsLen, XceedLicenseManager.ProductCodeBits);
      uint number2 = XceedLicenseManager.MapBitsToNumber(bits, bitsLen, XceedLicenseManager.ProductVersionBits);
      this.m_VerMajor = (byte) (number2 / 10U);
      this.m_VerMinor = (byte) (number2 % 10U);
      this.m_NbLicenses = (byte) XceedLicenseManager.MapBitsToNumber(bits, bitsLen, XceedLicenseManager.NbLicensesBits);
      this.m_Originator = (LicenseOrigin) XceedLicenseManager.MapBitsToNumber(bits, bitsLen, XceedLicenseManager.OriginCodeBits);
    }

    private void DecodeReadablePart()
    {
      if (!this.m_Key.StartsWith(XceedLicenseManager.ProductIds[(int) this.m_Product], StringComparison.Ordinal))
        throw new XceedLicenseManagerException(LicenseErrorCode.ProductMismatch);
      if ((int) Convert.ToByte(this.m_Key.Substring(3, 1), (IFormatProvider) CultureInfo.InvariantCulture) != (int) this.m_VerMajor || (int) Convert.ToByte(this.m_Key.Substring(4, 1), (IFormatProvider) CultureInfo.InvariantCulture) != (int) this.m_VerMinor)
        throw new XceedLicenseManagerException(LicenseErrorCode.VersionMismatch);
    }

    private void DecodeAlphaNumString(byte[] bits, uint bitsLen)
    {
      ushort num1 = 11;
      uint num2 = 0;
      uint num3 = 0;
      uint num4 = 5;
      for (; num2 < bitsLen && num3 < 65U; num3 += 5U)
      {
        ushort num5 = (ushort) ((uint) XceedLicenseManager.GetAlphaNumValue(this.m_Key[(int) num4++]) << (int) num1);
        bits[(int) num2] |= (byte) (((int) num5 & 65280) >> 8);
        bits[(int) num2 + 1] |= (byte) ((uint) num5 & (uint) byte.MaxValue);
        if (num1 < (ushort) 8)
        {
          num1 += (ushort) 3;
          ++num2;
        }
        else
          num1 -= (ushort) 5;
      }
    }

    private static uint MapBitsToNumber(byte[] bits, uint bitsLen, byte[] bitMapping)
    {
      if (bits == null || bitsLen == 0U)
        throw new XceedLicenseManagerException();
      if (bitMapping == null)
        throw new XceedLicenseManagerException();
      uint num1 = 0;
      for (uint index = 0; bitMapping[(int) index] != byte.MaxValue; ++index)
      {
        byte num2 = bitMapping[(int) index];
        byte num3 = (byte) (1 << 7 - (int) num2 % 8);
        if (((int) bits[(int) num2 / 8] & (int) num3) != 0)
          num1 |= 1U << (int) index;
      }
      return num1;
    }

    private static void MapNumberToBits(byte[] bits, uint bitsLen, uint number, byte[] bitMapping)
    {
      if (bits == null || bitsLen == 0U)
        throw new XceedLicenseManagerException();
      if (bitMapping == null)
        throw new XceedLicenseManagerException();
      byte num1 = 0;
      int index1;
      for (index1 = 0; bitMapping[index1] != byte.MaxValue; ++index1)
      {
        if ((int) bitMapping[index1] > (int) num1)
          num1 = bitMapping[index1];
      }
      if (number >= (uint) (1 << index1))
        throw new XceedLicenseManagerException();
      if (bitsLen * 8U <= (uint) num1)
        throw new XceedLicenseManagerException();
      for (int index2 = 0; index2 < index1; ++index2)
      {
        int num2 = ((ulong) number & (ulong) (1 << index2)) > 0UL ? 1 : 0;
        byte num3 = bitMapping[index2];
        byte num4 = (byte) (1 << 7 - (int) num3 % 8);
        if (num2 != 0)
          bits[(int) num3 / 8] |= num4;
        else
          bits[(int) num3 / 8] &= ~num4;
      }
    }

    private static ushort GetAlphaNumValue(char alphaNum)
    {
      for (ushort index = 0; index < (ushort) 32; ++index)
      {
        if ((int) "ABJCKTDL4UEMW71FNX52YGP98Z63HRS0"[(int) index] == (int) alphaNum)
          return index;
      }
      return ushort.MaxValue;
    }

    private void Reset()
    {
      this.m_Key = "";
      this.m_Product = LicenseProduct.InvalidProduct;
      this.m_VerMajor = (byte) 0;
      this.m_VerMinor = (byte) 0;
      this.m_Originator = LicenseOrigin.InvalidOrigin;
      this.m_NbLicenses = (byte) 0;
      this.m_UniqueSeed = (ushort) 0;
      this.m_Date = DateTime.Now;
    }

    private byte CalculateChecksum(byte[] bits, uint bitsLen)
    {
      uint num1 = XceedLicenseManager.Adler32(XceedLicenseManager.Adler32(0U, (Array) this.m_Key.ToCharArray(), 5U), (Array) bits, bitsLen);
      ushort num2 = (ushort) ((num1 & 4294901760U) >> 16 ^ num1 & (uint) ushort.MaxValue);
      return (byte) (((int) num2 & 65280) >> 8 ^ (int) num2 & (int) byte.MaxValue);
    }

    private static uint Adler32(uint adler, Array buffer, uint bufLen)
    {
      if (buffer == null)
        return 1;
      uint num1 = adler & (uint) ushort.MaxValue;
      uint num2 = adler >> 16 & (uint) ushort.MaxValue;
      int index = 0;
      while (bufLen > 0U)
      {
        uint num3 = bufLen < 5552U ? bufLen : 5552U;
        bufLen -= num3;
        for (; num3 >= 16U; num3 -= 16U)
        {
          int num4 = 0;
          while (num4 < 16)
          {
            num1 += Convert.ToUInt32(buffer.GetValue(index), (IFormatProvider) CultureInfo.InvariantCulture);
            num2 += num1;
            ++num4;
            ++index;
          }
        }
        if (num3 != 0U)
        {
          do
          {
            num1 += Convert.ToUInt32(buffer.GetValue(index), (IFormatProvider) CultureInfo.InvariantCulture);
            ++index;
            num2 += num1;
          }
          while (--num3 != 0U);
        }
        num1 %= 65521U;
        num2 %= 65521U;
      }
      return num2 << 16 | num1;
    }
  }
}
