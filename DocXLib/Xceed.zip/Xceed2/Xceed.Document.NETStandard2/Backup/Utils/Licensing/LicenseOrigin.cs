﻿// Decompiled with JetBrains decompiler
// Type: Xceed.Utils.Licensing.LicenseOrigin
// Assembly: Xceed.Document.NETStandard, Version=1.7.20371.21580, Culture=neutral, PublicKeyToken=ba83ff368b7563c6
// MVID: DA30F741-A666-4EFA-B79F-CC64891B04D2
// Assembly location: C:\Program Files (x86)\Xceed\Xceed Words for .NET v1.7\Bin\NETStandard\Xceed.Document.NETStandard.dll

namespace Xceed.Utils.Licensing
{
  internal enum LicenseOrigin
  {
    FirstOrigin = 0,
    FirstTrialValue = 0,
    TrialVersion = 0,
    TrialRenew1 = 1,
    TrialRenew2 = 2,
    TrialRenew3 = 3,
    TrialRenew4 = 4,
    TrialRenew5 = 5,
    TrialRenew6 = 6,
    TrialRenew7 = 7,
    TrialRenew8 = 8,
    LastTrialValue = 9,
    TrialRenew9 = 9,
    CommanderReseller = 10, // 0x0000000A
    CommanderDirect = 11, // 0x0000000B
    WebSite = 12, // 0x0000000C
    LockSmith = 13, // 0x0000000D
    Columbo = 14, // 0x0000000E
    WebSite41 = 15, // 0x0000000F
    CRM = 16, // 0x00000010
    LastOrigin = 16, // 0x00000010
    InvalidOrigin = 63, // 0x0000003F
  }
}
